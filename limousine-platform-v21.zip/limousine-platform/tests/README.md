# tests/

Pruebas de extremo a extremo del flujo completo (reserva, pago, confirmación).
Los tests unitarios y de integración viven en `backend/tests/`.
