import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { getTranslations } from "next-intl/server";
import { currentProxyHeaders } from "@/lib/client-ip";
import { API_PREFIX, config } from "@/lib/config";
import { getAccessToken } from "@/lib/session";

/**
 * Entrega el comprobante en PDF que genera la API (en el idioma de la persona).
 * Con ?download=1 se descarga; sin él, se abre en el navegador para imprimirlo.
 */
export async function proxyReceipt(request: NextRequest, apiPath: string): Promise<NextResponse> {
  const token = await getAccessToken();
  if (!token) return NextResponse.redirect(new URL(`/login?next=${encodeURIComponent(request.nextUrl.pathname)}`, request.url));
  const res = await fetch(`${config.apiInternalUrl}${API_PREFIX}${apiPath}`, {
    headers: { ...(await currentProxyHeaders()), Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  if (!res.ok) {
    const t = await getTranslations("receipt");
    return new NextResponse(t("unavailable"), { status: res.status === 404 ? 404 : 502 });
  }
  const disposition = res.headers.get("content-disposition") ?? 'inline; filename="comprobante.pdf"';
  const download = request.nextUrl.searchParams.get("download") === "1";
  return new NextResponse(res.body, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": download ? disposition.replace(/^inline/, "attachment") : disposition,
      "Cache-Control": "private, no-store",
    },
  });
}
