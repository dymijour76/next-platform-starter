import { API_PREFIX, config } from "./config";

export type CheckStatus = "ok" | "error";

export interface ReadyResponse {
  status: "ok" | "degraded";
  checks: Record<string, CheckStatus>;
}

export type ApiHealth =
  | { reachable: true; data: ReadyResponse }
  | { reachable: false; error: "status" | "unreachable"; status?: number };

/** Consulta la disponibilidad de la API desde el servidor (sin caché). */
export async function getApiHealth(timeoutMs = 3000): Promise<ApiHealth> {
  try {
    const res = await fetch(`${config.apiInternalUrl}${API_PREFIX}/health/ready`, {
      cache: "no-store",
      signal: AbortSignal.timeout(timeoutMs),
    });
    // 503 también trae un cuerpo válido con el detalle de cada dependencia.
    if (res.status !== 200 && res.status !== 503) {
      return { reachable: false, error: "status", status: res.status };
    }
    return { reachable: true, data: (await res.json()) as ReadyResponse };
  } catch {
    return { reachable: false, error: "unreachable" };
  }
}
