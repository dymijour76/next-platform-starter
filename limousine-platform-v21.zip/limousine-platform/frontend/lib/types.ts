/** Tipos que reflejan las respuestas de la API (ver los schemas.py de cada módulo del backend). */

export type UserStatus = "ACTIVE" | "INACTIVE" | "SUSPENDED";

export interface RoleBrief {
  code: string;
  name: string;
}

export interface Profile {
  address: string | null;
  city: string | null;
  region: string | null;
  company: string | null;
  billing_tax_id: string | null;
  billing_name: string | null;
  billing_activity: string | null;
  billing_address: string | null;
  preferences: Record<string, unknown>;
  marketing_consent: boolean;
}

export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone: string | null;
  status: UserStatus;
  email_verified: boolean;
  mfa_enabled: boolean;
  locale: "es" | "en" | "fr" | "ht" | "zh" | null;
  roles: RoleBrief[];
  last_login_at: string | null;
  created_at: string;
}

export interface Me extends User {
  permissions: string[];
  profile: Profile | null;
  mfa_setup_required: boolean;
  mfa_backup_codes_left: number;
}

export interface TokenPair {
  access_token: string;
  token_type: "bearer";
  expires_in: number;
  refresh_token: string;
  refresh_expires_in: number;
}

export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}

export interface Permission {
  code: string;
  module: string;
  description: string;
}

export interface Role {
  id: string;
  code: string;
  name: string;
  description: string | null;
  is_system: boolean;
  permissions: string[];
  user_count: number;
  display_name: string;
  display_description: string | null;
}

export interface ApiError {
  code: string;
  message: string;
  fields?: Record<string, string>;
}

export interface Service {
  rating: { average: number | null; count: number } | null;
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  description: string | null;
  passenger_capacity: number;
  luggage_capacity: number | null;
  features: string[];
  base_fare: string;
  hourly_rate: string;
  min_hours: string;
  max_hours: string | null;
  minimum_fare: string;
  currency: string;
  price_from: string;
  gallery: ImageInfo[];
}

export interface ServiceAdmin extends Service {
  vehicle_count: number;
  translations: import("@/lib/translations").Translations;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface QuoteLine {
  code: string;
  label: string;
  amount: string;
}

export interface Quote {
  service: { id: string; name: string };
  currency: string;
  pickup_local: string;
  duration_minutes: number;
  billed_hours: string;
  lines: QuoteLine[];
  total: string;
  net: string;
  tax: string;
  tax_rate: string;
  tax_name: string;
  prices_include_tax: boolean;
}

export interface PricingRule {
  translations: import("@/lib/translations").Translations;
  id: string;
  name: string;
  description: string | null;
  kind: "SURCHARGE" | "DISCOUNT";
  adjustment_type: "PERCENT" | "FIXED";
  value: string;
  service_ids: string[] | null;
  days_of_week: number[] | null;
  time_from: string | null;
  time_until: string | null;
  valid_from: string | null;
  valid_until: string | null;
  min_hours: string | null;
  priority: number;
  is_active: boolean;
}

export interface PricingSettings {
  currency: "CLP" | "USD" | "EUR";
  timezone: string;
  tax_rate: string;
  tax_name: string;
  prices_include_tax: boolean;
  billing_increment_minutes: 15 | 30 | 60;
  min_notice_minutes: number;
  max_advance_days: number;
}

export interface PublicPricingConfig {
  currency: string;
  timezone: string;
  tax_name: string;
  prices_include_tax: boolean;
  billing_increment_minutes: number;
  min_notice_minutes: number;
  max_advance_days: number;
}

export type ReservationStatus =
  | "PENDING_PAYMENT"
  | "CONFIRMED"
  | "EN_ROUTE"
  | "ARRIVED"
  | "IN_PROGRESS"
  | "COMPLETED"
  | "CANCELLED"
  | "EXPIRED"
  | "NO_SHOW";

export interface ReservationSummary {
  driver_code?: string | null;
  id: string;
  code: string;
  status: ReservationStatus;
  service: { id: string; name: string; slug: string };
  pickup_at: string;
  pickup_local: string;
  duration_minutes: number;
  passenger_count: number;
  contact_name: string;
  currency: string;
  total_amount: string;
  hold_expires_at: string | null;
  driver_name: string | null;
  vehicle_label: string | null;
}

export interface Reservation extends ReservationSummary {
  end_at: string;
  pickup_address: string;
  dropoff_address: string | null;
  notes: string | null;
  contact_email: string;
  contact_phone: string;
  pricing: {
    lines: { code?: string | null; label: string; amount: string }[];
    net: string;
    tax: string;
    tax_name: string;
    prices_include_tax: boolean;
    billed_hours: string;
  };
  cancellation_policy: string;
  confirmed_at: string | null;
  cancelled_at: string | null;
  cancellation_reason: string | null;
  refund_amount: string | null;
  created_at: string;
  can_cancel: boolean;
  refund_if_cancelled_now: string | null;
  can_pay: boolean;
  payments: PaymentInfo[];
  boarded_at: string | null;
  /** Sólo para el dueño de la reserva mientras el viaje está activo. */
  qr_token: string | null;
}

export interface RefundInfo {
  id: string;
  amount: string;
  status: "PENDING" | "SUCCEEDED" | "FAILED";
  reason: string | null;
  error_message: string | null;
  created_at: string;
}

export interface PaymentInfo {
  id: string;
  provider: string;
  status: string;
  amount: string;
  refunded_amount: string;
  card_last4: string | null;
  authorization_code: string | null;
  payment_type: string | null;
  installments: number | null;
  authorized_at: string | null;
  created_at: string;
  refunds: RefundInfo[];
}

export interface PaymentRedirect {
  url: string;
  fields: Record<string, string>;
}

export interface AdminPayment {
  id: string;
  reservation_id: string | null;
  reservation_code: string | null;
  customer_name: string;
  provider: string;
  status: string;
  amount: string;
  refunded_amount: string;
  currency: string;
  buy_order: string;
  card_last4: string | null;
  authorization_code: string | null;
  response_code: string | null;
  authorized_at: string | null;
  created_at: string;
  refunds: RefundInfo[];
  is_topup: boolean;
}

export interface PaymentPage extends Page<AdminPayment> {
  totals: { collected: string; refunded: string; net: string; count: number };
}

export interface ReservationAdmin extends Reservation {
  customer: { id: string; email: string; name: string } | null;
  vehicle: { id: string; label: string } | null;
  driver: { id: string; label: string; phone: string | null } | null;
  events: {
    from_status: ReservationStatus | null;
    to_status: ReservationStatus;
    actor_label: string;
    note: string | null;
    created_at: string;
  }[];
}

export interface BookingPreview {
  quote: Quote;
  available: boolean;
  passenger_capacity: number;
}

export interface BookingPolicy {
  text: string;
  hold_minutes: number;
  free_cancellation_hours: number;
  late_cancellation_refund_percent: number;
}

export interface BookingSettings {
  hold_minutes: number;
  turnaround_minutes: number;
  free_cancellation_hours: number;
  late_cancellation_refund_percent: number;
}

export type VehicleStatus = "ACTIVE" | "INACTIVE" | "RETIRED";

export interface Vehicle {
  id: string;
  plate: string;
  service_id: string;
  service_name: string;
  brand: string;
  model: string;
  year: number;
  color: string;
  passenger_capacity: number;
  status: VehicleStatus;
  notes: string | null;
  label: string;
  blocks: { id: string; starts_at: string; ends_at: string; reason: string }[];
  created_at: string;
}

export interface Driver {
  rating_average: number | null;
  rating_count: number;
  id: string;
  user_id: string;
  name: string;
  email: string;
  phone: string | null;
  license_number: string;
  license_class: string;
  license_expires_on: string;
  license_expired: boolean;
  status: "ACTIVE" | "INACTIVE";
  notes: string | null;
  upcoming_trips: number;
}

export interface AssignmentOption {
  id: string;
  label: string;
  available: boolean;
  reason: string | null;
}

export interface AssignmentOptions {
  vehicles: AssignmentOption[];
  drivers: AssignmentOption[];
}

export type TripAction = "EN_ROUTE" | "ARRIVED" | "BOARD" | "NO_SHOW" | "COMPLETED";

export interface Trip {
  driver_code: string | null;
  unread_messages: number;
  id: string;
  code: string;
  status: ReservationStatus;
  service_name: string;
  pickup_at: string;
  pickup_local: string;
  end_at: string;
  duration_minutes: number;
  pickup_address: string;
  dropoff_address: string | null;
  passenger_count: number;
  contact_name: string;
  contact_phone: string;
  notes: string | null;
  vehicle: string | null;
  boarded_at: string | null;
  actions: TripAction[];
}

export interface ImageInfo {
  id: string;
  alt: string;
  width: number;
  height: number;
  src: string;
  srcset: string;
}

export interface MediaAsset extends ImageInfo {
  original_filename: string;
  bytes: number;
  created_at: string;
  usage: number;
}

export interface Slide {
  id: string;
  title: string;
  subtitle: string | null;
  cta_label: string | null;
  cta_url: string | null;
  image: ImageInfo;
}

export interface SlideAdmin extends Slide {
  image_id: string;
  translations: import("@/lib/translations").Translations;
  sort_order: number;
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
  live: boolean;
}

export interface DashboardAlert {
  kind: "unassigned" | "failed_refunds" | "no_vehicles" | "license";
  count: number;
  text: string;
  href: string;
}

export interface Dashboard {
  currency: string;
  today: string;
  alerts: DashboardAlert[];
  operations: {
    trips_today: number;
    in_progress: number;
    next_7_days: number;
    pending_payment: number;
    unassigned_upcoming: number;
    today: { id: string; code: string; status: ReservationStatus; pickup_local: string; service: string;
      contact_name: string; driver: string | null; vehicle: string | null }[];
  } | null;
  finance: {
    month_net: string; month_collected: string; month_refunded: string; month_payments: number;
    average_ticket: string; previous_net: string; change: number | null; failed_refunds: number;
  } | null;
  fleet: { active_vehicles: number; in_maintenance: number } | null;
  drivers: { active: number } | null;
}

export interface ReservationsReport {
  series: { period: string; label: string; total: number; confirmed: number; completed: number;
    cancelled: number; no_show: number; expired: number; pending: number }[];
  by_service: { service: string; reservations: number; completed: number; cancelled: number; amount: string }[];
  total: number;
  completed: number;
  cancelled: number;
  cancellation_rate: number;
  currency: string;
}

export interface RevenueReport {
  series: { period: string; label: string; collected: string; refunded: string; net: string; payments: number }[];
  by_service: { service: string; collected: string; refunded: string; net: string }[];
  collected: string;
  refunded: string;
  net: string;
  payments: number;
  average_ticket: string;
  currency: string;
}

export interface WalletEntry {
  id: string;
  amount: string;
  balance_after: string;
  kind: "CREDIT" | "PAYMENT" | "REFUND" | "TOPUP" | "TOPUP_REFUND";
  description: string;
  reason: string | null;
  reservation_code: string | null;
  created_at: string;
}

export interface WalletInfo {
  number: string;
  holder: string;
  balance: string;
  currency: string;
  topup_enabled: boolean;
  topup_min: number;
  topup_max: number;
  entries: WalletEntry[];
}

export interface ChatMessage {
  id: string;
  mine: boolean;
  sender_role: "customer" | "driver";
  body: string | null;
  created_at: string;
  read: boolean;
}

export interface ChatInfo {
  open: boolean;
  closes_at: string | null;
  counterpart: string | null;
  messages: ChatMessage[];
}
