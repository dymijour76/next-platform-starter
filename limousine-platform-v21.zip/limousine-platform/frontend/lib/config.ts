/**
 * Configuración del frontend.
 *
 * - API_INTERNAL_URL: dirección de la API vista desde el servidor de Next.js
 *   (dentro de Docker es http://backend:8000).
 * - API_INTERNAL_URL: dirección de la API vista desde el servidor del sitio. El navegador
 *   nunca llama a la API directamente, así que en producción la API no se publica.
 *
 * Estos valores iniciales se reemplazarán en fases posteriores por los datos
 * de Admin > Configuración (nombre de empresa, logo, etc.).
 */
export const config = {
  companyName: process.env.NEXT_PUBLIC_COMPANY_NAME ?? "Limousine Platform",
  apiInternalUrl:
    process.env.API_INTERNAL_URL ?? process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000",
  // Cuánto espera el sitio a la API antes de mostrar "No se pudo conectar". En un computador lento
  // (Docker en Windows) conviene subirlo: API_TIMEOUT_MS=30000.
  apiTimeoutMs: Number(process.env.API_TIMEOUT_MS) || 10_000,
} as const;

export const API_PREFIX = "/api/v1";
