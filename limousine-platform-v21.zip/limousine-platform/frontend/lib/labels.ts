import type { ReservationStatus } from "./types";

/**
 * Color de cada estado de reserva. Los textos de los estados están en los archivos de
 * idioma (labels.reservation.*, labels.payment.*, labels.user.*…), no aquí.
 */
export const RESERVATION_TONE: Record<ReservationStatus, string> = {
  PENDING_PAYMENT: "text-ink bg-champagne/25",
  CONFIRMED: "text-ok bg-ok/10",
  EN_ROUTE: "text-ink bg-champagne/25",
  ARRIVED: "text-ink bg-champagne/40",
  IN_PROGRESS: "text-pearl bg-ink",
  COMPLETED: "text-slate bg-ink/5",
  CANCELLED: "text-alert bg-alert/10",
  EXPIRED: "text-slate bg-ink/5",
  NO_SHOW: "text-alert bg-alert/10",
};
