import "server-only";
import { getLocale, getTranslations } from "next-intl/server";
import type { Locale } from "@/i18n/config";
import { getRefRate } from "@/lib/currency-server";
import { makeFormat, type Format } from "@/lib/format";

/** Formateador para componentes de servidor, en el idioma de la petición. */
export async function getFormat(): Promise<Format> {
  const [locale, units, refRate] = await Promise.all([getLocale(), getTranslations("units"), getRefRate()]);
  return makeFormat(locale as Locale, (key, values) => units(key, values), refRate);
}
