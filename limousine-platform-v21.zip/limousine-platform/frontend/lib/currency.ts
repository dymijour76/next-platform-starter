/** Monedas para mostrar precios de referencia. Se cobra siempre en pesos chilenos (CLP). */
export const DISPLAY_CURRENCIES = ["CLP", "USD", "EUR", "BRL"] as const;
export type DisplayCurrency = (typeof DISPLAY_CURRENCIES)[number];
export const CURRENCY_COOKIE = "lp_currency";

/** Tasa de la moneda elegida: pesos por unidad. null = sólo pesos (sin referencia). */
export type RefRate = { code: Exclude<DisplayCurrency, "CLP">; rate: number } | null;

export function isDisplayCurrency(value: unknown): value is DisplayCurrency {
  return typeof value === "string" && (DISPLAY_CURRENCIES as readonly string[]).includes(value);
}
