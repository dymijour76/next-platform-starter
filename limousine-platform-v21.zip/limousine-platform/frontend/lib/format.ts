/**
 * Formato de montos, horas, duraciones y fechas según el idioma de la página.
 * Se obtiene con getFormat() en el servidor o useFormat() en el cliente.
 */
import type { Locale } from "@/i18n/config";
import type { RefRate } from "@/lib/currency";
import { formatDateTime, intlLocale, toCreole } from "@/lib/intl";

type Units = (key: "hours" | "hoursMinutes" | "passengers" | "never" | "approx", values?: Record<string, number | string>) => string;

export function makeFormat(locale: Locale, units: Units, refRate: RefRate = null) {
  const intl = intlLocale(locale);
  return {
    locale,
    /**
     * Valor aproximado en la moneda que eligió el visitante ("aprox. USD 315"), para mostrar
     * junto al precio en pesos. Vacío si no eligió otra moneda. Se cobra siempre en pesos.
     */
    ref(amount: string | number): string {
      if (!refRate || !refRate.rate) return "";
      const value = Number(amount) / refRate.rate;
      const text = new Intl.NumberFormat(intl, {
        style: "currency", currency: refRate.code, currencyDisplay: "code", maximumFractionDigits: 0,
      }).format(value);
      return units("approx", { amount: text });
    },
    money(amount: string | number, currency = "CLP"): string {
      const value = typeof amount === "string" ? Number(amount) : amount;
      const text = new Intl.NumberFormat(intl, {
        style: "currency",
        currency,
        maximumFractionDigits: currency === "CLP" ? 0 : 2,
      }).format(Math.abs(value));
      // "−$24.300" en vez de "$-24.300".
      return value < 0 ? `−${text}` : text;
    },
    number(value: number, options: Intl.NumberFormatOptions = {}): string {
      return new Intl.NumberFormat(intl, options).format(value);
    },
    /**
     * Porcentaje a partir de una proporción (0.2 → "20 %"). En español el signo va separado
     * del número, como en el desglose que arma el servidor; los demás idiomas, a su manera.
     */
    percent(ratio: number, maximumFractionDigits = 1): string {
      if (locale === "es") return `${new Intl.NumberFormat(intl, { maximumFractionDigits }).format(ratio * 100)} %`;
      return new Intl.NumberFormat(intl, { style: "percent", maximumFractionDigits }).format(ratio);
    },
    hours(hours: string | number): string {
      return units("hours", { count: Number(hours) });
    },
    duration(minutes: number): string {
      const h = Math.floor(minutes / 60);
      const m = minutes % 60;
      return m ? units("hoursMinutes", { hours: h, minutes: m }) : units("hours", { count: h });
    },
    passengers(count: number): string {
      return units("passengers", { count });
    },
    /** Fecha y hora de un instante, en hora de Chile. */
    date(iso: string | null): string {
      if (!iso) return units("never");
      return formatDateTime(iso, locale, { dateStyle: "medium", timeStyle: "short" });
    },
    dateTime(value: string | Date, options: Intl.DateTimeFormatOptions): string {
      return formatDateTime(value, locale, options);
    },
    /** Hora "de reloj" de un ISO con desfase ("2026-10-14T22:30:00-03:00"), tal como está escrita. */
    wall(iso: string, options: Intl.DateTimeFormatOptions): string {
      const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(iso);
      if (!m) return iso;
      const [, y, mo, da, h, mi] = m.map(Number) as [number, number, number, number, number, number];
      const text = new Intl.DateTimeFormat(intl, { ...options, timeZone: "UTC" }).format(new Date(Date.UTC(y, mo - 1, da, h, mi)));
      return locale === "ht" ? toCreole(text) : text;
    },
  };
}

export type Format = ReturnType<typeof makeFormat>;
