/**
 * Formato de fechas y montos según el idioma.
 *
 * Los navegadores no traen datos de creole haitiano (probado: "ht" cae en inglés).
 * Para el creole se formatea con las reglas del francés, que comparte orden y
 * convenciones, y se reemplazan los nombres de días y meses por los del creole.
 */
import type { Locale } from "@/i18n/config";

const INTL: Record<Locale, string> = { es: "es-CL", en: "en-US", fr: "fr-FR", ht: "fr-FR", zh: "zh-CN" };

const CREOLE: [RegExp, string][] = [
  ["lundi", "lendi"], ["mardi", "madi"], ["mercredi", "mèkredi"], ["jeudi", "jedi"],
  ["vendredi", "vandredi"], ["samedi", "samdi"], ["dimanche", "dimanch"],
  ["janvier", "janvye"], ["février", "fevriye"], ["mars", "mas"], ["avril", "avril"], ["mai", "me"],
  ["juin", "jen"], ["juillet", "jiyè"], ["août", "out"], ["septembre", "septanm"],
  ["octobre", "oktòb"], ["novembre", "novanm"], ["décembre", "desanm"],
]
  .map(([fr, ht]) => [new RegExp(`\\b${fr}\\b`, "giu"), ht] as [RegExp, string])
  .concat(
    // Abreviaturas (fechas cortas: "30 sept. 2026"). Van después de los nombres completos.
    [
      ["janv.", "jan"], ["févr.", "fev"], ["avr.", "avr"], ["juil.", "jiy"], ["sept.", "sep"],
      ["oct.", "okt"], ["nov.", "nov"], ["déc.", "des"],
      ["lun.", "len"], ["mar.", "mad"], ["mer.", "mèk"], ["jeu.", "jed"], ["ven.", "van"], ["sam.", "sam"], ["dim.", "dim"],
    ].map(([fr, ht]) => [new RegExp(`(?<![\\p{L}])${fr!.replace(".", "\\.")}`, "gu"), ht] as [RegExp, string]),
  );

export function intlLocale(locale: Locale): string {
  return INTL[locale] ?? "es-CL";
}

/** Convierte un texto formateado en francés a creole (sólo cambia nombres de días y meses). */
export function toCreole(text: string): string {
  const named = CREOLE.reduce(
    (acc, [re, ht]) => acc.replace(re, (m) => (m[0] === m[0]!.toUpperCase() ? ht[0]!.toUpperCase() + ht.slice(1) : ht)),
    text,
  );
  // "à 12:00" en francés es "a 12:00" en creole.
  return named.replace(/ à /g, " a ");
}

export function formatDateTime(value: Date | string | number, locale: Locale, options: Intl.DateTimeFormatOptions, timeZone = "America/Santiago"): string {
  const text = new Intl.DateTimeFormat(intlLocale(locale), { timeZone, ...options }).format(new Date(value));
  return locale === "ht" ? toCreole(text) : text;
}

export function formatNumber(value: number, locale: Locale, options: Intl.NumberFormatOptions = {}): string {
  return new Intl.NumberFormat(intlLocale(locale), options).format(value);
}
