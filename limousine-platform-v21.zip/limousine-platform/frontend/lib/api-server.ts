import "server-only";
import { currentProxyHeaders } from "./client-ip";
import { API_PREFIX, config } from "./config";
import { getAccessToken } from "./session";
import type { ApiError } from "./types";

export type ApiResult<T> =
  | { ok: true; status: number; data: T }
  | { ok: false; status: number; error: ApiError };

/** Mensaje en el idioma de la petición (en español si se llama fuera de una petición). */
async function message(key: "network" | "unexpected" | "upload", fallback: string): Promise<string> {
  try {
    const { getTranslations } = await import("next-intl/server");
    return (await getTranslations("errors"))(key);
  } catch {
    return fallback;
  }
}

async function networkError(): Promise<ApiError> {
  return { code: "NETWORK_ERROR", message: await message("network", "No se pudo conectar con el servidor.") };
}

interface RequestOptions {
  method?: "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
  body?: unknown;
  /** Adjunta el token de la sesión actual (por defecto true). */
  auth?: boolean;
  query?: Record<string, string | number | undefined>;
  headers?: Record<string, string>;
}

/** Llama a la API desde el servidor de Next.js. Nunca lanza: devuelve ok/error. */
export async function api<T>(path: string, options: RequestOptions = {}): Promise<ApiResult<T>> {
  const { method = "GET", body, auth = true, query, headers: extra } = options;
  const url = new URL(`${config.apiInternalUrl}${API_PREFIX}${path}`);
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value !== undefined && value !== "") url.searchParams.set(key, String(value));
  }

  const headers: Record<string, string> = { Accept: "application/json", ...(await currentProxyHeaders()), ...extra };
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (auth) {
    const token = await getAccessToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      cache: "no-store",
      signal: AbortSignal.timeout(config.apiTimeoutMs),
    });
  } catch {
    return { ok: false, status: 0, error: await networkError() };
  }

  if (res.status === 204) return { ok: true, status: 204, data: undefined as T };

  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    // Respuesta sin JSON (p. ej. un proxy caído devolviendo HTML).
  }
  if (res.ok) return { ok: true, status: res.status, data: payload as T };

  const error = (payload as { error?: ApiError } | null)?.error ?? {
    code: "HTTP_ERROR",
    message: await message("unexpected", "Ocurrió un error inesperado."),
  };
  return { ok: false, status: res.status, error };
}

/** Sube un archivo (multipart) a la API con la sesión actual. */
export async function apiUpload<T>(path: string, form: FormData): Promise<ApiResult<T>> {
  const token = await getAccessToken();
  let res: Response;
  try {
    res = await fetch(`${config.apiInternalUrl}${API_PREFIX}${path}`, {
      method: "POST",
      headers: { ...(await currentProxyHeaders()), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: form,
      cache: "no-store",
      signal: AbortSignal.timeout(60_000),
    });
  } catch {
    return { ok: false, status: 0, error: await networkError() };
  }
  const payload = (await res.json().catch(() => null)) as { error?: ApiError } | T | null;
  if (res.ok) return { ok: true, status: res.status, data: payload as T };
  return {
    ok: false,
    status: res.status,
    error: (payload as { error?: ApiError } | null)?.error ?? {
      code: "HTTP_ERROR",
      message: await message("upload", "No se pudo subir la imagen."),
    },
  };
}
