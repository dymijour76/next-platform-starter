import "server-only";
import { cookies } from "next/headers";
import { cache } from "react";
import { api } from "@/lib/api-server";
import { CURRENCY_COOKIE, isDisplayCurrency, type DisplayCurrency, type RefRate } from "@/lib/currency";

export interface RatesInfo {
  base: string;
  currencies: { code: string; rate: string | null; source: "auto" | "manual" | "none"; updated_at: string | null }[];
  attribution: { name: string; url: string };
}

/** La moneda que eligió el visitante (cookie); por defecto, pesos. */
export async function getDisplayCurrency(): Promise<DisplayCurrency> {
  const value = (await cookies()).get(CURRENCY_COOKIE)?.value;
  return isDisplayCurrency(value) ? value : "CLP";
}

/** Tasas vigentes, una vez por petición. */
export const getRates = cache(async (): Promise<RatesInfo | null> => {
  const res = await api<RatesInfo>("/currencies", { auth: false });
  return res.ok ? res.data : null;
});

/** La referencia a mostrar junto a los pesos, o null si no hay moneda elegida o tasa. */
export const getRefRate = cache(async (): Promise<RefRate> => {
  const code = await getDisplayCurrency();
  if (code === "CLP") return null;
  const rate = (await getRates())?.currencies.find((c) => c.code === code)?.rate;
  return rate ? { code, rate: Number(rate) } : null;
});
