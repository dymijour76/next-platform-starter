import type { Format } from "./format";
import type { PricingRule } from "./types";

type Translate = (key: string, values?: Record<string, string>) => string;

/** Lunes a domingo en el idioma de la página (0 = lunes, como la API). */
export function weekdayNames(fmt: Format, style: "long" | "short"): string[] {
  // 2024-01-01 fue lunes; se formatea como hora "de reloj" para no depender de la zona.
  return Array.from({ length: 7 }, (_, i) => fmt.wall(`2024-01-0${i + 1}T12:00`, { weekday: style }));
}

/** "a, b y c" en el idioma de la página (en creole, que los navegadores no traen, "ak"). */
export function joinList(items: string[], fmt: Format, t: Translate): string {
  if (items.length < 2) return items[0] ?? "";
  if (fmt.locale === "ht") return `${items.slice(0, -1).join(", ")} ${t("and")} ${items.at(-1)}`;
  return new Intl.ListFormat(fmt.locale === "zh" ? "zh-CN" : fmt.locale, { type: "conjunction" }).format(items);
}

function dmy(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${d}-${m}-${y}`;
}

/** Efecto de la regla: "+20 %", "−$30.000". */
export function ruleEffect(rule: PricingRule, fmt: Format, currency = "CLP"): string {
  const sign = rule.kind === "SURCHARGE" ? "+" : "−";
  const amount =
    rule.adjustment_type === "PERCENT"
      ? fmt.percent(Number(rule.value) / 100, 2)
      : fmt.money(rule.value, currency);
  return `${sign}${amount}`;
}

/**
 * Condiciones en lenguaje natural: "sáb y dom, de 22:00 a 06:00".
 * `t` es el traductor del espacio "adm.rules".
 */
export function ruleConditions(rule: PricingRule, serviceNames: Record<string, string>, fmt: Format, t: Translate): string {
  const parts: string[] = [];
  if (rule.days_of_week?.length) {
    const short = weekdayNames(fmt, "short");
    parts.push(joinList(rule.days_of_week.map((d) => short[d]!), fmt, t));
  }
  if (rule.time_from && rule.time_until) {
    parts.push(t("timeRange", { from: rule.time_from.slice(0, 5), to: rule.time_until.slice(0, 5) }));
  }
  if (rule.valid_from && rule.valid_until) {
    parts.push(rule.valid_from === rule.valid_until
      ? t("onDate", { date: dmy(rule.valid_from) })
      : t("dateRange", { from: dmy(rule.valid_from), to: dmy(rule.valid_until) }));
  } else if (rule.valid_from) parts.push(t("fromDate", { date: dmy(rule.valid_from) }));
  else if (rule.valid_until) parts.push(t("untilDate", { date: dmy(rule.valid_until) }));
  if (rule.min_hours) parts.push(t("fromHours", { hours: fmt.hours(rule.min_hours) }));
  if (rule.service_ids?.length) {
    const names = rule.service_ids.map((id) => serviceNames[id] ?? t("deletedService"));
    parts.push(t("onlyServices", { services: joinList(names, fmt, t) }));
  }
  // El chino separa con su propia coma (，).
  return parts.length ? parts.join(fmt.locale === "zh" ? "，" : ", ") : t("always");
}
