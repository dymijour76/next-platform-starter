import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { getTranslations } from "next-intl/server";
import { currentProxyHeaders } from "@/lib/client-ip";
import { API_PREFIX, config } from "@/lib/config";
import { getAccessToken } from "@/lib/session";

/**
 * Lleva las consultas y mensajes del chat a la API con la sesión y el idioma de la persona.
 * Un envío (POST) sólo se acepta si viene del propio sitio (cabecera Origin): así otra página
 * no puede escribir en nombre del usuario aprovechando su sesión (CSRF).
 */
export async function proxyChat(request: NextRequest, apiPath: string): Promise<NextResponse> {
  if (request.method === "POST") {
    const origin = request.headers.get("origin");
    if (!origin || new URL(origin).host !== request.headers.get("host")) {
      const t = await getTranslations("chat");
      return NextResponse.json({ error: { code: "FORBIDDEN", message: t("originDenied") } }, { status: 403 });
    }
  }
  const token = await getAccessToken();
  if (!token) {
    const t = await getTranslations("chat");
    return NextResponse.json({ error: { code: "UNAUTHENTICATED", message: t("sessionExpired") } }, { status: 401 });
  }
  const res = await fetch(`${config.apiInternalUrl}${API_PREFIX}${apiPath}`, {
    method: request.method,
    headers: {
      ...(await currentProxyHeaders()),
      Authorization: `Bearer ${token}`,
      ...(request.method === "POST" ? { "Content-Type": "application/json" } : {}),
    },
    body: request.method === "POST" ? await request.text() : undefined,
    cache: "no-store",
  });
  return new NextResponse(res.body, {
    status: res.status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}
