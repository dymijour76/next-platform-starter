import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { api } from "./api-server";
import { getAccessToken } from "./session";
import type { Me } from "./types";

/** Usuario de la sesión actual, o null. Se consulta una sola vez por petición. */
export const getCurrentUser = cache(async (): Promise<Me | null> => {
  if (!(await getAccessToken())) return null;
  const res = await api<Me>("/auth/me");
  return res.ok ? res.data : null;
});

export async function requireUser(next = "/account"): Promise<Me> {
  const user = await getCurrentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  return user;
}

export function can(user: Me | null, permission: string): boolean {
  return !!user?.permissions.includes(permission);
}

/** Personal administrativo: tiene algún permiso además del portal de conductor. */
export function isStaff(user: Me | null): boolean {
  return !!user?.permissions.some((p) => p !== "driver_portal:access");
}

export async function requireStaff(): Promise<Me> {
  const user = await requireUser("/admin");
  if (!isStaff(user)) redirect("/account");
  // Con REQUIRE_STAFF_MFA, el panel queda cerrado hasta activar la verificación en dos pasos.
  if (user.mfa_setup_required) redirect("/account/security?mfa=required");
  return user;
}

export async function requirePermission(permission: string): Promise<Me> {
  const user = await requireStaff();
  if (!can(user, permission)) redirect("/admin?denied=1");
  return user;
}

/** Evita redirecciones abiertas: sólo rutas internas del sitio. */
export function safeNext(value: FormDataEntryValue | string | null | undefined): string {
  const next = typeof value === "string" ? value : "";
  return next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/\\")
    ? next
    : "/account";
}
