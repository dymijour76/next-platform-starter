/** Duraciones ofrecidas al reservar, en minutos (el texto lo pone el formateador de cada idioma). */
export function durationOptions(minHours: string, maxHours: string | null, step = 30): number[] {
  const min = Math.round(Number(minHours) * 60);
  const max = Math.round(Number(maxHours ?? 12) * 60);
  const options: number[] = [];
  for (let m = Math.ceil(min / step) * step; m <= max; m += step) options.push(m);
  return options;
}
