/**
 * Traducciones del contenido administrable en los formularios del panel.
 * Los campos se llaman "tr.<idioma>.<campo>" (p. ej. "tr.en.name"); las listas
 * (características) van una por línea.
 */
import { LOCALES, type Locale } from "@/i18n/config";

export type TranslationField = { key: string; label: string; kind?: "text" | "textarea" | "lines"; maxLength?: number };
export type Translations = Partial<Record<Locale, Record<string, string | string[]>>>;
export const TARGET_LOCALES = LOCALES.filter((l) => l !== "es");

/** Lee los campos de traducción del formulario. Lo vacío no se envía (queda el español). */
export function readTranslations(form: FormData, fields: TranslationField[]): Translations {
  const out: Translations = {};
  for (const locale of TARGET_LOCALES) {
    const data: Record<string, string | string[]> = {};
    for (const f of fields) {
      const raw = String(form.get(`tr.${locale}.${f.key}`) ?? "").trim();
      if (!raw) continue;
      data[f.key] = f.kind === "lines" ? raw.split("\n").map((x) => x.trim()).filter(Boolean) : raw;
    }
    if (Object.keys(data).length) out[locale] = data;
  }
  return out;
}

/** Valores iniciales de los campos "tr.<idioma>.<campo>" a partir de las traducciones guardadas. */
export function translationValues(translations: Translations | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [locale, fields] of Object.entries(translations ?? {})) {
    for (const [key, value] of Object.entries(fields ?? {})) {
      out[`tr.${locale}.${key}`] = Array.isArray(value) ? value.join("\n") : String(value);
    }
  }
  return out;
}

/** Campos traducibles de cada tipo de contenido (las etiquetas las pone cada formulario). */
export const SERVICE_TR: TranslationField[] = [
  { key: "name", label: "", maxLength: 100 },
  { key: "tagline", label: "", maxLength: 200 },
  { key: "description", label: "", kind: "textarea", maxLength: 5000 },
  { key: "features", label: "", kind: "lines" },
];
export const RULE_TR: TranslationField[] = [{ key: "name", label: "", maxLength: 100 }];
export const SLIDE_TR: TranslationField[] = [
  { key: "title", label: "", maxLength: 80 },
  { key: "subtitle", label: "", maxLength: 200 },
  { key: "cta_label", label: "", maxLength: 30 },
];

/** Valores "tr.*" del formulario, para devolverlos si hay un error y no perder lo escrito. */
export function translationFormValues(form: FormData): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of form.entries()) if (k.startsWith("tr.") && typeof v === "string") out[k] = v;
  return out;
}

export function withLabels(fields: TranslationField[], labels: Record<string, string>): TranslationField[] {
  return fields.map((f) => ({ ...f, label: labels[f.key] ?? f.key }));
}
