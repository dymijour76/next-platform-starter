/**
 * Convierte fecha y hora "de reloj" en una zona horaria (p. ej. lo que el
 * cliente elige para Santiago) a un instante ISO con desfase, sin depender de
 * la zona horaria del servidor. Maneja el cambio de horario de verano.
 */

function offsetMinutes(instant: Date, timeZone: string): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).formatToParts(instant);
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value);
  const asUtc = Date.UTC(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), get("second"));
  return Math.round((asUtc - instant.getTime()) / 60000);
}

/** "2026-10-14" + "22:30" en America/Santiago → "2026-10-14T22:30:00-03:00". */
export function zonedToIso(date: string, time: string, timeZone: string): string | null {
  const d = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  const t = /^(\d{2}):(\d{2})$/.exec(time);
  if (!d || !t) return null;
  const [, y, mo, da] = d.map(Number) as [number, number, number, number];
  const [, h, mi] = t.map(Number) as [number, number, number];
  const wall = Date.UTC(y, mo - 1, da, h, mi);
  // Dos pasadas: la primera estimación puede caer al otro lado de un cambio de horario.
  let offset = offsetMinutes(new Date(wall), timeZone);
  offset = offsetMinutes(new Date(wall - offset * 60000), timeZone);
  const sign = offset >= 0 ? "+" : "-";
  const abs = Math.abs(offset);
  const hh = String(Math.floor(abs / 60)).padStart(2, "0");
  const mm = String(abs % 60).padStart(2, "0");
  return `${date}T${time}:00${sign}${hh}:${mm}`;
}

/** Fecha de hoy en la zona indicada, formato YYYY-MM-DD (para el mínimo del calendario). */
export function todayIn(timeZone: string): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone }).format(new Date());
}

