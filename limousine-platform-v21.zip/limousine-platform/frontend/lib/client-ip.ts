/**
 * IP del visitante para reenviarla a la API.
 *
 * En producción, Caddy recibe la conexión y escribe la IP real en X-Forwarded-For
 * (reemplaza lo que haya mandado el cliente). El sitio la reenvía a la API en
 * X-Client-IP junto con INTERNAL_PROXY_SECRET, que la API exige para creerla.
 * El sitio nunca debe quedar accesible sin pasar por Caddy.
 *
 * En Netlify no hay Caddy: CLIENT_IP_HEADER=x-nf-client-connection-ip indica la cabecera
 * que Netlify escribe con la IP real (el cliente no puede falsificarla).
 */

type HeaderReader = { get(name: string): string | null };

/** IP del visitante según la plataforma donde corre el sitio. */
export function visitorIp(h: HeaderReader): string | null {
  const trusted = process.env.CLIENT_IP_HEADER;
  if (trusted) return firstForwardedIp(h.get(trusted));
  return firstForwardedIp(h.get("x-forwarded-for")) ?? firstForwardedIp(h.get("x-real-ip"));
}

export function firstForwardedIp(value: string | null | undefined): string | null {
  const first = value?.split(",")[0]?.trim();
  return first ? first.slice(0, 64) : null;
}

export function proxyHeaders(ip: string | null): Record<string, string> {
  const secret = process.env.INTERNAL_PROXY_SECRET;
  if (!secret || !ip) return {};
  return { "X-Proxy-Secret": secret, "X-Client-IP": ip };
}

/** Desde componentes de servidor, Server Actions y rutas: lee la cabecera de la petición en curso. */
export async function currentProxyHeaders(): Promise<Record<string, string>> {
  try {
    const { headers } = await import("next/headers");
    const h = await headers();
    const ua = h.get("user-agent");
    const { getLocale } = await import("next-intl/server");
    const locale = await getLocale().catch(() => null);
    // El navegador del visitante: así las sesiones y la auditoría muestran su dispositivo.
    return {
      ...(ua ? { "User-Agent": ua.slice(0, 500) } : {}),
      // La API responde (errores, validaciones) en el idioma del visitante.
      ...(locale ? { "Accept-Language": locale } : {}),
      ...proxyHeaders(visitorIp(h)),
    };
  } catch {
    return {}; // fuera de una petición (por ejemplo, al compilar)
  }
}
