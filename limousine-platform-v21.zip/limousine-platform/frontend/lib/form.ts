import type { ApiError } from "./types";

/** Estado que devuelven las Server Actions a los formularios. */
export interface FormState {
  status: "idle" | "error" | "success";
  message?: string;
  fields?: Record<string, string>;
  /** Valores enviados, para no vaciar el formulario si hay errores (nunca contraseñas). */
  values?: Record<string, string>;
}

export const initialFormState: FormState = { status: "idle" };

export function fromApiError(error: ApiError, values?: Record<string, string>): FormState {
  return { status: "error", message: error.message, fields: error.fields, values };
}

export function text(form: FormData, name: string): string {
  const value = form.get(name);
  return typeof value === "string" ? value.trim() : "";
}

/** Texto opcional: "" se envía como null para borrar el dato. */
export function optional(form: FormData, name: string): string | null {
  return text(form, name) || null;
}

export function pick(form: FormData, names: string[]): Record<string, string> {
  return Object.fromEntries(names.map((n) => [n, text(form, n)]));
}
