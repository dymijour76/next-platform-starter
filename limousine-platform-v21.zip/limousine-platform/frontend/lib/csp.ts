/**
 * Política de seguridad de contenido (CSP). Se arma en proxy.ts en cada petición.
 *
 * - Scripts: sólo los de Next.js con el nonce de la petición ('strict-dynamic').
 *   Un script inyectado por un atacante no tiene el nonce y no se ejecuta.
 * - Estilos: hojas del propio sitio y bloques con nonce. Los atributos style=""
 *   (usados por el margen seguro del iPhone y los colores de los gráficos) no
 *   pueden llevar nonce: se permiten sólo ellos con style-src-attr.
 * - Imágenes: el propio sitio y el origen de las imágenes (API o CDN).
 * - Formularios: el propio sitio y la pasarela de pago (el pago se envía por POST a Transbank).
 */

const PAYMENT_ORIGINS = ["https://webpay3g.transbank.cl", "https://webpay3gint.transbank.cl"];

function origin(url: string | undefined): string | null {
  if (!url) return null;
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

export function buildCsp(nonce: string, isDev: boolean): string {
  const media = origin(process.env.MEDIA_BASE_URL) ?? origin(process.env.NEXT_PUBLIC_API_URL);
  const directives: Record<string, string[]> = {
    "default-src": ["'self'"],
    "script-src": ["'self'", `'nonce-${nonce}'`, "'strict-dynamic'", ...(isDev ? ["'unsafe-eval'"] : [])],
    "style-src": ["'self'", `'nonce-${nonce}'`],
    "style-src-attr": ["'unsafe-inline'"],
    "img-src": ["'self'", "data:", "blob:", ...(media ? [media] : [])],
    "font-src": ["'self'"],
    // El navegador sólo habla con el propio sitio: la API se llama desde el servidor.
    "connect-src": ["'self'", ...(isDev ? ["ws:"] : [])],
    "media-src": ["'self'", "blob:"],
    "form-action": ["'self'", ...PAYMENT_ORIGINS],
    "frame-ancestors": ["'none'"],
    "base-uri": ["'self'"],
    "object-src": ["'none'"],
    "worker-src": ["'self'", "blob:"],
    "manifest-src": ["'self'"],
  };
  const parts = Object.entries(directives).map(([k, v]) => `${k} ${v.join(" ")}`);
  if (!isDev) parts.push("upgrade-insecure-requests");
  return parts.join("; ");
}

export function newNonce(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes));
}
