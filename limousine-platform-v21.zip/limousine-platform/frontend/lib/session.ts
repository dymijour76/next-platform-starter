import "server-only";
import { cookies } from "next/headers";
import type { TokenPair } from "./types";

/**
 * Los tokens viven en cookies httpOnly del dominio del sitio: el JavaScript
 * del navegador no puede leerlos, así que un ataque XSS no puede robar la sesión.
 * Sólo el servidor de Next.js los lee y los envía a la API como Bearer.
 */
export const ACCESS_COOKIE = "lp_at";
export const REFRESH_COOKIE = "lp_rt";

export const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  path: "/",
};

export async function getAccessToken(): Promise<string | undefined> {
  return (await cookies()).get(ACCESS_COOKIE)?.value;
}

export async function getRefreshToken(): Promise<string | undefined> {
  return (await cookies()).get(REFRESH_COOKIE)?.value;
}

/** Sólo se puede llamar desde Server Actions o Route Handlers. */
export async function saveSession(pair: TokenPair): Promise<void> {
  const store = await cookies();
  store.set(ACCESS_COOKIE, pair.access_token, { ...cookieOptions, maxAge: pair.expires_in });
  store.set(REFRESH_COOKIE, pair.refresh_token, {
    ...cookieOptions,
    maxAge: pair.refresh_expires_in,
  });
}

export async function clearSession(): Promise<void> {
  const store = await cookies();
  store.delete(ACCESS_COOKIE);
  store.delete(REFRESH_COOKIE);
}
