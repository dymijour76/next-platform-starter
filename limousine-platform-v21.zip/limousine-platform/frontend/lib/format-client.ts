"use client";

import { useLocale, useTranslations } from "next-intl";
import { useMemo } from "react";
import type { Locale } from "@/i18n/config";
import { useRefRate } from "@/components/CurrencyProvider";
import { makeFormat, type Format } from "@/lib/format";

/** Formateador para componentes de cliente, en el idioma de la página. */
export function useFormat(): Format {
  const locale = useLocale() as Locale;
  const units = useTranslations("units");
  const refRate = useRefRate();
  return useMemo(() => makeFormat(locale, (key, values) => units(key, values), refRate), [locale, units, refRate]);
}
