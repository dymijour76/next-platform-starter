"use server";

import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { CURRENCY_COOKIE, isDisplayCurrency } from "@/lib/currency";

/** Cambia la moneda de referencia de este navegador (se cobra siempre en pesos). */
export async function setCurrencyAction(form: FormData): Promise<void> {
  const currency = form.get("currency");
  if (!isDisplayCurrency(currency)) return;
  (await cookies()).set(CURRENCY_COOKIE, currency, {
    path: "/",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 365,
    secure: process.env.NODE_ENV === "production",
  });
  revalidatePath("/", "layout");
}
