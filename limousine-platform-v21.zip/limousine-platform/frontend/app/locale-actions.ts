"use server";

import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { isLocale, LOCALE_COOKIE } from "@/i18n/config";
import { api } from "@/lib/api-server";
import { getAccessToken } from "@/lib/session";

/** Cambia el idioma: lo recuerda en este navegador y, si hay sesión, en la cuenta (emails). */
export async function setLocaleAction(form: FormData): Promise<void> {
  const locale = form.get("locale");
  if (!isLocale(locale)) return;
  (await cookies()).set(LOCALE_COOKIE, locale, {
    path: "/",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 365,
    secure: process.env.NODE_ENV === "production",
  });
  if (await getAccessToken()) {
    await api("/users/me", { method: "PATCH", body: { locale } });
  }
  revalidatePath("/", "layout");
}
