"use client";

import Link from "next/link";
import { useTranslations } from "next-intl";
import { useEffect } from "react";

/** Error al cargar una sección: se puede reintentar sin perder el resto del sitio. */
export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const t = useTranslations("errors");
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <main className="mx-auto max-w-2xl px-6 py-24 text-center">
      <h1 className="font-display text-4xl text-ink">{t("errorHeading")}</h1>
      <p className="mt-4 text-slate">{t("errorText")}</p>
      {error.digest ? <p className="mt-2 text-xs text-slate">{t("reference", { digest: error.digest })}</p> : null}
      <div className="mt-8 flex justify-center gap-4">
        <button type="button" onClick={reset} className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
          {t("retry")}
        </button>
        <Link href="/" className="rounded-sm border border-ink/25 px-5 py-2.5 text-sm hover:border-ink/50">{t("home")}</Link>
      </div>
    </main>
  );
}
