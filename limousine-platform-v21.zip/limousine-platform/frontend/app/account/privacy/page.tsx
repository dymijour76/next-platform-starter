import type { Metadata } from "next";
import { PageHeading, Section } from "@/components/PageHeading";
import { requireUser } from "@/lib/auth";
import { DeleteAccountForm } from "./DeleteAccountForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("account"))("navPrivacy") };
}

export default async function PrivacyPage() {
  const [user, t, acc] = await Promise.all([
    requireUser("/account/privacy"), getTranslations("privacy"), getTranslations("account"),
  ]);
  const customerOnly = user.roles.every((r) => r.code === "customer");
  return (
    <div className="space-y-10">
      <PageHeading title={acc("navPrivacy")} description={t("intro")} />
      <Section title={t("downloadTitle")} description={t("downloadHint")}>
        <a href="/account/privacy/export" className="inline-block rounded-sm border border-ink/25 bg-paper px-5 py-2.5 text-sm hover:border-ink/50">
          {t("download")}
        </a>
      </Section>
      <Section title={t("correctTitle")} description={t("correctHint")}>
        <a href="/account/profile" className="text-sm text-ink underline decoration-champagne underline-offset-4">{t("goToProfile")}</a>
      </Section>
      <Section title={t("deleteTitle")}>
        <div className="space-y-4 text-sm leading-relaxed text-ink">
          <p>
            {t("deleteWhat")}
          </p>
          <p className="text-slate">
            {t("deleteKeep")}
          </p>
          <p className="text-slate">
            {t("deletePending")}
          </p>
          {customerOnly ? (
            <DeleteAccountForm />
          ) : (
            <p className="text-slate">{t("staffNotice")}</p>
          )}
        </div>
      </Section>
    </div>
  );
}
