"use server";

import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import { clearSession } from "@/lib/session";

export async function deleteAccountAction(_: FormState, form: FormData): Promise<FormState> {
  const res = await api<void>("/users/me/delete", {
    method: "POST",
    body: { current_password: String(form.get("current_password") ?? ""), confirmation: text(form, "confirmation") },
  });
  if (!res.ok) return fromApiError(res.error);
  await clearSession();
  redirect("/login?deleted=1");
}
