import { NextResponse } from "next/server";
import { currentProxyHeaders } from "@/lib/client-ip";
import { API_PREFIX, config } from "@/lib/config";
import { getAccessToken } from "@/lib/session";
import { getTranslations } from "next-intl/server";

/** Descarga "mis datos" (JSON) con la sesión del usuario. */
export async function GET() {
  const token = await getAccessToken();
  const t = await getTranslations("privacy");
  if (!token) return new NextResponse(t("exportLogin"), { status: 401 });
  const res = await fetch(`${config.apiInternalUrl}${API_PREFIX}/users/me/export`, {
    // Idioma, IP y navegador del visitante, como en el resto de las llamadas a la API.
    headers: { ...(await currentProxyHeaders()), Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  if (!res.ok) return new NextResponse(t("exportFailed"), { status: res.status });
  return new NextResponse(res.body, {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": 'attachment; filename="mis-datos.json"',
      "Cache-Control": "no-store",
    },
  });
}
