"use client";

import { useActionState, useState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { deleteAccountAction } from "./actions";
import { useTranslations } from "next-intl";

export function DeleteAccountForm() {
  const t = useTranslations("privacy");
  const sec = useTranslations("security");
  const [state, action] = useActionState(deleteAccountAction, initialFormState);
  const [open, setOpen] = useState(false);
  if (!open && state.status === "idle") {
    return (
      <button type="button" onClick={() => setOpen(true)}
        className="rounded-sm border border-alert/40 bg-paper px-5 py-2.5 text-sm text-alert hover:border-alert">
        {t("deleteButton")}
      </button>
    );
  }
  return (
    <form action={action} className="max-w-md space-y-4 border-l-2 border-alert bg-paper px-5 py-5" noValidate>
      <FormAlert state={state} />
      <p className="text-sm text-ink">{t("irreversible")}</p>
      <Field label={sec("currentPassword")} name="current_password" type="password" required autoComplete="current-password"
        error={state.fields?.current_password} />
      <Field label={t("typeToConfirm")} name="confirmation" required autoComplete="off" error={state.fields?.confirmation} />
      <SubmitButton variant="danger" pendingLabel={t("deleting")}>{t("deleteForever")}</SubmitButton>
    </form>
  );
}
