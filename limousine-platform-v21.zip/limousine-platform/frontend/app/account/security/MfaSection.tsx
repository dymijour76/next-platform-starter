"use client";

import { useActionState, useState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { mfaDisableAction, mfaEnableAction, mfaRegenerateAction, mfaSetupAction, type MfaState } from "../mfa-actions";
import { useTranslations } from "next-intl";

const idle: MfaState = { status: "idle" };

function BackupCodes({ codes }: { codes: string[] }) {
  const t = useTranslations("mfa");
  const file = `data:text/plain;charset=utf-8,${encodeURIComponent(
    `${t("codesFile")}\n\n${codes.join("\n")}\n`,
  )}`;
  return (
    <div className="space-y-3 border-l-2 border-champagne bg-paper px-5 py-4">
      <p className="font-medium text-ink">{t("codesTitle")}</p>
      <p className="text-sm text-slate">
        {t("codesText")}
      </p>
      <ul className="grid grid-cols-2 gap-x-6 gap-y-1 font-mono text-sm text-ink sm:grid-cols-5">
        {codes.map((c) => <li key={c}>{c}</li>)}
      </ul>
      <a href={file} download="codigos-de-respaldo.txt" className="inline-block text-sm text-ink underline decoration-champagne underline-offset-4">
        {t("download")}
      </a>
    </div>
  );
}

export function MfaSection({ enabled, codesLeft }: { enabled: boolean; codesLeft: number }) {
  const t = useTranslations("mfa");
  const sec = useTranslations("security");
  const [setup, setupAction] = useActionState(mfaSetupAction, idle);
  const [enable, enableAction] = useActionState(mfaEnableAction, idle);
  const [regen, regenAction] = useActionState(mfaRegenerateAction, idle);
  const [disable, disableAction] = useActionState(mfaDisableAction, idle);
  const [mode, setMode] = useState<"none" | "regen" | "disable">("none");

  const codes = enable.backupCodes ?? regen.backupCodes;
  if (codes) {
    return (
      <div className="space-y-4">
        <FormAlert state={enable.step === "codes" ? enable : regen} />
        <BackupCodes codes={codes} />
      </div>
    );
  }
  if (disable.status === "success") return <FormAlert state={disable} />;

  if (enabled) {
    return (
      <div className="space-y-5">
        <p className="text-ink">
          {t("active", { count: codesLeft })}
        </p>
        <div className="flex flex-wrap gap-4 text-sm">
          <button type="button" onClick={() => setMode("regen")} className="text-ink underline decoration-champagne underline-offset-4">
            {t("regenerate")}
          </button>
          <button type="button" onClick={() => setMode("disable")} className="text-alert underline underline-offset-4">
            {t("disable")}
          </button>
        </div>
        {mode === "regen" ? (
          <form action={regenAction} className="max-w-sm space-y-4" noValidate>
            <FormAlert state={regen} />
            <Field label={t("appCode")} name="code" id="mfa-regen-code" required autoComplete="one-time-code" error={regen.fields?.code} />
            <SubmitButton variant="secondary" pendingLabel={t("generating")}>{t("generate")}</SubmitButton>
          </form>
        ) : null}
        {mode === "disable" ? (
          <form action={disableAction} className="max-w-sm space-y-4" noValidate>
            <FormAlert state={disable} />
            <Field label={sec("currentPassword")} name="current_password" id="mfa-disable-password" type="password" required autoComplete="current-password"
              error={disable.fields?.current_password} />
            <Field label={t("appOrBackupCode")} name="code" id="mfa-disable-code" required autoComplete="one-time-code"
              error={disable.fields?.code} />
            <SubmitButton variant="danger" pendingLabel={t("disabling")}>{t("disable")}</SubmitButton>
          </form>
        ) : null}
      </div>
    );
  }

  const secret = enable.secret ?? setup.secret;
  const qrSvg = enable.qrSvg ?? setup.qrSvg;
  if (secret && qrSvg) {
    return (
      <form action={enableAction} className="space-y-5" noValidate>
        <FormAlert state={enable} />
        <ol className="list-decimal space-y-2 pl-5 text-sm text-ink">
          <li>{t("step1")}</li>
          <li>{t("step2")}</li>
          <li>{t("step3")}</li>
        </ol>
        <div className="flex flex-wrap items-center gap-6">
          <div className="w-44 border border-ink/10 bg-paper p-2" role="img" aria-label={t("qrLabel")}
            dangerouslySetInnerHTML={{ __html: qrSvg }} />
          <p className="text-sm text-slate">{t.rich("key", { secret, key: (chunks) => <span className="break-all font-mono text-ink">{chunks}</span> })}</p>
        </div>
        <div className="max-w-xs">
          <Field label={t("sixDigits")} name="code" id="mfa-enable-code" required autoComplete="one-time-code" inputMode="numeric"
            maxLength={6} error={enable.fields?.code} />
        </div>
        <SubmitButton pendingLabel={t("activating")}>{t("activate")}</SubmitButton>
      </form>
    );
  }

  return (
    <form action={setupAction} className="max-w-sm space-y-4" noValidate>
      <FormAlert state={setup} />
      <p className="text-sm text-slate">
        {t("intro")}
      </p>
      <Field label={sec("currentPassword")} name="current_password" id="mfa-setup-password" type="password" required autoComplete="current-password"
        error={setup.fields?.current_password} />
      <SubmitButton pendingLabel={t("preparing")}>{t("setup")}</SubmitButton>
    </form>
  );
}
