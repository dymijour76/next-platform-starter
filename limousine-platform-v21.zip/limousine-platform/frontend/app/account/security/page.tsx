import type { Metadata } from "next";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { PageHeading, Section } from "@/components/PageHeading";
import { requireUser } from "@/lib/auth";
import { logoutAllAction } from "../actions";
import { MfaSection } from "./MfaSection";
import { ChangeEmailForm, ChangePasswordForm } from "./SecurityForms";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("account"))("navSecurity") };
}

export default async function SecurityPage({ searchParams }: { searchParams: Promise<{ mfa?: string }> }) {
  const [user, { mfa }, t, acc] = await Promise.all([
    requireUser("/account/security"), searchParams, getTranslations("security"), getTranslations("account"),
  ]);
  return (
    <div className="space-y-10">
      <PageHeading title={acc("navSecurity")} />
      {mfa === "required" || user.mfa_setup_required ? (
        <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">
          {t("mfaRequired")}
        </p>
      ) : null}
      <Section title={t("mfaTitle")} description={t("mfaHint")}>
        <MfaSection enabled={user.mfa_enabled} codesLeft={user.mfa_backup_codes_left} />
      </Section>
      <Section title={t("passwordTitle")} description={t("passwordHint")}>
        <ChangePasswordForm />
      </Section>
      <Section title={t("emailTitle")} description={t("emailHint")}>
        <ChangeEmailForm current={user.email} />
      </Section>
      <Section
        title={t("sessionsTitle")}
        description={t("sessionsHint")}
      >
        <form action={logoutAllAction}>
          <SubmitButton variant="danger" pendingLabel={t("closing")}>
            {t("signOutAll")}
          </SubmitButton>
        </form>
      </Section>
    </div>
  );
}
