"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { changeEmailAction, changePasswordAction } from "../actions";
import { useTranslations } from "next-intl";

export function ChangePasswordForm() {
  const t = useTranslations("security");
  const a = useTranslations("auth");
  const [state, action] = useActionState(changePasswordAction, initialFormState);
  const f = state.fields ?? {};
  return (
    <form action={action} className="space-y-5" noValidate key={state.status === "success" ? "done" : "form"}>
      <FormAlert state={state} />
      <Field label={t("currentPassword")} name="current_password" id="pw-current-password" type="password"
        autoComplete="current-password" required error={f.current_password} />
      <Field label={a("newPassword")} name="password" type="password" autoComplete="new-password"
        required minLength={10} error={f.password} hint={a("passwordMin")} />
      <Field label={t("repeatNewPassword")} name="password_confirmation" type="password"
        autoComplete="new-password" required error={f.password_confirmation} />
      <SubmitButton pendingLabel={a("saving")}>{t("changePassword")}</SubmitButton>
    </form>
  );
}

export function ChangeEmailForm({ current }: { current: string }) {
  const t = useTranslations("security");
  const a = useTranslations("auth");
  const [state, action] = useActionState(changeEmailAction, initialFormState);
  const f = state.fields ?? {};
  return (
    <form action={action} className="space-y-5" noValidate>
      <FormAlert state={state} />
      <p className="text-sm text-slate">
        {t.rich("currentEmail", { email: current, em: (chunks) => <span className="text-ink">{chunks}</span> })}
      </p>
      <Field label={t("newEmail")} name="email" type="email" autoComplete="email" required
        defaultValue={state.values?.email} error={f.email} />
      <Field label={t("currentPassword")} name="current_password" id="email-current-password" type="password"
        autoComplete="current-password" required error={f.current_password}
        hint={t("confirmItsYou")} />
      <SubmitButton pendingLabel={a("saving")} variant="secondary">{t("changeEmail")}</SubmitButton>
    </form>
  );
}
