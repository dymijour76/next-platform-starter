"use server";

import { getTranslations } from "next-intl/server";
import { revalidatePath } from "next/cache";
import { api } from "@/lib/api-server";
import { fromApiError, type FormState } from "@/lib/form";

export async function submitReviewAction(_: FormState, form: FormData): Promise<FormState> {
  const t = await getTranslations("reviews");
  const code = String(form.get("code") ?? "");
  const service = Number(form.get("service_rating") ?? 0);
  const driver = Number(form.get("driver_rating") ?? 0);
  const comment = String(form.get("comment") ?? "").trim();
  const values = { comment, consent_publish: form.get("consent_publish") ? "on" : "" };
  if (!service) return { status: "error", message: t("chooseRating"), fields: { service_rating: t("chooseRating") }, values };
  const res = await api(`/reservations/${encodeURIComponent(code)}/review`, {
    method: "POST",
    body: {
      service_rating: service,
      driver_rating: driver || null,
      comment: comment || null,
      consent_publish: Boolean(form.get("consent_publish")),
    },
  });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath(`/account/reservations/${code}`);
  return { status: "success", message: t("thanks") };
}
