"use client";

import { useTranslations } from "next-intl";
import { useActionState } from "react";
import { Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { StarInput } from "@/components/forms/StarInput";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { submitReviewAction } from "./review-actions";

export function ReviewForm({ code, hasDriver, displayName }: { code: string; hasDriver: boolean; displayName: string }) {
  const t = useTranslations("reviews");
  const [state, action] = useActionState(submitReviewAction, initialFormState);
  const f = state.fields ?? {};
  return (
    <form action={action} noValidate className="space-y-5">
      <FormAlert state={state} />
      <input type="hidden" name="code" value={code} />
      <div className="flex flex-wrap gap-8">
        <StarInput name="service_rating" legend={t("service")} required error={f.service_rating} />
        {hasDriver ? <StarInput name="driver_rating" legend={t("driver")} /> : null}
      </div>
      <Textarea label={t("comment")} name="comment" rows={3} maxLength={1000} hint={t("commentHint")}
        defaultValue={state.values?.comment} error={f.comment} />
      <label className="flex items-start gap-3 text-sm text-ink">
        <input type="checkbox" name="consent_publish" className="mt-1 size-4 accent-ink"
          defaultChecked={state.values?.consent_publish === "on"} />
        <span>{t("consent", { name: displayName })}</span>
      </label>
      <SubmitButton pendingLabel={t("sending")}>{t("send")}</SubmitButton>
    </form>
  );
}
