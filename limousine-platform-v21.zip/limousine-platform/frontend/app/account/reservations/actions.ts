"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import type { Reservation } from "@/lib/types";

export async function cancelReservationAction(_: FormState, form: FormData): Promise<FormState> {
  const code = text(form, "code");
  const res = await api<Reservation>(`/reservations/${encodeURIComponent(code)}/cancel`, {
    method: "POST",
    body: { reason: text(form, "reason") || null },
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/account", "layout");
  redirect(`/account/reservations/${encodeURIComponent(code)}?cancelled=1`);
}
