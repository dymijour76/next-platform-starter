import { getTranslations } from "next-intl/server";
import { Stars } from "@/components/Stars";
import { api } from "@/lib/api-server";
import { getFormat } from "@/lib/format-server";
import { ReviewForm } from "./ReviewForm";

interface ReviewState {
  eligible: boolean;
  deadline: string | null;
  has_driver: boolean;
  review: { service_rating: number; driver_rating: number | null; comment: string | null; consent_publish: boolean; status: string } | null;
}

/** Calificación de una reserva completada (id="calificar": el enlace del email llega aquí). */
export async function ReviewSection({ code, displayName }: { code: string; displayName: string }) {
  const res = await api<ReviewState>(`/reservations/${encodeURIComponent(code)}/review`);
  if (!res.ok || (!res.data.eligible && !res.data.review)) return null;
  const [t, fmt] = await Promise.all([getTranslations("reviews"), getFormat()]);
  const { review } = res.data;
  const note = !review ? null
    : !review.comment || !review.consent_publish ? (review.comment ? t("statusPrivate") : null)
    : review.status === "PENDING" ? t("statusPending")
    : review.status === "PUBLISHED" ? t("statusPublished") : t("statusHidden");
  return (
    <section id="calificar" aria-labelledby="calificar-title" className="scroll-mt-24 border border-ink/10 bg-paper p-6">
      <h2 id="calificar-title" className="font-display text-xl text-ink">{review ? t("yours") : t("formTitle")}</h2>
      {review ? (
        <div className="mt-4 space-y-3 text-sm">
          <p className="flex items-center gap-3"><span className="w-20 text-slate">{t("service")}</span><Stars rating={review.service_rating} /></p>
          {review.driver_rating ? (
            <p className="flex items-center gap-3"><span className="w-20 text-slate">{t("driver")}</span><Stars rating={review.driver_rating} /></p>
          ) : null}
          {review.comment ? <blockquote className="border-l-2 border-champagne pl-4 text-ink">{review.comment}</blockquote> : null}
          {note ? <p className="text-slate">{note}</p> : null}
        </div>
      ) : (
        <>
          <p className="mt-1 text-sm text-slate">
            {t("formHint", { date: fmt.dateTime(res.data.deadline!, { day: "numeric", month: "long", year: "numeric" }) })}
          </p>
          <div className="mt-5">
            <ReviewForm code={code} hasDriver={res.data.has_driver} displayName={displayName} />
          </div>
        </>
      )}
    </section>
  );
}
