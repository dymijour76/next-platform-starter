import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { PICKUP_FORMAT } from "@/components/reservations/ReservationDetails";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import { requireUser } from "@/lib/auth";
import type { ReservationSummary } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("account"))("navReservations") };
}

export default async function MyReservationsPage({
  searchParams,
}: {
  searchParams: Promise<{ scope?: string; payment?: string }>;
}) {
  const [, { scope, payment }] = await Promise.all([requireUser("/account/reservations"), searchParams]);
  const past = scope === "past";
  const [t, acc, fmt] = await Promise.all([getTranslations("reservations"), getTranslations("account"), getFormat()]);
  const res = await api<ReservationSummary[]>("/reservations", { query: { scope: past ? "past" : "upcoming" } });
  const tab = (active: boolean) =>
    `border-b-2 px-1 pb-2 text-sm ${active ? "border-champagne text-ink" : "border-transparent text-slate hover:text-ink"}`;

  return (
    <div className="space-y-8">
      <PageHeading
        title={acc("navReservations")}
        action={
          <Link href="/book" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
            {t("new")}
          </Link>
        }
      />
      {payment === "error" ? (
        <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">
          {t("paymentUnknown")}
        </p>
      ) : null}
      <nav aria-label={t("tabs")} className="flex gap-6 border-b border-ink/10">
        <Link href="/account/reservations" aria-current={!past ? "page" : undefined} className={tab(!past)}>{t("upcoming")}</Link>
        <Link href="/account/reservations?scope=past" aria-current={past ? "page" : undefined} className={tab(past)}>{t("history")}</Link>
      </nav>

      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="text-slate">
          {past ? t("noPast") : `${acc("noUpcoming")} `}
          {!past ? <Link href="/book" className="text-ink underline decoration-champagne underline-offset-4">{t("bookNext")}</Link> : null}
        </p>
      ) : (
        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {res.data.map((r) => (
            <li key={r.id}>
              <Link href={`/account/reservations/${r.code}`}
                className="grid gap-2 py-5 hover:bg-paper/60 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:gap-6">
                <span>
                  <span className="flex flex-wrap items-center gap-3">
                    <span className="font-display text-xl text-ink">{r.service.name}</span>
                    <StatusBadge status={r.status} />
                  </span>
                  <span className="mt-1 block text-sm text-slate first-letter:uppercase">{fmt.wall(r.pickup_local, PICKUP_FORMAT)}</span>
                  <span className="block text-sm text-slate">{r.code}</span>
                </span>
                <span className="font-display text-lg tabular-nums text-ink">{fmt.money(r.total_amount, r.currency)}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
