import type { NextRequest } from "next/server";
import { proxyChat } from "@/lib/chat-proxy";

type Params = { params: Promise<{ code: string }> };

export async function GET(request: NextRequest, { params }: Params) {
  return proxyChat(request, `/reservations/${encodeURIComponent((await params).code)}/messages`);
}

export async function POST(request: NextRequest, { params }: Params) {
  return proxyChat(request, `/reservations/${encodeURIComponent((await params).code)}/messages`);
}
