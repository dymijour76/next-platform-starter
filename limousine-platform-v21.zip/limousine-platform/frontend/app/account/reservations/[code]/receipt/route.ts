import type { NextRequest } from "next/server";
import { proxyReceipt } from "@/lib/receipt";

/** Comprobante de una reserva propia (la API verifica que sea de quien lo pide). */
export async function GET(request: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  return proxyReceipt(request, `/reservations/${encodeURIComponent(code)}/receipt`);
}
