import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { BoardingCard } from "@/components/reservations/BoardingCard";
import { ChatSection } from "@/components/chat/ChatSection";
import { ReviewSection } from "../ReviewSection";
import { ReceiptLinks } from "@/components/reservations/ReceiptLinks";
import { ReservationDetails } from "@/components/reservations/ReservationDetails";
import { PayButton } from "@/components/payments/PayButton";
import { PayWithWalletButton } from "@/components/payments/WalletButtons";
import type { WalletInfo } from "@/lib/types";
import { PaymentList } from "@/components/payments/PaymentList";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import { requireUser } from "@/lib/auth";
import type { PublicPricingConfig, Reservation } from "@/lib/types";
import { CancelForm } from "../CancelForm";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("reservations"))("metaTitle") };
}

const PAYMENT_NOTICES: Record<string, { ok: boolean; key: string }> = {
  paid: { ok: true, key: "paid" },
  rejected: { ok: false, key: "rejected" },
  aborted: { ok: false, key: "aborted" },
  error: { ok: false, key: "bankError" },
  refunded_unavailable: { ok: false, key: "refundedUnavailable" },
  unavailable: { ok: false, key: "gatewayDown" },
};

export default async function ReservationPage({
  params,
  searchParams,
}: {
  params: Promise<{ code: string }>;
  searchParams: Promise<{ created?: string; cancelled?: string; payment?: string }>;
}) {
  const [{ code }, { created, cancelled, payment }] = await Promise.all([params, searchParams]);
  const me = await requireUser(`/account/reservations/${code}`);
  // Como se mostrará si autoriza publicar su comentario: "Valentina M."
  const shortName = `${me.first_name.trim()}${me.last_name ? ` ${me.last_name.trim()[0]}.` : ""}`;
  const [res, config] = await Promise.all([
    api<Reservation>(`/reservations/${encodeURIComponent(code)}`),
    api<PublicPricingConfig>("/pricing/config", { auth: false }),
  ]);
  const tz = config.ok ? config.data.timezone : "America/Santiago";
  const [t, labels, acc, fmt] = await Promise.all([
    getTranslations("reservations"), getTranslations("labels.reservation"), getTranslations("account"), getFormat(),
  ]);
  const time = (iso: string) => fmt.dateTime(iso, { hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: tz });
  if (!res.ok) notFound();
  const r = res.data;
  // Saldo de la billetera: sólo hace falta si hay un pago pendiente.
  const [walletRes, w] = await Promise.all([
    r.can_pay ? api<WalletInfo>("/wallet") : Promise.resolve(null),
    getTranslations("wallet"),
  ]);
  const wallet = walletRes?.ok ? walletRes.data : null;

  const consequence =
    r.status === "PENDING_PAYMENT"
      ? t("cancelUnpaid")
      : r.refund_if_cancelled_now === r.total_amount
        ? t("cancelFree", { amount: fmt.money(r.total_amount, r.currency) })
        : Number(r.refund_if_cancelled_now ?? 0) > 0
          ? t("cancelLate", { amount: fmt.money(r.refund_if_cancelled_now!, r.currency) })
          : t("cancelNoRefund");

  return (
    <div className="space-y-8">
      <Link href="/account/reservations" className="text-sm text-slate hover:underline">{acc("navReservations")}</Link>
      <PageHeading title={r.service.name} description={(await getTranslations("boarding"))("booking", { code: r.code })} action={<StatusBadge status={r.status} />} />

      {created && !payment ? <Notice>{t("created")}</Notice> : null}
      {payment && PAYMENT_NOTICES[payment] ? (
        <div role="status" className={`border-l-2 px-4 py-3 text-sm ${PAYMENT_NOTICES[payment]!.ok ? "border-ok bg-ok/5 text-ok" : "border-alert bg-alert/5 text-alert"}`}>
          {t(PAYMENT_NOTICES[payment]!.key)}
        </div>
      ) : null}
      {payment === "wallet" ? <Notice>{w("paidNotice")}</Notice> : null}
      {cancelled ? <Notice>{t("cancelledNotice")}</Notice> : null}
      {r.can_pay ? (
        <div className="flex flex-wrap items-center justify-between gap-4 border-l-2 border-champagne bg-paper px-5 py-4 text-sm text-ink">
          <div>
            <p className="font-medium">{labels("PENDING_PAYMENT")}</p>
            <p className="mt-1 text-slate">
              {r.hold_expires_at
                ? t("holdUntil", { time: time(r.hold_expires_at) })
                : t("holdExpired")}
            </p>
          </div>
          <div className="flex flex-wrap items-start gap-4">
            <PayButton code={r.code} label={r.payments.length ? (await getTranslations("pay"))("retry") : undefined} />
            {wallet && Number(wallet.balance) >= Number(r.total_amount) ? (
              <PayWithWalletButton code={r.code} available={fmt.money(wallet.balance, wallet.currency)} />
            ) : null}
          </div>
        </div>
      ) : null}
      {r.status === "CANCELLED" ? (
        <Notice tone="info">
          {r.cancellation_reason ? t("cancelledReason", { reason: r.cancellation_reason }) : t("cancelledPlain")}{" "}
          {r.refund_amount !== null ? t("refundAmount", { amount: fmt.money(r.refund_amount, r.currency) }) : ""}
        </Notice>
      ) : null}

      <BoardingCard r={r} />
      <ChatSection as="customer" apiPath={`/reservations/${encodeURIComponent(r.code)}/messages`}
        endpoint={`/account/reservations/${encodeURIComponent(r.code)}/messages`} />

      <ReservationDetails r={r} />
      <ReceiptLinks href={`/account/reservations/${encodeURIComponent(r.code)}/receipt`} />
      {r.status === "COMPLETED" ? <ReviewSection code={r.code} displayName={shortName} /> : null}

      {r.payments.length ? (
        <section className="space-y-4 border-t border-ink/10 pt-8">
          <h2 className="font-display text-xl text-ink">{t("payments")}</h2>
          <PaymentList payments={r.payments} currency={r.currency} />
        </section>
      ) : null}

      <section className="space-y-4 border-t border-ink/10 pt-8">
        <h2 className="font-display text-xl text-ink">{t("policy")}</h2>
        <p className="text-slate">{r.cancellation_policy}</p>
        {r.can_cancel ? <CancelForm code={r.code} consequence={consequence} /> : null}
      </section>
    </div>
  );
}
