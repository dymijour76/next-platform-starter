"use client";

import { useActionState, useState } from "react";
import { Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { cancelReservationAction } from "./actions";
import { useTranslations } from "next-intl";

export function CancelForm({ code, consequence }: { code: string; consequence: string }) {
  const t = useTranslations("cancel");
  const [state, action] = useActionState(cancelReservationAction, initialFormState);
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)}
        className="rounded-sm border border-alert/40 bg-paper px-5 py-2.5 text-sm text-alert hover:border-alert">
        {t("open")}
      </button>
    );
  }
  return (
    <form action={action} className="max-w-xl space-y-4 border-l-2 border-alert bg-paper px-5 py-5">
      <FormAlert state={state} />
      <input type="hidden" name="code" value={code} />
      <p className="text-ink">{consequence}</p>
      <Textarea label={t("reason")} name="reason" rows={2} />
      <div className="flex flex-wrap gap-3">
        <SubmitButton variant="danger" pendingLabel={t("cancelling")}>{t("confirm")}</SubmitButton>
        <button type="button" onClick={() => setOpen(false)} className="px-3 text-sm text-slate hover:text-ink">
          {t("keep")}
        </button>
      </div>
    </form>
  );
}
