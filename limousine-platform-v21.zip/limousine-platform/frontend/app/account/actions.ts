"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, optional, pick, text, type FormState } from "@/lib/form";
import { clearSession, saveSession } from "@/lib/session";
import type { Me, TokenPair } from "@/lib/types";
import { getTranslations } from "next-intl/server";

const PROFILE_FIELDS = [
  "first_name", "last_name", "phone", "address", "city", "region", "company",
  "billing_tax_id", "billing_name", "billing_activity", "billing_address",
];

export async function updateProfileAction(_: FormState, form: FormData): Promise<FormState> {
  const values = pick(form, PROFILE_FIELDS);
  const body: Record<string, unknown> = {
    first_name: text(form, "first_name"),
    last_name: text(form, "last_name"),
    marketing_consent: form.get("marketing_consent") === "on",
  };
  for (const field of PROFILE_FIELDS.slice(2)) body[field] = optional(form, field);

  const res = await api<Me>("/users/me", { method: "PATCH", body });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/account", "layout");
  // Se muestran los datos tal como quedaron guardados (p. ej. el RUT normalizado).
  const saved = res.data;
  const p = saved.profile;
  return {
    status: "success",
    message: (await getTranslations("profile"))("saved"),
    values: {
      first_name: saved.first_name,
      last_name: saved.last_name,
      phone: saved.phone ?? "",
      address: p?.address ?? "",
      city: p?.city ?? "",
      region: p?.region ?? "",
      company: p?.company ?? "",
      billing_tax_id: p?.billing_tax_id ?? "",
      billing_name: p?.billing_name ?? "",
      billing_activity: p?.billing_activity ?? "",
      billing_address: p?.billing_address ?? "",
    },
  };
}

export async function changePasswordAction(_: FormState, form: FormData): Promise<FormState> {
  const res = await api<TokenPair>("/users/me/password", {
    method: "POST",
    body: {
      current_password: String(form.get("current_password") ?? ""),
      password: String(form.get("password") ?? ""),
      password_confirmation: String(form.get("password_confirmation") ?? ""),
    },
  });
  if (!res.ok) return fromApiError(res.error);
  // La API cerró las demás sesiones y devolvió tokens nuevos para esta.
  await saveSession(res.data);
  return {
    status: "success",
    message: (await getTranslations("security"))("passwordUpdated"),
  };
}

export async function changeEmailAction(_: FormState, form: FormData): Promise<FormState> {
  const email = text(form, "email");
  const res = await api<Me>("/users/me/email", {
    method: "POST",
    body: { email, current_password: String(form.get("current_password") ?? "") },
  });
  if (!res.ok) return fromApiError(res.error, { email });
  revalidatePath("/account", "layout");
  return {
    status: "success",
    message: (await getTranslations("security"))("emailPending", { email: res.data.email }),
  };
}

export async function resendVerificationAction(): Promise<void> {
  await api<void>("/auth/resend-verification", { method: "POST" });
  redirect("/account?resent=1");
}

export async function logoutAllAction(): Promise<void> {
  await api<void>("/auth/logout-all", { method: "POST" });
  await clearSession();
  redirect("/login?sessions=1");
}
