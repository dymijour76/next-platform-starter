"use server";

import QRCode from "qrcode";
import { revalidatePath } from "next/cache";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import { getTranslations } from "next-intl/server";

export interface MfaState extends FormState {
  step?: "setup" | "codes";
  secret?: string;
  qrSvg?: string;
  backupCodes?: string[];
}

export async function mfaSetupAction(_: MfaState, form: FormData): Promise<MfaState> {
  const res = await api<{ secret: string; otpauth_uri: string }>("/users/me/mfa/setup", {
    method: "POST",
    body: { current_password: String(form.get("current_password") ?? "") },
  });
  if (!res.ok) return fromApiError(res.error);
  const qrSvg = await QRCode.toString(res.data.otpauth_uri, { type: "svg", margin: 1, color: { dark: "#1b2433", light: "#ffffff" } });
  return { status: "idle", step: "setup", secret: res.data.secret, qrSvg };
}

export async function mfaEnableAction(prev: MfaState, form: FormData): Promise<MfaState> {
  const res = await api<{ backup_codes: string[] }>("/users/me/mfa/enable", {
    method: "POST",
    body: { code: text(form, "code") },
  });
  if (!res.ok) return { ...fromApiError(res.error), step: "setup", secret: prev.secret, qrSvg: prev.qrSvg };
  revalidatePath("/account", "layout");
  return { status: "success", step: "codes", backupCodes: res.data.backup_codes,
    message: (await getTranslations("mfa"))("enabled") };
}

export async function mfaRegenerateAction(_: MfaState, form: FormData): Promise<MfaState> {
  const res = await api<{ backup_codes: string[] }>("/users/me/mfa/backup-codes", {
    method: "POST",
    body: { code: text(form, "code") },
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/account", "layout");
  return { status: "success", step: "codes", backupCodes: res.data.backup_codes,
    message: (await getTranslations("mfa"))("regenerated") };
}

export async function mfaDisableAction(_: MfaState, form: FormData): Promise<MfaState> {
  const res = await api<void>("/users/me/mfa/disable", {
    method: "POST",
    body: { current_password: String(form.get("current_password") ?? ""), code: text(form, "code") },
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/account", "layout");
  return { status: "success", message: (await getTranslations("mfa"))("disabled") };
}
