import type { Metadata } from "next";
import Link from "next/link";
import { Notice } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { PageHeading } from "@/components/PageHeading";
import { PICKUP_FORMAT } from "@/components/reservations/ReservationDetails";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import { requireUser } from "@/lib/auth";
import type { ReservationSummary } from "@/lib/types";
import { resendVerificationAction } from "./actions";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("nav"))("account") };
}

export default async function AccountPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const [user, params] = await Promise.all([requireUser(), searchParams]);
  const upcoming = await api<ReservationSummary[]>("/reservations");
  const next = upcoming.ok ? upcoming.data[0] : undefined;
  const [t, a, fmt] = await Promise.all([getTranslations("account"), getTranslations("auth"), getFormat()]);
  // Frases completas por caso: unir fragmentos con "y" no funciona en todos los idiomas.
  const noPhone = !user.phone;
  const noBilling = !user.profile?.billing_tax_id;
  const missing = noPhone && noBilling ? "missingBoth" : noPhone ? "missingPhone" : noBilling ? "missingBilling" : null;

  return (
    <div className="space-y-8">
      <PageHeading title={t("hello", { name: user.first_name })} description={t("summaryIntro")} />

      {params.welcome === "1" ? <Notice>{t("welcome")}</Notice> : null}
      {params.verified === "1" ? <Notice>{t("verified")}</Notice> : null}
      {params.resent === "1" ? (
        <Notice>{t("resent")}</Notice>
      ) : null}

      {!user.email_verified ? (
        <div className="flex flex-wrap items-center justify-between gap-4 border-l-2 border-champagne bg-paper px-5 py-4">
          <p className="text-sm text-ink">
            {t.rich("confirmEmail", { email: user.email, strong: (chunks) => <strong className="font-medium">{chunks}</strong> })}
          </p>
          <form action={resendVerificationAction}>
            <SubmitButton variant="secondary" pendingLabel={a("sending")}>
              {t("resend")}
            </SubmitButton>
          </form>
        </div>
      ) : null}

      <dl className="grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-2">
        {[
          [a("firstName"), `${user.first_name} ${user.last_name}`],
          [a("email"), user.email],
          [a("phone"), user.phone ?? t("notRegistered")],
          [t("company"), user.profile?.company ?? t("notRegistered")],
        ].map(([term, value]) => (
          <div key={term} className="bg-paper px-5 py-4">
            <dt className="text-sm text-slate">{term}</dt>
            <dd className="mt-1 break-words text-ink">{value}</dd>
          </div>
        ))}
      </dl>

      {missing ? (
        <p className="text-sm text-slate">
          {t.rich(missing, {
            link: (chunks) => <Link href="/account/profile" className="text-ink underline decoration-champagne underline-offset-4">{chunks}</Link>,
          })}
        </p>
      ) : null}

      <section className="border-t border-ink/10 pt-8">
        <h2 className="font-display text-xl text-ink">{t("nextBooking")}</h2>
        {next ? (
          <Link href={`/account/reservations/${next.code}`} className="mt-4 flex flex-wrap items-center justify-between gap-4 bg-paper px-5 py-4 hover:bg-paper/70">
            <span>
              <span className="flex items-center gap-3"><span className="text-ink">{next.service.name}</span><StatusBadge status={next.status} /></span>
              <span className="mt-1 block text-sm text-slate first-letter:uppercase">{fmt.wall(next.pickup_local, PICKUP_FORMAT)}</span>
            </span>
            <span className="text-sm text-ink underline decoration-champagne underline-offset-4">{t("seeDetail")}</span>
          </Link>
        ) : (
          <p className="mt-2 text-slate">
            {t("noUpcoming")}{" "}
            <Link href="/book" className="text-ink underline decoration-champagne underline-offset-4">{t("bookNow")}</Link>
          </p>
        )}
      </section>
    </div>
  );
}
