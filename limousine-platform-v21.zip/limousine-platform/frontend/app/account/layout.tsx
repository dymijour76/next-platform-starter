import { SideNav } from "@/components/SideNav";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { requireUser } from "@/lib/auth";
import { getTranslations } from "next-intl/server";

const NAV = [
  { href: "/account", key: "navSummary" },
  { href: "/account/reservations", key: "navReservations" },
  { href: "/account/wallet", key: "navWallet" },
  { href: "/account/profile", key: "navProfile" },
  { href: "/account/security", key: "navSecurity" },
  { href: "/account/privacy", key: "navPrivacy" },
] as const;

export default async function AccountLayout({ children }: { children: React.ReactNode }) {
  const [, t, nav] = await Promise.all([requireUser(), getTranslations("account"), getTranslations("nav")]);
  return (
    <div className="min-h-dvh bg-pearl">
      <SiteHeader />
      <div className="mx-auto grid max-w-6xl gap-8 px-6 py-10 sm:px-10 lg:grid-cols-[12rem_minmax(0,1fr)] lg:gap-12">
        <SideNav items={NAV.map((n) => ({ href: n.href, label: t(n.key) }))} label={nav("account")} />
        <main>{children}</main>
      </div>
      <SiteFooter />
    </div>
  );
}
