import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { TopupForm } from "@/components/payments/WalletButtons";
import { WalletCard } from "@/components/payments/WalletCard";
import { config } from "@/lib/config";
import { api } from "@/lib/api-server";
import { requireUser } from "@/lib/auth";
import { getFormat } from "@/lib/format-server";
import type { WalletInfo } from "@/lib/types";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("wallet"))("title") };
}

export default async function WalletPage({ searchParams }: { searchParams: Promise<{ topup?: string }> }) {
  await requireUser("/account/wallet");
  const [{ topup }, res, site, t, fmt] = await Promise.all([
    searchParams, api<WalletInfo>("/wallet"), api<{ name: string }>("/site", { auth: false }),
    getTranslations("wallet"), getFormat(),
  ]);
  const company = site.ok ? site.data.name : config.companyName;
  if (!res.ok) throw new Error(res.error.message);
  const w = res.data;
  return (
    <div className="space-y-8">
      <PageHeading title={t("title")} description={t("hint")} />
      {topup === "paid" ? <Notice>{t("topupOk")}</Notice> : topup ? <Notice tone="info">{t("topupFailed")}</Notice> : null}
      <WalletCard company={company} number={w.number} holder={w.holder} balance={w.balance} currency={w.currency} />
      <p className="text-sm text-slate">{t("howToUse")}</p>
      {w.topup_enabled ? (
        <section aria-labelledby="topup" className="border border-ink/10 bg-paper p-6">
          <h2 id="topup" className="font-display text-xl text-ink">{t("topupTitle")}</h2>
          <div className="mt-4 max-w-sm">
            <TopupForm range={t("topupRange", { min: fmt.money(w.topup_min, w.currency), max: fmt.money(w.topup_max, w.currency) })} />
          </div>
        </section>
      ) : null}
      <section aria-labelledby="movements">
        <h2 id="movements" className="font-display text-xl text-ink">{t("movements")}</h2>
        {!w.entries.length ? <p className="mt-3 text-slate">{t("empty")}</p> : (
          <div className="mt-4 overflow-x-auto border border-ink/10 bg-paper">
            <table className="w-full text-sm">
              <thead className="text-left text-slate">
                <tr className="border-b border-ink/10">
                  <th className="px-4 py-3 font-medium">{t("colDate")}</th>
                  <th className="px-4 py-3 font-medium">{t("colDetail")}</th>
                  <th className="px-4 py-3 text-right font-medium">{t("colAmount")}</th>
                  <th className="px-4 py-3 text-right font-medium">{t("colBalance")}</th>
                </tr>
              </thead>
              <tbody>
                {w.entries.map((e) => {
                  const positive = Number(e.amount) > 0;
                  return (
                    <tr key={e.id} className="border-b border-ink/5 last:border-0">
                      <td className="whitespace-nowrap px-4 py-3 text-slate">{fmt.date(e.created_at)}</td>
                      <td className="px-4 py-3 text-ink">
                        {e.description}
                        {e.reason ? <span className="block text-xs text-slate">{e.reason}</span> : null}
                      </td>
                      <td className={`whitespace-nowrap px-4 py-3 text-right ${positive ? "text-ok" : "text-ink"}`}>
                        {positive ? "+" : "−"}{fmt.money(Math.abs(Number(e.amount)), w.currency)}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-right text-slate">{fmt.money(e.balance_after, w.currency)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
