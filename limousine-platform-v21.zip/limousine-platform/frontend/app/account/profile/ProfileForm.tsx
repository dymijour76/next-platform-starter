"use client";

import { useActionState } from "react";
import { Checkbox, Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { Section } from "@/components/PageHeading";
import type { FormState } from "@/lib/form";
import type { Me } from "@/lib/types";
import { updateProfileAction } from "../actions";
import { useTranslations } from "next-intl";

export function ProfileForm({ user }: { user: Me }) {
  const t = useTranslations("profile");
  const a = useTranslations("auth");
  const acc = useTranslations("account");
  const p = user.profile;
  const initial: FormState = {
    status: "idle",
    values: {
      first_name: user.first_name,
      last_name: user.last_name,
      phone: user.phone ?? "",
      address: p?.address ?? "",
      city: p?.city ?? "",
      region: p?.region ?? "",
      company: p?.company ?? "",
      billing_tax_id: p?.billing_tax_id ?? "",
      billing_name: p?.billing_name ?? "",
      billing_activity: p?.billing_activity ?? "",
      billing_address: p?.billing_address ?? "",
    },
  };
  const [state, action] = useActionState(updateProfileAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};

  return (
    <form action={action} className="space-y-10" noValidate key={JSON.stringify(v)}>
      <FormAlert state={state} />

      <Section title={t("personal")} description={t("personalHint")}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={a("firstName")} name="first_name" required autoComplete="given-name"
            defaultValue={v.first_name} error={f.first_name} />
          <Field label={a("lastName")} name="last_name" required autoComplete="family-name"
            defaultValue={v.last_name} error={f.last_name} />
          <Field label={a("phone")} name="phone" type="tel" autoComplete="tel" className="sm:col-span-2"
            placeholder="+56 9 1234 5678" defaultValue={v.phone} error={f.phone} />
        </div>
      </Section>

      <Section title={t("address")} description={t("addressHint")}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={t("address")} name="address" autoComplete="street-address" className="sm:col-span-2"
            defaultValue={v.address} error={f.address} />
          <Field label={t("city")} name="city" autoComplete="address-level2"
            defaultValue={v.city} error={f.city} />
          <Field label={t("region")} name="region" autoComplete="address-level1"
            defaultValue={v.region} error={f.region} />
        </div>
      </Section>

      <Section title={t("billing")} description={t("billingHint")}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={acc("company")} name="company" autoComplete="organization" className="sm:col-span-2"
            defaultValue={v.company} error={f.company} />
          <Field label={t("taxId")} name="billing_tax_id" placeholder="76.543.210-3"
            defaultValue={v.billing_tax_id} error={f.billing_tax_id} />
          <Field label={t("businessName")} name="billing_name"
            defaultValue={v.billing_name} error={f.billing_name} />
          <Field label={t("activity")} name="billing_activity"
            defaultValue={v.billing_activity} error={f.billing_activity} />
          <Field label={t("billingAddress")} name="billing_address"
            defaultValue={v.billing_address} error={f.billing_address} />
        </div>
      </Section>

      <Section title={t("communications")}>
        <Checkbox name="marketing_consent" defaultChecked={p?.marketing_consent}>
          {a("marketing")}
        </Checkbox>
      </Section>

      <div className="border-t border-ink/10 pt-6">
        <SubmitButton pendingLabel={a("saving")}>{t("save")}</SubmitButton>
      </div>
    </form>
  );
}
