import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { PageHeading } from "@/components/PageHeading";
import { requireUser } from "@/lib/auth";
import { ProfileForm } from "./ProfileForm";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("account"))("navProfile") };
}

export default async function ProfilePage() {
  const user = await requireUser("/account/profile");
  return (
    <div className="space-y-8">
      <PageHeading title={(await getTranslations("account"))("navProfile")} />
      <ProfileForm user={user} />
    </div>
  );
}
