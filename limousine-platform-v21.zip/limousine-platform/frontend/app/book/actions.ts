"use server";

import { randomUUID } from "node:crypto";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, text } from "@/lib/form";
import { zonedToIso } from "@/lib/timezone";
import type { BookingPreview, PaymentRedirect, PublicPricingConfig, Reservation } from "@/lib/types";
import { getTranslations } from "next-intl/server";

export interface PreviewState {
  status: "idle" | "error" | "success";
  message?: string;
  fields?: Record<string, string>;
  values?: Record<string, string>;
  preview?: BookingPreview;
  pickupAt?: string;
  /** Un identificador por intento: si el cliente pulsa dos veces, se crea una sola reserva. */
  idempotencyKey?: string;
}

export async function previewAction(_: PreviewState, form: FormData): Promise<PreviewState> {
  const values = {
    service_id: text(form, "service_id"),
    date: text(form, "date"),
    time: text(form, "time"),
    duration: text(form, "duration"),
  };
  const config = await api<PublicPricingConfig>("/pricing/config", { auth: false });
  if (!config.ok) return fromApiError(config.error, values);
  const pickupAt = zonedToIso(values.date, values.time, config.data.timezone);
  const t = await getTranslations("form");
  if (!pickupAt) {
    return {
      status: "error",
      message: t("checkData"),
      fields: {
        ...(values.date ? {} : { date: t("chooseDate") }),
        ...(values.time ? {} : { time: t("chooseTime") }),
      },
      values,
    };
  }
  const res = await api<BookingPreview>("/reservations/preview", {
    method: "POST",
    body: { service_id: values.service_id, pickup_at: pickupAt, duration_minutes: Number(values.duration) },
  });
  if (!res.ok) {
    const state = fromApiError(res.error, values);
    if (state.fields?.pickup_at) state.fields = { ...state.fields, date: state.fields.pickup_at };
    return state;
  }
  return { status: "success", values, preview: res.data, pickupAt, idempotencyKey: randomUUID() };
}

export interface BookState {
  status: "idle" | "error" | "redirect";
  redirect?: PaymentRedirect;
  message?: string;
  code?: string;
  fields?: Record<string, string>;
  values?: Record<string, string>;
}

const DETAIL_FIELDS = ["pickup_address", "dropoff_address", "passenger_count", "contact_name",
  "contact_email", "contact_phone", "notes"];

export async function bookAction(_: BookState, form: FormData): Promise<BookState> {
  const values = Object.fromEntries(DETAIL_FIELDS.map((n) => [n, text(form, n)]));
  const res = await api<Reservation>("/reservations", {
    method: "POST",
    body: {
      service_id: text(form, "service_id"),
      pickup_at: text(form, "pickup_at"),
      duration_minutes: Number(text(form, "duration")),
      expected_total: text(form, "expected_total"),
      idempotency_key: text(form, "idempotency_key"),
      pickup_address: values.pickup_address,
      dropoff_address: values.dropoff_address || null,
      passenger_count: Number(values.passenger_count),
      contact_name: values.contact_name,
      contact_email: values.contact_email,
      contact_phone: values.contact_phone,
      notes: values.notes || null,
      accept_policy: form.get("accept_policy") === "on",
    },
  });
  if (!res.ok) {
    return { status: "error", code: res.error.code, message: res.error.message, fields: res.error.fields, values };
  }
  // Reserva creada: se envía al cliente a pagar. Si la pasarela no responde, la
  // reserva queda pendiente y puede reintentar el pago desde su detalle.
  const pay = await api<PaymentRedirect>(`/reservations/${encodeURIComponent(res.data.code)}/pay`, {
    method: "POST",
  });
  if (!pay.ok) redirect(`/account/reservations/${res.data.code}?created=1&payment=unavailable`);
  return { status: "redirect", redirect: pay.data };
}
