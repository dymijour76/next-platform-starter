import type { Metadata } from "next";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { api } from "@/lib/api-server";
import { requireUser } from "@/lib/auth";
import { todayIn } from "@/lib/timezone";
import type { BookingPolicy, PublicPricingConfig, Service } from "@/lib/types";
import { BookingFlow } from "./BookingFlow";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("nav"))("book") };
}

export default async function BookPage({ searchParams }: { searchParams: Promise<{ service?: string }> }) {
  const [{ service: slug }, user] = await Promise.all([searchParams, requireUser("/book")]);
  const [services, config, policy] = await Promise.all([
    api<Service[]>("/services", { auth: false }),
    api<PublicPricingConfig>("/pricing/config", { auth: false }),
    api<BookingPolicy>("/booking/policy", { auth: false }),
  ]);
  const list = services.ok ? services.data : [];
  const initial = list.find((s) => s.slug === slug) ?? list[0];

  return (
    <div className="min-h-dvh bg-pearl">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-6 py-12 sm:px-10">
        <h1 className="font-display text-4xl text-ink sm:text-5xl">{(await getTranslations("nav"))("book")}</h1>
        <div className="mt-10">
          {!config.ok || !policy.ok || !services.ok ? (
            <p role="alert" className="text-alert">
              {(await getTranslations("book"))("loadError")}
            </p>
          ) : (
            <BookingFlow
              services={list}
              initialServiceId={initial?.id ?? ""}
              increment={config.data.billing_increment_minutes}
              minDate={todayIn(config.data.timezone)}
              policy={policy.data}
              contact={{
                name: `${user.first_name} ${user.last_name}`,
                email: user.email,
                phone: user.phone ?? "",
              }}
              defaultAddress={[user.profile?.address, user.profile?.city].filter(Boolean).join(", ")}
            />
          )}
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
