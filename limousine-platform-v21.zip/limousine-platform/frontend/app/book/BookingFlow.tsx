"use client";

import { useActionState, useState } from "react";
import { Checkbox, Field, Select, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { GatewayRedirect } from "@/components/payments/GatewayRedirect";
import { QuoteBreakdown } from "@/components/pricing/QuoteBreakdown";
import { durationOptions } from "@/lib/money";
import type { BookingPolicy, Service } from "@/lib/types";
import { bookAction, previewAction, type BookState, type PreviewState } from "./actions";
import { useTranslations } from "next-intl";
import { useFormat } from "@/lib/format-client";

interface Props {
  services: Service[];
  initialServiceId: string;
  increment: number;
  minDate: string;
  policy: BookingPolicy;
  contact: { name: string; email: string; phone: string };
  defaultAddress: string;
}

export function BookingFlow({ services, initialServiceId, increment, minDate, policy, contact, defaultAddress }: Props) {
  const t = useTranslations("book");
  const q = useTranslations("quote");
  const fmt = useFormat();
  const [preview, previewDispatch] = useActionState<PreviewState, FormData>(previewAction, { status: "idle" });
  const [booked, bookDispatch] = useActionState<BookState, FormData>(bookAction, { status: "idle" });
  const [editing, setEditing] = useState(false);
  const [serviceId, setServiceId] = useState(preview.values?.service_id || initialServiceId);

  const service = services.find((s) => s.id === serviceId) ?? services[0];
  if (booked.status === "redirect" && booked.redirect) {
    return (
      <div className="max-w-xl border-l-2 border-champagne bg-paper px-6 py-6">
        <p className="font-display text-2xl text-ink">{t("registered")}</p>
        <p className="mt-2 mb-6 text-slate">{t("holdWhilePaying")}</p>
        <GatewayRedirect redirect={booked.redirect} />
      </div>
    );
  }
  if (!service) return <p className="text-slate">{t("noServices")}</p>;

  const v = preview.values ?? {};
  const f = preview.fields ?? {};
  const ready = preview.status === "success" && preview.preview?.available && !editing;
  const durations = durationOptions(service.min_hours, service.max_hours, increment);

  return (
    <div className="grid gap-12 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
      <div className="space-y-12">
        {/* Paso 1: servicio y horario */}
        <section aria-labelledby="step-1">
          <h2 id="step-1" className="font-display text-2xl text-ink">{t("step1")}</h2>
          {ready ? (
            <>
              <div className="mt-4 flex flex-wrap items-baseline justify-between gap-4 border-l-2 border-champagne bg-paper px-5 py-4">
                <p className="text-ink">
                  {service.name}, {fmt.duration(Number(v.duration))}
                </p>
                <button type="button" onClick={() => setEditing(true)} className="text-sm text-ink underline underline-offset-4">
                  {t("change")}
                </button>
              </div>
              {/* En pantallas pequeñas el precio va aquí, antes de los datos del viaje. */}
              <div className="mt-4 lg:hidden">
                <QuoteBreakdown quote={preview.preview!.quote} />
              </div>
            </>
          ) : (
            <form action={(fd) => { setEditing(false); previewDispatch(fd); }} className="mt-6 space-y-5" noValidate
              key={JSON.stringify(v)}>
              {preview.status === "error" && !Object.keys(f).length ? <FormAlert state={preview} /> : null}
              <Select label={q("service")} name="service_id" value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
                {services.map((s) => (
                  <option key={s.id} value={s.id}>
                    {t("serviceOption", { name: s.name, count: s.passenger_capacity })}
                  </option>
                ))}
              </Select>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label={q("date")} name="date" type="date" required min={minDate} defaultValue={v.date} error={f.date} />
                <Field label={q("time")} name="time" type="time" required step={300} defaultValue={v.time} error={f.time} />
              </div>
              <Select label={q("duration")} name="duration" key={service.id} error={f.duration_minutes}
                defaultValue={v.duration && durations.includes(Number(v.duration)) ? v.duration : String(durations[0])}>
                {durations.map((m) => (
                  <option key={m} value={m}>{fmt.duration(m)}</option>
                ))}
              </Select>
              {preview.status === "success" && !preview.preview?.available ? (
                <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">
                  {t("unavailable")}
                </p>
              ) : null}
              <SubmitButton pendingLabel={t("checking")}>{t("checkAvailability")}</SubmitButton>
            </form>
          )}
        </section>

        {/* Paso 2: datos del viaje */}
        <section aria-labelledby="step-2" className={ready ? "" : "opacity-50"}>
          <h2 id="step-2" className="font-display text-2xl text-ink">{t("step2")}</h2>
          {!ready ? (
            <p className="mt-3 text-sm text-slate">{t("chooseFirst")}</p>
          ) : (
            <BookingDetails
              state={booked}
              dispatch={bookDispatch}
              preview={preview}
              contact={contact}
              defaultAddress={defaultAddress}
              policy={policy}
            />
          )}
        </section>
      </div>

      <aside className="hidden lg:sticky lg:top-8 lg:block lg:self-start">
        <h2 className="font-display text-xl text-ink">{t("summary")}</h2>
        <div className="mt-4">
          {preview.status === "success" && preview.preview && !editing ? (
            <QuoteBreakdown quote={preview.preview.quote} />
          ) : (
            <p className="border border-dashed border-ink/20 px-5 py-8 text-center text-sm text-slate">
              {t("pricePlaceholder")}
            </p>
          )}
        </div>
      </aside>
    </div>
  );
}

function BookingDetails({
  state, dispatch, preview, contact, defaultAddress, policy,
}: {
  state: BookState;
  dispatch: (fd: FormData) => void;
  preview: PreviewState;
  contact: Props["contact"];
  defaultAddress: string;
  policy: BookingPolicy;
}) {
  const p = preview.preview!;
  const v = state.values ?? {};
  const f = state.fields ?? {};
  const passengers = Array.from({ length: p.passenger_capacity }, (_, i) => i + 1);
  const t = useTranslations("book");
  const a = useTranslations("auth");
  const d = useTranslations("details");
  const s = useTranslations("service");
  return (
    <form action={dispatch} className="mt-6 space-y-5" noValidate key={JSON.stringify(v)}>
      {state.status === "error" ? <FormAlert state={{ status: "error", message: state.message }} /> : null}
      <input type="hidden" name="service_id" value={preview.values?.service_id} />
      <input type="hidden" name="pickup_at" value={preview.pickupAt} />
      <input type="hidden" name="duration" value={preview.values?.duration} />
      <input type="hidden" name="expected_total" value={p.quote.total} />
      <input type="hidden" name="idempotency_key" value={preview.idempotencyKey} />

      <Field label={t("pickupAddress")} name="pickup_address" required autoComplete="street-address"
        defaultValue={v.pickup_address ?? defaultAddress} error={f.pickup_address}
        hint={t("pickupHint")} />
      <Field label={d("destination")} name="dropoff_address" defaultValue={v.dropoff_address} error={f.dropoff_address}
        hint={t("destinationHint")} />
      <Select label={s("passengers")} name="passenger_count" defaultValue={v.passenger_count ?? "1"} error={f.passenger_count}>
        {passengers.map((n) => <option key={n} value={n}>{n}</option>)}
      </Select>

      <div role="group" aria-labelledby="contact-title" className="space-y-5 border-t border-ink/10 pt-5">
        <div>
          <h3 id="contact-title" className="text-sm font-medium text-ink">{t("contactTitle")}</h3>
          <p className="mt-1 text-sm text-slate">{t("contactHint")}</p>
        </div>
        <Field label={t("contactName")} name="contact_name" required autoComplete="name"
          defaultValue={v.contact_name ?? contact.name} error={f.contact_name} />
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={a("email")} name="contact_email" type="email" required autoComplete="email"
            defaultValue={v.contact_email ?? contact.email} error={f.contact_email} />
          <Field label={a("phone")} name="contact_phone" type="tel" required autoComplete="tel"
            defaultValue={v.contact_phone ?? contact.phone} error={f.contact_phone} />
        </div>
      </div>

      <Textarea label={d("notes")} name="notes" rows={3} defaultValue={v.notes} error={f.notes}
        hint={t("notesHint")} />

      <div className="space-y-3 border-t border-ink/10 pt-5">
        <p className="text-sm text-ink">{policy.text}</p>
        <Checkbox name="accept_policy" required error={f.accept_policy}>
          {t("acceptPolicy")}
        </Checkbox>
      </div>
      <p className="text-sm text-slate">
        {t("payNote", { button: t("bookAndPay") })}
      </p>
      <SubmitButton pendingLabel={t("booking")}>{t("bookAndPay")}</SubmitButton>
    </form>
  );
}
