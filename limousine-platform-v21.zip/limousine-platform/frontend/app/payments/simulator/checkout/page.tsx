import type { Metadata } from "next";
import { api } from "@/lib/api-server";
import { SimulatorForm } from "./SimulatorForm";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("simulator"))("metaTitle"), robots: { index: false } };
}

/** Imita la pantalla de pago de la pasarela. Sólo funciona con PAYMENT_PROVIDER=simulated. */
export default async function SimulatorPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const [{ token = "" }, t, fmt] = await Promise.all([searchParams, getTranslations("simulator"), getFormat()]);
  const res = await api<{ amount: string; buy_order: string }>(`/payments/simulator/${encodeURIComponent(token)}`, { auth: false });
  return (
    <main className="flex min-h-dvh items-center justify-center bg-[#eef1f4] px-6 py-12">
      <div className="w-full max-w-md border border-ink/10 bg-paper p-8 shadow-sm">
        <p className="text-xs font-medium uppercase tracking-widest text-alert">{t("warning")}</p>
        <h1 className="mt-3 font-display text-3xl text-ink">{t("title")}</h1>
        {res.ok ? (
          <>
            <dl className="mt-6 space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-slate">{t("order")}</dt><dd className="text-ink">{res.data.buy_order}</dd></div>
              <div className="flex justify-between"><dt className="text-slate">{t("amount")}</dt><dd className="font-display text-xl text-ink">{fmt.money(res.data.amount)}</dd></div>
            </dl>
            <p className="mt-6 text-sm text-slate">{t("choose")}</p>
            <div className="mt-4"><SimulatorForm token={token} /></div>
          </>
        ) : (
          <p role="alert" className="mt-6 text-alert">{res.error.message}</p>
        )}
      </div>
    </main>
  );
}
