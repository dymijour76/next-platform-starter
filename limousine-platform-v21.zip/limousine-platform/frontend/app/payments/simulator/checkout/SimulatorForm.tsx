"use client";

import { useActionState } from "react";
import { FormAlert } from "@/components/forms/FormAlert";
import { GatewayRedirect } from "@/components/payments/GatewayRedirect";
import { simulatorAction, type PayState } from "../../actions";
import { useTranslations } from "next-intl";

export function SimulatorForm({ token }: { token: string }) {
  const t = useTranslations("simulator");
  const [state, action, pending] = useActionState<PayState, FormData>(simulatorAction, { status: "idle" });
  if (state.status === "redirect" && state.redirect) {
    return <GatewayRedirect redirect={state.redirect} label={t("back")} />;
  }
  const button = "rounded-sm px-5 py-2.5 text-sm font-medium disabled:opacity-60";
  return (
    <form action={action} className="space-y-5">
      {state.status === "error" ? <FormAlert state={{ status: "error", message: state.message }} /> : null}
      <input type="hidden" name="token" value={token} />
      <div className="flex flex-wrap gap-3">
        <button name="decision" value="approve" disabled={pending} className={`${button} bg-ok text-paper`}>{t("approve")}</button>
        <button name="decision" value="reject" disabled={pending} className={`${button} border border-alert/40 text-alert`}>{t("reject")}</button>
        <button name="decision" value="abort" disabled={pending} className={`${button} text-slate hover:text-ink`}>{t("abort")}</button>
      </div>
    </form>
  );
}
