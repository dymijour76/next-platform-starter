import { NextResponse, type NextRequest } from "next/server";

/**
 * Entrada a la pasarela simulada (sólo desarrollo). Recibe el mismo formulario
 * POST con token_ws que recibiría Webpay y muestra la pantalla de decisión.
 */
export async function POST(request: NextRequest) {
  let token = "";
  try {
    token = String((await request.formData()).get("token_ws") ?? "");
  } catch {
    // cuerpo inválido: se muestra el error en la página
  }
  const target = `/payments/simulator/checkout?token=${encodeURIComponent(token.slice(0, 100))}`;
  return new NextResponse(null, { status: 303, headers: { Location: target } });
}
