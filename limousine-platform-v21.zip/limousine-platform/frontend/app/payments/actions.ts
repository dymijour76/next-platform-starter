"use server";

import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { text } from "@/lib/form";
import type { PaymentRedirect } from "@/lib/types";

export interface PayState {
  status: "idle" | "error" | "redirect";
  message?: string;
  redirect?: PaymentRedirect;
}

/** Inicia (o reintenta) el pago de una reserva propia. */
export async function payAction(_: PayState, form: FormData): Promise<PayState> {
  const res = await api<PaymentRedirect>(`/reservations/${encodeURIComponent(text(form, "code"))}/pay`, {
    method: "POST",
  });
  if (!res.ok) return { status: "error", message: res.error.message };
  return { status: "redirect", redirect: res.data };
}

/** Pasarela simulada: registra la decisión y devuelve el formulario de retorno. */
export async function simulatorAction(_: PayState, form: FormData): Promise<PayState> {
  const res = await api<PaymentRedirect>(`/payments/simulator/${encodeURIComponent(text(form, "token"))}`, {
    method: "POST",
    auth: false,
    body: { decision: text(form, "decision") },
  });
  if (!res.ok) return { status: "error", message: res.error.message };
  return { status: "redirect", redirect: res.data };
}

/** Recarga de saldo: la API devuelve la redirección a la pasarela (si la recarga está habilitada). */
export async function topupAction(_: PayState, form: FormData): Promise<PayState> {
  const amount = Number(text(form, "amount").replace(/[^0-9]/g, ""));
  const res = await api<PaymentRedirect>("/wallet/topups", { method: "POST", body: { amount } });
  if (!res.ok) return { status: "error", message: res.error.message };
  return { status: "redirect", redirect: res.data };
}

/** Paga la reserva completa con el saldo de la billetera. */
export async function payWithWalletAction(_: PayState, form: FormData): Promise<PayState> {
  const code = text(form, "code");
  const res = await api(`/reservations/${encodeURIComponent(code)}/pay-with-wallet`, { method: "POST" });
  if (!res.ok) return { status: "error", message: res.error.message };
  redirect(`/account/reservations/${encodeURIComponent(code)}?payment=wallet`);
}
