import { NextResponse, type NextRequest } from "next/server";
import { api } from "@/lib/api-server";

/**
 * Retorno desde la pasarela de pago. Webpay vuelve con token_ws (o con
 * TBK_TOKEN si el cliente abandonó), por GET o por POST según el caso, así
 * que se aceptan ambos. La API confirma el pago directamente con el proveedor:
 * nada de lo que llega aquí se da por válido sin esa verificación.
 *
 * El retorno es una navegación desde otro sitio, así que puede llegar sin la
 * cookie de sesión; por eso esta ruta no la necesita.
 */
const FIELDS = ["token_ws", "TBK_TOKEN", "TBK_ORDEN_COMPRA", "TBK_ID_SESION"] as const;

async function handle(params: URLSearchParams | FormData) {
  const body: Record<string, string> = {};
  for (const field of FIELDS) {
    const value = params.get(field);
    if (typeof value === "string" && value) body[field] = value.slice(0, 100);
  }
  const res = await api<{ reservation_code: string | null; outcome: string; topup?: boolean }>("/payments/return", {
    method: "POST",
    auth: false,
    body,
  });
  const outcome = res.ok ? res.data.outcome : "error";
  const code = res.ok ? res.data.reservation_code : null;
  const target = code
    ? `/account/reservations/${encodeURIComponent(code)}?payment=${outcome}`
    : res.ok && res.data.topup
      ? `/account/wallet?topup=${outcome}` // recarga de saldo
      : `/account/reservations?payment=${outcome}`;
  // 303: el navegador sigue con GET aunque haya llegado por POST. La dirección es
  // relativa: detrás de un proxy, el origen que ve Next.js no es el del cliente.
  return new NextResponse(null, { status: 303, headers: { Location: target } });
}

export async function GET(request: NextRequest) {
  return handle(request.nextUrl.searchParams);
}

export async function POST(request: NextRequest) {
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    form = new FormData();
  }
  // Algunos retornos combinan parámetros en la URL y en el cuerpo.
  for (const [k, v] of request.nextUrl.searchParams) if (!form.has(k)) form.set(k, v);
  return handle(form);
}
