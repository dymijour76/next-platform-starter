"use server";

import { revalidatePath } from "next/cache";
import { api } from "@/lib/api-server";
import { text, type FormState } from "@/lib/form";
import type { Trip } from "@/lib/types";
import { getTranslations } from "next-intl/server";

const DONE = new Set(["EN_ROUTE", "ARRIVED", "NO_SHOW", "COMPLETED"]);

export async function tripStatusAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "id");
  const status = text(form, "status");
  const res = await api<Trip>(`/driver/trips/${encodeURIComponent(id)}/status`, {
    method: "POST",
    body: { status, note: text(form, "note") || null },
  });
  if (!res.ok) return { status: "error", message: res.error.message };
  revalidatePath("/driver", "layout");
  const t = await getTranslations("driver");
  return { status: "success", message: DONE.has(status) ? t(`done.${status}`) : t("updated") };
}

export async function boardAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "id");
  const qr = text(form, "qr_token");
  const res = await api<Trip>(`/driver/trips/${encodeURIComponent(id)}/board`, {
    method: "POST",
    body: qr ? { qr_token: qr } : { without_qr: form.get("without_qr") === "true" },
  });
  if (!res.ok) return { status: "error", message: res.error.message };
  revalidatePath("/driver", "layout");
  return { status: "success", message: (await getTranslations("driver"))("boarded") };
}

/** Una sola acción para todos los pasos: así el mensaje en pantalla es siempre el del último. */
export async function tripAction(prev: FormState, form: FormData): Promise<FormState> {
  return form.get("kind") === "board" ? boardAction(prev, form) : tripStatusAction(prev, form);
}
