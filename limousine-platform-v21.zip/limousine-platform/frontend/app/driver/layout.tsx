import Link from "next/link";
import { redirect } from "next/navigation";
import { logoutAction } from "@/app/(auth)/actions";
import { can, requireUser } from "@/lib/auth";
import { config } from "@/lib/config";
import { getTranslations } from "next-intl/server";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

/** Panel del conductor: pensado para el teléfono, con botones grandes. */
export default async function DriverLayout({ children }: { children: React.ReactNode }) {
  const [user, t] = await Promise.all([requireUser("/driver"), getTranslations("driver")]);
  if (!can(user, "driver_portal:access")) redirect("/account");
  return (
    <div className="min-h-dvh bg-pearl">
      <header className="sticky top-0 z-10 bg-ink text-pearl" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
        <div className="mx-auto flex max-w-2xl items-center justify-between px-5 py-4">
          <Link href="/driver" className="font-display text-lg">{config.companyName}</Link>
          <div className="flex items-center gap-4 text-sm">
            <span className="text-pearl/70">{user.first_name}</span>
            {/* Selector de idioma: el panel del conductor no usa la cabecera del sitio. */}
            <LanguageSwitcher dark />
            <form action={logoutAction}><button type="submit" className="text-pearl/80 underline-offset-4 hover:underline">{t("logout")}</button></form>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-2xl px-5 py-6">{children}</main>
    </div>
  );
}
