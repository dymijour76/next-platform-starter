import type { Metadata } from "next";
import Link from "next/link";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import type { Trip } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("nav"))("myTrips") };
}

const TIME: Intl.DateTimeFormatOptions = { hour: "2-digit", minute: "2-digit", hourCycle: "h23" };
const DAY: Intl.DateTimeFormatOptions = { weekday: "long", day: "numeric", month: "long" };

export default async function DriverHome({ searchParams }: { searchParams: Promise<{ scope?: string }> }) {
  const { scope } = await searchParams;
  const past = scope === "past";
  const ct = await getTranslations("chat");
  const [tr, nav, r, fmt] = await Promise.all([
    getTranslations("driver"), getTranslations("nav"), getTranslations("reservations"), getFormat(),
  ]);
  const res = await api<Trip[]>("/driver/trips", { query: { scope: past ? "past" : "upcoming" } });
  const tab = (active: boolean) =>
    `flex-1 border-b-2 pb-3 text-center text-sm ${active ? "border-champagne text-ink" : "border-transparent text-slate"}`;

  return (
    <div className="space-y-6">
      <h1 className="font-display text-3xl text-ink">{nav("myTrips")}</h1>
      <nav aria-label={tr("tabs")} className="flex border-b border-ink/10">
        <Link href="/driver" aria-current={!past ? "page" : undefined} className={tab(!past)}>{tr("upcoming")}</Link>
        <Link href="/driver?scope=past" aria-current={past ? "page" : undefined} className={tab(past)}>{r("history")}</Link>
      </nav>
      {!res.ok ? (
        <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="py-8 text-center text-slate">{past ? tr("noPast") : tr("noTrips")}</p>
      ) : (
        <ul className="space-y-3">
          {res.data.map((t) => (
            <li key={t.id}>
              <Link href={`/driver/trips/${t.id}`} className="block bg-paper px-5 py-4 shadow-sm active:bg-paper/70">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-3xl tabular-nums text-ink">{fmt.wall(t.pickup_local, TIME)}</p>
                    <p className="text-sm text-slate first-letter:uppercase">{fmt.wall(t.pickup_local, DAY)}</p>
                  </div>
                  <StatusBadge status={t.status} />
                </div>
                <p className="mt-3 text-ink">{t.pickup_address}</p>
                <p className="mt-1 text-sm text-slate">{tr("tripSummary", { service: t.service_name, count: t.passenger_count, contact: t.contact_name })}</p>
                {t.unread_messages ? (
                  <p className="mt-2 inline-block rounded-sm bg-champagne/30 px-2 py-0.5 text-xs font-medium text-ink">
                    {ct("unread", { count: t.unread_messages })}
                  </p>
                ) : null}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
