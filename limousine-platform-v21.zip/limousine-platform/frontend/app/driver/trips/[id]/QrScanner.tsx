"use client";

import { useEffect, useRef, useState } from "react";
import { useTranslations } from "next-intl";

// BarcodeDetector existe en Chrome para Android y otros navegadores modernos, pero no en
// Safari (iPhone). Ahí se decodifica cada cuadro de la cámara con jsQR.
type Detector = { detect(source: HTMLVideoElement): Promise<{ rawValue: string }[]> };
declare global {
  interface Window {
    BarcodeDetector?: new (options: { formats: string[] }) => Detector;
  }
}

type Reader = (video: HTMLVideoElement) => Promise<string | null>;

async function makeReader(canvas: HTMLCanvasElement): Promise<Reader> {
  if (window.BarcodeDetector) {
    const detector = new window.BarcodeDetector({ formats: ["qr_code"] });
    return async (video) => (await detector.detect(video).catch(() => []))[0]?.rawValue ?? null;
  }
  const { default: jsQR } = await import("jsqr");
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  return async (video) => {
    if (!ctx || !video.videoWidth) return null;
    // Se analiza una versión reducida del cuadro: suficiente para un QR y más rápido.
    const scale = Math.min(1, 640 / video.videoWidth);
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const frame = ctx.getImageData(0, 0, canvas.width, canvas.height);
    return jsQR(frame.data, frame.width, frame.height, { inversionAttempts: "dontInvert" })?.data ?? null;
  };
}

/** Lee el QR con la cámara trasera. Si no puede abrirla, lo dice y ofrece la alternativa. */
export function QrScanner({ onDetected, onCancel }: { onDetected: (value: string) => void; onCancel: () => void }) {
  const t = useTranslations("driver");
  const video = useRef<HTMLVideoElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  // La función puede cambiar en cada render; la cámara no debe reiniciarse por eso.
  const detected = useRef(onDetected);
  useEffect(() => {
    detected.current = onDetected;
  }, [onDetected]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    let timer: number | undefined;
    let done = false;

    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      } catch {
        setError(t("cameraError"));
        return;
      }
      if (!video.current || !canvas.current || done) return;
      video.current.srcObject = stream;
      await video.current.play().catch(() => undefined);
      const read = await makeReader(canvas.current);
      timer = window.setInterval(async () => {
        if (!video.current || done) return;
        const value = await read(video.current);
        if (value) {
          done = true;
          detected.current(value);
        }
      }, 300);
    })();

    return () => {
      done = true;
      window.clearInterval(timer);
      stream?.getTracks().forEach((track) => track.stop());
    };
    // t sólo cambia si cambia el idioma: la cámara se abre una vez.
  }, [t]);

  return (
    <div className="space-y-3">
      {error ? (
        <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">{error}</p>
      ) : (
        <div className="relative overflow-hidden rounded-sm bg-ink">
          {/* playsInline y muted: sin ellos, Safari abre el video a pantalla completa */}
          <video ref={video} className="aspect-square w-full object-cover" muted playsInline />
          <div className="pointer-events-none absolute inset-10 border-2 border-champagne" aria-hidden="true" />
          <p className="absolute inset-x-0 bottom-3 text-center text-sm text-pearl">{t("aim")}</p>
        </div>
      )}
      <canvas ref={canvas} className="hidden" aria-hidden="true" />
      <button type="button" onClick={onCancel} className="w-full py-2 text-sm text-slate">{t("cancel")}</button>
    </div>
  );
}
