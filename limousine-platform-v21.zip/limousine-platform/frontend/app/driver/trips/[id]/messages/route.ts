import type { NextRequest } from "next/server";
import { proxyChat } from "@/lib/chat-proxy";

type Params = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, { params }: Params) {
  return proxyChat(request, `/driver/trips/${encodeURIComponent((await params).id)}/messages`);
}

export async function POST(request: NextRequest, { params }: Params) {
  return proxyChat(request, `/driver/trips/${encodeURIComponent((await params).id)}/messages`);
}
