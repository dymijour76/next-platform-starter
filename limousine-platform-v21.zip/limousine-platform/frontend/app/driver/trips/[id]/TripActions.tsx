"use client";

import { startTransition, useActionState, useState } from "react";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import type { TripAction } from "@/lib/types";
import { tripAction } from "../../actions";
import { QrScanner } from "./QrScanner";
import { useTranslations } from "next-intl";

// Texto del botón de cada paso y del estado "enviando" (claves de driver.*).
const PENDING: Record<Exclude<TripAction, "BOARD">, "notifying" | "recording" | "finishing"> = {
  EN_ROUTE: "notifying",
  ARRIVED: "recording",
  NO_SHOW: "recording",
  COMPLETED: "finishing",
};

const big = "w-full py-4 text-base";

export function TripActions({ id, actions }: { id: string; actions: TripAction[] }) {
  const t = useTranslations("driver");
  const [state, action] = useActionState(tripAction, initialFormState);
  const [scanning, setScanning] = useState(false);
  const [confirmNoShow, setConfirmNoShow] = useState(false);

  return (
    <div className="space-y-4">
      <FormAlert state={state} />
      {actions.includes("BOARD") ? (
        <div className="space-y-3">
          {scanning ? (
            <QrScanner onCancel={() => setScanning(false)} onDetected={(token) => {
              const fd = new FormData();
              fd.set("id", id);
              fd.set("kind", "board");
              fd.set("qr_token", token);
              setScanning(false);
              startTransition(() => action(fd));
            }} />
          ) : (
            <button type="button" onClick={() => setScanning(true)}
              className={`${big} rounded-sm bg-ink font-medium text-pearl`}>{t("scan")}</button>
          )}
          <form action={action}>
            <input type="hidden" name="id" value={id} />
            <input type="hidden" name="kind" value="board" />
            <input type="hidden" name="without_qr" value="true" />
            <SubmitButton variant="secondary" pendingLabel={t("recording")} className={big}>
              {t("boardWithoutQr")}
            </SubmitButton>
          </form>
          <p className="text-center text-xs text-slate">{t("withoutQrHint")}</p>
        </div>
      ) : null}
      {actions.filter((a): a is Exclude<TripAction, "BOARD"> => a !== "BOARD").map((a) =>
        a === "NO_SHOW" && !confirmNoShow ? (
          <button key={a} type="button" onClick={() => setConfirmNoShow(true)}
            className={`${big} rounded-sm border border-alert/40 text-alert`}>{t(a)}</button>
        ) : (
          <form key={a} action={action}>
            <input type="hidden" name="id" value={id} />
            <input type="hidden" name="status" value={a} />
            <SubmitButton pendingLabel={t(PENDING[a])} variant={a === "NO_SHOW" ? "danger" : "primary"} className={big}>
              {a === "NO_SHOW" ? t("confirmNoShow") : t(a)}
            </SubmitButton>
          </form>
        ),
      )}
    </div>
  );
}
