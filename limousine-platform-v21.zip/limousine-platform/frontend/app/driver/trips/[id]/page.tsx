import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import type { Trip } from "@/lib/types";
import { TripActions } from "./TripActions";
import { ChatSection } from "@/components/chat/ChatSection";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("driver"))("tripTitle") };
}

const WHEN: Intl.DateTimeFormatOptions = { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit", hourCycle: "h23" };

function maps(address: string) {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
}

export default async function TripPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const res = await api<Trip>(`/driver/trips/${encodeURIComponent(id)}`);
  if (!res.ok) notFound();
  const t = res.data;
  const row = "border-b border-ink/10 py-4";
  const [tr, nav, q, d, b, fmt] = await Promise.all([
    getTranslations("driver"), getTranslations("nav"), getTranslations("quote"),
    getTranslations("details"), getTranslations("boarding"), getFormat(),
  ]);
  return (
    <div className="space-y-6">
      <Link href="/driver" className="text-sm text-slate">← {nav("myTrips")}</Link>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-sm text-slate">{t.code}, {t.service_name}</p>
          <h1 className="mt-1 font-display text-2xl text-ink first-letter:uppercase">{fmt.wall(t.pickup_local, WHEN)}</h1>
          <p className="text-sm text-slate">{fmt.duration(t.duration_minutes)}</p>
        </div>
        <StatusBadge status={t.status} />
      </div>

      {t.driver_code ? (
        <section aria-labelledby="driver-code" className="border-l-4 border-champagne bg-paper px-5 py-4">
          <h2 id="driver-code" className="text-sm font-medium text-ink">{tr("codeTitle")}</h2>
          <p className="my-1 font-mono text-4xl tracking-[0.3em] text-ink" aria-label={t.driver_code.split("").join(" ")}>{t.driver_code}</p>
          <p className="text-sm text-slate">{tr("codeText")}</p>
        </section>
      ) : null}
      <TripActions id={t.id} actions={t.actions} />
      <ChatSection as="driver" apiPath={`/driver/trips/${encodeURIComponent(t.id)}/messages`}
        endpoint={`/driver/trips/${encodeURIComponent(t.id)}/messages`} />
      {t.actions.length === 0 && t.status === "CONFIRMED" ? (
        <p className="text-sm text-slate">{tr("departFrom", { hours: 12 })}</p>
      ) : null}

      <dl className="bg-paper px-5">
        <div className={row}>
          <dt className="text-sm text-slate">{q("pickup")}</dt>
          <dd className="mt-1 text-ink">{t.pickup_address}</dd>
          <a href={maps(t.pickup_address)} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-sm text-ink underline decoration-champagne underline-offset-4">{tr("openMap")}</a>
        </div>
        {t.dropoff_address ? (
          <div className={row}>
            <dt className="text-sm text-slate">{d("destination")}</dt>
            <dd className="mt-1 text-ink">{t.dropoff_address}</dd>
            <a href={maps(t.dropoff_address)} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block text-sm text-ink underline decoration-champagne underline-offset-4">{tr("openMap")}</a>
          </div>
        ) : null}
        <div className={row}>
          <dt className="text-sm text-slate">{tr("passenger")}</dt>
          <dd className="mt-1 text-ink">{tr("passengerLine", { name: t.contact_name, count: t.passenger_count })}</dd>
          <a href={`tel:${t.contact_phone}`} className="mt-2 inline-block rounded-sm border border-ink/25 px-4 py-2 text-sm text-ink">{tr("call", { phone: t.contact_phone })}</a>
        </div>
        {t.notes ? <div className={row}><dt className="text-sm text-slate">{d("notes")}</dt><dd className="mt-1 text-ink">{t.notes}</dd></div> : null}
        <div className="py-4"><dt className="text-sm text-slate">{b("vehicle")}</dt><dd className="mt-1 text-ink first-letter:uppercase">{t.vehicle ?? tr("noVehicle")}</dd></div>
      </dl>
    </div>
  );
}
