"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { forgotPasswordAction } from "../actions";
import { useTranslations } from "next-intl";

export function ForgotForm() {
  const t = useTranslations("auth");
  const [state, action] = useActionState(forgotPasswordAction, initialFormState);
  if (state.status === "success") return <FormAlert state={state} />;
  return (
    <form action={action} className="space-y-5" noValidate>
      <FormAlert state={state} />
      <Field label={t("email")} name="email" type="email" autoComplete="email" required
        defaultValue={state.values?.email} error={state.fields?.email} />
      <SubmitButton pendingLabel={t("sending")}>{t("sendLink")}</SubmitButton>
    </form>
  );
}
