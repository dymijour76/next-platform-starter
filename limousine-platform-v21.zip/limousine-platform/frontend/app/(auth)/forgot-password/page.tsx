import type { Metadata } from "next";
import Link from "next/link";
import { ForgotForm } from "./ForgotForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("auth"))("forgotTitle") };
}

export default async function ForgotPasswordPage() {
  const t = await getTranslations("auth");
  return (
    <>
      <h1 className="font-display text-4xl text-ink">{t("forgotTitle")}</h1>
      <p className="mt-3 text-slate">
        {t("forgotIntro")}
      </p>
      <div className="mt-8">
        <ForgotForm />
      </div>
      <p className="mt-8 text-sm">
        <Link href="/login" className="text-slate underline-offset-4 hover:underline">
          {t("backToLogin")}
        </Link>
      </p>
    </>
  );
}
