"use client";

import { useActionState } from "react";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { verifyEmailAction } from "../actions";
import { useTranslations } from "next-intl";

export function VerifyForm({ token }: { token: string }) {
  const t = useTranslations("auth");
  const [state, action] = useActionState(verifyEmailAction, initialFormState);
  return (
    <form action={action} className="space-y-5">
      <FormAlert state={state} />
      <input type="hidden" name="token" value={token} />
      <SubmitButton pendingLabel={t("confirming")}>{t("confirmEmail")}</SubmitButton>
    </form>
  );
}
