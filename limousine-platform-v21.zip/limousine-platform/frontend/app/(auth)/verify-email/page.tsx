import type { Metadata } from "next";
import { VerifyForm } from "./VerifyForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("auth"))("verifyTitle"), robots: { index: false } };
}

/**
 * La confirmación exige pulsar un botón en vez de ocurrir al abrir el enlace:
 * algunos filtros de correo abren automáticamente los enlaces de los emails, y
 * eso no debe contar como confirmación.
 */
export default async function VerifyEmailPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const [{ token }, t] = await Promise.all([searchParams, getTranslations("auth")]);
  return (
    <>
      <h1 className="font-display text-4xl text-ink">{t("verifyTitle")}</h1>
      <p className="mt-3 text-slate">
        {token
          ? t("verifyIntro")
          : t("verifyIncomplete")}
      </p>
      {token ? (
        <div className="mt-8">
          <VerifyForm token={token} />
        </div>
      ) : null}
    </>
  );
}
