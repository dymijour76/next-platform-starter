"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Checkbox, Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { registerAction } from "../actions";
import { useTranslations } from "next-intl";

export function RegisterForm() {
  const t = useTranslations("auth");
  const [state, action] = useActionState(registerAction, initialFormState);
  const f = state.fields ?? {};
  const v = state.values ?? {};

  if (state.status === "success") return <FormAlert state={state} />;

  return (
    <form action={action} className="space-y-5" noValidate>
      <FormAlert state={state} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={t("firstName")} name="first_name" autoComplete="given-name" required
          defaultValue={v.first_name} error={f.first_name} />
        <Field label={t("lastName")} name="last_name" autoComplete="family-name" required
          defaultValue={v.last_name} error={f.last_name} />
      </div>
      <Field label={t("email")} name="email" type="email" autoComplete="email" required
        defaultValue={v.email} error={f.email} />
      <Field label={t("phone")} name="phone" type="tel" autoComplete="tel"
        placeholder="+56 9 1234 5678" defaultValue={v.phone} error={f.phone}
        hint={t("phoneHint")} />
      <Field label={t("password")} name="password" type="password" autoComplete="new-password"
        required minLength={10} error={f.password} hint={t("passwordHint")} />
      <Field label={t("repeatPassword")} name="password_confirmation" type="password"
        autoComplete="new-password" required error={f.password_confirmation} />
      <div className="space-y-3 pt-1">
        <Checkbox name="accept_terms" required error={f.accept_terms}>
          {t.rich("acceptTerms", {
            terms: (chunks) => <Link href="/terms" target="_blank" className="underline underline-offset-4">{chunks}</Link>,
            privacy: (chunks) => <Link href="/privacy" target="_blank" className="underline underline-offset-4">{chunks}</Link>,
          })}
        </Checkbox>
        <Checkbox name="marketing_consent">
          {t("marketing")}
        </Checkbox>
      </div>
      <SubmitButton pendingLabel={t("creatingAccount")}>{t("createAccount")}</SubmitButton>
    </form>
  );
}
