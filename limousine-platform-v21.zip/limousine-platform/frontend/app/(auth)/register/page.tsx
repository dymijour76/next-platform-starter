import type { Metadata } from "next";
import Link from "next/link";
import { RegisterForm } from "./RegisterForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("nav"))("register") };
}

export default async function RegisterPage() {
  const [t, nav] = await Promise.all([getTranslations("auth"), getTranslations("nav")]);
  return (
    <>
      <h1 className="font-display text-4xl text-ink">{nav("register")}</h1>
      <p className="mt-3 text-slate">
        {t.rich("hasAccount", {
          link: (chunks) => (
            <Link href="/login" className="text-ink underline decoration-champagne underline-offset-4">{chunks}</Link>
          ),
        })}
      </p>
      <div className="mt-8">
        <RegisterForm />
      </div>
    </>
  );
}
