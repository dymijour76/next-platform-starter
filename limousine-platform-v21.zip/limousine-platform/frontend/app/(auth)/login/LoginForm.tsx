"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { loginAction, mfaAction, type LoginState } from "../actions";
import { useTranslations } from "next-intl";

/** Dos pasos: contraseña y, si la cuenta la tiene activa, el código de verificación. */
export function LoginForm({ next }: { next?: string }) {
  const t = useTranslations("auth");
  const [login, loginDispatch] = useActionState<LoginState, FormData>(loginAction, { status: "idle" });
  const [mfa, mfaDispatch] = useActionState<LoginState, FormData>(mfaAction, { status: "idle" });
  // El paso del código sigue mientras haya un permiso temporal vigente.
  const mfaToken = mfa.status === "error" && !mfa.mfaToken ? undefined : (mfa.mfaToken ?? login.mfaToken);

  if (mfaToken) {
    return (
      <form action={mfaDispatch} className="space-y-5" noValidate>
        <FormAlert state={mfa} />
        <input type="hidden" name="mfa_token" value={mfaToken} />
        <input type="hidden" name="next" value={next ?? ""} />
        <p className="text-slate">
          {t("mfaIntro")}
        </p>
        <Field label={t("mfaCode")} name="code" required autoComplete="one-time-code" inputMode="text"
          autoFocus maxLength={12} error={mfa.fields?.code} />
        <SubmitButton pendingLabel={t("verifying")}>{t("verify")}</SubmitButton>
      </form>
    );
  }

  const state = mfa.status === "error" ? mfa : login;
  return (
    <form action={loginDispatch} className="space-y-5" noValidate>
      <FormAlert state={state} />
      <input type="hidden" name="next" value={next ?? ""} />
      <Field label={t("email")} name="email" type="email" autoComplete="email" required
        defaultValue={login.values?.email} error={login.fields?.email} />
      <Field label={t("password")} name="password" type="password" autoComplete="current-password" required
        error={login.fields?.password} />
      <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
        <SubmitButton pendingLabel={t("signingIn")}>{t("signIn")}</SubmitButton>
        <Link href="/forgot-password" className="text-sm text-slate underline-offset-4 hover:underline">
          {t("forgot")}
        </Link>
      </div>
    </form>
  );
}
