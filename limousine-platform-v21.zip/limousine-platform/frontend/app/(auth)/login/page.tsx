import type { Metadata } from "next";
import Link from "next/link";
import { Notice } from "@/components/forms/FormAlert";
import { LoginForm } from "./LoginForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("nav"))("login") };
}

const NOTICES = {
  reset: "noticeReset",
  verified: "noticeVerified",
  sessions: "noticeSessions",
  expired: "noticeExpired",
  deleted: "noticeDeleted",
} as const;

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;
  const notice = (Object.keys(NOTICES) as (keyof typeof NOTICES)[]).find((key) => params[key] === "1");
  const [t, nav] = await Promise.all([getTranslations("auth"), getTranslations("nav")]);
  return (
    <>
      <h1 className="font-display text-4xl text-ink">{nav("login")}</h1>
      <p className="mt-3 text-slate">
        {t.rich("noAccount", {
          link: (chunks) => (
            <Link href="/register" className="text-ink underline decoration-champagne underline-offset-4">{chunks}</Link>
          ),
        })}
      </p>
      <div className="mt-8 space-y-6">
        {notice ? <Notice>{t(NOTICES[notice])}</Notice> : null}
        <LoginForm next={params.next} />
      </div>
    </>
  );
}
