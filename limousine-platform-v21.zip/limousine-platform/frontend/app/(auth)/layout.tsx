import Link from "next/link";
import { config } from "@/lib/config";
import { getTranslations } from "next-intl/server";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

/** Páginas de acceso: franja de marca a la izquierda (arriba en móvil) y formulario. */
export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const t = await getTranslations("auth");
  return (
    <div className="grid min-h-dvh grid-rows-[auto_1fr] lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:grid-rows-none">
      <aside className="flex flex-col justify-between bg-ink px-6 py-8 text-pearl sm:px-10 lg:py-12">
        <div className="flex items-center justify-between gap-4">
          <Link href="/" className="font-display text-lg tracking-wide">
            {config.companyName}
          </Link>
          {/* Las páginas de acceso no usan la cabecera del sitio: el selector va aquí. */}
          <LanguageSwitcher dark />
        </div>
        <div className="hidden lg:block">
          <p className="max-w-sm font-display text-4xl leading-tight">
            {t("tagline")}
          </p>
          <div className="mt-6 h-0.5 w-16 bg-champagne" aria-hidden="true" />
        </div>
        <p className="hidden text-sm text-pearl/60 lg:block">
          {t("footer")}
        </p>
      </aside>
      <main className="flex items-start justify-center bg-pearl px-6 py-12 sm:px-10 lg:items-center">
        <div className="w-full max-w-md">{children}</div>
      </main>
    </div>
  );
}
