"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { isLocale, LOCALE_COOKIE } from "@/i18n/config";
import { api } from "@/lib/api-server";
import { getCurrentUser, safeNext } from "@/lib/auth";
import { fromApiError, pick, text, type FormState } from "@/lib/form";
import { clearSession, getRefreshToken, saveSession } from "@/lib/session";
import type { Me, TokenPair } from "@/lib/types";
import { getLocale, getTranslations } from "next-intl/server";

type LoginResult = TokenPair | { mfa_required: true; mfa_token: string; expires_in: number };

/** Estado del inicio de sesión: si la cuenta tiene verificación en dos pasos, pide el código. */
export interface LoginState extends FormState {
  mfaToken?: string;
}

/**
 * Idioma al iniciar sesión:
 * - si este navegador ya tiene uno elegido, se respeta y se guarda en la cuenta
 *   (gana la elección más reciente);
 * - si no, y la cuenta tiene uno, se usa el de la cuenta (quien eligió inglés en su
 *   teléfono ve el sitio en inglés también en su computador);
 * - si la cuenta nunca eligió, se mantiene el idioma del navegador y se guarda en la
 *   cuenta, para que sus emails lleguen en ese idioma.
 */
async function syncLocale(accessToken: string, accountLocale: string | null): Promise<void> {
  const store = await cookies();
  const chosen = store.get(LOCALE_COOKIE)?.value;
  const save = (locale: string) =>
    api("/users/me", {
      method: "PATCH",
      auth: false,
      headers: { Authorization: `Bearer ${accessToken}` },
      body: { locale },
    });
  if (isLocale(chosen)) {
    if (chosen !== accountLocale) await save(chosen);
    return;
  }
  if (isLocale(accountLocale)) {
    store.set(LOCALE_COOKIE, accountLocale, {
      path: "/", sameSite: "lax", maxAge: 60 * 60 * 24 * 365, secure: process.env.NODE_ENV === "production",
    });
    return;
  }
  await save(await getLocale());
}

async function finishLogin(pair: TokenPair, next: FormDataEntryValue | null): Promise<never> {
  await saveSession(pair);
  const me = await api<Me>("/auth/me", {
    auth: false,
    headers: { Authorization: `Bearer ${pair.access_token}` },
  });
  await syncLocale(pair.access_token, me.ok ? me.data.locale : null);
  // Un conductor sin página de destino va directo a sus viajes.
  if (!next && me.ok && me.data.permissions.length === 1 && me.data.permissions[0] === "driver_portal:access") {
    redirect("/driver");
  }
  redirect(safeNext(next as string | null));
}

export async function loginAction(_: LoginState, form: FormData): Promise<LoginState> {
  const email = text(form, "email");
  const res = await api<LoginResult>("/auth/login", {
    method: "POST",
    auth: false,
    body: { email, password: form.get("password") ?? "" },
  });
  if (!res.ok) return fromApiError(res.error, { email });
  if ("mfa_required" in res.data) {
    return { status: "idle", mfaToken: res.data.mfa_token, values: { email } };
  }
  return finishLogin(res.data, form.get("next"));
}

export async function mfaAction(prev: LoginState, form: FormData): Promise<LoginState> {
  const res = await api<TokenPair>("/auth/mfa", {
    method: "POST",
    auth: false,
    body: { mfa_token: text(form, "mfa_token"), code: text(form, "code") },
  });
  if (!res.ok) {
    // Si venció el permiso temporal, se vuelve a pedir la contraseña.
    if (res.error.code === "MFA_TOKEN_INVALID") return { status: "error", message: res.error.message };
    return { ...fromApiError(res.error), mfaToken: text(form, "mfa_token"), values: prev.values };
  }
  return finishLogin(res.data, form.get("next"));
}

const REGISTER_FIELDS = ["email", "first_name", "last_name", "phone"];

export async function registerAction(_: FormState, form: FormData): Promise<FormState> {
  const values = pick(form, REGISTER_FIELDS);
  const password = String(form.get("password") ?? "");
  const res = await api<Me>("/auth/register", {
    method: "POST",
    auth: false,
    body: {
      ...values,
      phone: values.phone || null,
      password,
      password_confirmation: String(form.get("password_confirmation") ?? ""),
      accept_terms: form.get("accept_terms") === "on",
      marketing_consent: form.get("marketing_consent") === "on",
    },
  });
  if (!res.ok) return fromApiError(res.error, values);

  // Cuenta creada: se inicia sesión automáticamente.
  const login = await api<TokenPair>("/auth/login", {
    method: "POST",
    auth: false,
    body: { email: values.email, password },
  });
  if (!login.ok) {
    // Si la configuración exige verificar el email antes de entrar.
    return {
      status: "success",
      message: (await getTranslations("auth"))("registered"),
    };
  }
  await saveSession(login.data);
  redirect("/account?welcome=1");
}

export async function forgotPasswordAction(_: FormState, form: FormData): Promise<FormState> {
  const email = text(form, "email");
  const res = await api<{ message: string }>("/auth/forgot-password", {
    method: "POST",
    auth: false,
    body: { email },
  });
  if (!res.ok) return fromApiError(res.error, { email });
  return { status: "success", message: res.data.message };
}

export async function resetPasswordAction(_: FormState, form: FormData): Promise<FormState> {
  const res = await api<void>("/auth/reset-password", {
    method: "POST",
    auth: false,
    body: {
      token: text(form, "token"),
      password: String(form.get("password") ?? ""),
      password_confirmation: String(form.get("password_confirmation") ?? ""),
    },
  });
  if (!res.ok) return fromApiError(res.error);
  await clearSession();
  redirect("/login?reset=1");
}

export async function verifyEmailAction(_: FormState, form: FormData): Promise<FormState> {
  const res = await api<void>("/auth/verify-email", {
    method: "POST",
    auth: false,
    body: { token: text(form, "token") },
  });
  if (!res.ok) return fromApiError(res.error);
  redirect((await getCurrentUser()) ? "/account?verified=1" : "/login?verified=1");
}

export async function logoutAction(): Promise<void> {
  const refreshToken = await getRefreshToken();
  if (refreshToken) {
    await api<void>("/auth/logout", {
      method: "POST",
      auth: false,
      body: { refresh_token: refreshToken },
    });
  }
  await clearSession();
  redirect("/");
}
