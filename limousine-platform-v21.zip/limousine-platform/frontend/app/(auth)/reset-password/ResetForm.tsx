"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { resetPasswordAction } from "../actions";
import { useTranslations } from "next-intl";

export function ResetForm({ token }: { token: string }) {
  const t = useTranslations("auth");
  const [state, action] = useActionState(resetPasswordAction, initialFormState);
  const f = state.fields ?? {};
  const invalidLink = state.status === "error" && !state.fields;
  return (
    <form action={action} className="space-y-5" noValidate>
      <FormAlert state={state} />
      {invalidLink ? (
        <p className="text-sm">
          <Link href="/forgot-password" className="underline underline-offset-4">
            {t("requestNewLink")}
          </Link>
        </p>
      ) : null}
      <input type="hidden" name="token" value={token} />
      <Field label={t("newPassword")} name="password" type="password" autoComplete="new-password"
        required minLength={10} error={f.password} hint={t("passwordMin")} />
      <Field label={t("repeatPassword")} name="password_confirmation" type="password"
        autoComplete="new-password" required error={f.password_confirmation} />
      <SubmitButton pendingLabel={t("saving")}>{t("savePassword")}</SubmitButton>
    </form>
  );
}
