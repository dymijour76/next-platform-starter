import type { Metadata } from "next";
import Link from "next/link";
import { ResetForm } from "./ResetForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("auth"))("resetTitle"), robots: { index: false } };
}

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>;
}) {
  const [{ token }, t] = await Promise.all([searchParams, getTranslations("auth")]);
  return (
    <>
      <h1 className="font-display text-4xl text-ink">{t("resetTitle")}</h1>
      {token ? (
        <>
          <p className="mt-3 text-slate">
            {t("resetIntro")}
          </p>
          <div className="mt-8">
            <ResetForm token={token} />
          </div>
        </>
      ) : (
        <p className="mt-3 text-slate">
          {t.rich("resetIncomplete", {
            link: (chunks) => <Link href="/forgot-password" className="text-ink underline underline-offset-4">{chunks}</Link>,
          })}
        </p>
      )}
    </>
  );
}
