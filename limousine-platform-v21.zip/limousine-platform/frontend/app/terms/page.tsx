import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("legal"))("termsTitle") };
}

/** Texto legal pendiente: lo redacta la empresa y se cargará desde Admin > Configuración. */
export default async function Page() {
  const t = await getTranslations("legal");
  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-6 py-16 sm:px-10">
        <h1 className="font-display text-4xl text-ink">{t("termsTitle")}</h1>
        <p className="mt-6 leading-relaxed text-slate">
          {t("termsPending")}
        </p>
      </main>
      <SiteFooter />
    </>
  );
}
