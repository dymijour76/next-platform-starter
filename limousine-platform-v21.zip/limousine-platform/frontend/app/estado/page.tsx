import type { Metadata } from "next";
import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { getApiHealth, type CheckStatus } from "@/lib/api";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("status"))("title") };
}

// Se evalúa en cada visita: nunca debe mostrar un estado en caché.
export const dynamic = "force-dynamic";

const CHECK_KEYS: Record<string, "database" | "redis"> = {
  database: "database",
  redis: "redis",
};

function StatusDot({ status }: { status: CheckStatus }) {
  return (
    <span
      aria-hidden="true"
      className={`inline-block size-2.5 rounded-full ${status === "ok" ? "bg-ok" : "bg-alert"}`}
    />
  );
}

export default async function StatusPage() {
  const [health, t] = await Promise.all([getApiHealth(), getTranslations("status")]);
  const operational = health.reachable && health.data.status === "ok";

  return (
    <main className="mx-auto max-w-2xl px-6 py-16 sm:px-10">
      <Link href="/" className="text-sm text-slate underline-offset-4 hover:underline">
        {t("back")}
      </Link>

      <h1 className="mt-10 font-display text-4xl">{t("title")}</h1>
      <p className="mt-3 text-slate" role="status">
        {operational
          ? t("allOk")
          : health.reachable
            ? t("someDown")
            : health.error === "status"
              ? t("apiStatus", { status: health.status ?? 0 })
              : t("apiUnreachable")}
      </p>

      <ul className="mt-10 divide-y divide-ink/10 border-y border-ink/10 bg-paper">
        <li className="flex items-center justify-between px-5 py-4">
          <span>API</span>
          <span className="flex items-center gap-2 text-sm">
            <StatusDot status={health.reachable ? "ok" : "error"} />
            {health.reachable ? t("available") : t("offline")}
          </span>
        </li>
        {health.reachable &&
          Object.entries(health.data.checks).map(([name, status]) => (
            <li key={name} className="flex items-center justify-between px-5 py-4">
              <span>{CHECK_KEYS[name] ? t(CHECK_KEYS[name]!) : name}</span>
              <span className="flex items-center gap-2 text-sm">
                <StatusDot status={status} />
                {status === "ok" ? t("available") : t("failing")}
              </span>
            </li>
          ))}
      </ul>
    </main>
  );
}
