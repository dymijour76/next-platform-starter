"use client";

import "./globals.css";

/**
 * Falla de la estructura base: reemplaza todo el documento (incluido el proveedor de
 * idiomas), así que trae sus propios textos y detecta el idioma por su cuenta.
 */
const TEXTS = {
  es: ["Algo salió mal", "El sitio tuvo un problema. Inténtelo de nuevo en unos segundos.", "Reintentar"],
  en: ["Something went wrong", "The site had a problem. Please try again in a few seconds.", "Try again"],
  fr: ["Un problème est survenu", "Le site a rencontré un problème. Réessayez dans quelques secondes.", "Réessayer"],
  ht: ["Gen yon bagay ki pa mache", "Sit la gen yon pwoblèm. Eseye ankò nan kèk segonn.", "Eseye ankò"],
  zh: ["出了点问题", "网站出现问题。请几秒后重试。", "重试"],
} as const;
type Lang = keyof typeof TEXTS;

function detect(): Lang {
  if (typeof document === "undefined") return "es";
  const saved = /(?:^|; )lp_locale=([a-z]{2})/.exec(document.cookie)?.[1];
  const browser = navigator.language?.slice(0, 2);
  for (const l of [saved, browser]) if (l && l in TEXTS) return l as Lang;
  return "es";
}

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const lang = detect();
  const [title, text, retry] = TEXTS[lang];
  return (
    <html lang={lang === "zh" ? "zh-Hans" : lang}>
      <body className="min-h-dvh bg-pearl">
        <main className="mx-auto max-w-2xl px-6 py-24 text-center">
          <h1 className="text-4xl text-ink">{title}</h1>
          <p className="mt-4 text-slate">{text}</p>
          <button type="button" onClick={reset} className="mt-8 rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl">
            {retry}
          </button>
        </main>
      </body>
    </html>
  );
}
