/** Healthcheck del propio servidor de Next.js (lo usa Docker). */
export const dynamic = "force-dynamic";

export function GET() {
  return Response.json({ status: "ok" });
}
