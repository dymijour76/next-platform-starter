import type { Metadata, Viewport } from "next";
import "@fontsource/marcellus/400.css";
import "@fontsource-variable/instrument-sans";
import "./globals.css";
import { connection } from "next/server";
import { NextIntlClientProvider } from "next-intl";
import { CurrencyProvider } from "@/components/CurrencyProvider";
import { getRefRate } from "@/lib/currency-server";
import { getLocale, getTranslations } from "next-intl/server";
import { HTML_LANG, type Locale } from "@/i18n/config";
import { config } from "@/lib/config";

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: { default: config.companyName, template: `%s | ${config.companyName}` },
    // La leen los buscadores y las vistas previas al compartir un enlace.
    description: (await getTranslations("common"))("siteDescription"),
  };
}

export const viewport: Viewport = {
  themeColor: "#1b2433",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  // Renderizado por petición en todo el sitio: es lo que permite poner el nonce de la CSP.
  await connection();
  const locale = (await getLocale()) as Locale;
  return (
    <html lang={HTML_LANG[locale] ?? "es"}>
      <body className="min-h-dvh">
        {/* Hereda el idioma y los textos de la petición para los componentes de cliente. */}
        <NextIntlClientProvider>
          <CurrencyProvider value={await getRefRate()}>{children}</CurrencyProvider>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
