import { NextResponse, type NextRequest } from "next/server";
import { currentProxyHeaders } from "@/lib/client-ip";
import { API_PREFIX, config } from "@/lib/config";
import { getAccessToken } from "@/lib/session";
import { getTranslations } from "next-intl/server";

/** Descarga del CSV: la API verifica los permisos con el token de la sesión. */
export async function GET(request: NextRequest) {
  const tx = await getTranslations("adm.reports");
  const params = new URLSearchParams(request.nextUrl.searchParams);
  const kind = params.get("kind") === "revenue" ? "revenue" : "reservations";
  params.delete("kind");
  const token = await getAccessToken();
  const res = await fetch(`${config.apiInternalUrl}${API_PREFIX}/admin/reports/${kind}.csv?${params}`, {
    // Idioma, IP y navegador del visitante, como en el resto de las llamadas a la API.
    headers: { ...(await currentProxyHeaders()), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    cache: "no-store",
  });
  if (!res.ok) return new NextResponse(tx("exportFailed"), { status: res.status });
  return new NextResponse(res.body, {
    headers: {
      "Content-Type": res.headers.get("content-type") ?? "text/csv; charset=utf-8",
      "Content-Disposition": res.headers.get("content-disposition") ?? `attachment; filename="${kind}.csv"`,
    },
  });
}
