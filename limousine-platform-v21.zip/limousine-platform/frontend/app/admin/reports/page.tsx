import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { BarChart } from "@/components/charts/BarChart";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requireStaff } from "@/lib/auth";
import { todayIn } from "@/lib/timezone";
import type { PublicPricingConfig, ReservationsReport, RevenueReport } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { useTranslations } from "next-intl";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.reports");
  return { title: tx("title") };
}

type Params = { tab?: string; date_from?: string; date_to?: string; group?: string; basis?: string };

function minusDays(iso: string, days: number) {
  const d = new Date(`${iso}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - days);
  return d.toISOString().slice(0, 10);
}

const COLORS = { ink: "#1b2433", champagne: "#b8a374", ok: "#2f6f4f", alert: "#9c3b32", slate: "#6b7483" };

export default async function ReportsPage({ searchParams }: { searchParams: Promise<Params> }) {
  const tx = await getTranslations("adm.reports");
  const fmt = await getFormat();
  const [user, params] = await Promise.all([requireStaff(), searchParams]);
  const canOps = can(user, "reports:read");
  const canFin = can(user, "reports:financial");
  if (!canOps && !canFin) redirect("/admin?denied=1");

  const config = await api<PublicPricingConfig>("/pricing/config", { auth: false });
  const today = todayIn(config.ok ? config.data.timezone : "America/Santiago");
  const tab = params.tab === "revenue" && canFin ? "revenue" : canOps ? "reservations" : "revenue";
  const query = {
    date_from: params.date_from || minusDays(today, 29),
    date_to: params.date_to || today,
    group: params.group || "day",
    ...(tab === "reservations" ? { basis: params.basis || "pickup" } : {}),
  };
  const qs = new URLSearchParams(query).toString();
  // Al cambiar de pestaña se conservan las fechas y la agrupación.
  const keep = new URLSearchParams({ date_from: query.date_from, date_to: query.date_to, group: query.group }).toString();
  const input = "mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5";
  const tabClass = (active: boolean) =>
    `border-b-2 px-1 pb-2 text-sm ${active ? "border-champagne text-ink" : "border-transparent text-slate hover:text-ink"}`;

  const reservations = tab === "reservations" ? await api<ReservationsReport>("/admin/reports/reservations", { query }) : null;
  const revenue = tab === "revenue" ? await api<RevenueReport>("/admin/reports/revenue", { query }) : null;
  const error = (reservations && !reservations.ok ? reservations.error : null) ?? (revenue && !revenue.ok ? revenue.error : null);

  return (
    <div className="space-y-8">
      <PageHeading title={tx("title")} description={tx("hint")} />
      <nav aria-label={tx("title")} className="flex gap-6 border-b border-ink/10">
        {canOps ? <Link href={`/admin/reports?tab=reservations&${keep}`} aria-current={tab === "reservations" ? "page" : undefined} className={tabClass(tab === "reservations")}>{tx("reservations")}</Link> : null}
        {canFin ? <Link href={`/admin/reports?tab=revenue&${keep}`} aria-current={tab === "revenue" ? "page" : undefined} className={tabClass(tab === "revenue")}>{tx("revenue")}</Link> : null}
      </nav>

      {/* key: si cambian los filtros (p. ej. al cambiar de pestaña), el formulario se rehace con ellos */}
      <form key={`${tab}-${qs}`} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 lg:items-end">
        <input type="hidden" name="tab" value={tab} />
        <label><span className="block text-sm font-medium text-ink">{tx("from")}</span>
          <input type="date" name="date_from" defaultValue={query.date_from} className={input} /></label>
        <label><span className="block text-sm font-medium text-ink">{tx("to")}</span>
          <input type="date" name="date_to" defaultValue={query.date_to} className={input} /></label>
        <label><span className="block text-sm font-medium text-ink">{tx("groupBy")}</span>
          <select name="group" defaultValue={query.group} className={input}>
            <option value="day">{tx("day")}</option><option value="week">{tx("week")}</option><option value="month">{tx("month")}</option>
          </select></label>
        {tab === "reservations" ? (
          <label><span className="block text-sm font-medium text-ink">{tx("basis")}</span>
            <select name="basis" defaultValue={query.basis} className={input}>
              <option value="pickup">{tx("tripDate")}</option><option value="created">{tx("bookingDate")}</option>
            </select></label>
        ) : null}
        <div className="flex gap-3">
          <button type="submit" className="rounded-sm border border-ink/25 bg-paper px-5 py-2.5 text-sm hover:border-ink/50">{tx("view")}</button>
          <a href={`/admin/reports/export?kind=${tab}&${qs}`} className="rounded-sm px-3 py-2.5 text-sm text-ink underline decoration-champagne underline-offset-4">{tx("downloadCsv")}</a>
        </div>
      </form>

      {error ? <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">{error.fields?._ ?? error.message}</p> : null}

      {reservations?.ok ? (() => {
        const r = reservations.data;
        return (
          <div className="space-y-8">
            <dl className="grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-3">
              {[[tx("reservations"), String(r.total)], [tx("completed"), String(r.completed)],
                [tx("cancellationRate"), fmt.percent(r.cancellation_rate)]].map(([k, v]) => (
                <div key={k} className="bg-paper px-5 py-4"><dt className="text-sm text-slate">{k}</dt><dd className="mt-1 font-display text-3xl tabular-nums">{v}</dd></div>
              ))}
            </dl>
            <BarChart title={tx("chartReservations")} labels={r.series.map((p) => p.label)}
              segments={[
                { key: "completed", label: tx("completed"), color: COLORS.ok },
                { key: "confirmed", label: tx("confirmedOngoing"), color: COLORS.ink },
                { key: "pending", label: tx("pendingPayment"), color: COLORS.champagne },
                { key: "cancelled", label: tx("cancelledNoShow"), color: COLORS.alert },
              ]}
              values={r.series.map((p) => ({ completed: p.completed, confirmed: p.confirmed, pending: p.pending,
                cancelled: p.cancelled + p.no_show }))} />
            <DataTable
              caption={tx("byPeriod")}
              head={[tx("period"), tx("total"), tx("confirmed"), tx("completed"), tx("cancelled"), tx("noShow"), tx("expired"), tx("pending")]}
              rows={r.series.map((p) => [p.label, p.total, p.confirmed, p.completed, p.cancelled, p.no_show, p.expired, p.pending])} />
            <DataTable
              caption={tx("byService")}
              head={[tx("service"), tx("reservations"), tx("completed"), tx("cancelled"), tx("bookedAmount")]}
              rows={r.by_service.map((s) => [s.service, s.reservations, s.completed, s.cancelled, fmt.money(s.amount, r.currency)])} />
          </div>
        );
      })() : null}

      {revenue?.ok ? (() => {
        const r = revenue.data;
        const n = (v: string) => Number(v);
        return (
          <div className="space-y-8">
            <dl className="grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
              {[[tx("collected"), fmt.money(r.collected, r.currency)], [tx("refunded"), fmt.money(r.refunded, r.currency)],
                [tx("net"), fmt.money(r.net, r.currency)], [tx("averageTicket"), fmt.money(r.average_ticket, r.currency)]].map(([k, v]) => (
                <div key={k} className="bg-paper px-5 py-4"><dt className="text-sm text-slate">{k}</dt><dd className="mt-1 font-display text-3xl tabular-nums">{v}</dd></div>
              ))}
            </dl>
            <BarChart title={tx("chartRevenue")} labels={r.series.map((p) => p.label)}
              segments={[
                { key: "net", label: tx("net"), color: COLORS.ink },
                { key: "refunded", label: tx("refunded"), color: COLORS.alert },
              ]}
              values={r.series.map((p) => ({ net: Math.max(0, n(p.net)), refunded: n(p.refunded) }))}
              format={(v) => fmt.money(v, r.currency)} />
            <DataTable
              caption={tx("chartRevenue")}
              head={[tx("period"), tx("collected"), tx("refunded"), tx("net"), tx("payments")]}
              rows={r.series.map((p) => [p.label, fmt.money(p.collected, r.currency), fmt.money(p.refunded, r.currency), fmt.money(p.net, r.currency), p.payments])} />
            <DataTable
              caption={tx("byService")}
              head={[tx("service"), tx("collected"), tx("refunded"), tx("net")]}
              rows={r.by_service.map((s) => [s.service, fmt.money(s.collected, r.currency), fmt.money(s.refunded, r.currency), fmt.money(s.net, r.currency)])} />
          </div>
        );
      })() : null}
    </div>
  );
}

function DataTable({ caption, head, rows }: { caption: string; head: string[]; rows: (string | number)[][] }) {
  const tx = useTranslations("adm.reports");
  return (
    <div className="overflow-x-auto border border-ink/10 bg-paper">
      <table className="w-full min-w-[36rem] text-sm">
        <caption className="px-4 pt-3 text-left text-sm font-medium text-ink">{caption}</caption>
        <thead className="border-b border-ink/10 text-slate">
          <tr>{head.map((h, i) => <th key={h} scope="col" className={`px-4 py-2 font-medium ${i ? "text-right" : "text-left"}`}>{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-ink/10">
          {rows.length ? rows.map((row, i) => (
            <tr key={i}>{row.map((c, j) => j === 0
              ? <th key={j} scope="row" className="px-4 py-2 text-left font-normal">{c}</th>
              : <td key={j} className="px-4 py-2 text-right tabular-nums">{c}</td>)}</tr>
          )) : <tr><td colSpan={head.length} className="px-4 py-4 text-slate">{tx("noData")}</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
