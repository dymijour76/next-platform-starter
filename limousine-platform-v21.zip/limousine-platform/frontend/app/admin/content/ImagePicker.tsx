import { ResponsiveImage } from "@/components/ResponsiveImage";
import type { MediaAsset } from "@/lib/types";
import { useTranslations } from "next-intl";

/** Elegir una imagen de la biblioteca (botones de radio con miniatura). */
export function ImagePicker({ images, selected, error }: { images: MediaAsset[]; selected?: string; error?: string }) {
  const tx = useTranslations("adm.content");
  if (!images.length) {
    return <p className="text-sm text-alert">{tx("emptyLibrary")}</p>;
  }
  return (
    <fieldset>
      <legend className="text-sm font-medium text-ink">{tx("image")}</legend>
      <div className="mt-2 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {images.map((img) => (
          <label key={img.id} className="cursor-pointer">
            <input type="radio" name="image_id" value={img.id} defaultChecked={img.id === selected} className="peer sr-only" />
            <span className="block border-2 border-transparent p-0.5 peer-checked:border-champagne peer-focus-visible:outline-2 peer-focus-visible:outline-champagne">
              <ResponsiveImage image={img} sizes="12rem" className="aspect-[16/9] w-full object-cover" />
            </span>
            <span className="mt-1 block truncate text-xs text-slate">{img.alt}</span>
          </label>
        ))}
      </div>
      {error ? <p className="mt-1.5 text-sm text-alert">{error}</p> : null}
    </fieldset>
  );
}
