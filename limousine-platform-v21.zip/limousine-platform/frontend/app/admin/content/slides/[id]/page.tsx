import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { PageHeading, Section } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { MediaAsset, SlideAdmin } from "@/lib/types";
import { deleteSlideAction } from "../../../content-actions";
import { SlideForm } from "../../SlideForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.content");
  return { title: tx("slide") };
}

export default async function SlidePage({ params }: { params: Promise<{ id: string }> }) {
  const tx = await getTranslations("adm.content");
  const [, { id }] = await Promise.all([requirePermission("content:write"), params]);
  const [slide, media] = await Promise.all([
    api<SlideAdmin>(`/admin/carousel/${encodeURIComponent(id)}`),
    api<MediaAsset[]>("/admin/media"),
  ]);
  if (!slide.ok) notFound();
  const images = media.ok ? media.data : [];
  return (
    <div className="space-y-10">
      <Link href="/admin/content" className="text-sm text-slate hover:underline">{tx("backToCarousel")}</Link>
      <PageHeading title={slide.data.title} description={slide.data.live ? tx("shownToday") : tx("notShownToday")} />
      <SlideForm slide={slide.data} images={images} />
      <Section title={tx("deleteSlide")} description={tx("deleteSlideHint")}>
        <form action={deleteSlideAction}>
          <input type="hidden" name="id" value={slide.data.id} />
          <button type="submit" className="rounded-sm border border-alert/40 bg-paper px-5 py-2.5 text-sm text-alert hover:border-alert">{tx("delete")}</button>
        </form>
      </Section>
    </div>
  );
}
