import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { MediaAsset } from "@/lib/types";
import { SlideForm } from "../../SlideForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.content");
  return { title: tx("newSlide") };
}

export default async function NewSlidePage() {
  const tx = await getTranslations("adm.content");
  await requirePermission("content:write");
  const media = await api<MediaAsset[]>("/admin/media");
  const images = media.ok ? media.data : [];
  return (
    <div className="space-y-8">
      <Link href="/admin/content" className="text-sm text-slate hover:underline">{tx("backToCarousel")}</Link>
      <PageHeading title={tx("newSlide")} description={tx("newSlideHint")} />
      <SlideForm images={images} />
    </div>
  );
}
