"use client";

import { TranslationFields } from "@/components/forms/TranslationFields";
import { SLIDE_TR, translationValues, withLabels } from "@/lib/translations";
import { useActionState } from "react";
import { Checkbox, Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import type { FormState } from "@/lib/form";
import type { MediaAsset, SlideAdmin } from "@/lib/types";
import { saveSlideAction } from "../content-actions";
import { ImagePicker } from "./ImagePicker";
import { useTranslations } from "next-intl";

function split(iso: string | null): [string, string] {
  if (!iso) return ["", ""];
  const local = new Intl.DateTimeFormat("sv-SE", { timeZone: "America/Santiago", dateStyle: "short", timeStyle: "short" }).format(new Date(iso));
  const [d, t] = local.split(" ");
  return [d ?? "", t ?? ""];
}

export function SlideForm({ slide: s, images }: { slide?: SlideAdmin; images: MediaAsset[] }) {
  const tx = useTranslations("adm.content");
  const [sd, st] = split(s?.starts_at ?? null);
  const [ed, et] = split(s?.ends_at ?? null);
  const initial: FormState = {
    status: "idle",
    values: s
      ? { image_id: s.image_id, title: s.title, subtitle: s.subtitle ?? "", cta_label: s.cta_label ?? "", cta_url: s.cta_url ?? "",
          start_date: sd, start_time: st, end_date: ed, end_time: et, ...translationValues(s.translations) }
      : {},
  };
  const [state, action] = useActionState(saveSlideAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};
  return (
    <form action={action} className="max-w-3xl space-y-6" noValidate>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={s?.id ?? ""} />
      <ImagePicker images={images} selected={v.image_id} error={f.image_id} />
      <Field label={tx("slideTitle")} name="title" required maxLength={80} defaultValue={v.title} error={f.title} />
      <Field label={tx("slideText")} name="subtitle" maxLength={200} defaultValue={v.subtitle} error={f.subtitle} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={tx("ctaLabel")} name="cta_label" maxLength={30} defaultValue={v.cta_label} error={f.cta_label} hint={tx("ctaLabelHint")} />
        <Field label={tx("ctaUrl")} name="cta_url" defaultValue={v.cta_url} error={f.cta_url}
          hint={tx("ctaUrlHint")} />
      </div>
      {f._ ? <p role="alert" className="text-sm text-alert">{f._}</p> : null}
      <fieldset className="space-y-3">
        <legend className="mb-2 text-sm font-medium text-ink">{tx("translations")}</legend>
        <TranslationFields values={v} fields={withLabels(SLIDE_TR, { title: tx("slideTitle"), subtitle: tx("slideText"), cta_label: tx("ctaLabel") })}
          labels={{ complete: tx("trComplete"), partial: tx("trPartial"), missing: tx("trMissing"), hint: tx("trHint") }} />
      </fieldset>
      <fieldset className="grid gap-5 sm:grid-cols-4">
        <legend className="mb-2 text-sm font-medium text-ink">{tx("schedule")}</legend>
        <Field label={tx("from")} name="start_date" type="date" defaultValue={v.start_date} />
        <Field label={tx("time")} name="start_time" id="f-start_time" type="time" defaultValue={v.start_time} />
        <Field label={tx("to")} name="end_date" type="date" defaultValue={v.end_date} error={f.end_date} />
        <Field label={tx("time")} name="end_time" id="f-end_time" type="time" defaultValue={v.end_time} />
      </fieldset>
      <Checkbox name="is_active" defaultChecked={s ? s.is_active : true}>{tx("active")}</Checkbox>
      <SubmitButton pendingLabel={tx("saving")}>{s ? tx("saveChanges") : tx("createSlide")}</SubmitButton>
    </form>
  );
}
