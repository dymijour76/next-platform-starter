import type { Metadata } from "next";
import Link from "next/link";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { SlideAdmin } from "@/lib/types";
import { moveSlideAction } from "../content-actions";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import type { Format } from "@/lib/format";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.content");
  return { title: tx("title") };
}

type Tx = (key: string, values?: Record<string, string>) => string;

/** Estado de la diapositiva; recibe la traducción y el formato de la página. */
function state(s: SlideAdmin, tx: Tx, fmt: Format): { label: string; tone: string } {
  if (s.live) return { label: tx("live"), tone: "text-ok" };
  if (!s.is_active) return { label: tx("inactive"), tone: "text-slate" };
  if (s.starts_at && new Date(s.starts_at) > new Date()) return { label: tx("scheduledFrom", { date: fmt.date(s.starts_at) }), tone: "text-ink" };
  return { label: tx("endedOn", { date: fmt.date(s.ends_at) }), tone: "text-slate" };
}

export default async function ContentPage({ searchParams }: { searchParams: Promise<{ saved?: string; deleted?: string }> }) {
  const tx = await getTranslations("adm.content");
  const fmt = await getFormat();
  const [, params] = await Promise.all([requirePermission("content:write"), searchParams]);
  const res = await api<SlideAdmin[]>("/admin/carousel");
  const small = "rounded-sm border border-ink/20 px-2.5 py-1 text-xs text-ink hover:border-ink/50 disabled:opacity-30";

  return (
    <div className="space-y-8">
      <PageHeading
        title={tx("carousel")}
        description={tx("carouselHint")}
        action={
          <div className="flex flex-wrap gap-3">
            <Link href="/admin/content/media" className="rounded-sm border border-ink/25 bg-paper px-5 py-2.5 text-sm hover:border-ink/50">{tx("library")}</Link>
            <Link href="/admin/content/slides/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">{tx("newSlide")}</Link>
          </div>
        }
      />
      {params.saved ? <Notice>{tx("slideCreated")}</Notice> : null}
      {params.deleted ? <Notice>{tx("slideDeleted")}</Notice> : null}
      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="text-slate">{tx("noSlides")}</p>
      ) : (
        <ol className="space-y-3">
          {res.data.map((s, i) => {
            const st = state(s, (key, values) => tx(key, values), fmt);
            return (
              <li key={s.id} className="grid items-center gap-4 bg-paper p-3 sm:grid-cols-[9rem_minmax(0,1fr)_auto]">
                <ResponsiveImage image={s.image} sizes="9rem" className="aspect-[16/9] w-full object-cover" />
                <div>
                  <Link href={`/admin/content/slides/${s.id}`} className="font-display text-lg text-ink hover:underline">{s.title}</Link>
                  <p className={`text-sm ${st.tone}`}>{st.label}</p>
                </div>
                <div className="flex gap-2">
                  {(["up", "down"] as const).map((dir) => (
                    <form key={dir} action={moveSlideAction}>
                      <input type="hidden" name="id" value={s.id} />
                      <input type="hidden" name="direction" value={dir} />
                      <button type="submit" className={small} disabled={dir === "up" ? i === 0 : i === res.data.length - 1}
                        aria-label={`${dir === "up" ? tx("upload") : "Bajar"} «${s.title}»`}>{dir === "up" ? "↑" : "↓"}</button>
                    </form>
                  ))}
                </div>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}
