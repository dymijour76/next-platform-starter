import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { MediaAsset } from "@/lib/types";
import { MediaItemForms, UploadForm } from "./MediaForms";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.content");
  return { title: tx("library") };
}

export default async function MediaPage() {
  const tx = await getTranslations("adm.content");
  const fmt = await getFormat();
  await requirePermission("content:write");
  const res = await api<MediaAsset[]>("/admin/media");
  return (
    <div className="space-y-10">
      <Link href="/admin/content" className="text-sm text-slate hover:underline">{tx("backToCarousel")}</Link>
      <PageHeading title={tx("library")} description={tx("libraryHint")} />
      <UploadForm />
      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="text-slate">{tx("noImages")}</p>
      ) : (
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {res.data.map((img) => (
            <li key={img.id} className="bg-paper">
              <ResponsiveImage image={img} sizes="(min-width: 1024px) 20rem, 50vw" className="aspect-[3/2] w-full object-cover" />
              <div className="space-y-3 p-4">
                <p className="text-xs text-slate">
                  {tx("imageInfo", { width: img.width, height: img.height, mb: fmt.number(img.bytes / 1024 / 1024, { maximumFractionDigits: 1, minimumFractionDigits: 1 }) })}{" "}
                  {img.usage ? tx("inUse", { count: img.usage }) : tx("unused")}
                </p>
                <MediaItemForms image={img} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
