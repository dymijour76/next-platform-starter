"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import type { MediaAsset } from "@/lib/types";
import { deleteMediaAction, updateAltAction, uploadMediaAction } from "../../content-actions";
import { useTranslations } from "next-intl";

export function UploadForm() {
  const tx = useTranslations("adm.content");
  const [state, action] = useActionState(uploadMediaAction, initialFormState);
  const f = state.fields ?? {};
  return (
    <form action={action} noValidate className="grid max-w-3xl gap-5 bg-paper p-5 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto] sm:items-start">
      <div className="sm:col-span-3"><FormAlert state={state} /></div>
      <div>
        <label htmlFor="f-file" className="block text-sm font-medium text-ink">{tx("image")}</label>
        <input id="f-file" name="file" type="file" accept="image/jpeg,image/png,image/webp" required
          aria-describedby={f.file ? "f-file-error" : undefined}
          className="mt-1.5 block w-full text-sm text-slate file:mr-3 file:rounded-sm file:border-0 file:bg-ink file:px-4 file:py-2 file:text-sm file:text-pearl" />
        {f.file ? <p id="f-file-error" className="mt-1.5 text-sm text-alert">{f.file}</p> : null}
      </div>
      <Field label={tx("altText")} name="alt_text" required maxLength={200} defaultValue={state.values?.alt_text}
        error={f.alt_text} hint={tx("altHint")} />
      <div className="sm:pt-6"><SubmitButton pendingLabel={tx("uploading")}>{tx("upload")}</SubmitButton></div>
    </form>
  );
}

export function MediaItemForms({ image }: { image: MediaAsset }) {
  const tx = useTranslations("adm.content");
  const [altState, altAction] = useActionState(updateAltAction, initialFormState);
  const [delState, delAction] = useActionState(deleteMediaAction, initialFormState);
  return (
    <div className="space-y-3">
      <form action={altAction} className="space-y-2" noValidate>
        <FormAlert state={altState} />
        <input type="hidden" name="id" value={image.id} />
        <Field label={tx("description")} name="alt_text" id={`alt-${image.id}`} required maxLength={200} defaultValue={image.alt} />
        <SubmitButton variant="secondary" pendingLabel={tx("saving")}>{tx("saveDescription")}</SubmitButton>
      </form>
      <form action={delAction}>
        <FormAlert state={delState} />
        <input type="hidden" name="id" value={image.id} />
        <button type="submit" disabled={image.usage > 0} className="text-sm text-alert hover:underline disabled:cursor-not-allowed disabled:text-slate disabled:no-underline"
          title={image.usage ? tx("inUseHint") : undefined}>
          {tx("deleteImage")}
        </button>
      </form>
    </div>
  );
}
