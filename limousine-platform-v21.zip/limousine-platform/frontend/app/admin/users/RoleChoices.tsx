import type { Role } from "@/lib/types";
import { useTranslations } from "next-intl";

/**
 * Casillas de roles. Los roles con permisos que el administrador actual no
 * tiene se muestran deshabilitados (la API también lo impide).
 */
export function RoleChoices({
  roles,
  actorPermissions,
  selected,
  disabled = false,
  error,
}: {
  roles: Role[];
  actorPermissions: string[];
  selected: string[];
  disabled?: boolean;
  error?: string;
}) {
  const tx = useTranslations("adm.users");
  const granted = new Set(actorPermissions);
  return (
    <fieldset aria-describedby={error ? "roles-error" : undefined}>
      <legend className="text-sm font-medium text-ink">{tx("roles")}</legend>
      <input type="hidden" name="roles_present" value="1" />
      <ul className="mt-3 space-y-3">
        {roles.map((role) => {
          const allowed = role.permissions.every((p) => granted.has(p));
          return (
            <li key={role.code}>
              <label className={`flex items-start gap-3 text-sm ${allowed && !disabled ? "" : "opacity-60"}`}>
                <input
                  type="checkbox"
                  name="roles"
                  value={role.code}
                  defaultChecked={selected.includes(role.code)}
                  disabled={disabled || !allowed}
                  className="mt-1 size-4 accent-ink"
                />
                <span>
                  <span className="font-medium text-ink">{role.display_name}</span>
                  {role.display_description ? <span className="block text-slate">{role.display_description}</span> : null}
                  {!allowed ? (
                    <span className="block text-slate">{tx("missingPermissions")}</span>
                  ) : null}
                </span>
              </label>
            </li>
          );
        })}
      </ul>
      {error ? <p id="roles-error" className="mt-2 text-sm text-alert">{error}</p> : null}
    </fieldset>
  );
}
