"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { inviteUserAction } from "../../actions";
import { useTranslations } from "next-intl";

export function InviteForm({ children }: { children: React.ReactNode }) {
  const tx = useTranslations("adm.users");
  const [state, action] = useActionState(inviteUserAction, initialFormState);
  const f = state.fields ?? {};
  const v = state.values ?? {};
  return (
    <form action={action} className="max-w-xl space-y-6" noValidate>
      <FormAlert state={state} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label={tx("name")} name="first_name" required defaultValue={v.first_name} error={f.first_name} />
        <Field label={tx("lastName")} name="last_name" required defaultValue={v.last_name} error={f.last_name} />
      </div>
      <Field label={tx("email")} name="email" type="email" required defaultValue={v.email} error={f.email} />
      <Field label={tx("phone")} name="phone" type="tel" defaultValue={v.phone} error={f.phone} />
      {children}
      {f.roles ? <p className="text-sm text-alert">{f.roles}</p> : null}
      <SubmitButton pendingLabel={tx("sendingInvite")}>{tx("sendInvite")}</SubmitButton>
    </form>
  );
}
