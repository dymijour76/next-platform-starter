import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { Role } from "@/lib/types";
import { RoleChoices } from "../RoleChoices";
import { InviteForm } from "./InviteForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.users");
  return { title: tx("invite") };
}

export default async function NewUserPage() {
  const tx = await getTranslations("adm.users");
  const actor = await requirePermission("users:write");
  const roles = await api<Role[]>("/roles");
  return (
    <div className="space-y-8">
      <Link href="/admin/users" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading
        title={tx("invite")}
        description={tx("inviteHint")}
      />
      <InviteForm>
        <RoleChoices
          roles={roles.ok ? roles.data.filter((r) => r.code !== "customer") : []}
          actorPermissions={actor.permissions}
          selected={[]}
        />
      </InviteForm>
    </div>
  );
}
