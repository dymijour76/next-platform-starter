import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { WalletInfo } from "@/lib/types";
import { GrantCreditForm } from "./WalletPanel";
import type { Role, User } from "@/lib/types";
import { RoleChoices } from "../RoleChoices";
import { EditUserForm } from "./EditUserForm";
import { ResetMfa } from "./ResetMfa";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.users");
  return { title: tx("user") };
}

export default async function UserDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ invited?: string; mfa_reset?: string }>;
}) {
  const tx = await getTranslations("adm.users");
  const fmt = await getFormat();
  const [actor, { id }, { invited, mfa_reset }] = await Promise.all([
    requirePermission("users:read"),
    params,
    searchParams,
  ]);
  const [userRes, rolesRes, walletRes, w] = await Promise.all([
    api<User>(`/users/${encodeURIComponent(id)}`),
    can(actor, "roles:read") ? api<Role[]>("/roles") : Promise.resolve(null),
    can(actor, "payments:read") ? api<WalletInfo>(`/admin/users/${encodeURIComponent(id)}/wallet`) : Promise.resolve(null),
    getTranslations("wallet"),
  ]);
  const wallet = walletRes?.ok ? walletRes.data : null;
  if (!userRes.ok) notFound();
  const user = userRes.data;
  const isSelf = user.id === actor.id;
  const roles = rolesRes?.ok ? rolesRes.data : [];

  return (
    <div className="space-y-8">
      <Link href="/admin/users" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={`${user.first_name} ${user.last_name}`} description={user.email} />
      {invited ? <Notice>{tx("invited", { email: user.email })}</Notice> : null}
      {mfa_reset ? (
        <Notice>{tx("mfaResetDone")}</Notice>
      ) : null}

      <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-3">
        <div><dt className="text-slate">{tx("emailConfirmed")}</dt><dd className="text-ink">{user.email_verified ? tx("yes") : tx("no")}</dd></div>
        <div><dt className="text-slate">{tx("lastLogin")}</dt><dd className="text-ink">{fmt.date(user.last_login_at)}</dd></div>
        <div><dt className="text-slate">{tx("createdAt")}</dt><dd className="text-ink">{fmt.date(user.created_at)}</dd></div>
        <div><dt className="text-slate">{tx("mfa")}</dt><dd className="text-ink">{user.mfa_enabled ? tx("on") : tx("mfaOff")}</dd></div>
      </dl>

      {user.mfa_enabled && !isSelf && can(actor, "users:write") ? <ResetMfa id={user.id} /> : null}
      {wallet ? (
        <section aria-labelledby="wallet-title" className="space-y-4 border border-ink/10 bg-paper p-6">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <div>
              <h2 id="wallet-title" className="font-display text-xl text-ink">{w("adminTitle")}</h2>
              <p className="font-mono text-sm tracking-wider text-slate">{wallet.number}</p>
            </div>
            <p className="font-display text-2xl text-ink">{fmt.money(wallet.balance, wallet.currency)}</p>
          </div>
          {wallet.entries.length ? (
            <ul className="divide-y divide-ink/5 text-sm">
              {wallet.entries.slice(0, 8).map((e) => (
                <li key={e.id} className="flex justify-between gap-4 py-2">
                  <span>
                    <span className="text-ink">{e.description}</span>
                    {e.reason ? <span className="block text-xs text-slate">{e.reason}</span> : null}
                    <span className="block text-xs text-slate">{fmt.date(e.created_at)}</span>
                  </span>
                  <span className={`whitespace-nowrap ${Number(e.amount) > 0 ? "text-ok" : "text-ink"}`}>
                    {Number(e.amount) > 0 ? "+" : "−"}{fmt.money(Math.abs(Number(e.amount)), wallet.currency)}
                  </span>
                </li>
              ))}
            </ul>
          ) : <p className="text-sm text-slate">{w("empty")}</p>}
          {can(actor, "payments:refund") ? (
            <div className="border-t border-ink/10 pt-4">
              <h3 className="text-sm font-medium text-ink">{w("grantTitle")}</h3>
              <p className="mb-3 text-xs text-slate">{w("grantHint")}</p>
              <GrantCreditForm userId={user.id} />
            </div>
          ) : null}
        </section>
      ) : null}
      <EditUserForm user={user} isSelf={isSelf} canEdit={can(actor, "users:write")}>
        {roles.length ? (
          <RoleChoices
            roles={roles}
            actorPermissions={actor.permissions}
            selected={user.roles.map((r) => r.code)}
          />
        ) : null}
      </EditUserForm>
    </div>
  );
}
