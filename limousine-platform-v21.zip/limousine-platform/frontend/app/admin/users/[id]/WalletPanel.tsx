"use client";

import { useTranslations } from "next-intl";
import { useActionState } from "react";
import { grantCreditAction } from "@/app/admin/wallet-actions";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";

/** Formulario para otorgar crédito (sólo con permiso para mover dinero). */
export function GrantCreditForm({ userId }: { userId: string }) {
  const t = useTranslations("wallet");
  const [state, action] = useActionState(grantCreditAction, initialFormState);
  const f = state.fields ?? {};
  return (
    <form action={action} noValidate className="space-y-4">
      <FormAlert state={state} />
      <input type="hidden" name="user_id" value={userId} />
      <div className="grid gap-4 sm:grid-cols-[10rem_minmax(0,1fr)]">
        <Field label={t("grantAmount")} name="amount" inputMode="numeric" required error={f.amount}
          defaultValue={state.status === "success" ? "" : state.values?.amount} />
        <Field label={t("grantReason")} name="reason" required minLength={5} maxLength={300} error={f.reason}
          hint={t("grantReasonHint")} defaultValue={state.status === "success" ? "" : state.values?.reason} />
      </div>
      <SubmitButton pendingLabel={t("granting")}>{t("grantButton")}</SubmitButton>
    </form>
  );
}
