"use client";

import { useActionState } from "react";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { resetMfaAction } from "../../actions";
import { useTranslations } from "next-intl";

/** Para quien perdió el teléfono y sus códigos de respaldo. Queda en la auditoría. */
export function ResetMfa({ id }: { id: string }) {
  const tx = useTranslations("adm.users");
  const [state, action] = useActionState(resetMfaAction, initialFormState);
  return (
    <form action={action} className="space-y-3">
      <FormAlert state={state} />
      <input type="hidden" name="id" value={id} />
      {state.status !== "success" ? (
        <SubmitButton variant="secondary" pendingLabel={tx("resetting")}>{tx("resetMfa")}</SubmitButton>
      ) : null}
    </form>
  );
}
