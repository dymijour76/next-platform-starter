"use client";

import { useActionState } from "react";
import { Field, Select } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import type { FormState } from "@/lib/form";
import type { User, UserStatus } from "@/lib/types";
import { updateUserAction } from "../../actions";
import { useTranslations } from "next-intl";

export function EditUserForm({
  user,
  isSelf,
  canEdit,
  children,
}: {
  user: User;
  isSelf: boolean;
  canEdit: boolean;
  children: React.ReactNode;
}) {
  const tx = useTranslations("adm.users");
  const us = useTranslations("labels.user");
  const initial: FormState = {
    status: "idle",
    values: {
      first_name: user.first_name,
      last_name: user.last_name,
      phone: user.phone ?? "",
      status: user.status,
    },
  };
  const [state, action] = useActionState(updateUserAction, initial);
  const f = state.fields ?? {};
  const v = state.values ?? {};
  return (
    <form action={action} className="max-w-xl space-y-6" noValidate>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={user.id} />
      <fieldset disabled={!canEdit} className="space-y-6">
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={tx("name")} name="first_name" required defaultValue={v.first_name} error={f.first_name} />
          <Field label={tx("lastName")} name="last_name" required defaultValue={v.last_name} error={f.last_name} />
        </div>
        <Field label={tx("phone")} name="phone" type="tel" defaultValue={v.phone} error={f.phone} />
        {isSelf ? (
          <p className="text-sm text-slate">
            {tx("ownLimits")}
          </p>
        ) : (
          <>
            <Select label={tx("accountStatus")} name="status" defaultValue={v.status} error={f.status}>
              {(["ACTIVE", "INACTIVE", "SUSPENDED"] as UserStatus[]).map((s) => (
                <option key={s} value={s}>{us(s)}</option>
              ))}
            </Select>
            {children}
          </>
        )}
      </fieldset>
      {canEdit ? <SubmitButton pendingLabel={tx("saving")}>{tx("saveChanges")}</SubmitButton> : null}
    </form>
  );
}
