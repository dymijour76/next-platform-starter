import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { Page, Role, User, UserStatus } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.users");
  return { title: tx("title") };
}

const PAGE_SIZE = 20;

export default async function UsersPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; role?: string; status?: string; page?: string }>;
}) {
  const tx = await getTranslations("adm.users");
  const [us, fmt] = await Promise.all([getTranslations("labels.user"), getFormat()]);
  const [actor, params] = await Promise.all([requirePermission("users:read"), searchParams]);
  const page = Math.max(1, Number(params.page) || 1);
  const [usersRes, rolesRes] = await Promise.all([
    api<Page<User>>("/users", {
      query: { q: params.q, role: params.role, status: params.status, page, page_size: PAGE_SIZE },
    }),
    can(actor, "roles:read") ? api<Role[]>("/roles") : Promise.resolve(null),
  ]);
  const roles = rolesRes?.ok ? rolesRes.data : [];
  const pages = usersRes.ok ? Math.max(1, Math.ceil(usersRes.data.total / PAGE_SIZE)) : 1;

  const pageLink = (p: number) => {
    const qs = new URLSearchParams(
      Object.entries({ ...params, page: String(p) }).filter(([, v]) => v) as [string, string][],
    );
    return `/admin/users?${qs}`;
  };

  return (
    <div className="space-y-8">
      <PageHeading
        title={tx("title")}
        description={tx("listHint")}
        action={
          can(actor, "users:write") ? (
            <Link href="/admin/users/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
              {tx("invite")}
            </Link>
          ) : null
        }
      />

      <form className="flex flex-wrap items-end gap-3" role="search">
        <label className="flex-1 basis-64">
          <span className="block text-sm font-medium text-ink">{tx("search")}</span>
          <input name="q" defaultValue={params.q} placeholder={tx("searchPlaceholder")}
            className="mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5" />
        </label>
        {roles.length ? (
          <label>
            <span className="block text-sm font-medium text-ink">{tx("role")}</span>
            <select name="role" defaultValue={params.role ?? ""}
              className="mt-1.5 block rounded-sm border border-ink/20 bg-paper px-3 py-2.5">
              <option value="">{tx("all")}</option>
              {roles.map((r) => (<option key={r.code} value={r.code}>{r.display_name}</option>))}
            </select>
          </label>
        ) : null}
        <label>
          <span className="block text-sm font-medium text-ink">{tx("status")}</span>
          <select name="status" defaultValue={params.status ?? ""}
            className="mt-1.5 block rounded-sm border border-ink/20 bg-paper px-3 py-2.5">
            <option value="">{tx("all")}</option>
            {(["ACTIVE", "INACTIVE", "SUSPENDED"] as UserStatus[]).map((s) => (
              <option key={s} value={s}>{us(s)}</option>
            ))}
          </select>
        </label>
        <button type="submit" className="rounded-sm border border-ink/25 bg-paper px-5 py-2.5 text-sm hover:border-ink/50">
          {tx("filter")}
        </button>
      </form>

      {!usersRes.ok ? (
        <p role="alert" className="text-alert">{usersRes.error.message}</p>
      ) : usersRes.data.items.length === 0 ? (
        <p className="text-slate">
          {tx("noResults")}{" "}
          <Link href="/admin/users" className="text-ink underline underline-offset-4">{tx("seeAll")}</Link>
        </p>
      ) : (
        <>
          <div className="overflow-x-auto border border-ink/10 bg-paper">
            <table className="w-full min-w-[40rem] text-left text-sm">
              <caption className="sr-only">{tx("title")}</caption>
              <thead className="border-b border-ink/10 text-slate">
                <tr>
                  <th scope="col" className="px-4 py-3 font-medium">{tx("name")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{tx("roles")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{tx("status")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{tx("twoSteps")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{tx("lastLogin")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/10">
                {usersRes.data.items.map((u) => (
                  <tr key={u.id} className="hover:bg-pearl/50">
                    <td className="px-4 py-3">
                      <Link href={`/admin/users/${u.id}`} className="font-medium text-ink hover:underline">
                        {u.first_name} {u.last_name}
                      </Link>
                      <span className="block text-slate">{u.email}</span>
                    </td>
                    <td className="px-4 py-3">{u.roles.map((r) => r.name).join(", ")}</td>
                    <td className="px-4 py-3">
                      <span className={u.status === "ACTIVE" ? "text-ok" : "text-alert"}>
                        {us(u.status)}
                      </span>
                    </td>
                    <td className="px-4 py-3">{u.mfa_enabled ? <span className="text-ok">{tx("on")}</span> : <span className="text-slate">{tx("no")}</span>}</td>
                    <td className="px-4 py-3 text-slate">{fmt.date(u.last_login_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <nav aria-label={tx("pagination")} className="flex items-center justify-between text-sm text-slate">
            <span>
              {tx("pageInfo", { total: usersRes.data.total, page, pages })}
            </span>
            <span className="flex gap-4">
              {page > 1 ? <Link href={pageLink(page - 1)} className="text-ink hover:underline">{tx("previous")}</Link> : null}
              {page < pages ? <Link href={pageLink(page + 1)} className="text-ink hover:underline">{tx("next")}</Link> : null}
            </span>
          </nav>
        </>
      )}
    </div>
  );
}
