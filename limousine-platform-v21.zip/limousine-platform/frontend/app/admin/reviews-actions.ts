"use server";

import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";

/** Publica u oculta una reseña y vuelve a la lista con el aviso correspondiente. */
export async function moderateReviewAction(form: FormData): Promise<void> {
  const id = String(form.get("id") ?? "");
  const action = form.get("action") === "publish" ? "publish" : "hide";
  const status = String(form.get("status") ?? "PENDING");
  await api(`/admin/reviews/${encodeURIComponent(id)}/moderate`, { method: "POST", body: { action } });
  redirect(`/admin/reviews?status=${encodeURIComponent(status)}&done=${action}`);
}
