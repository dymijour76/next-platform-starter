"use server";

import { getTranslations } from "next-intl/server";
import { revalidatePath } from "next/cache";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";

/** Otorga un crédito a la billetera de un cliente (queda en la auditoría). */
export async function grantCreditAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "user_id");
  const values = { amount: text(form, "amount"), reason: text(form, "reason") };
  const amount = Number(values.amount.replace(/[^0-9]/g, ""));
  const res = await api(`/admin/users/${encodeURIComponent(id)}/wallet/credits`, {
    method: "POST",
    body: { amount, reason: values.reason },
  });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath(`/admin/users/${id}`);
  return { status: "success", message: (await getTranslations("wallet"))("granted") };
}
