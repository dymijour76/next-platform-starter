"use server";

import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";

/** Fija una tasa manual (o vuelve a la automática si viene vacía) y vuelve con el aviso. */
export async function setRateAction(form: FormData): Promise<void> {
  const code = String(form.get("code") ?? "");
  // "1.234,56" (con coma: el punto separa miles) o "943.40" (sin coma: el punto es decimal).
  const typed = String(form.get("manual_rate") ?? "").trim().replace(/\s/g, "");
  const raw = typed.includes(",") ? typed.replace(/\./g, "").replace(",", ".") : typed;
  const clear = form.get("clear") === "1" || !raw;
  const res = await api(`/admin/currencies/${encodeURIComponent(code)}`, {
    method: "PUT",
    body: { manual_rate: clear ? null : raw },
  });
  redirect(`/admin/currencies?${res.ok ? `done=${clear ? "cleared" : "saved"}` : `error=${encodeURIComponent(res.error.message)}`}`);
}

/** Pide las tasas a la fuente ahora mismo. */
export async function refreshRatesAction(): Promise<void> {
  const res = await api("/admin/currencies/refresh", { method: "POST" });
  redirect(`/admin/currencies?${res.ok ? "done=refreshed" : `error=${encodeURIComponent(res.error.message)}`}`);
}
