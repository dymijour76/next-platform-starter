"use client";

import { useTranslations } from "next-intl";
import { useActionState } from "react";
import { Field, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { TranslationFields } from "@/components/forms/TranslationFields";
import { saveSiteAction } from "@/app/admin/site-actions";
import { Section } from "@/components/PageHeading";
import { NETWORKS, SITE_TR } from "./fields";
import { initialFormState } from "@/lib/form";
import { translationValues, withLabels, type Translations } from "@/lib/translations";

export interface CompanySettings {
  name: string; legal_name: string | null; tax_id: string | null; address: string | null; phone: string | null;
  whatsapp: string | null; email: string | null; about: string | null; hours: string | null;
  social: Record<string, string>; translations: Translations;
}

// Nombres de las redes: marcas, no se traducen.
const NETWORK_NAMES: Record<string, string> = {
  instagram: "Instagram", facebook: "Facebook", tiktok: "TikTok", youtube: "YouTube", x: "X", threads: "Threads",
  linkedin: "LinkedIn", pinterest: "Pinterest", snapchat: "Snapchat", telegram: "Telegram", tripadvisor: "Tripadvisor",
  google: "Google",
};

export function SiteForm({ site }: { site: CompanySettings }) {
  const tx = useTranslations("adm.site");
  const [state, action] = useActionState(saveSiteAction, {
    ...initialFormState,
    values: {
      name: site.name, legal_name: site.legal_name ?? "", tax_id: site.tax_id ?? "", about: site.about ?? "",
      hours: site.hours ?? "", address: site.address ?? "", phone: site.phone ?? "", whatsapp: site.whatsapp ?? "",
      email: site.email ?? "",
      ...Object.fromEntries(NETWORKS.map((n) => [`social.${n}`, site.social[n] ?? ""])),
      ...translationValues(site.translations),
    },
  });
  const v = state.values ?? {};
  const f = state.fields ?? {};
  return (
    <form action={action} noValidate className="space-y-10">
      <FormAlert state={state} />
      <Section title={tx("company")} description={tx("companyHint")}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={tx("name")} name="name" required defaultValue={v.name} error={f.name} maxLength={80} />
          <Field label={tx("legalName")} name="legal_name" defaultValue={v.legal_name} error={f.legal_name} maxLength={120} />
          <Field label={tx("taxId")} name="tax_id" defaultValue={v.tax_id} error={f.tax_id} />
          <Field label={tx("hours")} name="hours" defaultValue={v.hours} error={f.hours} hint={tx("hoursHint")} maxLength={120} />
        </div>
        <Textarea label={tx("about")} name="about" rows={2} defaultValue={v.about} error={f.about} hint={tx("aboutHint")} maxLength={300} />
      </Section>
      <Section title={tx("contact")}>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={tx("address")} name="address" defaultValue={v.address} error={f.address} className="sm:col-span-2" />
          <Field label={tx("phone")} name="phone" type="tel" defaultValue={v.phone} error={f.phone} />
          <Field label={tx("email")} name="email" type="email" defaultValue={v.email} error={f.email} />
          <Field label={tx("whatsapp")} name="whatsapp" type="tel" defaultValue={v.whatsapp} error={f.whatsapp}
            hint={tx("whatsappHint")} className="sm:col-span-2" />
        </div>
      </Section>
      <Section title={tx("social")} description={tx("socialHint")}>
        {f.social ? <p className="text-sm text-alert" role="alert">{f.social}</p> : null}
        <div className="grid gap-5 sm:grid-cols-2">
          {NETWORKS.map((n) => (
            <Field key={n} label={NETWORK_NAMES[n]!} name={`social.${n}`} id={`social-${n}`} type="url" inputMode="url"
              placeholder="https://" defaultValue={v[`social.${n}`]} />
          ))}
        </div>
      </Section>
      <Section title={tx("translations")} description={tx("translationsHint")}>
        <TranslationFields values={v} fields={withLabels(SITE_TR, { about: tx("about"), hours: tx("hours") })}
          labels={{ complete: tx("trComplete"), partial: tx("trPartial"), missing: tx("trMissing"), hint: tx("trHint") }} />
      </Section>
      <SubmitButton pendingLabel={tx("saving")}>{tx("save")}</SubmitButton>
    </form>
  );
}
