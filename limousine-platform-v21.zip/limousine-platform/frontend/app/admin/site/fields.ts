import type { TranslationField } from "@/lib/translations";

/** Campos traducibles de los datos de la empresa y redes sociales disponibles. */
export const SITE_TR: TranslationField[] = [
  { key: "about", label: "", kind: "textarea", maxLength: 300 },
  { key: "hours", label: "", maxLength: 120 },
];
export const NETWORKS = [
  "instagram", "facebook", "tiktok", "youtube", "x", "threads", "linkedin", "pinterest", "snapchat", "telegram",
  "tripadvisor", "google",
] as const;
