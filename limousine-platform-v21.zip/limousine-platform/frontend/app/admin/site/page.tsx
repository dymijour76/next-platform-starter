import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import { SiteForm, type CompanySettings } from "./SiteForm";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("adm.site"))("title") };
}

export default async function SitePage() {
  await requirePermission("settings:write");
  const [res, tx] = await Promise.all([api<CompanySettings>("/admin/site"), getTranslations("adm.site")]);
  if (!res.ok) throw new Error(res.error.message);
  return (
    <div className="space-y-8">
      <PageHeading title={tx("title")} description={tx("hint")} />
      <SiteForm site={res.data} />
    </div>
  );
}
