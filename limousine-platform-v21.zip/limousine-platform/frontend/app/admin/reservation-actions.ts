"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import type { BookingSettings, ReservationAdmin } from "@/lib/types";
import { getTranslations } from "next-intl/server";

const STEPS = new Set(["confirm", "complete", "no-show"]);

/** Confirmar, completar o marcar no presentada. La API verifica permisos y transiciones. */
export async function reservationStepAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "id");
  const step = text(form, "step");
  if (!STEPS.has(step)) return { status: "error", message: (await getTranslations("ar"))("unknownAction") };
  const res = await api<ReservationAdmin>(`/admin/reservations/${encodeURIComponent(id)}/${step}`, {
    method: "POST",
    body: { note: text(form, "note") || null },
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/admin/reservations", "layout");
  // La página cambia (desaparece el botón usado), así que el aviso va en la URL.
  redirect(`/admin/reservations/${id}?done=${step}`);
}

export async function adminCancelAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "id");
  const res = await api<ReservationAdmin>(`/admin/reservations/${encodeURIComponent(id)}/cancel`, {
    method: "POST",
    body: { reason: text(form, "reason"), apply_policy: form.get("apply_policy") === "on" },
  });
  if (!res.ok) return fromApiError(res.error, { reason: text(form, "reason") });
  revalidatePath("/admin/reservations", "layout");
  redirect(`/admin/reservations/${id}?done=cancel`);
}

export async function saveBookingSettingsAction(_: FormState, form: FormData): Promise<FormState> {
  const names = ["hold_minutes", "turnaround_minutes", "free_cancellation_hours", "late_cancellation_refund_percent"];
  const values = Object.fromEntries(names.map((n) => [n, text(form, n)]));
  const res = await api<BookingSettings>("/admin/booking/settings", {
    method: "PUT",
    body: Object.fromEntries(names.map((n) => [n, Number(values[n])])),
  });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/admin/reservations/settings");
  return { status: "success", message: (await getTranslations("ar"))("settingsSaved"), values };
}
