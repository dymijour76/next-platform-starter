import type { Metadata } from "next";
import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { Stars } from "@/components/Stars";
import { moderateReviewAction } from "@/app/admin/reviews-actions";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import { getFormat } from "@/lib/format-server";

interface AdminReview {
  id: string; reservation_id: string; reservation_code: string; customer: string; service_name: string;
  driver_name: string | null; service_rating: number; driver_rating: number | null; comment: string | null;
  consent_publish: boolean; status: "PENDING" | "PUBLISHED" | "HIDDEN"; created_at: string;
}
const TABS = [["PENDING", "tabPending"], ["PUBLISHED", "tabPublished"], ["HIDDEN", "tabHidden"], ["all", "tabAll"]] as const;

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("reviews"))("adminTitle") };
}

export default async function ReviewsPage({ searchParams }: { searchParams: Promise<{ status?: string; done?: string }> }) {
  await requirePermission("content:write");
  const { status: raw, done } = await searchParams;
  const status = TABS.some(([s]) => s === raw) ? raw! : "PENDING";
  const [res, t, fmt] = await Promise.all([
    api<{ items: AdminReview[]; total: number; pending: number }>(`/admin/reviews?status=${status}`),
    getTranslations("reviews"), getFormat(),
  ]);
  if (!res.ok) throw new Error(res.error.message);
  const tab = (active: boolean) => `border-b-2 px-1 pb-2 text-sm ${active ? "border-champagne text-ink" : "border-transparent text-slate hover:text-ink"}`;
  return (
    <div className="space-y-8">
      <PageHeading title={t("adminTitle")} description={t("adminHint")} />
      {done === "publish" ? <Notice>{t("published")}</Notice> : done === "hide" ? <Notice>{t("hidden")}</Notice> : null}
      <nav aria-label={t("adminTitle")} className="flex gap-6 border-b border-ink/10">
        {TABS.map(([s, key]) => (
          <Link key={s} href={`/admin/reviews?status=${s}`} className={tab(s === status)} aria-current={s === status ? "page" : undefined}>
            {t(key)}{s === "PENDING" && res.data.pending ? ` (${res.data.pending})` : ""}
          </Link>
        ))}
      </nav>
      {!res.data.items.length ? <p className="text-slate">{t("empty")}</p> : (
        <ul className="space-y-4">
          {res.data.items.map((r) => (
            <li key={r.id} className="border border-ink/10 bg-paper p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="space-y-1">
                  <p className="flex items-center gap-3 text-sm text-ink">
                    <Stars rating={r.service_rating} /> <span>{r.service_name}</span>
                  </p>
                  {r.driver_rating && r.driver_name ? (
                    <p className="text-sm text-slate">{t("driverRating", { driver: r.driver_name, rating: `${r.driver_rating}/5` })}</p>
                  ) : null}
                </div>
                <span className="rounded-sm bg-pearl px-2 py-0.5 text-xs text-ink">{t(`statusLabel.${r.status}`)}</span>
              </div>
              <blockquote className="mt-3 text-ink">{r.comment ?? <span className="text-slate">{t("noComment")}</span>}</blockquote>
              {r.comment && !r.consent_publish ? <p className="mt-1 text-xs text-slate">{t("notAuthorized")}</p> : null}
              <p className="mt-3 text-xs text-slate">
                {t("by", { name: r.customer, code: r.reservation_code, date: fmt.date(r.created_at) })}{" · "}
                <Link href={`/admin/reservations/${r.reservation_id}`} className="underline underline-offset-4">{r.reservation_code}</Link>
              </p>
              {r.comment && r.consent_publish ? (
                <form action={moderateReviewAction} className="mt-4 flex gap-3">
                  <input type="hidden" name="id" value={r.id} />
                  <input type="hidden" name="status" value={status} />
                  {r.status !== "PUBLISHED" ? (
                    <button name="action" value="publish" className="rounded-sm bg-ink px-4 py-2 text-sm text-pearl">{t("publish")}</button>
                  ) : null}
                  {r.status !== "HIDDEN" ? (
                    <button name="action" value="hide" className="rounded-sm border border-ink/25 px-4 py-2 text-sm text-ink">{t("hide")}</button>
                  ) : null}
                </form>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
