import type { Metadata } from "next";
import Link from "next/link";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import { can, requireStaff } from "@/lib/auth";
import type { Dashboard } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("admin"))("title") };
}

const TIME: Intl.DateTimeFormatOptions = { hour: "2-digit", minute: "2-digit", hourCycle: "h23" };

function Kpi({ label, value, hint, href }: { label: string; value: string; hint?: string; href?: string }) {
  const body = (
    <>
      <dt className="text-sm text-slate">{label}</dt>
      <dd className="mt-1 font-display text-3xl tabular-nums text-ink">{value}</dd>
      {hint ? <dd className="mt-1 text-xs text-slate">{hint}</dd> : null}
    </>
  );
  return (
    <div className="bg-paper px-5 py-4">
      {href ? <Link href={href} className="block hover:opacity-80">{body}</Link> : body}
    </div>
  );
}

export default async function AdminHome({ searchParams }: { searchParams: Promise<{ denied?: string }> }) {
  const [t, tr, acc, labels, fmt] = await Promise.all([
    getTranslations("dash"), getTranslations("dash"), getTranslations("account"),
    getTranslations("labels.reservation"), getFormat(),
  ]);
  const [user, { denied }] = await Promise.all([requireStaff(), searchParams]);
  const res = can(user, "dashboard:view") ? await api<Dashboard>("/admin/dashboard") : null;
  const d = res?.ok ? res.data : null;
  const change = d?.finance?.change;

  return (
    <div className="space-y-10">
      <PageHeading title={acc("hello", { name: user.first_name })} description={t("profile", { roles: user.roles.map((r) => r.name).join(", ") })} />
      {denied ? <Notice tone="info">{t("denied")}</Notice> : null}

      {d?.alerts.length ? (
        <section aria-labelledby="alerts-title" className="border-l-2 border-alert bg-paper px-5 py-4">
          <h2 id="alerts-title" className="text-sm font-medium text-alert">{t("attention")}</h2>
          <ul className="mt-2 space-y-1.5">
            {d.alerts.map((a, i) => (
              <li key={i}><Link href={a.href} className="text-ink underline decoration-alert/40 underline-offset-4 hover:decoration-alert">{a.text}</Link></li>
            ))}
          </ul>
        </section>
      ) : d ? (
        <p className="border-l-2 border-ok bg-paper px-5 py-3 text-sm text-ok">{t("allGood")}</p>
      ) : null}

      {d?.operations ? (
        <section aria-labelledby="ops-title" className="space-y-4">
          <h2 id="ops-title" className="font-display text-2xl text-ink">{t("operations")}</h2>
          <dl className="grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label={t("tripsToday")} value={String(d.operations.trips_today)} hint={t("inProgressNow", { count: d.operations.in_progress })} />
            <Kpi label={t("next7")} value={String(d.operations.next_7_days)} href="/admin/reservations" />
            <Kpi label={t("unassigned")} value={String(d.operations.unassigned_upcoming)} hint={t("unassignedHint")}
              href="/admin/reservations?unassigned=true" />
            <Kpi label={labels("PENDING_PAYMENT")} value={String(d.operations.pending_payment)} hint={t("pendingHint")}
              href="/admin/reservations?status=PENDING_PAYMENT" />
          </dl>
          {d.operations.today.length ? (
            <div className="overflow-x-auto border border-ink/10 bg-paper">
              <table className="w-full min-w-[40rem] text-left text-sm">
                <caption className="px-4 pt-3 text-left text-sm font-medium text-ink">{t("todayTrips")}</caption>
                <thead className="border-b border-ink/10 text-slate">
                  <tr>
                    <th scope="col" className="px-4 py-2 font-medium">{t("time")}</th>
                    <th scope="col" className="px-4 py-2 font-medium">{t("booking")}</th>
                    <th scope="col" className="px-4 py-2 font-medium">{t("driver")}</th>
                    <th scope="col" className="px-4 py-2 font-medium">{t("status")}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink/10">
                  {d.operations.today.map((t) => (
                    <tr key={t.id}>
                      <td className="px-4 py-2 font-display text-lg tabular-nums">{fmt.wall(t.pickup_local, TIME)}</td>
                      <td className="px-4 py-2">
                        <Link href={`/admin/reservations/${t.id}`} className="font-medium text-ink hover:underline">{t.code}</Link>
                        <span className="block text-slate">{t.service}, {t.contact_name}</span>
                      </td>
                      <td className="px-4 py-2">{t.driver ?? <span className="text-alert">{tr("noDriver")}</span>}
                        {t.vehicle ? <span className="block text-slate">{t.vehicle}</span> : null}</td>
                      <td className="px-4 py-2"><StatusBadge status={t.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm text-slate">{t("noTripsToday")}</p>
          )}
        </section>
      ) : null}

      {d?.finance ? (
        <section aria-labelledby="fin-title" className="space-y-4">
          <h2 id="fin-title" className="font-display text-2xl text-ink">{t("thisMonth")}</h2>
          <dl className="grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-2 lg:grid-cols-4">
            <Kpi label={t("netRevenue")} value={fmt.money(d.finance.month_net, d.currency)}
              hint={change === null || change === undefined ? t("noPrevious")
                : t("change", { change: `${change >= 0 ? "+" : "−"}${fmt.number(Math.abs(change * 100), { maximumFractionDigits: 1 })}` })} />
            <Kpi label={t("collected")} value={fmt.money(d.finance.month_collected, d.currency)} hint={t("payments", { count: d.finance.month_payments })} href="/admin/payments" />
            <Kpi label={t("refunded")} value={fmt.money(d.finance.month_refunded, d.currency)} />
            <Kpi label={t("averageTicket")} value={fmt.money(d.finance.average_ticket, d.currency)} />
          </dl>
        </section>
      ) : null}

      {d?.fleet || d?.drivers ? (
        <section aria-labelledby="fleet-title" className="space-y-4">
          <h2 id="fleet-title" className="font-display text-2xl text-ink">{t("fleet")}</h2>
          <dl className="grid gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-3">
            {d.fleet ? <Kpi label={t("activeVehicles")} value={String(d.fleet.active_vehicles)} href="/admin/vehicles" /> : null}
            {d.fleet ? <Kpi label={t("inMaintenance")} value={String(d.fleet.in_maintenance)} /> : null}
            {d.drivers ? <Kpi label={t("activeDrivers")} value={String(d.drivers.active)} href="/admin/drivers" /> : null}
          </dl>
        </section>
      ) : null}

      {!d ? (
        <p className="text-slate">{t("useMenu")}</p>
      ) : null}
    </div>
  );
}
