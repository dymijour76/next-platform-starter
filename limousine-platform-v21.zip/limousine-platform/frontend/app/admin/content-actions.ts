"use server";

import { readTranslations, SLIDE_TR, translationFormValues } from "@/lib/translations";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api, apiUpload } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import { zonedToIso } from "@/lib/timezone";
import type { MediaAsset, PublicPricingConfig, SlideAdmin } from "@/lib/types";
import { getTranslations } from "next-intl/server";

function refresh() {
  revalidatePath("/", "layout");
}

export async function uploadMediaAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.content");
  const file = form.get("file");
  const alt = text(form, "alt_text");
  if (!(file instanceof File) || file.size === 0) {
    return { status: "error", message: tx("chooseImage"), fields: { file: tx("chooseImage") }, values: { alt_text: alt } };
  }
  const body = new FormData();
  body.set("file", file, file.name);
  body.set("alt_text", alt);
  const res = await apiUpload<MediaAsset>("/admin/media", body);
  if (!res.ok) return fromApiError(res.error, { alt_text: alt });
  refresh();
  return { status: "success", message: tx("uploaded") };
}

export async function updateAltAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.content");
  const res = await api<MediaAsset>(`/admin/media/${encodeURIComponent(text(form, "id"))}`, {
    method: "PATCH",
    body: { alt_text: text(form, "alt_text") },
  });
  if (!res.ok) return fromApiError(res.error);
  refresh();
  return { status: "success", message: tx("descriptionSaved") };
}

export async function deleteMediaAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.content");
  const res = await api<void>(`/admin/media/${encodeURIComponent(text(form, "id"))}`, { method: "DELETE" });
  if (!res.ok) return fromApiError(res.error);
  refresh();
  return { status: "success", message: tx("imageDeleted") };
}

async function toIso(date: string, time: string): Promise<string | null> {
  if (!date) return null;
  const config = await api<PublicPricingConfig>("/pricing/config", { auth: false });
  return zonedToIso(date, time || "00:00", config.ok ? config.data.timezone : "America/Santiago");
}

const SLIDE_FIELDS = ["image_id", "title", "subtitle", "cta_label", "cta_url", "start_date", "start_time", "end_date", "end_time"];

export async function saveSlideAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.content");
  const id = text(form, "id");
  const v = Object.fromEntries(SLIDE_FIELDS.map((n) => [n, text(form, n)]));
  const body = {
    image_id: v.image_id,
    title: v.title,
    subtitle: v.subtitle || null,
    cta_label: v.cta_label || null,
    cta_url: v.cta_url || null,
    is_active: form.get("is_active") === "on",
    starts_at: await toIso(v.start_date!, v.start_time!),
    ends_at: await toIso(v.end_date!, v.end_time!),
    translations: readTranslations(form, SLIDE_TR),
  };
  if (!body.image_id) return { status: "error", message: tx("chooseImage"), fields: { image_id: tx("chooseImage") }, values: v };
  const res = id
    ? await api<SlideAdmin>(`/admin/carousel/${encodeURIComponent(id)}`, { method: "PUT", body })
    : await api<SlideAdmin>("/admin/carousel", { method: "POST", body });
  if (!res.ok) {
    const state = fromApiError(res.error, { ...v, ...translationFormValues(form) });
    if (state.fields?.ends_at) state.fields.end_date = state.fields.ends_at;
    return state;
  }
  refresh();
  if (!id) redirect("/admin/content?saved=1");
  return { status: "success", message: tx("slideSaved"), values: { ...v, ...translationFormValues(form) } };
}

export async function deleteSlideAction(form: FormData): Promise<void> {
  await api<void>(`/admin/carousel/${encodeURIComponent(text(form, "id"))}`, { method: "DELETE" });
  refresh();
  redirect("/admin/content?deleted=1");
}

/** Sube o baja una diapositiva un lugar, partiendo del orden actual (no del que tenía la página). */
export async function moveSlideAction(form: FormData): Promise<void> {
  const current = await api<SlideAdmin[]>("/admin/carousel");
  if (!current.ok) return;
  const ids = current.data.map((s) => s.id);
  const id = text(form, "id");
  const i = ids.indexOf(id);
  const j = form.get("direction") === "up" ? i - 1 : i + 1;
  if (i < 0 || j < 0 || j >= ids.length) return;
  [ids[i], ids[j]] = [ids[j]!, ids[i]!];
  await api<SlideAdmin[]>("/admin/carousel-order", { method: "PUT", body: { ids } });
  refresh();
}

export async function saveGalleryAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.content");
  // Cada imagen marcada trae su posición; se ordenan por ella.
  const chosen = form.getAll("image").map(String);
  const ordered = chosen
    .map((id) => ({ id, pos: Number(form.get(`pos-${id}`)) || 99 }))
    .sort((a, b) => a.pos - b.pos)
    .map((x) => x.id);
  const res = await api(`/admin/services/${encodeURIComponent(text(form, "service_id"))}/images`, {
    method: "PUT",
    body: { image_ids: ordered },
  });
  if (!res.ok) return fromApiError(res.error);
  refresh();
  return { status: "success", message: ordered.length ? tx("photosSaved") : tx("noPhotos") };
}
