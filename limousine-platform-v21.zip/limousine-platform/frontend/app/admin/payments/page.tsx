import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { PaymentPage } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.payments");
  return { title: tx("title") };
}

const PAGE_SIZE = 25;
type Params = { q?: string; status?: string; date_from?: string; date_to?: string; page?: string };

export default async function PaymentsPage({ searchParams }: { searchParams: Promise<Params> }) {
  const tx = await getTranslations("adm.payments");
  const wt = await getTranslations("wallet");
  const [lb, fmt] = await Promise.all([getTranslations("labels"), getFormat()]);
  const [actor, params] = await Promise.all([requirePermission("payments:read"), searchParams]);
  const page = Math.max(1, Number(params.page) || 1);
  const res = await api<PaymentPage>("/admin/payments", { query: { ...params, page, page_size: PAGE_SIZE } });
  const linkReservations = can(actor, "reservations:read");
  const pages = res.ok ? Math.max(1, Math.ceil(res.data.total / PAGE_SIZE)) : 1;
  const pageLink = (p: number) =>
    `/admin/payments?${new URLSearchParams(Object.entries({ ...params, page: String(p) }).filter(([, v]) => v) as [string, string][])}`;
  const input = "mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5";

  return (
    <div className="space-y-8">
      <PageHeading title={tx("title")} description={tx("listHint")} />

      <form className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 lg:items-end" role="search">
        <label className="lg:col-span-2">
          <span className="block text-sm font-medium text-ink">{tx("search")}</span>
          <input name="q" defaultValue={params.q} placeholder={tx("searchPlaceholder")} className={input} />
        </label>
        <label>
          <span className="block text-sm font-medium text-ink">{tx("status")}</span>
          <select name="status" defaultValue={params.status ?? ""} className={input}>
            <option value="">{tx("withCharges")}</option>
            {["CREATED", "AUTHORIZED", "REJECTED", "ABORTED", "EXPIRED", "ERROR", "REFUNDED", "PARTIALLY_REFUNDED"].map((k) => <option key={k} value={k}>{lb(`payment.${k}`)}</option>)}
          </select>
        </label>
        <label>
          <span className="block text-sm font-medium text-ink">{tx("from")}</span>
          <input type="date" name="date_from" defaultValue={params.date_from} className={input} />
        </label>
        <label>
          <span className="block text-sm font-medium text-ink">{tx("to")}</span>
          <input type="date" name="date_to" defaultValue={params.date_to} className={input} />
        </label>
        <div className="flex gap-3 lg:col-span-5">
          <button type="submit" className="rounded-sm border border-ink/25 bg-paper px-5 py-2.5 text-sm hover:border-ink/50">{tx("filter")}</button>
          <Link href="/admin/payments" className="px-2 py-2.5 text-sm text-slate hover:text-ink">{tx("clear")}</Link>
        </div>
      </form>

      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : (
        <>
          <dl className="grid grid-cols-2 gap-px overflow-hidden border border-ink/10 bg-ink/10 sm:grid-cols-4">
            {[
              [tx("collected"), fmt.money(res.data.totals.collected)],
              [tx("refunded"), fmt.money(res.data.totals.refunded)],
              [tx("net"), fmt.money(res.data.totals.net)],
              [tx("title"), String(res.data.totals.count)],
            ].map(([term, value]) => (
              <div key={term} className="bg-paper px-5 py-4">
                <dt className="text-sm text-slate">{term}</dt>
                <dd className="mt-1 font-display text-2xl tabular-nums text-ink">{value}</dd>
              </div>
            ))}
          </dl>

          {res.data.items.length === 0 ? (
            <p className="text-slate">{tx("noResults")}</p>
          ) : (
            <div className="overflow-x-auto border border-ink/10 bg-paper">
              <table className="w-full min-w-[52rem] text-left text-sm">
                <caption className="sr-only">{tx("title")}</caption>
                <thead className="border-b border-ink/10 text-slate">
                  <tr>
                    <th scope="col" className="px-4 py-3 font-medium">{tx("date")}</th>
                    <th scope="col" className="px-4 py-3 font-medium">{tx("booking")}</th>
                    <th scope="col" className="px-4 py-3 font-medium">{tx("method")}</th>
                    <th scope="col" className="px-4 py-3 font-medium">{tx("status")}</th>
                    <th scope="col" className="px-4 py-3 text-right font-medium">{tx("amount")}</th>
                    <th scope="col" className="px-4 py-3 text-right font-medium">{tx("refunded")}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ink/10">
                  {res.data.items.map((p) => (
                    <tr key={p.id}>
                      <td className="whitespace-nowrap px-4 py-3">{fmt.date(p.authorized_at ?? p.created_at)}</td>
                      <td className="px-4 py-3">
                        {p.is_topup ? <span className="whitespace-nowrap font-medium">{wt("topupRow")}</span>
                          : linkReservations ? (
                          <Link href={`/admin/reservations/${p.reservation_id}`} className="whitespace-nowrap font-medium text-ink hover:underline">{p.reservation_code}</Link>
                        ) : <span className="whitespace-nowrap font-medium">{p.reservation_code}</span>}
                        <span className="block text-slate">{p.customer_name}</span>
                      </td>
                      <td className="px-4 py-3">
                        {lb.has(`provider.${p.provider}`) ? lb(`provider.${p.provider}`) : p.provider}
                        <span className="block text-slate">
                          {p.card_last4 ? `**** ${p.card_last4}` : ""}{p.authorization_code ? `, ${tx("authShort", { code: p.authorization_code })}` : ""}
                        </span>
                      </td>
                      <td className={`px-4 py-3 ${p.status === "ERROR" || p.refunds.some((f) => f.status === "FAILED") ? "text-alert" : ""}`}>
                        {lb.has(`payment.${p.status}`) ? lb(`payment.${p.status}`) : p.status}
                        {p.refunds.some((f) => f.status === "FAILED") ? <span className="block">{tx("refundFailed")}</span> : null}
                      </td>
                      <td className="px-4 py-3 text-right tabular-nums">{fmt.money(p.amount, p.currency)}</td>
                      <td className="px-4 py-3 text-right tabular-nums">{Number(p.refunded_amount) ? fmt.money(p.refunded_amount, p.currency) : "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <nav aria-label={tx("pagination")} className="flex items-center justify-between text-sm text-slate">
            <span>{tx("pageOf", { page, pages })}</span>
            <span className="flex gap-4">
              {page > 1 ? <Link href={pageLink(page - 1)} className="text-ink hover:underline">{tx("previous")}</Link> : null}
              {page < pages ? <Link href={pageLink(page + 1)} className="text-ink hover:underline">{tx("next")}</Link> : null}
            </span>
          </nav>
        </>
      )}
    </div>
  );
}
