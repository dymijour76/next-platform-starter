"use client";

import { useActionState } from "react";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import { initialFormState } from "@/lib/form";
import type { ImageInfo, MediaAsset } from "@/lib/types";
import { saveGalleryAction } from "../content-actions";
import { useTranslations } from "next-intl";

/** Fotografías del servicio: marque las que se muestran y su orden (1 = portada). */
export function GalleryForm({ serviceId, gallery, library }: { serviceId: string; gallery: ImageInfo[]; library: MediaAsset[] }) {
  const tx = useTranslations("adm.services");
  const [state, action] = useActionState(saveGalleryAction, initialFormState);
  const position = new Map(gallery.map((g, i) => [g.id, i + 1]));
  if (!library.length) return <p className="text-sm text-slate">{tx("uploadHint")}</p>;
  return (
    <form action={action} className="space-y-4">
      <FormAlert state={state} />
      <input type="hidden" name="service_id" value={serviceId} />
      <ul className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {library.map((img) => (
          <li key={img.id} className="bg-paper p-2">
            <ResponsiveImage image={img} sizes="12rem" className="aspect-[4/3] w-full object-cover" />
            <div className="mt-2 flex items-center justify-between gap-2 text-sm">
              <label className="flex items-center gap-2">
                <input type="checkbox" name="image" value={img.id} defaultChecked={position.has(img.id)} className="size-4 accent-ink" />
                {tx("show")}
              </label>
              <label className="flex items-center gap-1 text-slate">
                {tx("order")}
                <input type="number" name={`pos-${img.id}`} min={1} max={12} defaultValue={position.get(img.id) ?? ""}
                  aria-label={tx("orderOf", { name: img.alt })} className="w-14 rounded-sm border border-ink/20 px-2 py-1 text-ink" />
              </label>
            </div>
            <p className="mt-1 truncate text-xs text-slate">{img.alt}</p>
          </li>
        ))}
      </ul>
      <SubmitButton pendingLabel={tx("saving")} variant="secondary">{tx("savePhotos")}</SubmitButton>
    </form>
  );
}
