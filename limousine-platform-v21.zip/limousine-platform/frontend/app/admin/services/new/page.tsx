import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { requirePermission } from "@/lib/auth";
import { ServiceForm } from "../ServiceForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.services");
  return { title: tx("new") };
}

export default async function NewServicePage() {
  const tx = await getTranslations("adm.services");
  await requirePermission("services:write");
  await requirePermission("pricing:write");
  return (
    <div className="space-y-8">
      <Link href="/admin/services" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={tx("new")} />
      <ServiceForm canWrite canPrice />
    </div>
  );
}
