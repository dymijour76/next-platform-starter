"use client";

import { TranslationFields } from "@/components/forms/TranslationFields";
import { SERVICE_TR, translationValues, withLabels } from "@/lib/translations";
import { useActionState } from "react";
import { Checkbox, Field, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { Section } from "@/components/PageHeading";
import type { FormState } from "@/lib/form";
import type { ServiceAdmin } from "@/lib/types";
import { saveServiceAction } from "../catalog-actions";
import { useTranslations } from "next-intl";

interface Props {
  service?: ServiceAdmin;
  canWrite: boolean;
  canPrice: boolean;
}

export function ServiceForm({ service: s, canWrite, canPrice }: Props) {
  const tx = useTranslations("adm.services");
  const initial: FormState = {
    status: "idle",
    values: s
      ? {
          slug: s.slug, name: s.name, tagline: s.tagline ?? "", description: s.description ?? "",
          features: s.features.join("\n"), passenger_capacity: String(s.passenger_capacity),
          luggage_capacity: s.luggage_capacity === null ? "" : String(s.luggage_capacity),
          sort_order: String(s.sort_order), base_fare: s.base_fare, hourly_rate: s.hourly_rate,
          min_hours: s.min_hours, max_hours: s.max_hours ?? "", minimum_fare: s.minimum_fare,
          ...translationValues(s.translations),
        }
      : { sort_order: "100", base_fare: "0", minimum_fare: "0" },
  };
  const [state, action] = useActionState(saveServiceAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};

  return (
    <form action={action} className="space-y-10" noValidate key={JSON.stringify(v)}>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={s?.id ?? ""} />
      <fieldset disabled={!canWrite} className="space-y-10">
        <Section title={tx("presentation")} description={tx("presentationHint")}>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label={tx("name")} name="name" required defaultValue={v.name} error={f.name} />
            <Field label={tx("slug")} name="slug" required defaultValue={v.slug} error={f.slug}
              hint={tx("slugHint")} />
            <Field label={tx("tagline")} name="tagline" className="sm:col-span-2" defaultValue={v.tagline} error={f.tagline} />
            <Textarea label={tx("description")} name="description" rows={4} className="sm:col-span-2"
              defaultValue={v.description} error={f.description} />
            <Textarea label={tx("features")} name="features" rows={4} className="sm:col-span-2"
              defaultValue={v.features} error={f.features} hint={tx("featuresHint")} />
          </div>
        </Section>

        <Section title={tx("translations")} description={tx("translationsHint")}>
          <TranslationFields
            values={v}
            fields={withLabels(SERVICE_TR, { name: tx("name"), tagline: tx("shortTagline"), description: tx("description"), features: tx("featuresPerLine") })}
            labels={{ complete: tx("trComplete"), partial: tx("trPartial"), missing: tx("trMissing"), hint: tx("trHint") }}
          />
        </Section>

        <Section title={tx("capacity")} description={s
          ? tx("capacityCount", { count: s.vehicle_count })
          : tx("capacityHint")}>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label={tx("passengers")} name="passenger_capacity" type="number" min={1} max={60} required
              defaultValue={v.passenger_capacity} error={f.passenger_capacity} />
            <Field label={tx("luggage")} name="luggage_capacity" type="number" min={0} max={50}
              defaultValue={v.luggage_capacity} error={f.luggage_capacity} />
            <Field label={tx("sortOrder")} name="sort_order" type="number" min={0} required
              defaultValue={v.sort_order} error={f.sort_order} hint={tx("sortOrderHint")} />
          </div>
        </Section>

        <Section
          title={tx("tariff")}
          description={canPrice
            ? tx("tariffHint")
            : tx("tariffReadOnly")}
        >
          <fieldset disabled={!canPrice} className="grid gap-5 sm:grid-cols-2">
            <Field label={tx("hourlyRate")} name="hourly_rate" inputMode="numeric" required defaultValue={v.hourly_rate} error={f.hourly_rate} />
            <Field label={tx("baseFare")} name="base_fare" inputMode="numeric" required defaultValue={v.base_fare} error={f.base_fare}
              hint={tx("baseFareHint")} />
            <Field label={tx("minHours")} name="min_hours" inputMode="decimal" required defaultValue={v.min_hours} error={f.min_hours} />
            <Field label={tx("maxHours")} name="max_hours" inputMode="decimal" defaultValue={v.max_hours} error={f.max_hours} />
            <Field label={tx("minimumFare")} name="minimum_fare" inputMode="numeric" required defaultValue={v.minimum_fare}
              error={f.minimum_fare} hint={tx("minimumFareHint")} />
          </fieldset>
        </Section>

        <Section title={tx("publication")}>
          <Checkbox name="is_active" defaultChecked={s ? s.is_active : true}>
            {tx("activeHint")}
          </Checkbox>
        </Section>
      </fieldset>
      {canWrite ? (
        <div className="border-t border-ink/10 pt-6">
          <SubmitButton pendingLabel={tx("saving")}>{s ? tx("saveChanges") : tx("create")}</SubmitButton>
        </div>
      ) : null}
    </form>
  );
}
