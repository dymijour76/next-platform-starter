import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading, Section } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { MediaAsset, ServiceAdmin } from "@/lib/types";
import { GalleryForm } from "../GalleryForm";
import { ServiceForm } from "../ServiceForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.services");
  return { title: tx("service") };
}

export default async function ServiceDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ created?: string }>;
}) {
  const tx = await getTranslations("adm.services");
  const [actor, { id }, { created }] = await Promise.all([
    requirePermission("services:read"), params, searchParams,
  ]);
  const [res, library] = await Promise.all([
    api<ServiceAdmin>(`/admin/services/${encodeURIComponent(id)}`),
    can(actor, "content:write") ? api<MediaAsset[]>("/admin/media") : Promise.resolve(null),
  ]);
  if (!res.ok) notFound();
  const s = res.data;
  return (
    <div className="space-y-8">
      <Link href="/admin/services" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading
        title={s.name}
        description={s.is_active ? tx("activeInCatalog") : tx("inactiveHidden")}
        action={s.is_active ? (
          <Link href={`/services/${s.slug}`} className="text-sm text-ink underline decoration-champagne underline-offset-4">
            {tx("viewOnSite")}
          </Link>
        ) : null}
      />
      {created ? <Notice>{tx("created")}</Notice> : null}
      <ServiceForm service={s} canWrite={can(actor, "services:write")} canPrice={can(actor, "pricing:write")} />
      {library?.ok ? (
        <Section title={tx("photos")} description={tx("photosHint")}>
          <GalleryForm serviceId={s.id} gallery={s.gallery} library={library.data} />
        </Section>
      ) : null}
    </div>
  );
}
