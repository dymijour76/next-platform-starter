import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { ServiceAdmin } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.services");
  return { title: tx("title") };
}

export default async function AdminServicesPage() {
  const tx = await getTranslations("adm.services");
  const fmt = await getFormat();
  const actor = await requirePermission("services:read");
  const res = await api<ServiceAdmin[]>("/admin/services");
  const canCreate = can(actor, "services:write") && can(actor, "pricing:write");
  return (
    <div className="space-y-8">
      <PageHeading
        title={tx("title")}
        description={tx("listHint")}
        action={canCreate ? (
          <Link href="/admin/services/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
            {tx("new")}
          </Link>
        ) : null}
      />
      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="text-slate">
          {tx("empty")} {canCreate ? tx("createFirst") : null}
        </p>
      ) : (
        <div className="overflow-x-auto border border-ink/10 bg-paper">
          <table className="w-full min-w-[44rem] text-left text-sm">
            <caption className="sr-only">{tx("title")}</caption>
            <thead className="border-b border-ink/10 text-slate">
              <tr>
                <th scope="col" className="px-4 py-3 font-medium">{tx("service")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("passengers")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("vehicles")}</th>
                <th scope="col" className="px-4 py-3 text-right font-medium">{tx("hourlyRate")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("minimum")}</th>
                <th scope="col" className="px-4 py-3 text-right font-medium">{tx("from")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("status")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10">
              {res.data.map((s) => (
                <tr key={s.id} className="hover:bg-pearl/50">
                  <td className="px-4 py-3">
                    <Link href={`/admin/services/${s.id}`} className="font-medium text-ink hover:underline">{s.name}</Link>
                    <span className="block text-slate">/services/{s.slug}</span>
                  </td>
                  <td className="px-4 py-3 tabular-nums">{s.passenger_capacity}</td>
                  <td className={`px-4 py-3 tabular-nums ${s.vehicle_count === 0 && s.is_active ? "text-alert" : ""}`}>
                    {s.vehicle_count}{s.vehicle_count === 0 && s.is_active ? " (no se puede reservar)" : ""}
                  </td>
                  <td className="px-4 py-3 text-right tabular-nums">{fmt.money(s.hourly_rate, s.currency)}</td>
                  <td className="px-4 py-3">{fmt.hours(s.min_hours)}</td>
                  <td className="px-4 py-3 text-right tabular-nums">{fmt.money(s.price_from, s.currency)}</td>
                  <td className="px-4 py-3">
                    <span className={s.is_active ? "text-ok" : "text-slate"}>{s.is_active ? tx("active") : tx("inactive")}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
