"use server";

import { revalidatePath } from "next/cache";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import type { RefundInfo } from "@/lib/types";
import { getTranslations } from "next-intl/server";

function decimal(raw: string): string {
  return raw.replace(/[\s$.]/g, "").replace(",", ".");
}

export async function refundPaymentAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.payments");
  const values = { amount: text(form, "amount"), reason: text(form, "reason") };
  const res = await api<RefundInfo>(`/admin/payments/${encodeURIComponent(text(form, "payment_id"))}/refund`, {
    method: "POST",
    body: { amount: decimal(values.amount), reason: values.reason },
  });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/admin", "layout");
  return res.data.status === "SUCCEEDED"
    ? { status: "success", message: tx("refundDone") }
    : { status: "error", message: tx("gatewayRejected", { detail: res.data.error_message ?? tx("noDetail") }) };
}

export async function retryRefundAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.payments");
  const res = await api<RefundInfo>(`/admin/refunds/${encodeURIComponent(text(form, "refund_id"))}/retry`, {
    method: "POST",
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/admin", "layout");
  return res.data.status === "SUCCEEDED"
    ? { status: "success", message: tx("refundDone") }
    : { status: "error", message: tx("failedAgain", { detail: res.data.error_message ?? tx("noDetail") }) };
}
