"use client";

import { useActionState } from "react";
import { Field, Select, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import type { FormState } from "@/lib/form";
import type { Driver } from "@/lib/types";
import { saveDriverAction } from "../fleet-actions";
import { useTranslations } from "next-intl";

const CLASSES = ["A1", "A2", "A3", "A4", "A5", "B"];

export function DriverForm({ driver: d, canWrite }: { driver?: Driver; canWrite: boolean }) {
  const tx = useTranslations("adm.drivers");
  const [first, ...rest] = (d?.name ?? "").split(" ");
  const initial: FormState = {
    status: "idle",
    values: d
      ? { email: d.email, first_name: first ?? "", last_name: rest.join(" "), phone: d.phone ?? "",
          license_number: d.license_number, license_class: d.license_class,
          license_expires_on: d.license_expires_on, status: d.status, notes: d.notes ?? "" }
      : { license_class: "A2", status: "ACTIVE" },
  };
  const [state, action] = useActionState(saveDriverAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};
  return (
    <form action={action} className="max-w-2xl space-y-6" noValidate key={JSON.stringify(v)}>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={d?.id ?? ""} />
      <fieldset disabled={!canWrite} className="grid gap-5 sm:grid-cols-2">
        <Field label={tx("email")} name="email" type="email" required className="sm:col-span-2" readOnly={!!d}
          defaultValue={v.email} error={f.email}
          hint={d ? tx("emailHintEdit") : tx("emailHintNew")} />
        <Field label={tx("firstName")} name="first_name" required defaultValue={v.first_name} error={f.first_name} />
        <Field label={tx("lastName")} name="last_name" required defaultValue={v.last_name} error={f.last_name} />
        <Field label={tx("phone")} name="phone" type="tel" required defaultValue={v.phone} error={f.phone} />
        <Field label={tx("licenseNumber")} name="license_number" required defaultValue={v.license_number} error={f.license_number} />
        <Select label={tx("licenseClassLabel")} name="license_class" defaultValue={v.license_class} error={f.license_class}>
          {CLASSES.map((c) => <option key={c} value={c}>{tx("cls", { cls: c })}</option>)}
        </Select>
        <Field label={tx("licenseExpiry")} name="license_expires_on" type="date" required
          defaultValue={v.license_expires_on} error={f.license_expires_on} hint={tx("licenseExpiryHint")} />
        <Select label={tx("status")} name="status" defaultValue={v.status} error={f.status}>
          <option value="ACTIVE">{tx("active")}</option>
          <option value="INACTIVE">{tx("inactive")}</option>
        </Select>
        <Textarea label={tx("notes")} name="notes" rows={2} className="sm:col-span-2" defaultValue={v.notes} error={f.notes} />
      </fieldset>
      {canWrite ? <SubmitButton pendingLabel={tx("saving")}>{d ? tx("saveChanges") : tx("create")}</SubmitButton> : null}
    </form>
  );
}
