import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { RatingSummary } from "@/components/Stars";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { Driver } from "@/lib/types";
import { DriverForm } from "../DriverForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.drivers");
  return { title: tx("driver") };
}

export default async function DriverPage({ params, searchParams }: {
  params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }>;
}) {
  const tx = await getTranslations("adm.drivers");
  const rv = await getTranslations("reviews");
  const [actor, { id }, { created }] = await Promise.all([requirePermission("drivers:read"), params, searchParams]);
  const res = await api<Driver>(`/admin/drivers/${encodeURIComponent(id)}`);
  if (!res.ok) notFound();
  const d = res.data;
  return (
    <div className="space-y-8">
      <Link href="/admin/drivers" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={d.name} description={tx("upcomingCount", { count: d.upcoming_trips })} />
      {created ? <Notice>{tx("created")}</Notice> : null}
      <section aria-labelledby="driver-rating" className="border border-ink/10 bg-paper p-5">
        <h2 id="driver-rating" className="text-sm font-medium text-ink">{rv("driverPanel")}</h2>
        <div className="mt-2">
          {d.rating_count && d.rating_average !== null
            ? <RatingSummary rating={{ average: d.rating_average, count: d.rating_count }} />
            : <p className="text-sm text-slate">{rv("noRatings")}</p>}
        </div>
      </section>
      {d.license_expired ? <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">{tx("expiredNotice")}</p> : null}
      <DriverForm driver={d} canWrite={can(actor, "drivers:write")} />
    </div>
  );
}
