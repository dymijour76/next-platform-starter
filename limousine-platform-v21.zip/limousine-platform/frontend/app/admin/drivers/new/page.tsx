import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { requirePermission } from "@/lib/auth";
import { DriverForm } from "../DriverForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.drivers");
  return { title: tx("new") };
}

export default async function NewDriverPage() {
  const tx = await getTranslations("adm.drivers");
  await requirePermission("drivers:write");
  return (
    <div className="space-y-8">
      <Link href="/admin/drivers" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={tx("new")} />
      <DriverForm canWrite />
    </div>
  );
}
