import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { Driver } from "@/lib/types";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.drivers");
  return { title: tx("title") };
}

function dmy(iso: string) {
  const [y, m, d] = iso.split("-");
  return `${d}-${m}-${y}`;
}

export default async function DriversPage() {
  const tx = await getTranslations("adm.drivers");
  const actor = await requirePermission("drivers:read");
  const res = await api<Driver[]>("/admin/drivers");
  return (
    <div className="space-y-8">
      <PageHeading
        title={tx("title")}
        description={tx("listHint")}
        action={can(actor, "drivers:write") ? (
          <Link href="/admin/drivers/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">{tx("new")}</Link>
        ) : null}
      />
      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="text-slate">{tx("empty")}</p>
      ) : (
        <div className="overflow-x-auto border border-ink/10 bg-paper">
          <table className="w-full min-w-[44rem] text-left text-sm">
            <caption className="sr-only">{tx("title")}</caption>
            <thead className="border-b border-ink/10 text-slate">
              <tr>
                <th scope="col" className="px-4 py-3 font-medium">{tx("driver")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("license")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("upcomingTrips")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("status")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10">
              {res.data.map((d) => (
                <tr key={d.id} className="hover:bg-pearl/50">
                  <td className="px-4 py-3">
                    <Link href={`/admin/drivers/${d.id}`} className="font-medium text-ink hover:underline">{d.name}</Link>
                    <span className="block text-slate">{d.phone}</span>
                  </td>
                  <td className={`px-4 py-3 ${d.license_expired ? "text-alert" : ""}`}>
                    {tx("cls", { cls: d.license_class })}
                    <span className="block text-slate">{d.license_expired ? tx("expiredOn", { date: dmy(d.license_expires_on) }) : tx("expiresOn", { date: dmy(d.license_expires_on) })}</span>
                  </td>
                  <td className="px-4 py-3 tabular-nums">{d.upcoming_trips}</td>
                  <td className="px-4 py-3"><span className={d.status === "ACTIVE" ? "text-ok" : "text-slate"}>{d.status === "ACTIVE" ? tx("active") : tx("inactive")}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
