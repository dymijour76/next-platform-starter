"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, optional, pick, text, type FormState } from "@/lib/form";
import type { Role, User } from "@/lib/types";
import { getTranslations } from "next-intl/server";

// La API verifica los permisos de cada operación: estas acciones sólo traducen
// el formulario y muestran el error si la API la rechaza.

export async function inviteUserAction(_: FormState, form: FormData): Promise<FormState> {
  const values = pick(form, ["email", "first_name", "last_name", "phone"]);
  const res = await api<User>("/users", {
    method: "POST",
    body: { ...values, phone: values.phone || null, roles: form.getAll("roles").map(String) },
  });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/admin/users");
  redirect(`/admin/users/${res.data.id}?invited=1`);
}

export async function updateUserAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.users");
  const id = text(form, "id");
  const values = pick(form, ["first_name", "last_name", "phone", "status"]);
  const body: Record<string, unknown> = {
    first_name: values.first_name,
    last_name: values.last_name,
    phone: optional(form, "phone"),
  };
  // Estado y roles sólo se envían si el formulario los incluía (no en la propia cuenta).
  if (form.has("status")) body.status = values.status;
  if (form.has("roles_present")) body.roles = form.getAll("roles").map(String);

  const res = await api<User>(`/users/${encodeURIComponent(id)}`, { method: "PATCH", body });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/admin/users");
  return { status: "success", message: tx("saved"), values };
}

export async function saveRoleAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.users");
  const id = text(form, "id");
  const values = pick(form, ["code", "name", "description"]);
  const permissions = form.getAll("permissions").map(String);
  const res = id
    ? await api<Role>(`/roles/${encodeURIComponent(id)}`, {
        method: "PUT",
        body: { name: values.name, description: values.description || null, permissions },
      })
    : await api<Role>("/roles", {
        method: "POST",
        body: { ...values, description: values.description || null, permissions },
      });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/admin/roles");
  if (!id) redirect(`/admin/roles/${res.data.id}?created=1`);
  return { status: "success", message: tx("roleSaved"), values };
}

export async function deleteRoleAction(_: FormState, form: FormData): Promise<FormState> {
  const res = await api<void>(`/roles/${encodeURIComponent(text(form, "id"))}`, {
    method: "DELETE",
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/admin/roles");
  redirect("/admin/roles?deleted=1");
}

export async function resetMfaAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "id");
  const res = await api<void>(`/users/${encodeURIComponent(id)}/mfa/reset`, { method: "POST" });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath(`/admin/users/${id}`);
  // Tras restablecer, el botón ya no corresponde y desaparece: el aviso va en la dirección.
  redirect(`/admin/users/${id}?mfa_reset=1`);
}
