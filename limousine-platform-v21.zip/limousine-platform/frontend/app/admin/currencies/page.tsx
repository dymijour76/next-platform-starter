import type { Metadata } from "next";
import { getTranslations } from "next-intl/server";
import { refreshRatesAction, setRateAction } from "@/app/admin/currency-actions";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import { getFormat } from "@/lib/format-server";

interface AdminRate {
  code: string; rate: string | null; source: "auto" | "manual" | "none"; updated_at: string | null;
  auto_rate: string | null; auto_updated_at: string | null; manual_rate: string | null;
}

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("adm.currency"))("title") };
}

export default async function CurrenciesPage({ searchParams }: { searchParams: Promise<{ done?: string; error?: string }> }) {
  await requirePermission("settings:write");
  const [{ done, error }, res, tx, cur, fmt] = await Promise.all([
    searchParams, api<AdminRate[]>("/admin/currencies"), getTranslations("adm.currency"), getTranslations("currency"), getFormat(),
  ]);
  if (!res.ok) throw new Error(res.error.message);
  const clp = (v: string) => fmt.number(Number(v), { maximumFractionDigits: 2 });
  return (
    <div className="space-y-8">
      <PageHeading title={tx("title")} description={tx("hint")} />
      {done === "refreshed" ? <Notice>{tx("refreshed")}</Notice> : done === "saved" ? <Notice>{tx("saved")}</Notice>
        : done === "cleared" ? <Notice>{tx("cleared")}</Notice> : null}
      {error ? <p role="alert" className="border-l-2 border-alert bg-alert/5 px-4 py-3 text-sm text-alert">{error}</p> : null}
      <form action={refreshRatesAction}>
        <button className="rounded-sm border border-ink/25 px-4 py-2 text-sm text-ink hover:border-ink/50">{tx("refresh")}</button>
      </form>
      <div className="overflow-x-auto border border-ink/10 bg-paper">
        <table className="w-full text-sm">
          <caption className="sr-only">{tx("title")}</caption>
          <thead className="text-left text-slate">
            <tr className="border-b border-ink/10">
              <th scope="col" className="px-4 py-3 font-medium">{tx("colCurrency")}</th>
              <th scope="col" className="px-4 py-3 font-medium">{tx("colAuto")}</th>
              <th scope="col" className="px-4 py-3 font-medium">{tx("colCurrent")}</th>
              <th scope="col" className="px-4 py-3 font-medium">{tx("colManual")}</th>
            </tr>
          </thead>
          <tbody>
            {res.data.map((r) => (
              <tr key={r.code} className="border-b border-ink/5 align-top last:border-0">
                <th scope="row" className="px-4 py-4 text-left font-normal">
                  <span className="font-medium text-ink">{r.code}</span>
                  <span className="block text-xs text-slate">{cur(r.code as "USD" | "EUR" | "BRL")}</span>
                </th>
                <td className="px-4 py-4 text-ink">
                  {r.auto_rate ? tx("perUnit", { amount: clp(r.auto_rate), code: r.code }) : <span className="text-slate">{tx("noRate")}</span>}
                  {r.auto_updated_at ? <span className="block text-xs text-slate">{tx("updatedAt", { date: fmt.date(r.auto_updated_at) })}</span> : null}
                </td>
                <td className="px-4 py-4">
                  {r.rate ? <span className="text-ink">{tx("perUnit", { amount: clp(r.rate), code: r.code })}</span> : <span className="text-slate">{tx("noRate")}</span>}
                  {r.source !== "none" ? (
                    <span className={`mt-1 block w-fit rounded-sm px-2 py-0.5 text-xs ${r.source === "manual" ? "bg-champagne/30 text-ink" : "bg-pearl text-slate"}`}>
                      {r.source === "manual" ? tx("manual") : tx("auto")}
                    </span>
                  ) : null}
                </td>
                <td className="px-4 py-4">
                  <form action={setRateAction} className="flex flex-wrap items-end gap-2">
                    <input type="hidden" name="code" value={r.code} />
                    <label className="text-xs text-slate">
                      {tx("manualLabel", { code: r.code })}
                      <input name="manual_rate" inputMode="decimal" defaultValue={r.manual_rate ? clp(r.manual_rate) : ""}
                        className="mt-1 block w-32 rounded-sm border border-ink/25 bg-paper px-2 py-1.5 text-sm text-ink" />
                    </label>
                    <button className="rounded-sm bg-ink px-3 py-1.5 text-sm text-pearl">{tx("save")}</button>
                    {r.manual_rate ? (
                      <button name="clear" value="1" className="rounded-sm border border-ink/25 px-3 py-1.5 text-sm text-ink">{tx("useAuto")}</button>
                    ) : null}
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs text-slate">
        <a href="https://www.exchangerate-api.com" target="_blank" rel="noopener noreferrer" className="underline underline-offset-2">
          {tx("attribution", { source: "ExchangeRate-API" })}
        </a>
      </p>
    </div>
  );
}
