import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading, Section } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { ServiceAdmin, Vehicle } from "@/lib/types";
import { deleteBlockAction } from "../../fleet-actions";
import { BlockForm } from "../BlockForm";
import { VehicleForm } from "../VehicleForm";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.vehicles");
  return { title: tx("vehicle") };
}

export default async function VehiclePage({ params, searchParams }: {
  params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }>;
}) {
  const tx = await getTranslations("adm.vehicles");
  const fmt = await getFormat();
  const [actor, { id }, { created }] = await Promise.all([requirePermission("vehicles:read"), params, searchParams]);
  const [res, services] = await Promise.all([
    api<Vehicle>(`/admin/vehicles/${encodeURIComponent(id)}`),
    api<ServiceAdmin[]>("/admin/services"),
  ]);
  if (!res.ok) notFound();
  const v = res.data;
  const canWrite = can(actor, "vehicles:write");
  return (
    <div className="space-y-10">
      <Link href="/admin/vehicles" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={`${v.brand} ${v.model}`} description={tx("plateService", { plate: v.plate, service: v.service_name })} />
      {created ? <Notice>{tx("created")}</Notice> : null}
      <VehicleForm vehicle={v} services={services.ok ? services.data : []} canWrite={canWrite} />
      <Section title={tx("blocks")} description={tx("blocksHint")}>
        <div className="space-y-6">
          {v.blocks.length ? (
            <ul className="divide-y divide-ink/10 border-y border-ink/10">
              {v.blocks.map((b) => (
                <li key={b.id} className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
                  <span>
                    <span className="text-ink">{b.reason}</span>
                    <span className="block text-slate">{tx("blockRange", { from: fmt.date(b.starts_at), to: fmt.date(b.ends_at) })}</span>
                  </span>
                  {canWrite ? (
                    <form action={deleteBlockAction}>
                      <input type="hidden" name="id" value={v.id} />
                      <input type="hidden" name="block_id" value={b.id} />
                      <button type="submit" className="text-sm text-alert hover:underline">{tx("remove")}</button>
                    </form>
                  ) : null}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-slate">{tx("noBlocks")}</p>
          )}
          {canWrite ? <BlockForm vehicleId={v.id} /> : null}
        </div>
      </Section>
    </div>
  );
}
