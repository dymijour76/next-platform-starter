"use client";

import { useActionState } from "react";
import { Field, Select, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import type { FormState } from "@/lib/form";
import type { Vehicle } from "@/lib/types";
import { saveVehicleAction } from "../fleet-actions";
import { useTranslations } from "next-intl";

export function VehicleForm({ vehicle: v, services, canWrite }: {
  vehicle?: Vehicle; services: { id: string; name: string }[]; canWrite: boolean;
}) {
  const tx = useTranslations("adm.vehicles");
  const st = useTranslations("labels.vehicle");
  const initial: FormState = {
    status: "idle",
    values: v
      ? { plate: v.plate, service_id: v.service_id, brand: v.brand, model: v.model, year: String(v.year),
          color: v.color, passenger_capacity: String(v.passenger_capacity), status: v.status, notes: v.notes ?? "" }
      : { year: String(new Date().getFullYear()), status: "ACTIVE", service_id: services[0]?.id ?? "" },
  };
  const [state, action] = useActionState(saveVehicleAction, initial);
  const val = state.values ?? {};
  const f = state.fields ?? {};
  return (
    <form action={action} className="max-w-2xl space-y-6" noValidate key={JSON.stringify(val)}>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={v?.id ?? ""} />
      <fieldset disabled={!canWrite} className="grid gap-5 sm:grid-cols-2">
        <Field label={tx("plate")} name="plate" required defaultValue={val.plate} error={f.plate} hint={tx("plateHint")} />
        <Select label={tx("service")} name="service_id" defaultValue={val.service_id} error={f.service_id}>
          {services.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </Select>
        <Field label={tx("brand")} name="brand" required defaultValue={val.brand} error={f.brand} />
        <Field label={tx("model")} name="model" required defaultValue={val.model} error={f.model} />
        <Field label={tx("year")} name="year" type="number" min={1950} max={2100} required defaultValue={val.year} error={f.year} />
        <Field label={tx("color")} name="color" required defaultValue={val.color} error={f.color} />
        <Field label={tx("passengers")} name="passenger_capacity" type="number" min={1} max={60} required
          defaultValue={val.passenger_capacity} error={f.passenger_capacity} />
        <Select label={tx("status")} name="status" defaultValue={val.status} error={f.status}>
          {(["ACTIVE", "INACTIVE", "RETIRED"] as const).map((k) => <option key={k} value={k}>{st(k)}</option>)}
        </Select>
        <Textarea label={tx("notes")} name="notes" rows={2} className="sm:col-span-2" defaultValue={val.notes} error={f.notes} />
      </fieldset>
      {canWrite ? <SubmitButton pendingLabel={tx("saving")}>{v ? tx("saveChanges") : tx("create")}</SubmitButton> : null}
    </form>
  );
}
