import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { ServiceAdmin } from "@/lib/types";
import { VehicleForm } from "../VehicleForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.vehicles");
  return { title: tx("new") };
}

export default async function NewVehiclePage() {
  const tx = await getTranslations("adm.vehicles");
  await requirePermission("vehicles:write");
  const services = await api<ServiceAdmin[]>("/admin/services");
  return (
    <div className="space-y-8">
      <Link href="/admin/vehicles" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={tx("new")} />
      <VehicleForm services={services.ok ? services.data : []} canWrite />
    </div>
  );
}
