"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { addBlockAction } from "../fleet-actions";
import { useTranslations } from "next-intl";

export function BlockForm({ vehicleId }: { vehicleId: string }) {
  const tx = useTranslations("adm.vehicles");
  const [state, action] = useActionState(addBlockAction, initialFormState);
  const v = state.values ?? {};
  return (
    <form action={action} className="space-y-4" noValidate>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={vehicleId} />
      <div className="grid gap-4 sm:grid-cols-4">
        <Field label={tx("from")} name="start_date" type="date" required defaultValue={v.start_date} />
        <Field label={tx("time")} name="start_time" type="time" defaultValue={v.start_time ?? "08:00"} />
        <Field label={tx("to")} name="end_date" type="date" required defaultValue={v.end_date} />
        <Field label={tx("time")} name="end_time" type="time" id="f-end_time" defaultValue={v.end_time ?? "18:00"} />
      </div>
      <Field label={tx("reason")} name="reason" required defaultValue={v.reason} error={state.fields?.reason}
        hint={tx("reasonHint")} />
      <SubmitButton variant="secondary" pendingLabel={tx("saving")}>{tx("addBlock")}</SubmitButton>
    </form>
  );
}
