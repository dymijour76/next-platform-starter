import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { Vehicle } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.vehicles");
  return { title: tx("title") };
}

export default async function VehiclesPage() {
  const tx = await getTranslations("adm.vehicles");
  const [st, fmt] = await Promise.all([getTranslations("labels.vehicle"), getFormat()]);
  const actor = await requirePermission("vehicles:read");
  const res = await api<Vehicle[]>("/admin/vehicles");
  return (
    <div className="space-y-8">
      <PageHeading
        title={tx("title")}
        description={tx("listHint")}
        action={can(actor, "vehicles:write") ? (
          <Link href="/admin/vehicles/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">{tx("new")}</Link>
        ) : null}
      />
      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.length === 0 ? (
        <p className="text-slate">{tx("empty")}</p>
      ) : (
        <div className="overflow-x-auto border border-ink/10 bg-paper">
          <table className="w-full min-w-[46rem] text-left text-sm">
            <caption className="sr-only">{tx("title")}</caption>
            <thead className="border-b border-ink/10 text-slate">
              <tr>
                <th scope="col" className="px-4 py-3 font-medium">{tx("vehicle")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("service")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("passengers")}</th>
                <th scope="col" className="px-4 py-3 font-medium">{tx("status")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10">
              {res.data.map((v) => (
                <tr key={v.id} className="hover:bg-pearl/50">
                  <td className="px-4 py-3">
                    <Link href={`/admin/vehicles/${v.id}`} className="font-medium text-ink hover:underline">{v.brand} {v.model}</Link>
                    <span className="block text-slate">{v.plate}, {v.color.toLowerCase()}, {v.year}</span>
                  </td>
                  <td className="px-4 py-3">{v.service_name}</td>
                  <td className="px-4 py-3 tabular-nums">{v.passenger_capacity}</td>
                  <td className="px-4 py-3">
                    <span className={v.status === "ACTIVE" ? "text-ok" : "text-slate"}>{st(v.status)}</span>
                    {v.blocks.length ? <span className="block text-slate">{tx("maintenanceFrom")} {fmt.date(v.blocks[0]!.starts_at)}</span> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
