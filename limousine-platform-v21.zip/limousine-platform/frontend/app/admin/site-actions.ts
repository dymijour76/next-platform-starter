"use server";

import { getTranslations } from "next-intl/server";
import { revalidatePath } from "next/cache";
import { api } from "@/lib/api-server";
import { fromApiError, type FormState } from "@/lib/form";
import { readTranslations, translationFormValues } from "@/lib/translations";
import { NETWORKS, SITE_TR } from "./site/fields";

const FIELDS = ["name", "legal_name", "tax_id", "about", "hours", "address", "phone", "whatsapp", "email"] as const;

/** Guarda los datos de la empresa (pie de página, redes, encabezado de los comprobantes). */
export async function saveSiteAction(_: FormState, form: FormData): Promise<FormState> {
  const v: Record<string, string> = {};
  for (const k of [...FIELDS, ...NETWORKS.map((n) => `social.${n}`)]) v[k] = String(form.get(k) ?? "").trim();
  const body = {
    ...Object.fromEntries(FIELDS.map((k) => [k, v[k] || null])),
    name: v.name,
    social: Object.fromEntries(NETWORKS.map((n) => [n, v[`social.${n}`] ?? ""])),
    translations: readTranslations(form, SITE_TR),
  };
  const values = { ...v, ...translationFormValues(form) };
  const res = await api("/admin/site", { method: "PUT", body });
  // Los errores de las redes la API los informa en el campo "social".
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/", "layout");
  return { status: "success", message: (await getTranslations("adm.site"))("saved"), values };
}
