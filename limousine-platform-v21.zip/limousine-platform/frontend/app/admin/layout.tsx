import { getTranslations } from "next-intl/server";
import { SideNav, type NavItem } from "@/components/SideNav";
import { SiteHeader } from "@/components/SiteHeader";
import { can, requireStaff } from "@/lib/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const [user, t] = await Promise.all([requireStaff(), getTranslations("admin")]);
  // Cada módulo aparece sólo para quien tiene permiso; los demás se agregan en sus fases.
  const nav: NavItem[] = [
    { href: "/admin", label: t("nav.home") },
    ...(can(user, "reservations:read") ? [{ href: "/admin/reservations", label: t("nav.reservations") }] : []),
    ...(can(user, "reports:read") || can(user, "reports:financial") ? [{ href: "/admin/reports", label: t("nav.reports") }] : []),
    ...(can(user, "payments:read") ? [{ href: "/admin/payments", label: t("nav.payments") }] : []),
    ...(can(user, "vehicles:read") ? [{ href: "/admin/vehicles", label: t("nav.vehicles") }] : []),
    ...(can(user, "drivers:read") ? [{ href: "/admin/drivers", label: t("nav.drivers") }] : []),
    ...(can(user, "services:read") ? [{ href: "/admin/services", label: t("nav.services") }] : []),
    ...(can(user, "pricing:read") ? [{ href: "/admin/pricing", label: t("nav.pricing") }] : []),
    ...(can(user, "content:write") ? [{ href: "/admin/content", label: t("nav.content") }] : []),
    ...(can(user, "users:read") ? [{ href: "/admin/users", label: t("nav.users") }] : []),
    ...(can(user, "roles:read") ? [{ href: "/admin/roles", label: t("nav.roles") }] : []),
    ...(can(user, "content:write") ? [{ href: "/admin/reviews", label: t("nav.reviews") }] : []),
    ...(can(user, "settings:write") ? [{ href: "/admin/site", label: t("nav.site") }] : []),
    ...(can(user, "settings:write") ? [{ href: "/admin/currencies", label: t("nav.currencies") }] : []),
  ];
  return (
    <div className="min-h-dvh bg-pearl">
      <SiteHeader />
      <div className="mx-auto grid max-w-6xl gap-8 px-6 py-10 sm:px-10 lg:grid-cols-[12rem_minmax(0,1fr)] lg:gap-12">
        <SideNav items={nav} label={t("title")} />
        <main className="min-w-0">{children}</main>
      </div>
    </div>
  );
}
