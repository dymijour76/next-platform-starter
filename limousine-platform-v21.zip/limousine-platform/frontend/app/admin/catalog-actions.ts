"use server";

import { readTranslations, RULE_TR, SERVICE_TR, translationFormValues } from "@/lib/translations";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import type { PricingRule, PricingSettings, ServiceAdmin } from "@/lib/types";
import { getTranslations } from "next-intl/server";

// La API valida todo y verifica permisos; aquí sólo se traduce el formulario.

const SERVICE_TEXT = ["slug", "name", "tagline", "description", "features"];
const TARIFF = ["base_fare", "hourly_rate", "min_hours", "max_hours", "minimum_fare"];

function values(form: FormData, names: string[]): Record<string, string> {
  return Object.fromEntries(names.filter((n) => form.has(n)).map((n) => [n, text(form, n)]));
}

/** "60.000" o "60000" → "60000"; "2,5" → "2.5". Vacío → null. */
function decimal(raw: string): string | null {
  const cleaned = raw.replace(/\s|\$/g, "");
  if (!cleaned) return null;
  return /,\d{1,2}$/.test(cleaned) ? cleaned.replace(/\./g, "").replace(",", ".") : cleaned.replace(/\./g, "");
}

export async function saveServiceAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.services");
  const id = text(form, "id");
  const v = values(form, [...SERVICE_TEXT, ...TARIFF, "passenger_capacity", "luggage_capacity", "sort_order"]);
  const body: Record<string, unknown> = {
    slug: v.slug,
    name: v.name,
    tagline: v.tagline || null,
    description: v.description || null,
    features: (v.features ?? "").split("\n").map((f) => f.trim()).filter(Boolean),
    translations: readTranslations(form, SERVICE_TR),
    // Sólo vacío significa "sin cambio": un 0 se envía para que la API lo rechace con su mensaje.
    passenger_capacity: v.passenger_capacity ? Number(v.passenger_capacity) : null,
    luggage_capacity: v.luggage_capacity ? Number(v.luggage_capacity) : null,
    sort_order: v.sort_order ? Number(v.sort_order) : 100,
    is_active: form.get("is_active") === "on",
  };
  // Los campos de tarifa sólo se envían si el formulario los incluía (permiso de precios).
  for (const field of TARIFF) {
    if (field in v) body[field] = decimal(v[field] ?? "") ?? (field === "max_hours" ? null : "0");
  }
  const res = id
    ? await api<ServiceAdmin>(`/admin/services/${encodeURIComponent(id)}`, { method: "PATCH", body })
    : await api<ServiceAdmin>("/admin/services", { method: "POST", body });
  if (!res.ok) return fromApiError(res.error, { ...v, ...translationFormValues(form) });
  revalidatePath("/admin/services");
  revalidatePath("/services");
  if (!id) redirect(`/admin/services/${res.data.id}?created=1`);
  return { status: "success", message: tx("serviceSaved"), values: { ...v, ...translationFormValues(form) } };
}

const RULE_FIELDS = ["name", "description", "kind", "adjustment_type", "value", "time_from",
  "time_until", "valid_from", "valid_until", "min_hours", "priority"];

export async function saveRuleAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.services");
  const id = text(form, "id");
  const v = values(form, RULE_FIELDS);
  const days = form.getAll("days_of_week").map(Number);
  const services = form.getAll("service_ids").map(String);
  const body = {
    translations: readTranslations(form, RULE_TR),
    name: v.name,
    description: v.description || null,
    kind: v.kind,
    adjustment_type: v.adjustment_type,
    value: decimal(v.value ?? ""),
    days_of_week: days.length ? days : null,
    service_ids: services.length ? services : null,
    time_from: v.time_from || null,
    time_until: v.time_until || null,
    valid_from: v.valid_from || null,
    valid_until: v.valid_until || null,
    min_hours: decimal(v.min_hours ?? ""),
    priority: v.priority ? Number(v.priority) : 100,
    is_active: form.get("is_active") === "on",
  };
  const res = id
    ? await api<PricingRule>(`/admin/pricing/rules/${encodeURIComponent(id)}`, { method: "PUT", body })
    : await api<PricingRule>("/admin/pricing/rules", { method: "POST", body });
  if (!res.ok) return fromApiError(res.error, { ...v, ...translationFormValues(form) });
  revalidatePath("/admin/pricing");
  if (!id) redirect(`/admin/pricing/rules/${res.data.id}?created=1`);
  return { status: "success", message: tx("ruleSaved"), values: { ...v, ...translationFormValues(form) } };
}

export async function deleteRuleAction(_: FormState, form: FormData): Promise<FormState> {
  const res = await api<void>(`/admin/pricing/rules/${encodeURIComponent(text(form, "id"))}`, {
    method: "DELETE",
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/admin/pricing");
  redirect("/admin/pricing?deleted=1");
}

export async function saveSettingsAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.services");
  const v = values(form, ["currency", "timezone", "tax_rate", "tax_name", "billing_increment_minutes",
    "min_notice_hours", "max_advance_days"]);
  const taxPercent = Number(decimal(v.tax_rate ?? "") ?? "NaN");
  const body = {
    currency: v.currency,
    timezone: v.timezone,
    tax_rate: Number.isFinite(taxPercent) ? String(taxPercent / 100) : v.tax_rate,
    tax_name: v.tax_name,
    prices_include_tax: form.get("prices_include_tax") === "on",
    billing_increment_minutes: Number(v.billing_increment_minutes),
    min_notice_minutes: Math.round(Number(decimal(v.min_notice_hours ?? "") ?? "0") * 60),
    max_advance_days: Number(v.max_advance_days),
  };
  const res = await api<PricingSettings>("/admin/pricing/settings", { method: "PUT", body });
  if (!res.ok) {
    const state = fromApiError(res.error, v);
    if (state.fields?.min_notice_minutes) state.fields.min_notice_hours = state.fields.min_notice_minutes;
    return state;
  }
  revalidatePath("/admin/pricing");
  revalidatePath("/services", "layout");
  return { status: "success", message: tx("settingsSaved"), values: v };
}
