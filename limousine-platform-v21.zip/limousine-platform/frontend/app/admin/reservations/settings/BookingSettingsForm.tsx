"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import type { FormState } from "@/lib/form";
import type { BookingSettings } from "@/lib/types";
import { saveBookingSettingsAction } from "../../reservation-actions";
import { useTranslations } from "next-intl";

export function BookingSettingsForm({ settings: s, canWrite }: { settings: BookingSettings; canWrite: boolean }) {
  const t = useTranslations("ar");
  const initial: FormState = {
    status: "idle",
    values: Object.fromEntries(Object.entries(s).map(([k, v]) => [k, String(v)])),
  };
  const [state, action] = useActionState(saveBookingSettingsAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};
  return (
    <form action={action} className="max-w-2xl space-y-6" noValidate key={JSON.stringify(v)}>
      <FormAlert state={state} />
      {!canWrite ? <p className="text-sm text-slate">{t("readOnly")}</p> : null}
      <fieldset disabled={!canWrite} className="grid gap-5 sm:grid-cols-2">
        <Field label={t("holdMinutes")} name="hold_minutes" type="number" min={5} required
          defaultValue={v.hold_minutes} error={f.hold_minutes} hint={t("holdMinutesHint")} />
        <Field label={t("buffer")} name="turnaround_minutes" type="number" min={0} required
          defaultValue={v.turnaround_minutes} error={f.turnaround_minutes} hint={t("bufferHint")} />
        <Field label={t("freeCancelHours")} name="free_cancellation_hours" type="number" min={0} required
          defaultValue={v.free_cancellation_hours} error={f.free_cancellation_hours} />
        <Field label={t("lateRefund")} name="late_cancellation_refund_percent" type="number" min={0} max={100} required
          defaultValue={v.late_cancellation_refund_percent} error={f.late_cancellation_refund_percent} hint={t("lateRefundHint")} />
      </fieldset>
      {canWrite ? <SubmitButton pendingLabel={t("saving")}>{t("save")}</SubmitButton> : null}
    </form>
  );
}
