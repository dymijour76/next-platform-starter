import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { BookingSettings } from "@/lib/types";
import { BookingSettingsForm } from "./BookingSettingsForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("ar"))("settingsTitle") };
}

export default async function BookingSettingsPage() {
  const t = await getTranslations("ar");
  const actor = await requirePermission("reservations:read");
  const res = await api<BookingSettings>("/admin/booking/settings");
  return (
    <div className="space-y-8">
      <Link href="/admin/reservations" className="text-sm text-slate hover:underline">{t("back")}</Link>
      <PageHeading
        title={t("policyLink")}
        description={t("settingsHint")}
      />
      {res.ok ? (
        <BookingSettingsForm settings={res.data} canWrite={can(actor, "settings:write")} />
      ) : (
        <p role="alert" className="text-alert">{res.error.message}</p>
      )}
    </div>
  );
}
