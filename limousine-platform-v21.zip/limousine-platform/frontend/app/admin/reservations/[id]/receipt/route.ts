import type { NextRequest } from "next/server";
import { proxyReceipt } from "@/lib/receipt";

/** Comprobante desde el panel (la API exige el permiso de ver reservas). */
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return proxyReceipt(request, `/admin/reservations/${encodeURIComponent(id)}/receipt`);
}
