import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading, Section } from "@/components/PageHeading";
import { StaffChat } from "@/components/chat/ChatSection";
import { ReceiptLinks } from "@/components/reservations/ReceiptLinks";
import { ReservationDetails } from "@/components/reservations/ReservationDetails";
import { PaymentList } from "@/components/payments/PaymentList";
import { RefundControls } from "@/components/payments/RefundControls";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { AssignmentOptions, ReservationAdmin } from "@/lib/types";
import { CancelReservation, StepForm } from "./Actions";
import { AssignForm } from "./AssignForm";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("reservations"))("metaTitle") };
}

const DONE = new Set(["confirm", "complete", "no-show", "cancel", "assign"]);

export default async function AdminReservationPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ done?: string }>;
}) {
  const [t, rsv, status, fmt] = await Promise.all([
    getTranslations("ar"), getTranslations("reservations"), getTranslations("labels.reservation"), getFormat(),
  ]);
  const [actor, { id }, { done }] = await Promise.all([requirePermission("reservations:read"), params, searchParams]);
  const res = await api<ReservationAdmin>(`/admin/reservations/${encodeURIComponent(id)}`);
  if (!res.ok) notFound();
  const r = res.data;
  const started = new Date(r.pickup_at) <= new Date();
  const write = can(actor, "reservations:write");
  const open = ["PENDING_PAYMENT", "CONFIRMED", "EN_ROUTE", "ARRIVED", "IN_PROGRESS"].includes(r.status);
  const assignable = r.status === "CONFIRMED" && can(actor, "reservations:assign");
  const options = assignable
    ? await api<AssignmentOptions>(`/admin/reservations/${encodeURIComponent(r.id)}/assignment`)
    : null;

  return (
    <div className="space-y-10">
      <Link href="/admin/reservations" className="text-sm text-slate hover:underline">{t("back")}</Link>
      <PageHeading title={r.code} description={r.service.name} action={<StatusBadge status={r.status} />} />
      {done && DONE.has(done) ? <Notice>{t(`done.${done}`)}</Notice> : null}

      {r.status === "PENDING_PAYMENT" && r.hold_expires_at ? (
        <Notice tone="info">{t("holdUntil", { date: fmt.date(r.hold_expires_at) })}</Notice>
      ) : null}
      {r.status === "CANCELLED" ? (
        <Notice tone="info">
          {r.cancellation_reason
            ? t("cancelledOnReason", { date: fmt.date(r.cancelled_at), reason: r.cancellation_reason })
            : t("cancelledOn", { date: fmt.date(r.cancelled_at) })}{" "}
          {r.refund_amount !== null ? rsv("refundAmount", { amount: fmt.money(r.refund_amount, r.currency) }) : t("noCharges")}
        </Notice>
      ) : null}

      <ReservationDetails r={r} />
      <ReceiptLinks href={`/admin/reservations/${r.id}/receipt`} />

      <Section title={t("assignTitle")} description={assignable
        ? t("assignOnlyService")
        : r.status === "PENDING_PAYMENT" ? t("assignAfterConfirm") : undefined}>
        {options?.ok ? (
          <AssignForm id={r.id} options={options.data} vehicleId={r.vehicle?.id ?? null} driverId={r.driver?.id ?? null} />
        ) : (
          <dl className="grid gap-4 text-sm sm:grid-cols-2">
            <div><dt className="text-slate">{t("vehicle")}</dt><dd className="text-ink">{r.vehicle?.label ?? t("unassigned")}</dd></div>
            <div><dt className="text-slate">{t("driver")}</dt><dd className="text-ink">{r.driver ? `${r.driver.label}${r.driver.phone ? `, ${r.driver.phone}` : ""}` : t("unassigned")}</dd></div>
          </dl>
        )}
      </Section>

      <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-3">
        <div><dt className="text-slate">{t("account")}</dt><dd className="text-ink">{r.customer ? <Link href={`/admin/users/${r.customer.id}`} className="hover:underline">{r.customer.name}</Link> : t("noAccount")}</dd></div>
        <div><dt className="text-slate">{t("bookedAt")}</dt><dd className="text-ink">{fmt.date(r.created_at)}</dd></div>
        <div><dt className="text-slate">{t("policyAccepted")}</dt><dd className="text-ink">{r.cancellation_policy}</dd></div>
      </dl>

      {open ? (
        <Section title={t("actions")} description={t("actionsHint")}>
          <div className="space-y-8">
            {write && r.status === "PENDING_PAYMENT" ? (
              <StepForm id={r.id} step="confirm" label={t("confirmOffline")} pending={t("confirming")}
                help={t("confirmOfflineHelp")} />
            ) : null}
            {write && ["CONFIRMED", "EN_ROUTE", "ARRIVED", "IN_PROGRESS"].includes(r.status) && started ? (
              <div className="flex flex-wrap gap-8">
                <StepForm id={r.id} step="complete" label={t("markCompleted")} pending={t("saving")} help={t("optional")} />
                <StepForm id={r.id} step="no-show" label={t("noShow")} pending={t("saving")} help={t("optional")} variant="secondary" />
              </div>
            ) : null}
            {write && r.status === "CONFIRMED" && !started ? (
              <p className="text-sm text-slate">{t("completeAfterPickup")}</p>
            ) : null}
            {can(actor, "reservations:cancel") ? (
              <CancelReservation id={r.id} confirmed={r.status !== "PENDING_PAYMENT"} />
            ) : null}
          </div>
        </Section>
      ) : null}

      <Section title={t("payments")} description={t("paymentsHint")}>
        <PaymentList
          payments={r.payments}
          currency={r.currency}
          actions={can(actor, "payments:refund") ? (p) => <RefundControls payment={p} currency={r.currency} /> : undefined}
        />
        {r.status === "CANCELLED" && r.refund_amount && !r.payments.some((p) => p.refunds.length) ? (
          <p className="mt-4 text-sm text-alert">
            {t("offlineRefund", { amount: fmt.money(r.refund_amount, r.currency) })}
          </p>
        ) : null}
      </Section>

      <StaffChat reservationId={r.id} />
      <Section title={t("history")}>
        <ol className="space-y-4 border-l border-ink/15 pl-5">
          {r.events.map((e, i) => (
            <li key={i} className="relative">
              <span className="absolute -left-[1.4rem] top-1.5 size-2 rounded-full bg-champagne" aria-hidden="true" />
              <p className="text-ink">{status(e.to_status)}</p>
              <p className="text-sm text-slate">{e.note
                ? t("eventByNote", { date: fmt.date(e.created_at), actor: e.actor_label, note: e.note })
                : t("eventBy", { date: fmt.date(e.created_at), actor: e.actor_label })}</p>
            </li>
          ))}
        </ol>
      </Section>
    </div>
  );
}
