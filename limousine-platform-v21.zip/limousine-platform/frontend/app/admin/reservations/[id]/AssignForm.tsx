"use client";

import { useActionState } from "react";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import type { AssignmentOption, AssignmentOptions } from "@/lib/types";
import { assignAction } from "../../fleet-actions";
import { useTranslations } from "next-intl";

function OptionSelect({ name, label, options, current, empty }: {
  name: string; label: string; options: AssignmentOption[]; current: string | null; empty: string;
}) {
  const t = useTranslations("ar");
  const id = `f-${name}`;
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-ink">{label}</label>
      <select id={id} name={name} defaultValue={current ?? ""}
        className="mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5 text-base text-ink">
        <option value="">{empty}</option>
        {options.map((o) => (
          <option key={o.id} value={o.id} disabled={!o.available && o.id !== current}>
            {o.label}{o.reason ? ` (${o.reason})` : ""}
          </option>
        ))}
      </select>
      {options.length === 0 ? <p className="mt-1.5 text-sm text-alert">{t("noOptions")}</p> : null}
    </div>
  );
}

export function AssignForm({ id, options, vehicleId, driverId }: {
  id: string; options: AssignmentOptions; vehicleId: string | null; driverId: string | null;
}) {
  const t = useTranslations("ar");
  const [state, action] = useActionState(assignAction, initialFormState);
  return (
    <form action={action} className="space-y-5">
      <FormAlert state={state} />
      <input type="hidden" name="id" value={id} />
      <div className="grid gap-5 sm:grid-cols-2">
        <OptionSelect name="vehicle_id" label={t("vehicle")} options={options.vehicles} current={vehicleId} empty={t("noVehicle")} />
        <OptionSelect name="driver_id" label={t("driver")} options={options.drivers} current={driverId} empty={t("noDriver")} />
      </div>
      <p className="text-sm text-slate">
        {t("optionsHelp")}
      </p>
      <SubmitButton pendingLabel={t("assigning")}>{t("saveAssignment")}</SubmitButton>
    </form>
  );
}
