"use client";

import { useActionState } from "react";
import { Checkbox, Field, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import { adminCancelAction, reservationStepAction } from "../../reservation-actions";
import { useTranslations } from "next-intl";

export function StepForm({ id, step, label, pending, help, variant = "primary" }: {
  id: string; step: "confirm" | "complete" | "no-show"; label: string; pending: string; help: string;
  variant?: "primary" | "secondary";
}) {
  const t = useTranslations("ar");
  const [state, action] = useActionState(reservationStepAction, initialFormState);
  return (
    <form action={action} className="space-y-3">
      <FormAlert state={state} />
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="step" value={step} />
      <Field label={t("note")} name="note" hint={help} />
      <SubmitButton pendingLabel={pending} variant={variant}>{label}</SubmitButton>
    </form>
  );
}

export function CancelReservation({ id, confirmed }: { id: string; confirmed: boolean }) {
  const t = useTranslations("ar");
  const cancel = useTranslations("cancel");
  // `confirmed`: la reserva está pagada o en curso, así que puede haber reembolso.
  const [state, action] = useActionState(adminCancelAction, initialFormState);
  return (
    <form action={action} className="space-y-3" noValidate>
      <FormAlert state={state} />
      <input type="hidden" name="id" value={id} />
      <Textarea label={t("cancelReason")} name="reason" rows={2} required defaultValue={state.values?.reason}
        error={state.fields?.reason} hint={t("cancelReasonHint")} />
      {confirmed ? (
        <Checkbox name="apply_policy">
          {t("applyPolicy")}
        </Checkbox>
      ) : null}
      <SubmitButton variant="secondary" pendingLabel={cancel("cancelling")}>{cancel("open")}</SubmitButton>
    </form>
  );
}
