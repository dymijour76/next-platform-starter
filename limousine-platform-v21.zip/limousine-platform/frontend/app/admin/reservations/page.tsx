import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { PICKUP_FORMAT } from "@/components/reservations/ReservationDetails";
import { StatusBadge } from "@/components/StatusBadge";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import { RESERVATION_TONE } from "@/lib/labels";
import type { Page, ReservationStatus, ReservationSummary, ServiceAdmin } from "@/lib/types";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("admin"))("nav.reservations") };
}

const PAGE_SIZE = 25;
type Params = { q?: string; status?: string; service_id?: string; date_from?: string; date_to?: string; unassigned?: string; page?: string };

export default async function AdminReservationsPage({ searchParams }: { searchParams: Promise<Params> }) {
  const [t, adm, status, fmt] = await Promise.all([
    getTranslations("ar"), getTranslations("admin"), getTranslations("labels.reservation"), getFormat(),
  ]);
  const [actor, params] = await Promise.all([requirePermission("reservations:read"), searchParams]);
  const page = Math.max(1, Number(params.page) || 1);
  const [res, services] = await Promise.all([
    api<Page<ReservationSummary>>("/admin/reservations", {
      query: { ...params, page, page_size: PAGE_SIZE },
    }),
    can(actor, "services:read") ? api<ServiceAdmin[]>("/admin/services") : Promise.resolve(null),
  ]);
  const pages = res.ok ? Math.max(1, Math.ceil(res.data.total / PAGE_SIZE)) : 1;
  const pageLink = (p: number) =>
    `/admin/reservations?${new URLSearchParams(Object.entries({ ...params, page: String(p) }).filter(([, v]) => v) as [string, string][])}`;
  const input = "mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5";

  return (
    <div className="space-y-8">
      <PageHeading
        title={adm("nav.reservations")}
        description={t("listHint")}
        action={
          <Link href="/admin/reservations/settings" className="text-sm text-ink underline decoration-champagne underline-offset-4">
            {t("policyLink")}
          </Link>
        }
      />

      <form className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6 lg:items-end" role="search">
        <label className="lg:col-span-2">
          <span className="block text-sm font-medium text-ink">{t("search")}</span>
          <input name="q" defaultValue={params.q} placeholder={t("searchPlaceholder")} className={input} />
        </label>
        <label>
          <span className="block text-sm font-medium text-ink">{t("status")}</span>
          <select name="status" defaultValue={params.status ?? ""} className={input}>
            <option value="">{t("all")}</option>
            {(Object.keys(RESERVATION_TONE) as ReservationStatus[]).map((s) => (
              <option key={s} value={s}>{status(s)}</option>
            ))}
          </select>
        </label>
        {services?.ok ? (
          <label>
            <span className="block text-sm font-medium text-ink">{t("service")}</span>
            <select name="service_id" defaultValue={params.service_id ?? ""} className={input}>
              <option value="">{t("all")}</option>
              {services.data.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </label>
        ) : null}
        <label>
          <span className="block text-sm font-medium text-ink">{t("from")}</span>
          <input type="date" name="date_from" defaultValue={params.date_from} className={input} />
        </label>
        <label>
          <span className="block text-sm font-medium text-ink">{t("to")}</span>
          <input type="date" name="date_to" defaultValue={params.date_to} className={input} />
        </label>
        <div className="flex flex-wrap items-center gap-3 lg:col-span-6">
          <label className="mr-3 flex items-center gap-2 text-sm text-ink">
            <input type="checkbox" name="unassigned" value="true" defaultChecked={params.unassigned === "true"} className="size-4 accent-ink" />
            {t("onlyUnassigned")}
          </label>
          <button type="submit" className="rounded-sm border border-ink/25 bg-paper px-5 py-2.5 text-sm hover:border-ink/50">{t("filter")}</button>
          <Link href="/admin/reservations" className="px-2 py-2.5 text-sm text-slate hover:text-ink">{t("clear")}</Link>
        </div>
      </form>

      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : res.data.items.length === 0 ? (
        <p className="text-slate">{t("noResults")}</p>
      ) : (
        <>
          <div className="overflow-x-auto border border-ink/10 bg-paper">
            <table className="w-full min-w-[48rem] text-left text-sm">
              <caption className="sr-only">{adm("nav.reservations")}</caption>
              <thead className="border-b border-ink/10 text-slate">
                <tr>
                  <th scope="col" className="px-4 py-3 font-medium">{t("colBooking")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{t("colPickup")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{t("colCustomer")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{t("status")}</th>
                  <th scope="col" className="px-4 py-3 font-medium">{t("colAssignment")}</th>
                  <th scope="col" className="px-4 py-3 text-right font-medium">{t("colTotal")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink/10">
                {res.data.items.map((r) => (
                  <tr key={r.id} className="hover:bg-pearl/50">
                    <td className="px-4 py-3">
                      <Link href={`/admin/reservations/${r.id}`} className="font-medium text-ink hover:underline">{r.code}</Link>
                      <span className="block text-slate">{r.service.name}</span>
                    </td>
                    <td className="px-4 py-3 first-letter:uppercase">{fmt.wall(r.pickup_local, PICKUP_FORMAT)}</td>
                    <td className="px-4 py-3">{r.contact_name}<span className="block text-slate">{fmt.passengers(r.passenger_count)}</span></td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3">
                      {r.vehicle_label || r.driver_name ? (
                        <>
                          <span className="block">{r.driver_name ?? <span className="text-alert">{t("noDriver")}</span>}</span>
                          <span className="block text-slate">{/* La patente es la última palabra de la etiqueta en todos los idiomas ("…, plate TBWX48"). */}
                          {r.vehicle_label?.trim().split(/\s+/).at(-1) ?? <span className="text-alert">{t("noVehicle")}</span>}</span>
                        </>
                      ) : ["CONFIRMED"].includes(r.status) ? <span className="text-alert">{t("unassigned")}</span> : <span className="text-slate">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{fmt.money(r.total_amount, r.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <nav aria-label={t("pagination")} className="flex items-center justify-between text-sm text-slate">
            <span>{t("pageInfo", { total: res.data.total, page, pages })}</span>
            <span className="flex gap-4">
              {page > 1 ? <Link href={pageLink(page - 1)} className="text-ink hover:underline">{t("previous")}</Link> : null}
              {page < pages ? <Link href={pageLink(page + 1)} className="text-ink hover:underline">{t("next")}</Link> : null}
            </span>
          </nav>
        </>
      )}
    </div>
  );
}
