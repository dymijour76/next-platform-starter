"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { api } from "@/lib/api-server";
import { fromApiError, text, type FormState } from "@/lib/form";
import { zonedToIso } from "@/lib/timezone";
import type { Driver, PublicPricingConfig, ReservationAdmin, Vehicle } from "@/lib/types";
import { getTranslations } from "next-intl/server";

const VEHICLE_FIELDS = ["plate", "service_id", "brand", "model", "year", "color", "passenger_capacity", "status", "notes"];

export async function saveVehicleAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.vehicles");
  const id = text(form, "id");
  const v = Object.fromEntries(VEHICLE_FIELDS.map((n) => [n, text(form, n)]));
  const body = { ...v, year: Number(v.year), passenger_capacity: Number(v.passenger_capacity), notes: v.notes || null };
  const res = id
    ? await api<Vehicle>(`/admin/vehicles/${encodeURIComponent(id)}`, { method: "PUT", body })
    : await api<Vehicle>("/admin/vehicles", { method: "POST", body });
  if (!res.ok) return fromApiError(res.error, v);
  revalidatePath("/admin", "layout");
  if (!id) redirect(`/admin/vehicles/${res.data.id}?created=1`);
  return { status: "success", message: tx("saved"), values: { ...v, plate: res.data.plate } };
}

export async function addBlockAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.vehicles");
  const id = text(form, "id");
  const values = Object.fromEntries(["start_date", "start_time", "end_date", "end_time", "reason"].map((n) => [n, text(form, n)]));
  const config = await api<PublicPricingConfig>("/pricing/config", { auth: false });
  const tz = config.ok ? config.data.timezone : "America/Santiago";
  const starts = zonedToIso(values.start_date!, values.start_time || "00:00", tz);
  const ends = zonedToIso(values.end_date!, values.end_time || "23:59", tz);
  if (!starts || !ends) return { status: "error", message: tx("datesRequired"), values };
  const res = await api<Vehicle>(`/admin/vehicles/${encodeURIComponent(id)}/blocks`, {
    method: "POST",
    body: { starts_at: starts, ends_at: ends, reason: values.reason },
  });
  if (!res.ok) return fromApiError(res.error, values);
  revalidatePath("/admin", "layout");
  return { status: "success", message: tx("blockSaved") };
}

export async function deleteBlockAction(form: FormData): Promise<void> {
  await api<Vehicle>(`/admin/vehicles/${encodeURIComponent(text(form, "id"))}/blocks/${encodeURIComponent(text(form, "block_id"))}`, {
    method: "DELETE",
  });
  revalidatePath("/admin", "layout");
}

const DRIVER_FIELDS = ["email", "first_name", "last_name", "phone", "license_number", "license_class", "license_expires_on", "status", "notes"];

export async function saveDriverAction(_: FormState, form: FormData): Promise<FormState> {
  const tx = await getTranslations("adm.vehicles");
  const id = text(form, "id");
  const v = Object.fromEntries(DRIVER_FIELDS.map((n) => [n, text(form, n)]));
  const body = { ...v, notes: v.notes || null };
  const res = id
    ? await api<Driver>(`/admin/drivers/${encodeURIComponent(id)}`, { method: "PUT", body })
    : await api<Driver>("/admin/drivers", { method: "POST", body });
  if (!res.ok) return fromApiError(res.error, v);
  revalidatePath("/admin", "layout");
  if (!id) redirect(`/admin/drivers/${res.data.id}?created=1`);
  return { status: "success", message: tx("driverSaved"), values: v };
}

export async function assignAction(_: FormState, form: FormData): Promise<FormState> {
  const id = text(form, "id");
  const res = await api<ReservationAdmin>(`/admin/reservations/${encodeURIComponent(id)}/assignment`, {
    method: "PUT",
    body: { vehicle_id: text(form, "vehicle_id") || null, driver_id: text(form, "driver_id") || null },
  });
  if (!res.ok) return fromApiError(res.error);
  revalidatePath("/admin/reservations", "layout");
  redirect(`/admin/reservations/${id}?done=assign`);
}
