import type { Metadata } from "next";
import Link from "next/link";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading, Section } from "@/components/PageHeading";
import { QuoteForm } from "@/components/pricing/QuoteForm";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import { durationOptions } from "@/lib/money";
import { ruleConditions, ruleEffect } from "@/lib/rules";
import { todayIn } from "@/lib/timezone";
import type { PricingRule, PricingSettings, ServiceAdmin } from "@/lib/types";
import { SettingsForm } from "./SettingsForm";
import { getLocale, getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.pricing");
  return { title: tx("title") };
}

export default async function PricingPage({ searchParams }: { searchParams: Promise<{ deleted?: string }> }) {
  const tx = await getTranslations("adm.pricing");
  const locale = await getLocale();
  const [rt, fmt] = await Promise.all([getTranslations("adm.rules"), getFormat()]);
  const [actor, { deleted }] = await Promise.all([requirePermission("pricing:read"), searchParams]);
  const [rulesRes, settingsRes, servicesRes] = await Promise.all([
    api<PricingRule[]>("/admin/pricing/rules"),
    api<PricingSettings>("/admin/pricing/settings"),
    can(actor, "services:read") ? api<ServiceAdmin[]>("/admin/services") : Promise.resolve(null),
  ]);
  const services = servicesRes?.ok ? servicesRes.data : [];
  const names = Object.fromEntries(services.map((s) => [s.id, s.name]));
  const canWrite = can(actor, "pricing:write");
  const settings = settingsRes.ok ? settingsRes.data : null;

  return (
    <div className="space-y-10">
      <PageHeading
        title={tx("title")}
        description={tx("listHint")}
        action={canWrite ? (
          <Link href="/admin/pricing/rules/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
            {tx("newRule")}
          </Link>
        ) : null}
      />
      {deleted ? <Notice>{tx("deleted")}</Notice> : null}

      <section aria-labelledby="rules-title">
        <h2 id="rules-title" className="sr-only">{tx("rules")}</h2>
        {!rulesRes.ok ? (
          <p role="alert" className="text-alert">{rulesRes.error.message}</p>
        ) : rulesRes.data.length === 0 ? (
          <p className="text-slate">{tx("noRules")}</p>
        ) : (
          <ul className="divide-y divide-ink/10 border-y border-ink/10">
            {rulesRes.data.map((r) => (
              <li key={r.id}>
                <Link href={`/admin/pricing/rules/${r.id}`}
                  className={`grid gap-1 py-4 hover:bg-paper/60 sm:grid-cols-[6rem_minmax(0,1fr)_auto] sm:items-baseline sm:gap-6 ${r.is_active ? "" : "opacity-60"}`}>
                  <span className={`font-display text-xl tabular-nums ${r.kind === "DISCOUNT" ? "text-ok" : "text-ink"}`}>
                    {ruleEffect(r, fmt, settings?.currency)}
                  </span>
                  <span>
                    {/* En el idioma de quien mira, si la regla tiene esa traducción. */}
                    <span className="text-ink">{(r.translations as Record<string, { name?: string }> | undefined)?.[locale]?.name ?? r.name}</span>
                    <span className="block text-sm text-slate first-letter:uppercase">{ruleConditions(r, names, fmt, (key, values) => rt(key, values))}</span>
                  </span>
                  <span className="text-sm text-slate">{r.is_active ? "Activa" : "Inactiva"}</span>
                </Link>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-4 text-sm leading-relaxed text-slate">
          {tx("howItWorks")}
        </p>
      </section>

      {services.length && settings ? (
        <Section title={tx("simulator")} description={tx("simulatorHint")}>
          <QuoteForm
            mode="simulate"
            services={services.map((s) => ({ id: s.id, name: s.is_active ? s.name : `${s.name} (inactivo)` }))}
            durations={durationOptions("0.5", "12", settings.billing_increment_minutes)}
            minDate={todayIn(settings.timezone)}
          />
        </Section>
      ) : null}

      {settings ? (
        <Section title={tx("settings")} description={tx("settingsHint")}>
          <SettingsForm settings={settings} canWrite={canWrite} />
        </Section>
      ) : null}
    </div>
  );
}
