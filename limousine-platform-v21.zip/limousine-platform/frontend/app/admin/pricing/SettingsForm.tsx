"use client";

import { useActionState } from "react";
import { Checkbox, Field, Select } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import type { FormState } from "@/lib/form";
import type { PricingSettings } from "@/lib/types";
import { saveSettingsAction } from "../catalog-actions";
import { useTranslations } from "next-intl";

export function SettingsForm({ settings: s, canWrite }: { settings: PricingSettings; canWrite: boolean }) {
  const tx = useTranslations("adm.pricing");
  const initial: FormState = {
    status: "idle",
    values: {
      currency: s.currency,
      timezone: s.timezone,
      tax_rate: String(Number(s.tax_rate) * 100),
      tax_name: s.tax_name,
      billing_increment_minutes: String(s.billing_increment_minutes),
      min_notice_hours: String(s.min_notice_minutes / 60),
      max_advance_days: String(s.max_advance_days),
    },
  };
  const [state, action] = useActionState(saveSettingsAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};
  return (
    <form action={action} className="space-y-5" noValidate key={JSON.stringify(v)}>
      <FormAlert state={state} />
      <fieldset disabled={!canWrite} className="grid gap-5 sm:grid-cols-2">
        <Select label={tx("currency")} name="currency" defaultValue={v.currency} error={f.currency}>
          <option value="CLP">{tx("clp")}</option>
          <option value="USD">{tx("usd")}</option>
          <option value="EUR">{tx("eur")}</option>
        </Select>
        <Field label={tx("timezone")} name="timezone" required defaultValue={v.timezone} error={f.timezone}
          hint={tx("timezoneHint")} />
        <Field label={tx("tax")} name="tax_rate" inputMode="decimal" required defaultValue={v.tax_rate} error={f.tax_rate} />
        <Field label={tx("taxName")} name="tax_name" required defaultValue={v.tax_name} error={f.tax_name} />
        <Select label={tx("increment")} name="billing_increment_minutes" defaultValue={v.billing_increment_minutes}
          error={f.billing_increment_minutes}>
          <option value="15">{tx("min15")}</option>
          <option value="30">{tx("min30")}</option>
          <option value="60">{tx("hour1")}</option>
        </Select>
        <Field label={tx("minNotice")} name="min_notice_hours" inputMode="decimal" required
          defaultValue={v.min_notice_hours} error={f.min_notice_hours} />
        <Field label={tx("maxAdvance")} name="max_advance_days" type="number" min={1} max={730} required
          defaultValue={v.max_advance_days} error={f.max_advance_days} />
        <div className="self-end pb-2">
          <Checkbox name="prices_include_tax" defaultChecked={s.prices_include_tax}>
            {tx("taxIncluded")}
          </Checkbox>
        </div>
      </fieldset>
      {canWrite ? <SubmitButton pendingLabel={tx("saving")} variant="secondary">{tx("saveSettings")}</SubmitButton> : null}
    </form>
  );
}
