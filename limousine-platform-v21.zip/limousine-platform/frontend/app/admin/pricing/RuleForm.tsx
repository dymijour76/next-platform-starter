"use client";

import { TranslationFields } from "@/components/forms/TranslationFields";
import { RULE_TR, translationValues, withLabels } from "@/lib/translations";
import { useActionState } from "react";
import { Checkbox, Field, Select, Textarea } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { Section } from "@/components/PageHeading";
import { initialFormState, type FormState } from "@/lib/form";
import { useFormat } from "@/lib/format-client";
import { weekdayNames } from "@/lib/rules";
import type { PricingRule } from "@/lib/types";
import { deleteRuleAction, saveRuleAction } from "../catalog-actions";
import { useTranslations } from "next-intl";

interface Props {
  rule?: PricingRule;
  services: { id: string; name: string }[];
  canWrite: boolean;
}

export function RuleForm({ rule: r, services, canWrite }: Props) {
  const tx = useTranslations("adm.pricing");
  const fmt = useFormat();
  const initial: FormState = {
    status: "idle",
    values: r
      ? {
          name: r.name, description: r.description ?? "", kind: r.kind, adjustment_type: r.adjustment_type,
          value: r.value, time_from: r.time_from?.slice(0, 5) ?? "", time_until: r.time_until?.slice(0, 5) ?? "",
          valid_from: r.valid_from ?? "", valid_until: r.valid_until ?? "", min_hours: r.min_hours ?? "",
          priority: String(r.priority),
          ...translationValues(r.translations),
        }
      : { kind: "SURCHARGE", adjustment_type: "PERCENT", priority: "100" },
  };
  const [state, action] = useActionState(saveRuleAction, initial);
  const v = state.values ?? {};
  const f = state.fields ?? {};
  const days = new Set(r?.days_of_week ?? []);
  const selected = new Set(r?.service_ids ?? []);

  return (
    <div className="space-y-10">
      <form action={action} className="space-y-10" noValidate key={JSON.stringify(v)}>
        <FormAlert state={state} />
        <input type="hidden" name="id" value={r?.id ?? ""} />
        <fieldset disabled={!canWrite} className="space-y-10">
          <Section title={tx("effect")}>
            <div className="grid gap-5 sm:grid-cols-2">
              <Field label={tx("name")} name="name" required className="sm:col-span-2" defaultValue={v.name} error={f.name}
                hint={tx("nameHint")} />
              <Select label={tx("kind")} name="kind" defaultValue={v.kind} error={f.kind}>
                <option value="SURCHARGE">{tx("surcharge")}</option>
                <option value="DISCOUNT">{tx("discount")}</option>
              </Select>
              <Select label={tx("calcAs")} name="adjustment_type" defaultValue={v.adjustment_type} error={f.adjustment_type}>
                <option value="PERCENT">{tx("percent")}</option>
                <option value="FIXED">{tx("fixed")}</option>
              </Select>
              <Field label={tx("value")} name="value" inputMode="decimal" required defaultValue={v.value} error={f.value}
                hint={tx("valueHint")} />
              <Field label={tx("priority")} name="priority" type="number" min={0} required defaultValue={v.priority}
                error={f.priority} hint={tx("priorityHint")} />
              <Textarea label={tx("internalNote")} name="description" rows={2} className="sm:col-span-2"
                defaultValue={v.description} error={f.description} />
            </div>
          </Section>

          <Section title={tx("when")} description={tx("whenHint")}>
            <div className="space-y-6">
              <fieldset>
                <legend className="text-sm font-medium text-ink">{tx("weekdays")}</legend>
                <div className="mt-2 flex flex-wrap gap-x-5 gap-y-2">
                  {weekdayNames(fmt, "long").map((day, i) => (
                    <label key={day} className="flex items-center gap-2 text-sm">
                      <input type="checkbox" name="days_of_week" value={i} defaultChecked={days.has(i)} className="size-4 accent-ink" />
                      {day}
                    </label>
                  ))}
                </div>
                {f.days_of_week ? <p className="mt-1.5 text-sm text-alert">{f.days_of_week}</p> : null}
              </fieldset>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label={tx("timeFrom")} name="time_from" type="time" defaultValue={v.time_from} error={f.time_from} />
                <Field label={tx("timeUntil")} name="time_until" type="time" defaultValue={v.time_until} error={f.time_until}
                  hint={tx("timeHint")} />
                <Field label={tx("dateFrom")} name="valid_from" type="date" defaultValue={v.valid_from} error={f.valid_from} />
                <Field label={tx("dateUntil")} name="valid_until" type="date" defaultValue={v.valid_until} error={f.valid_until}
                  hint={tx("inclusive")} />
                <Field label={tx("minHours")} name="min_hours" inputMode="decimal" defaultValue={v.min_hours}
                  error={f.min_hours} hint={tx("minHoursHint")} />
              </div>
              {services.length ? (
                <fieldset>
                  <legend className="text-sm font-medium text-ink">{tx("services")}</legend>
                  <p className="text-sm text-slate">{tx("servicesHint")}</p>
                  <div className="mt-2 flex flex-wrap gap-x-5 gap-y-2">
                    {services.map((s) => (
                      <label key={s.id} className="flex items-center gap-2 text-sm">
                        <input type="checkbox" name="service_ids" value={s.id} defaultChecked={selected.has(s.id)} className="size-4 accent-ink" />
                        {s.name}
                      </label>
                    ))}
                  </div>
                  {f.service_ids ? <p className="mt-1.5 text-sm text-alert">{f.service_ids}</p> : null}
                </fieldset>
              ) : null}
            </div>
          </Section>

          <Section title={tx("translations")} description={tx("translationsHint")}>
            <TranslationFields values={v} fields={withLabels(RULE_TR, { name: tx("name") })}
              labels={{ complete: tx("trComplete"), partial: tx("trPartial"), missing: tx("trMissing"), hint: tx("trHint") }} />
          </Section>

          <Section title={tx("status")}>
            <Checkbox name="is_active" defaultChecked={r ? r.is_active : true}>
              {tx("activeHint")}
            </Checkbox>
          </Section>
        </fieldset>
        {f._ ? <p role="alert" className="text-sm text-alert">{f._}</p> : null}
        {canWrite ? (
          <div className="border-t border-ink/10 pt-6">
            <SubmitButton pendingLabel={tx("saving")}>{r ? tx("saveChanges") : tx("create")}</SubmitButton>
          </div>
        ) : null}
      </form>
      {canWrite && r ? <DeleteRule id={r.id} /> : null}
    </div>
  );
}

function DeleteRule({ id }: { id: string }) {
  const tx = useTranslations("adm.pricing");
  const [state, action] = useActionState(deleteRuleAction, initialFormState);
  return (
    <form action={action} className="space-y-4 border-t border-ink/10 pt-8">
      <input type="hidden" name="id" value={id} />
      <h2 className="font-display text-xl text-ink">{tx("delete")}</h2>
      <p className="text-sm text-slate">
        {tx("deleteHint")}
      </p>
      <FormAlert state={state} />
      <SubmitButton variant="danger" pendingLabel={tx("deleting")}>{tx("delete")}</SubmitButton>
    </form>
  );
}
