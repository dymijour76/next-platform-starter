import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { ServiceAdmin } from "@/lib/types";
import { RuleForm } from "../../RuleForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.pricing");
  return { title: tx("newPricingRule") };
}

export default async function NewRulePage() {
  const tx = await getTranslations("adm.pricing");
  const actor = await requirePermission("pricing:write");
  const services = can(actor, "services:read") ? await api<ServiceAdmin[]>("/admin/services") : null;
  return (
    <div className="space-y-8">
      <Link href="/admin/pricing" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={tx("newPricingRule")} />
      <RuleForm services={services?.ok ? services.data : []} canWrite />
    </div>
  );
}
