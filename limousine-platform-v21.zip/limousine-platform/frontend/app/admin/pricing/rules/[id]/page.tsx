import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { PricingRule, ServiceAdmin } from "@/lib/types";
import { RuleForm } from "../../RuleForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.pricing");
  return { title: tx("rule") };
}

export default async function RulePage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ created?: string }>;
}) {
  const tx = await getTranslations("adm.pricing");
  const [actor, { id }, { created }] = await Promise.all([requirePermission("pricing:read"), params, searchParams]);
  const [rule, services] = await Promise.all([
    api<PricingRule>(`/admin/pricing/rules/${encodeURIComponent(id)}`),
    can(actor, "services:read") ? api<ServiceAdmin[]>("/admin/services") : Promise.resolve(null),
  ]);
  if (!rule.ok) notFound();
  return (
    <div className="space-y-8">
      <Link href="/admin/pricing" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={rule.data.name} />
      {created ? <Notice>{tx("created")}</Notice> : null}
      <RuleForm rule={rule.data} services={services?.ok ? services.data : []} canWrite={can(actor, "pricing:write")} />
    </div>
  );
}
