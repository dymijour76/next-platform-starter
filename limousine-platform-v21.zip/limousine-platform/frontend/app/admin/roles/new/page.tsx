import type { Metadata } from "next";
import Link from "next/link";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { requirePermission } from "@/lib/auth";
import type { Permission } from "@/lib/types";
import { RoleForm } from "../RoleForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.roles");
  return { title: tx("new") };
}

export default async function NewRolePage() {
  const tx = await getTranslations("adm.roles");
  const actor = await requirePermission("roles:write");
  const perms = await api<Permission[]>("/permissions");
  return (
    <div className="space-y-8">
      <Link href="/admin/roles" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading title={tx("new")} description={tx("newHint")} />
      <RoleForm permissions={perms.ok ? perms.data : []} actorPermissions={actor.permissions} canWrite />
    </div>
  );
}
