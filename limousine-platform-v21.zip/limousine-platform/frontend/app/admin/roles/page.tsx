import type { Metadata } from "next";
import Link from "next/link";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { Role } from "@/lib/types";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.roles");
  return { title: tx("title") };
}

export default async function RolesPage({
  searchParams,
}: {
  searchParams: Promise<{ deleted?: string }>;
}) {
  const tx = await getTranslations("adm.roles");
  const [actor, { deleted }] = await Promise.all([requirePermission("roles:read"), searchParams]);
  const res = await api<Role[]>("/roles");

  return (
    <div className="space-y-8">
      <PageHeading
        title={tx("title")}
        description={tx("listHint")}
        action={
          can(actor, "roles:write") ? (
            <Link href="/admin/roles/new" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
              {tx("new")}
            </Link>
          ) : null
        }
      />
      {deleted ? <Notice>{tx("deleted")}</Notice> : null}
      {!res.ok ? (
        <p role="alert" className="text-alert">{res.error.message}</p>
      ) : (
        <ul className="divide-y divide-ink/10 border-y border-ink/10">
          {res.data.map((role) => (
            <li key={role.id}>
              <Link href={`/admin/roles/${role.id}`} className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 py-5 hover:bg-paper/60">
                <span>
                  <span className="font-display text-xl text-ink">{role.display_name}</span>
                  {role.is_system ? <span className="ml-3 text-xs uppercase tracking-wider text-slate">{tx("system")}</span> : null}
                  {role.display_description ? <span className="mt-1 block text-slate">{role.display_description}</span> : null}
                </span>
                <span className="text-sm text-slate">
                  {tx("counts", { permissions: role.permissions.length, users: role.user_count })}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
