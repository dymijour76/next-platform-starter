"use client";

import { useActionState } from "react";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState, type FormState } from "@/lib/form";
import type { Permission, Role } from "@/lib/types";
import { deleteRoleAction, saveRoleAction } from "../actions";
import { useTranslations } from "next-intl";

interface Props {
  role?: Role;
  permissions: Permission[];
  actorPermissions: string[];
  canWrite: boolean;
}

export function RoleForm({ role, permissions, actorPermissions, canWrite }: Props) {
  const tx = useTranslations("adm.roles");
  const mod = useTranslations("labels.module");
  const initial: FormState = {
    status: "idle",
    values: { code: role?.code ?? "", name: role?.name ?? "", description: role?.description ?? "" },
  };
  const [state, action] = useActionState(saveRoleAction, initial);
  const f = state.fields ?? {};
  const v = state.values ?? {};
  const granted = new Set(actorPermissions);
  const selected = new Set(role?.permissions ?? []);
  const locked = !canWrite || role?.code === "super_admin";

  // Grupos en este orden: operación primero, configuración al final.
  const order = ["dashboard", "reservations", "customers", "services", "pricing", "vehicles", "drivers", "driver_portal",
    "payments", "reports", "promotions", "content", "users", "roles", "settings", "audit"];
  const groups = Object.entries(
    permissions.reduce<Record<string, Permission[]>>((acc, p) => {
      (acc[p.module] ??= []).push(p);
      return acc;
    }, {}),
  ).sort(([a], [b]) => (order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99));

  return (
    <div className="space-y-10">
      <form action={action} className="space-y-8" noValidate>
        <FormAlert state={state} />
        <input type="hidden" name="id" value={role?.id ?? ""} />
        <fieldset disabled={!canWrite} className="max-w-xl space-y-5">
          {role ? null : (
            <Field label={tx("code")} name="code" required defaultValue={v.code} error={f.code}
              hint={tx("codeHint")} />
          )}
          <Field label={tx("name")} name="name" required defaultValue={v.name} error={f.name} />
          <Field label={tx("description")} name="description" defaultValue={v.description} error={f.description} />
        </fieldset>

        <fieldset>
          <legend className="font-display text-xl text-ink">{tx("permissions")}</legend>
          {role?.code === "super_admin" ? (
            <p className="mt-2 text-sm text-slate">{tx("superAdminNote")}</p>
          ) : null}
          {f.permissions ? <p className="mt-2 text-sm text-alert">{f.permissions}</p> : null}
          <div className="mt-4 grid gap-6 sm:grid-cols-2">
            {groups.map(([module, perms]) => (
              <div key={module} className="border-t border-ink/10 pt-4">
                <h3 className="text-sm font-medium text-ink">{mod.has(module) ? mod(module) : module}</h3>
                <ul className="mt-3 space-y-2">
                  {perms.map((p) => (
                    <li key={p.code}>
                      <label className="flex items-start gap-3 text-sm">
                        <input
                          type="checkbox"
                          name="permissions"
                          value={p.code}
                          defaultChecked={selected.has(p.code)}
                          disabled={locked || !granted.has(p.code)}
                          className="mt-0.5 size-4 accent-ink"
                        />
                        <span className={granted.has(p.code) ? "text-ink" : "text-slate"}>{p.description}</span>
                      </label>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </fieldset>

        {canWrite && role?.code !== "super_admin" ? (
          <SubmitButton pendingLabel={tx("saving")}>{role ? tx("saveChanges") : tx("create")}</SubmitButton>
        ) : null}
      </form>

      {canWrite && role && !role.is_system ? <DeleteRole role={role} /> : null}
    </div>
  );
}

function DeleteRole({ role }: { role: Role }) {
  const tx = useTranslations("adm.roles");
  const [state, action] = useActionState(deleteRoleAction, initialFormState);
  return (
    <form action={action} className="space-y-4 border-t border-ink/10 pt-8">
      <input type="hidden" name="id" value={role.id} />
      <h2 className="font-display text-xl text-ink">{tx("delete")}</h2>
      <p className="text-sm text-slate">
        {role.user_count
          ? tx("hasUsers", { count: role.user_count })
          : tx("irreversible")}
      </p>
      <FormAlert state={state} />
      {role.user_count === 0 ? (
        <SubmitButton variant="danger" pendingLabel={tx("deleting")}>{tx("delete")}</SubmitButton>
      ) : null}
    </form>
  );
}
