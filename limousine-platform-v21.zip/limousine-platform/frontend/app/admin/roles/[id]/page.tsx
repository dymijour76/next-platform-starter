import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Notice } from "@/components/forms/FormAlert";
import { PageHeading } from "@/components/PageHeading";
import { api } from "@/lib/api-server";
import { can, requirePermission } from "@/lib/auth";
import type { Permission, Role } from "@/lib/types";
import { RoleForm } from "../RoleForm";
import { getTranslations } from "next-intl/server";

export async function generateMetadata(): Promise<Metadata> {
  const tx = await getTranslations("adm.roles");
  return { title: tx("role") };
}

export default async function RoleDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ created?: string }>;
}) {
  const tx = await getTranslations("adm.roles");
  const [actor, { id }, { created }] = await Promise.all([
    requirePermission("roles:read"),
    params,
    searchParams,
  ]);
  const [rolesRes, permsRes] = await Promise.all([
    api<Role[]>("/roles"),
    api<Permission[]>("/permissions"),
  ]);
  const role = rolesRes.ok ? rolesRes.data.find((r) => r.id === id) : undefined;
  if (!role) notFound();

  return (
    <div className="space-y-8">
      <Link href="/admin/roles" className="text-sm text-slate hover:underline">{tx("back")}</Link>
      <PageHeading
        title={role.display_name}
        description={role.is_system ? tx("codeLineSystem", { code: role.code }) : tx("codeLine", { code: role.code })}
      />
      {created ? <Notice>{tx("created")}</Notice> : null}
      <RoleForm
        key={role.id}
        role={role}
        permissions={permsRes.ok ? permsRes.data : []}
        actorPermissions={actor.permissions}
        canWrite={can(actor, "roles:write")}
      />
    </div>
  );
}
