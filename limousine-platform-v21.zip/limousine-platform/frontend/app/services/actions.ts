"use server";

import { getTranslations } from "next-intl/server";

import { api } from "@/lib/api-server";
import { fromApiError, text } from "@/lib/form";
import { zonedToIso } from "@/lib/timezone";
import type { PublicPricingConfig, Quote } from "@/lib/types";

export interface QuoteState {
  status: "idle" | "error" | "success";
  message?: string;
  fields?: Record<string, string>;
  quote?: Quote;
  values?: Record<string, string>;
}

/** Cotiza en el servidor. El navegador sólo envía servicio, fecha, hora y duración. */
export async function quoteAction(_: QuoteState, form: FormData): Promise<QuoteState> {
  const values = {
    date: text(form, "date"),
    time: text(form, "time"),
    duration: text(form, "duration"),
  };
  const config = await api<PublicPricingConfig>("/pricing/config", { auth: false });
  if (!config.ok) return { ...fromApiError(config.error, values) };

  const t = await getTranslations("form");
  const pickupAt = zonedToIso(values.date, values.time, config.data.timezone);
  if (!pickupAt) {
    return {
      status: "error",
      message: t("checkData"),
      fields: { date: values.date ? "" : t("chooseDate"), time: values.time ? "" : t("chooseTime") },
      values,
    };
  }
  const simulate = form.get("mode") === "simulate";
  const res = await api<Quote>(simulate ? "/admin/pricing/simulate" : "/pricing/quote", {
    method: "POST",
    auth: simulate,
    body: {
      service_id: text(form, "service_id"),
      pickup_at: pickupAt,
      duration_minutes: Number(values.duration),
    },
  });
  if (!res.ok) {
    const state = fromApiError(res.error, values);
    // El error de la fecha se muestra junto al campo de fecha.
    if (state.fields?.pickup_at) state.fields = { ...state.fields, date: state.fields.pickup_at };
    return state;
  }
  return { status: "success", quote: res.data, values };
}
