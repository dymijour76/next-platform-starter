import type { Metadata } from "next";
import Link from "next/link";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import { SiteFooter } from "@/components/SiteFooter";
import { RatingSummary } from "@/components/Stars";
import { SiteHeader } from "@/components/SiteHeader";
import { api } from "@/lib/api-server";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import type { Service } from "@/lib/types";

export async function generateMetadata(): Promise<Metadata> {
  const [t, nav] = await Promise.all([getTranslations("services"), getTranslations("nav")]);
  return { title: nav("services"), description: t("metaDescription") };
}

export default async function ServicesPage() {
  const [t, nav, home, fmt] = await Promise.all([
    getTranslations("services"), getTranslations("nav"), getTranslations("home"), getFormat(),
  ]);
  const res = await api<Service[]>("/services", { auth: false });
  const services = res.ok ? res.data : [];
  return (
    <div className="min-h-dvh bg-pearl">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-6 py-14 sm:px-10">
        <h1 className="font-display text-4xl text-ink sm:text-5xl">{nav("services")}</h1>
        <p className="mt-4 max-w-xl text-slate">
          {t("intro")}
        </p>

        {!res.ok ? (
          <p role="alert" className="mt-10 text-alert">{res.error.message}</p>
        ) : services.length === 0 ? (
          <p className="mt-10 text-slate">{t("empty")}</p>
        ) : (
          <ul className="mt-12 divide-y divide-ink/10 border-y border-ink/10">
            {services.map((s) => (
              <li key={s.id}>
                <Link href={`/services/${s.slug}`}
                  className={`group grid gap-4 py-8 sm:items-end sm:gap-10 ${s.gallery[0] ? "sm:grid-cols-[14rem_minmax(0,1fr)_auto]" : "sm:grid-cols-[minmax(0,1fr)_auto]"}`}>
                  {s.gallery[0] ? (
                    <div className="aspect-[4/3] overflow-hidden bg-ink/10 sm:self-center">
                      <ResponsiveImage image={s.gallery[0]} sizes="(min-width: 640px) 14rem, 100vw" className="h-full w-full object-cover" />
                    </div>
                  ) : null}
                  <div>
                    <h2 className="font-display text-3xl text-ink group-hover:underline group-hover:decoration-champagne group-hover:underline-offset-8">
                      {s.name}
                    </h2>
                    {s.tagline ? <p className="mt-2 text-slate">{s.tagline}</p> : null}
                    <p className="mt-4 text-sm text-ink">
                      {home("upTo", { count: s.passenger_capacity })}
                      {s.features.length ? <span className="text-slate">. {s.features.slice(0, 3).join(", ")}</span> : null}
                    {s.rating?.count ? <RatingSummary rating={s.rating} /> : null}
                    </p>
                  </div>
                  <div className="sm:text-right">
                    <p className="text-sm text-slate">{home("from")}</p>
                    <p className="font-display text-2xl text-ink tabular-nums">{fmt.money(s.price_from, s.currency)}</p>
                    {fmt.ref(s.price_from) ? <p className="text-xs font-medium text-navy">{fmt.ref(s.price_from)}</p> : null}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}
