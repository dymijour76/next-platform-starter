import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { QuoteForm } from "@/components/pricing/QuoteForm";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import { ReviewList } from "@/components/ReviewList";
import { SiteFooter } from "@/components/SiteFooter";
import { RatingSummary } from "@/components/Stars";
import { SiteHeader } from "@/components/SiteHeader";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import { api } from "@/lib/api-server";
import { durationOptions } from "@/lib/money";
import { todayIn } from "@/lib/timezone";
import type { PublicPricingConfig, Service } from "@/lib/types";

async function load(slug: string) {
  const [service, config] = await Promise.all([
    api<Service>(`/services/${encodeURIComponent(slug)}`, { auth: false }),
    api<PublicPricingConfig>("/pricing/config", { auth: false }),
  ]);
  return { service: service.ok ? service.data : null, config: config.ok ? config.data : null };
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { service } = await load((await params).slug);
  return service
    ? { title: service.name, description: service.tagline ?? service.description ?? undefined }
    : { title: (await getTranslations("service"))("notFound") };
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { service: s, config } = await load((await params).slug);
  if (!s || !config) notFound();

  const [t, fmt] = await Promise.all([getTranslations("service"), getFormat()]);
  const facts = [
    [t("passengers"), t("upTo", { count: s.passenger_capacity })],
    s.luggage_capacity !== null ? [t("luggage"), t("suitcases", { count: s.luggage_capacity })] : null,
    [t("hourlyRate"), fmt.ref(s.hourly_rate) ? (
      <>{fmt.money(s.hourly_rate, s.currency)} <span className="text-sm font-medium text-navy">· {fmt.ref(s.hourly_rate)}</span></>
    ) : fmt.money(s.hourly_rate, s.currency)],
    Number(s.base_fare) ? [t("baseFare"), fmt.money(s.base_fare, s.currency)] : null,
    [t("minimum"), fmt.hours(s.min_hours)],
  ].filter(Boolean) as [string, string][];

  return (
    <div className="min-h-dvh bg-pearl">
      <SiteHeader />
      <main className="mx-auto grid max-w-6xl gap-12 px-6 py-14 sm:px-10 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
        <div>
          <Link href="/services" className="text-sm text-slate hover:underline">{t("allServices")}</Link>
          <h1 className="mt-4 font-display text-5xl text-ink">{s.name}</h1>
            {s.rating?.count ? <p className="mt-3"><RatingSummary rating={s.rating} /></p> : null}
          {s.tagline ? <p className="mt-4 text-lg text-slate">{s.tagline}</p> : null}
          <div className="mt-6 h-0.5 w-16 bg-champagne" aria-hidden="true" />
          {s.gallery.length ? (
            <div className="mt-8 space-y-3">
              <ResponsiveImage image={s.gallery[0]!} sizes="(min-width: 1024px) 58vw, 100vw" priority
                className="aspect-[3/2] w-full object-cover" />
              {s.gallery.length > 1 ? (
                <ul className="grid grid-cols-3 gap-3">
                  {s.gallery.slice(1, 4).map((img) => (
                    <li key={img.id}>
                      <ResponsiveImage image={img} sizes="(min-width: 1024px) 19vw, 33vw" className="aspect-[4/3] w-full object-cover" />
                    </li>
                  ))}
                </ul>
              ) : null}
            </div>
          ) : null}
          {s.description ? <p className="mt-8 max-w-prose leading-relaxed text-ink">{s.description}</p> : null}

          <dl className="mt-10 grid grid-cols-2 gap-x-8 gap-y-5 sm:grid-cols-3">
            {facts.map(([term, value]) => (
              <div key={term}>
                <dt className="text-sm text-slate">{term}</dt>
                <dd className="mt-0.5 text-ink tabular-nums">{value}</dd>
              </div>
            ))}
          </dl>

          {s.features.length ? (
            <section className="mt-10">
              <h2 className="font-display text-xl text-ink">{t("includes")}</h2>
              <ul className="mt-4 grid gap-2 sm:grid-cols-2">
                {s.features.map((feature) => (
                  <li key={feature} className="flex gap-3 text-ink">
                    <span className="mt-2.5 h-px w-3 shrink-0 bg-champagne" aria-hidden="true" />
                    {feature}
                  </li>
                ))}
              </ul>
            </section>
          ) : null}
        </div>

        <aside className="lg:sticky lg:top-8 lg:self-start">
          <h2 className="font-display text-2xl text-ink">{t("quoteTitle")}</h2>
          <p className="mt-2 text-sm text-slate">
            {t("quoteNote", { tax: config.tax_name, minutes: config.billing_increment_minutes })}
          </p>
          <div className="mt-6">
            <QuoteForm
              serviceId={s.id}
              durations={durationOptions(s.min_hours, s.max_hours, config.billing_increment_minutes)}
              minDate={todayIn(config.timezone)}
              note={
                <Link href={`/book?service=${s.slug}`}
                  className="inline-block rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
                  {t("bookThis")}
                </Link>
              }
            />
          </div>
        </aside>
      </main>
      <ReviewList service={s.slug} title={(await getTranslations("reviews"))("serviceTitle")} />
      <SiteFooter />
    </div>
  );
}
