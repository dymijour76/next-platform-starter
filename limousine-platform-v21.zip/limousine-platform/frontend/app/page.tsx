import Link from "next/link";
import { HeroCarousel } from "@/components/HeroCarousel";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import { ReviewList } from "@/components/ReviewList";
import { SiteFooter } from "@/components/SiteFooter";
import { RatingSummary } from "@/components/Stars";
import { SiteHeader } from "@/components/SiteHeader";
import { api } from "@/lib/api-server";
import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import type { Service, Slide } from "@/lib/types";

/** Portada: carrusel administrable y servicios con su fotografía de portada. */
export default async function HomePage() {
  const [slides, services] = await Promise.all([
    api<Slide[]>("/content/carousel", { auth: false }),
    api<Service[]>("/services", { auth: false }),
  ]);
  const list = services.ok ? services.data : [];
  const [t, tNav, fmt] = await Promise.all([getTranslations("home"), getTranslations("nav"), getFormat()]);

  return (
    <div className="min-h-dvh bg-pearl">
      <div className="bg-ink"><SiteHeader tone="dark" /></div>

      {slides.ok && slides.data.length ? (
        <HeroCarousel slides={slides.data} />
      ) : (
        // Sin diapositivas publicadas: portada de texto.
        <section className="bg-ink text-pearl">
          <div className="mx-auto max-w-6xl px-6 py-24 sm:px-10">
            <h1 className="max-w-3xl font-display text-5xl leading-[1.05] sm:text-7xl">{t("heroTitle")}</h1>
            <div className="mt-8 h-0.5 w-16 bg-champagne" aria-hidden="true" />
            <p className="mt-8 max-w-xl text-lg leading-relaxed text-pearl/80">
              {t("heroText")}
            </p>
            <Link href="/book" className="mt-10 inline-block rounded-sm bg-champagne px-6 py-3 text-sm font-medium text-ink hover:bg-pearl">
              {tNav("book")}
            </Link>
          </div>
        </section>
      )}

      {list.length ? (
        <section aria-labelledby="services-title" className="mx-auto max-w-6xl px-6 py-20 sm:px-10">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 id="services-title" className="font-display text-4xl text-ink">{t("ourServices")}</h2>
            <Link href="/services" className="text-sm text-ink underline decoration-champagne underline-offset-4">{t("detailsAndPrices")}</Link>
          </div>
          <ul className="mt-10 grid gap-8 md:grid-cols-3">
            {list.map((s) => (
              <li key={s.id}>
                <Link href={`/services/${s.slug}`} className="group block">
                  <div className="aspect-[4/3] overflow-hidden bg-ink">
                    {s.gallery[0] ? (
                      <ResponsiveImage image={s.gallery[0]} sizes="(min-width: 768px) 33vw, 100vw"
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03] motion-reduce:transition-none" />
                    ) : (
                      // Sin fotografía: portada tipográfica con los colores de la marca.
                      <div className="flex h-full flex-col justify-end p-6 text-pearl" aria-hidden="true">
                        <div className="mb-4 h-0.5 w-10 bg-champagne" />
                        <span className="font-display text-3xl">{s.name}</span>
                        <span className="mt-1 text-sm text-pearl/60">{t("upTo", { count: s.passenger_capacity })}</span>
                    {s.rating?.count ? <span className="mt-1 block"><RatingSummary rating={s.rating} dark /></span> : null}
                      </div>
                    )}
                  </div>
                  <h3 className="mt-5 font-display text-2xl text-ink group-hover:underline group-hover:decoration-champagne group-hover:underline-offset-8">{s.name}</h3>
                  {s.tagline ? <p className="mt-1 text-slate">{s.tagline}</p> : null}
                  <p className="mt-3 text-sm text-ink">{t("from")} <span className="font-display text-lg tabular-nums">{fmt.money(s.price_from, s.currency)}</span></p>
                  {fmt.ref(s.price_from) ? <p className="text-xs font-medium text-navy">{fmt.ref(s.price_from)}</p> : null}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <ReviewList title={t("reviewsTitle")} />
      <SiteFooter />
    </div>
  );
}
