import type { Metadata } from "next";
import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getTranslations("errors"))("notFoundTitle") };
}

export default async function NotFound() {
  const t = await getTranslations("errors");
  return (
    <div className="min-h-dvh bg-pearl">
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-6 py-24 text-center">
        <p className="text-sm uppercase tracking-widest text-slate">404</p>
        <h1 className="mt-3 font-display text-4xl text-ink">{t("notFoundHeading")}</h1>
        <p className="mt-4 text-slate">{t("notFoundText")}</p>
        <div className="mt-8 flex justify-center gap-4">
          <Link href="/" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">{t("home")}</Link>
          <Link href="/services" className="rounded-sm border border-ink/25 px-5 py-2.5 text-sm hover:border-ink/50">{t("services")}</Link>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}
