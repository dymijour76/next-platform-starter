// Función programada de Netlify: visita la API cada 10 minutos para que el plan gratuito
// de Render no la duerma (dormida tarda cerca de un minuto en responder y el sitio
// mostraría un error). Sólo se usa al publicar en Netlify.
const keepAwake = async () => {
  const api = process.env.API_INTERNAL_URL;
  if (!api) return new Response("API_INTERNAL_URL no definida", { status: 500 });
  try {
    const res = await fetch(`${api.replace(/\/$/, "")}/api/v1/health/live`, {
      signal: AbortSignal.timeout(25_000),
    });
    return new Response(`API: ${res.status}`);
  } catch (error) {
    return new Response(`API sin respuesta: ${String(error)}`, { status: 502 });
  }
};

export default keepAwake;

export const config = { schedule: "*/10 * * * *" };
