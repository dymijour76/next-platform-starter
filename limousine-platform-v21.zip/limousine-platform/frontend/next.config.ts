import createNextIntlPlugin from "next-intl/plugin";
import type { NextConfig } from "next";

const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  // Aísla la ventana de otras (protege contra ataques entre pestañas).
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
  ...(process.env.NODE_ENV === "production"
    ? [{ key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" }]
    : []),
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  // camera=(self): el panel del conductor escanea el QR. La política la fija el primer
  // documento cargado y la navegación interna no la cambia, así que no basta con permitirla
  // sólo en /driver. El navegador igual pide permiso a la persona antes de abrir la cámara.
  { key: "Permissions-Policy", value: "camera=(self), microphone=(), geolocation=(self)" },
];

const nextConfig: NextConfig = {
  // Genera un servidor autocontenido para una imagen Docker pequeña. En Netlify (que define
  // NETLIFY=true al compilar) el adaptador de Netlify arma el sitio a su manera.
  ...(process.env.NETLIFY ? {} : { output: "standalone" as const }),
  poweredByHeader: false,
  reactStrictMode: true,
  experimental: {
    // Subida de imágenes por Server Actions: la API acepta hasta 10 MB (más el formulario).
    serverActions: { bodySizeLimit: "11mb" },
  },
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

// Traducciones: next-intl lee la configuración de i18n/request.ts.
export default createNextIntlPlugin()(nextConfig);
