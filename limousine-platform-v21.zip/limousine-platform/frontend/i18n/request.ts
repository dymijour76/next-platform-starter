import { cookies, headers } from "next/headers";
import { getRequestConfig } from "next-intl/server";
import { DEFAULT_LOCALE, isLocale, LOCALE_COOKIE, negotiate, type Locale } from "./config";

/** Idioma de la petición: la elección guardada, luego el navegador, luego el español. */
export async function requestLocale(): Promise<Locale> {
  const chosen = (await cookies()).get(LOCALE_COOKIE)?.value;
  if (isLocale(chosen)) return chosen;
  return negotiate((await headers()).get("accept-language"));
}

export default getRequestConfig(async () => {
  const locale = await requestLocale();
  const messages = (await import(`../messages/${locale}.json`)).default;
  // Los textos que falten en un idioma se toman del español.
  const fallback = locale === DEFAULT_LOCALE ? {} : (await import(`../messages/${DEFAULT_LOCALE}.json`)).default;
  return {
    locale,
    messages: deepMerge(fallback, messages),
    timeZone: "America/Santiago",
  };
});

type Tree = { [key: string]: string | Tree };

function deepMerge(base: Tree, over: Tree): Tree {
  const out: Tree = { ...base };
  for (const [k, v] of Object.entries(over)) {
    const b = out[k];
    out[k] = typeof v === "object" && typeof b === "object" ? deepMerge(b, v) : v;
  }
  return out;
}
