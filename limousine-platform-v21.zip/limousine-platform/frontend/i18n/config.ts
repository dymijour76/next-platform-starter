/**
 * Idiomas de la plataforma. El español es el idioma de origen y el de respaldo:
 * si falta una traducción, se muestra el texto en español.
 */
export const LOCALES = ["es", "en", "fr", "ht", "zh"] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "es";
export const LOCALE_COOKIE = "lp_locale";

/** Cada idioma escrito en su propia lengua (así lo reconoce quien lo habla). */
export const LOCALE_NAMES: Record<Locale, string> = {
  es: "Español",
  en: "English",
  fr: "Français",
  ht: "Kreyòl ayisyen",
  zh: "中文（简体）",
};

/** Valor del atributo lang de <html>: lo usan los lectores de pantalla y los traductores. */
export const HTML_LANG: Record<Locale, string> = { es: "es", en: "en", fr: "fr", ht: "ht", zh: "zh-Hans" };

export function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (LOCALES as readonly string[]).includes(value);
}

/** Elige el idioma a partir de la cabecera Accept-Language del navegador. */
export function negotiate(acceptLanguage: string | null | undefined): Locale {
  if (!acceptLanguage) return DEFAULT_LOCALE;
  const ranked = acceptLanguage
    .split(",")
    .map((part) => {
      const [tag, q] = part.trim().split(";q=");
      return { tag: (tag ?? "").toLowerCase(), q: q ? Number(q) : 1 };
    })
    .sort((a, b) => b.q - a.q);
  for (const { tag } of ranked) {
    const base = tag.split("-")[0];
    if (isLocale(base)) return base;
  }
  return DEFAULT_LOCALE;
}
