import { useTranslations } from "next-intl";
import type { InputHTMLAttributes, ReactNode } from "react";

interface FieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  name: string;
  error?: string;
  hint?: ReactNode;
}

export function Field({ label, name, error, hint, id, className, ...input }: FieldProps) {
  const inputId = id ?? `f-${name}`;
  const describedBy = [error ? `${inputId}-error` : null, hint ? `${inputId}-hint` : null]
    .filter(Boolean)
    .join(" ");
  const t = useTranslations("forms");
  return (
    <div className={className}>
      <label htmlFor={inputId} className="block text-sm font-medium text-ink">
        {label}
        {input.required ? null : <span className="font-normal text-slate"> ({t("optional")})</span>}
      </label>
      <input
        id={inputId}
        name={name}
        aria-invalid={error ? true : undefined}
        aria-describedby={describedBy || undefined}
        className={`mt-1.5 block w-full rounded-sm border bg-paper px-3 py-2.5 text-base text-ink placeholder:text-slate/70 focus:outline-2 focus:outline-offset-0 focus:outline-champagne ${
          error ? "border-alert" : "border-ink/20"
        }`}
        {...input}
      />
      {hint && !error ? (
        <p id={`${inputId}-hint`} className="mt-1.5 text-sm text-slate">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={`${inputId}-error`} className="mt-1.5 text-sm text-alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

interface CheckboxProps extends InputHTMLAttributes<HTMLInputElement> {
  name: string;
  error?: string;
  children: ReactNode;
}

export function Checkbox({ name, error, children, id, ...input }: CheckboxProps) {
  const inputId = id ?? `f-${name}`;
  return (
    <div>
      <label htmlFor={inputId} className="flex items-start gap-3 text-sm leading-relaxed text-ink">
        <input
          id={inputId}
          name={name}
          type="checkbox"
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? `${inputId}-error` : undefined}
          className="mt-1 size-4 shrink-0 accent-ink"
          {...input}
        />
        <span>{children}</span>
      </label>
      {error ? (
        <p id={`${inputId}-error`} className="mt-1.5 pl-7 text-sm text-alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  name: string;
  error?: string;
  children: ReactNode;
}

export function Select({ label, name, error, children, id, ...select }: SelectProps) {
  const inputId = id ?? `f-${name}`;
  return (
    <div>
      <label htmlFor={inputId} className="block text-sm font-medium text-ink">
        {label}
      </label>
      <select
        id={inputId}
        name={name}
        aria-invalid={error ? true : undefined}
        className="mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5 text-base text-ink focus:outline-2 focus:outline-offset-0 focus:outline-champagne"
        {...select}
      >
        {children}
      </select>
      {error ? <p className="mt-1.5 text-sm text-alert">{error}</p> : null}
    </div>
  );
}

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  name: string;
  error?: string;
  hint?: ReactNode;
}

export function Textarea({ label, name, error, hint, id, className, ...area }: TextareaProps) {
  const inputId = id ?? `f-${name}`;
  const t = useTranslations("forms");
  return (
    <div className={className}>
      <label htmlFor={inputId} className="block text-sm font-medium text-ink">
        {label}
        {area.required ? null : <span className="font-normal text-slate"> ({t("optional")})</span>}
      </label>
      <textarea
        id={inputId}
        name={name}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
        className={`mt-1.5 block w-full rounded-sm border bg-paper px-3 py-2.5 text-base text-ink focus:outline-2 focus:outline-offset-0 focus:outline-champagne ${
          error ? "border-alert" : "border-ink/20"
        }`}
        {...area}
      />
      {hint && !error ? <p id={`${inputId}-hint`} className="mt-1.5 text-sm text-slate">{hint}</p> : null}
      {error ? <p id={`${inputId}-error`} className="mt-1.5 text-sm text-alert">{error}</p> : null}
    </div>
  );
}
