"use client";

import { useTranslations } from "next-intl";
import { useState } from "react";

/**
 * Calificación de 1 a 5 con botones de opción reales: funciona con teclado (flechas) y con
 * lector de pantalla ("3 estrellas, 3 de 5"). Las estrellas son sólo el dibujo de las opciones.
 */
export function StarInput({ name, legend, required, error }: { name: string; legend: string; required?: boolean; error?: string }) {
  const t = useTranslations("reviews");
  const [value, setValue] = useState(0);
  const [hover, setHover] = useState(0);
  const shown = hover || value;
  const errorId = error ? `${name}-error` : undefined;
  return (
    <fieldset aria-describedby={errorId}>
      <legend className="text-sm font-medium text-ink">{legend}</legend>
      <div className="mt-2 flex gap-1" onMouseLeave={() => setHover(0)}>
        {[1, 2, 3, 4, 5].map((i) => (
          <label key={i} className="cursor-pointer" onMouseEnter={() => setHover(i)}>
            <input type="radio" name={name} value={i} required={required} className="peer sr-only"
              checked={value === i} onChange={() => setValue(i)} />
            <span className="sr-only">{t("star", { count: i })}</span>
            <svg viewBox="0 0 20 20" aria-hidden="true"
              className="size-8 text-champagne peer-focus-visible:rounded-sm peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-ink">
              <path d="M10 1.8l2.5 5.2 5.7.8-4.1 4 1 5.6L10 14.7l-5.1 2.7 1-5.6-4.1-4 5.7-.8z"
                fill={i <= shown ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
            </svg>
          </label>
        ))}
      </div>
      {error ? <p id={errorId} className="mt-1 text-sm text-alert">{error}</p> : null}
    </fieldset>
  );
}
