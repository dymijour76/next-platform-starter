"use client";

import { useFormStatus } from "react-dom";

interface Props {
  children: React.ReactNode;
  pendingLabel: string;
  variant?: "primary" | "secondary" | "danger";
  className?: string;
}

const VARIANTS = {
  primary: "bg-ink text-pearl hover:bg-ink-soft",
  secondary: "border border-ink/25 bg-paper text-ink hover:border-ink/50",
  danger: "border border-alert/40 bg-paper text-alert hover:border-alert",
};

export function SubmitButton({ children, pendingLabel, variant = "primary", className = "" }: Props) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      aria-disabled={pending}
      className={`inline-flex items-center justify-center rounded-sm px-5 py-2.5 text-sm font-medium transition-colors disabled:cursor-wait disabled:opacity-70 ${VARIANTS[variant]} ${className}`}
    >
      {pending ? pendingLabel : children}
    </button>
  );
}
