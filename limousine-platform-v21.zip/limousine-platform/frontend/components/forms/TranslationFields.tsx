import { HTML_LANG, LOCALE_NAMES } from "@/i18n/config";
import { TARGET_LOCALES, type TranslationField } from "@/lib/translations";

/**
 * Campos de traducción: un bloque desplegable por idioma, con su estado.
 * Lo que se deje vacío se muestra en español al visitante.
 */
export function TranslationFields({ fields, values, labels }: {
  fields: TranslationField[];
  values: Record<string, string | undefined>;
  labels: { complete: string; partial: string; missing: string; hint: string };
}) {
  return (
    <div className="space-y-3">
      <p className="text-sm text-slate">{labels.hint}</p>
      {TARGET_LOCALES.map((locale) => {
        const filled = fields.filter((f) => (values[`tr.${locale}.${f.key}`] ?? "").trim()).length;
        const state = filled === 0 ? labels.missing : filled === fields.length ? labels.complete : labels.partial;
        const tone = filled === 0 ? "text-slate" : filled === fields.length ? "text-ok" : "text-ink";
        return (
          <details key={locale} className="border border-ink/10 bg-paper" open={false}>
            <summary className="flex cursor-pointer items-center justify-between gap-3 px-4 py-3 text-sm">
              <span lang={HTML_LANG[locale]} className="font-medium text-ink">{LOCALE_NAMES[locale]}</span>
              <span className={tone}>{state}</span>
            </summary>
            <div className="grid gap-4 border-t border-ink/10 px-4 py-4" lang={HTML_LANG[locale]}>
              {fields.map((f) => {
                const id = `tr-${locale}-${f.key}`;
                const name = `tr.${locale}.${f.key}`;
                const common = {
                  id, name, defaultValue: values[name] ?? "", maxLength: f.maxLength,
                  className: "mt-1.5 block w-full rounded-sm border border-ink/20 bg-paper px-3 py-2.5 text-base text-ink",
                };
                return (
                  <div key={f.key}>
                    <label htmlFor={id} className="block text-sm font-medium text-ink">
                      {f.label}
                      {/* Nombre accesible único: "Nombre (English)", no cinco campos "Nombre" iguales. */}
                      <span className="sr-only"> ({LOCALE_NAMES[locale]})</span>
                    </label>
                    {f.kind === "textarea" || f.kind === "lines" ? <textarea rows={f.kind === "lines" ? 4 : 3} {...common} /> : <input type="text" {...common} />}
                  </div>
                );
              })}
            </div>
          </details>
        );
      })}
    </div>
  );
}
