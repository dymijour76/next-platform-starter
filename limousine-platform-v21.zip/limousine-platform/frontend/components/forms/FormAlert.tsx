import type { FormState } from "@/lib/form";

/** Mensaje general del formulario. Se anuncia a lectores de pantalla. */
export function FormAlert({ state }: { state: FormState }) {
  if (state.status === "idle" || !state.message) return null;
  const isError = state.status === "error";
  return (
    <div
      role={isError ? "alert" : "status"}
      className={`border-l-2 px-4 py-3 text-sm ${
        isError ? "border-alert bg-alert/5 text-alert" : "border-ok bg-ok/5 text-ok"
      }`}
    >
      {state.message}
    </div>
  );
}

export function Notice({ tone = "ok", children }: { tone?: "ok" | "info"; children: React.ReactNode }) {
  return (
    <div
      role="status"
      className={`border-l-2 px-4 py-3 text-sm ${
        tone === "ok" ? "border-ok bg-ok/5 text-ok" : "border-champagne bg-champagne/10 text-ink"
      }`}
    >
      {children}
    </div>
  );
}
