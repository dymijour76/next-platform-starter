import { useLocale, useTranslations } from "next-intl";
import type { Locale } from "@/i18n/config";
import { intlLocale } from "@/lib/intl";

/**
 * Estrellas para mostrar: el lector de pantalla anuncia "4,5 de 5", no cinco imágenes.
 * Se dibujan enteras (redondeadas); el valor exacto va en el nombre accesible y, si se
 * quiere, en el texto junto a las estrellas.
 */
export function Stars({ rating, size = "size-4" }: { rating: number; size?: string }) {
  const t = useTranslations("reviews");
  const locale = useLocale() as Locale;
  const value = new Intl.NumberFormat(intlLocale(locale), { maximumFractionDigits: 1 }).format(rating);
  const filled = Math.round(rating);
  return (
    <span role="img" aria-label={t("outOf", { rating: value })} className="inline-flex items-center gap-0.5 text-champagne">
      {[1, 2, 3, 4, 5].map((i) => (
        <svg key={i} viewBox="0 0 20 20" className={size} aria-hidden="true">
          <path
            d="M10 1.8l2.5 5.2 5.7.8-4.1 4 1 5.6L10 14.7l-5.1 2.7 1-5.6-4.1-4 5.7-.8z"
            fill={i <= filled ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
        </svg>
      ))}
    </span>
  );
}

/** "4,8 · 23 opiniones" junto a las estrellas. */
export function RatingSummary({ rating, dark = false }: { rating: { average: number | null; count: number } | null; dark?: boolean }) {
  const t = useTranslations("reviews");
  const locale = useLocale() as Locale;
  if (!rating?.count || rating.average === null) return null;
  return (
    <span className={`inline-flex items-center gap-2 text-sm ${dark ? "text-pearl/75" : "text-slate"}`}>
      <Stars rating={rating.average} />
      <span>
        {new Intl.NumberFormat(intlLocale(locale), { maximumFractionDigits: 1, minimumFractionDigits: 1 }).format(rating.average)}
        {" · "}
        {t("count", { count: rating.count })}
      </span>
    </span>
  );
}
