import { useTranslations } from "next-intl";
import { RESERVATION_TONE } from "@/lib/labels";
import type { ReservationStatus } from "@/lib/types";

export function StatusBadge({ status }: { status: ReservationStatus }) {
  const t = useTranslations("labels.reservation");
  return <span className={`inline-block rounded-sm px-2 py-0.5 text-xs font-medium ${RESERVATION_TONE[status]}`}>{t(status)}</span>;
}
