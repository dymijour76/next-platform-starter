/**
 * Gráfico de barras apiladas en SVG, generado en el servidor (sin JavaScript).
 * Siempre acompañado de una tabla con los mismos datos: es lo que leen los
 * lectores de pantalla y permite ver las cifras exactas.
 */

export interface Segment {
  key: string;
  label: string;
  color: string;
}

interface Props {
  title: string;
  labels: string[];
  segments: Segment[];
  values: Record<string, number>[];
  format?: (n: number) => string;
}

const W = 720;
const H = 240;
const PAD = { top: 12, right: 8, bottom: 28, left: 64 };

function niceMax(n: number): number {
  if (n <= 0) return 1;
  const mag = 10 ** Math.floor(Math.log10(n));
  return Math.ceil(n / mag) * mag;
}

export function BarChart({ title, labels, segments, values, format = (n) => n.toLocaleString("es-CL") }: Props) {
  const totals = values.map((v) => segments.reduce((sum, s) => sum + Math.max(0, v[s.key] ?? 0), 0));
  const max = niceMax(Math.max(0, ...totals));
  const innerW = W - PAD.left - PAD.right;
  const innerH = H - PAD.top - PAD.bottom;
  const slot = innerW / Math.max(1, labels.length);
  const barW = Math.max(2, Math.min(40, slot * 0.7));
  // Etiquetas del eje X: como máximo ~12 para que no se amontonen.
  const every = Math.ceil(labels.length / 12);
  const ticks = [0, 0.5, 1].map((f) => f * max);
  const id = title.replace(/\W+/g, "-").toLowerCase();

  return (
    <figure className="space-y-3">
      <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-slate" aria-hidden="true">
        {segments.map((s) => (
          <span key={s.key} className="flex items-center gap-1.5">
            <span className="inline-block size-2.5 rounded-sm" style={{ background: s.color }} />
            {s.label}
          </span>
        ))}
      </div>
      <div className="overflow-x-auto">
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full min-w-[32rem]" role="img" aria-labelledby={`${id}-t`}>
          <title id={`${id}-t`}>{title}</title>
          {ticks.map((t) => {
            const y = PAD.top + innerH - (t / max) * innerH;
            return (
              <g key={t}>
                <line x1={PAD.left} x2={W - PAD.right} y1={y} y2={y} stroke="currentColor" className="text-ink/10" />
                <text x={PAD.left - 8} y={y + 4} textAnchor="end" className="fill-slate text-[10px]">{format(t)}</text>
              </g>
            );
          })}
          {values.map((v, i) => {
            let y = PAD.top + innerH;
            const x = PAD.left + i * slot + (slot - barW) / 2;
            return (
              <g key={i}>
                {segments.map((s) => {
                  const h = (Math.max(0, v[s.key] ?? 0) / max) * innerH;
                  y -= h;
                  return h > 0 ? (
                    <rect key={s.key} x={x} y={y} width={barW} height={h} fill={s.color}>
                      <title>{`${labels[i]}: ${s.label} ${format(v[s.key] ?? 0)}`}</title>
                    </rect>
                  ) : null;
                })}
                {i % every === 0 ? (
                  <text x={x + barW / 2} y={H - 8} textAnchor="middle" className="fill-slate text-[10px]">{labels[i]}</text>
                ) : null}
              </g>
            );
          })}
        </svg>
      </div>
    </figure>
  );
}
