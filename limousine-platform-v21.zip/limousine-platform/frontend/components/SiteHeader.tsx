import Link from "next/link";
import { logoutAction } from "@/app/(auth)/actions";
import { getCurrentUser, isStaff } from "@/lib/auth";
import { getTranslations } from "next-intl/server";
import { CurrencySwitcher } from "@/components/CurrencySwitcher";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { config } from "@/lib/config";

/**
 * Cabecera del sitio.
 */
export async function SiteHeader({ tone = "light" }: { tone?: "light" | "dark" }) {
  const [user, t] = await Promise.all([getCurrentUser(), getTranslations("nav")]);
  const dark = tone === "dark";
  const link = `text-sm underline-offset-4 hover:underline ${dark ? "text-pearl/80 hover:text-pearl" : "text-slate hover:text-ink"}`;

  return (
    <header className={dark ? "text-pearl" : "border-b border-ink/10 bg-paper text-ink"}>
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-x-6 gap-y-3 px-6 py-5 sm:px-10">
        <Link href="/" className="font-display text-lg tracking-wide">
          {config.companyName}
        </Link>
        <nav aria-label={t("main")} className="flex flex-wrap items-center gap-x-5 gap-y-2">
          <Link href="/services" className={link}>
            {t("services")}
          </Link>
          <Link href="/book" className={link}>
            {t("book")}
          </Link>
          {user ? (
            <>
              {user.roles.some((r) => r.code === "driver") ? (
                <Link href="/driver" className={link}>
                  {t("myTrips")}
                </Link>
              ) : null}
              {isStaff(user) ? (
                <Link href="/admin" className={link}>
                  {t("admin")}
                </Link>
              ) : null}
              <Link href="/account" className={link}>
                {t("account")}
              </Link>
              <form action={logoutAction}>
                <button type="submit" className={`${link} cursor-pointer`}>
                  {t("logout")}
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className={link}>
                {t("login")}
              </Link>
              <Link
                href="/register"
                className={`rounded-sm px-4 py-2 text-sm ${
                  dark ? "border border-pearl/40 hover:border-pearl" : "bg-ink text-pearl hover:bg-ink-soft"
                }`}
              >
                {t("register")}
              </Link>
            </>
          )}
          <CurrencySwitcher dark={dark} />
          <LanguageSwitcher dark={dark} />
        </nav>
      </div>
    </header>
  );
}
