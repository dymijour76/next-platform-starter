"use client";

import { useTranslations } from "next-intl";
import { useCallback, useEffect, useRef, useState } from "react";
import { useFormat } from "@/lib/format-client";
import type { ChatInfo, ChatMessage } from "@/lib/types";

const POLL_MS = 5000;

/**
 * Conversación de una reserva. Consulta mensajes nuevos cada 5 segundos mientras la pestaña
 * está a la vista (se pausa al ocultarla). Los mensajes que llegan se anuncian a los lectores
 * de pantalla sin interrumpir (aria-live="polite").
 */
export function Chat({ endpoint, initial, emptyText }: { endpoint: string; initial: ChatInfo; emptyText: string }) {
  const t = useTranslations("chat");
  const fmt = useFormat();
  const [chat, setChat] = useState<ChatInfo>(initial);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [announce, setAnnounce] = useState("");
  const list = useRef<HTMLOListElement>(null);
  const known = useRef(new Set(initial.messages.map((m) => m.id)));

  const refresh = useCallback(async () => {
    const res = await fetch(endpoint, { cache: "no-store" });
    if (!res.ok) return;
    const next: ChatInfo = await res.json();
    const incoming = next.messages.filter((m) => !m.mine && !known.current.has(m.id));
    next.messages.forEach((m) => known.current.add(m.id));
    if (incoming.length && next.counterpart) setAnnounce(t("newFrom", { name: next.counterpart }));
    setChat(next);
  }, [endpoint, t]);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | undefined;
    const start = () => { if (!timer) timer = setInterval(refresh, POLL_MS); };
    const stop = () => { if (timer) { clearInterval(timer); timer = undefined; } };
    const onVisibility = () => { if (document.visibilityState === "visible") { void refresh(); start(); } else stop(); };
    if (document.visibilityState === "visible") start();
    document.addEventListener("visibilitychange", onVisibility);
    return () => { stop(); document.removeEventListener("visibilitychange", onVisibility); };
  }, [refresh]);

  useEffect(() => {
    list.current?.scrollTo({ top: list.current.scrollHeight });
  }, [chat.messages.length]);

  async function send() {
    const body = text.trim();
    if (!body || sending) return;
    setSending(true);
    setError(null);
    const res = await fetch(endpoint, { method: "POST", body: JSON.stringify({ body }), headers: { "Content-Type": "application/json" } });
    setSending(false);
    if (!res.ok) {
      const data = await res.json().catch(() => null);
      setError(data?.error?.fields?.body ?? data?.error?.message ?? t("error"));
      return;
    }
    setText("");
    await refresh();
  }

  const who = (m: ChatMessage) => (m.mine ? t("you") : chat.counterpart ?? t(m.sender_role));
  const lastMine = [...chat.messages].reverse().find((m) => m.mine);

  return (
    <div className="space-y-4">
      <p aria-live="polite" className="sr-only">{announce}</p>
      {chat.messages.length ? (
        <ol ref={list} className="max-h-96 space-y-3 overflow-y-auto border border-ink/10 bg-pearl/60 p-4">
          {chat.messages.map((m) => (
            <li key={m.id} className={`flex ${m.mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-sm px-3 py-2 text-sm ${m.mine ? "bg-ink text-pearl" : "border border-ink/10 bg-paper text-ink"}`}>
                <p className="sr-only">{who(m)}:</p>
                {m.body === null ? <p className="italic opacity-70">{t("deleted")}</p> : <p className="whitespace-pre-line break-words">{m.body}</p>}
                <p className={`mt-1 text-[11px] ${m.mine ? "text-pearl/70" : "text-slate"}`}>
                  {fmt.dateTime(m.created_at, { hour: "2-digit", minute: "2-digit", hourCycle: "h23" })}
                  {m.mine && m.id === lastMine?.id ? ` · ${m.read ? t("read") : t("sent")}` : ""}
                </p>
              </div>
            </li>
          ))}
        </ol>
      ) : <p className="text-sm text-slate">{emptyText}</p>}
      {chat.open ? (
        <form onSubmit={(e) => { e.preventDefault(); void send(); }} className="space-y-2">
          <label htmlFor="chat-message" className="text-sm font-medium text-ink">{t("label")}</label>
          <textarea id="chat-message" value={text} maxLength={1000} rows={2} aria-describedby="chat-hint"
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void send(); } }}
            className="block w-full rounded-sm border border-ink/25 bg-paper px-3 py-2 text-ink focus:border-ink focus:outline-none" />
          <div className="flex items-center justify-between gap-3">
            <p id="chat-hint" className="text-xs text-slate">{t("hint")}</p>
            <button type="submit" disabled={sending || !text.trim()} className="rounded-sm bg-ink px-4 py-2 text-sm text-pearl disabled:opacity-50">
              {sending ? t("sending") : t("send")}
            </button>
          </div>
          {error ? <p role="alert" className="text-sm text-alert">{error}</p> : null}
          <p className="text-xs text-slate">{t("openUntil")}</p>
        </form>
      ) : <p className="text-sm text-slate">{t("closed")}</p>}
    </div>
  );
}
