import { getTranslations } from "next-intl/server";
import { api } from "@/lib/api-server";
import { getFormat } from "@/lib/format-server";
import type { ChatInfo } from "@/lib/types";
import { Chat } from "./Chat";

/**
 * Sección de mensajes (id="mensajes": el enlace del email llega aquí). No se muestra hasta que
 * hay chófer asignado. `apiPath` es la ruta de la API; `endpoint`, la del sitio que usa el navegador.
 */
export async function ChatSection({ apiPath, endpoint, as }: { apiPath: string; endpoint: string; as: "customer" | "driver" }) {
  const res = await api<ChatInfo>(apiPath);
  if (!res.ok || res.data.counterpart === null) return null;
  const t = await getTranslations("chat");
  const name = res.data.counterpart;
  return (
    <section id="mensajes" aria-labelledby="mensajes-title" className="scroll-mt-24 border border-ink/10 bg-paper p-6">
      <h2 id="mensajes-title" className="mb-4 font-display text-xl text-ink">
        {as === "customer" ? t("titleCustomer") : t("titleDriver")}
      </h2>
      <Chat endpoint={endpoint} initial={res.data}
        emptyText={as === "customer" ? t("emptyCustomer", { name }) : t("emptyDriver", { name })} />
    </section>
  );
}

/** La conversación en el panel: sólo lectura, sin formulario ni consultas periódicas. */
export async function StaffChat({ reservationId }: { reservationId: string }) {
  const res = await api<ChatInfo>(`/admin/reservations/${encodeURIComponent(reservationId)}/messages`);
  if (!res.ok || !res.data.messages.length) return null;
  const [t, fmt] = await Promise.all([getTranslations("chat"), getFormat()]);
  return (
    <section aria-labelledby="staff-chat" className="space-y-3">
      <h2 id="staff-chat" className="font-display text-xl text-ink">{t("titleStaff")}</h2>
      <p className="text-sm text-slate">{t("staffHint")}</p>
      <ol className="space-y-2 text-sm">
        {res.data.messages.map((m) => (
          <li key={m.id} className="border-l-2 border-ink/15 pl-3">
            <span className="font-medium text-ink">{t(m.sender_role)}</span>{" "}
            <span className="text-xs text-slate">{fmt.date(m.created_at)}</span>
            <p className="whitespace-pre-line text-ink">{m.body ?? <em className="text-slate">{t("deleted")}</em>}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
