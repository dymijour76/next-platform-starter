import type { ImageInfo } from "@/lib/types";

/** <img> con srcset: el navegador elige el ancho justo para la pantalla. */
export function ResponsiveImage({ image, sizes, className = "", priority = false }: {
  image: ImageInfo;
  sizes: string;
  className?: string;
  priority?: boolean;
}) {
  return (
    // eslint-disable-next-line @next/next/no-img-element -- los tamaños ya vienen generados por la API
    <img
      src={image.src}
      srcSet={image.srcset}
      sizes={sizes}
      alt={image.alt}
      width={image.width}
      height={image.height}
      loading={priority ? "eager" : "lazy"}
      fetchPriority={priority ? "high" : undefined}
      decoding="async"
      className={className}
    />
  );
}
