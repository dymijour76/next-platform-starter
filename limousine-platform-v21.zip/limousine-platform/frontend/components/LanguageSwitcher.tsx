import { getLocale, getTranslations } from "next-intl/server";
import { setLocaleAction } from "@/app/locale-actions";
import { HTML_LANG, LOCALE_NAMES, LOCALES, type Locale } from "@/i18n/config";

/**
 * Selector de idioma: un menú con un botón por idioma (no una lista que cambia al
 * seleccionar: traducir toda la página es un cambio de contexto, WCAG 3.2.2).
 * Cada idioma aparece escrito en su propia lengua y con su atributo lang.
 */
export async function LanguageSwitcher({ dark = false }: { dark?: boolean }) {
  const [locale, t] = [(await getLocale()) as Locale, await getTranslations("common")];
  return (
    // key: al cambiar de idioma el menú se vuelve a crear, así queda cerrado.
    <details key={locale} className="relative">
      <summary
        className={`flex cursor-pointer list-none items-center gap-1.5 text-sm ${dark ? "text-pearl/80 hover:text-pearl" : "text-slate hover:text-ink"}`}
        aria-label={`${t("language")}: ${LOCALE_NAMES[locale]}`}
      >
        <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <circle cx="12" cy="12" r="9" />
          <path d="M3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18" />
        </svg>
        {/* En pantallas pequeñas, sólo el código ("HT"); el nombre completo va en aria-label. */}
        <span lang={HTML_LANG[locale]} className="hidden sm:inline">{LOCALE_NAMES[locale]}</span>
        <span aria-hidden="true" className="text-xs font-medium tracking-wide sm:hidden">{locale.toUpperCase()}</span>
      </summary>
      <form action={setLocaleAction} className="absolute right-0 z-20 mt-2 w-48 border border-ink/10 bg-paper py-1 text-ink shadow-lg">
        {LOCALES.map((l) => (
          <button
            key={l}
            type="submit"
            name="locale"
            value={l}
            lang={HTML_LANG[l]}
            aria-current={l === locale ? "true" : undefined}
            className={`block w-full px-4 py-2 text-left text-sm hover:bg-pearl ${l === locale ? "font-medium" : ""}`}
          >
            {LOCALE_NAMES[l]}
          </button>
        ))}
      </form>
    </details>
  );
}
