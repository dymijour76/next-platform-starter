import { getTranslations } from "next-intl/server";
import { setCurrencyAction } from "@/app/currency-actions";
import { DISPLAY_CURRENCIES } from "@/lib/currency";
import { getDisplayCurrency, getRates } from "@/lib/currency-server";

/**
 * Selector de moneda: un menú con un botón por moneda, como el de idioma. Los precios siguen
 * en pesos; la moneda elegida agrega un valor aproximado al lado.
 */
export async function CurrencySwitcher({ dark = false }: { dark?: boolean }) {
  const [current, rates, t] = await Promise.all([getDisplayCurrency(), getRates(), getTranslations("currency")]);
  const available = DISPLAY_CURRENCIES.filter((c) => c === "CLP" || rates?.currencies.some((r) => r.code === c && r.rate));
  if (available.length < 2) return null; // sin tasas, no hay a qué cambiar
  return (
    <details key={current} className="relative">
      <summary
        className={`flex cursor-pointer list-none items-center gap-1 text-sm ${dark ? "text-pearl/80 hover:text-pearl" : "text-slate hover:text-ink"}`}
        aria-label={`${t("label")}: ${t(current)}`}
      >
        <span className="font-medium tracking-wide">{current}</span>
        <svg viewBox="0 0 24 24" className="size-3.5" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true">
          <path d="m6 9 6 6 6-6" />
        </svg>
      </summary>
      <div className="absolute right-0 z-30 mt-2 w-64 rounded-sm border border-ink/10 bg-paper p-2 text-sm text-ink shadow-lg">
        <form action={setCurrencyAction}>
          <ul>
            {available.map((c) => (
              <li key={c}>
                <button name="currency" value={c} aria-current={c === current ? "true" : undefined}
                  className={`flex w-full items-center justify-between rounded-sm px-3 py-2 text-left hover:bg-pearl ${c === current ? "font-medium" : ""}`}>
                  <span>{t(c)}</span>
                  <span className="text-xs text-slate">{c}</span>
                </button>
              </li>
            ))}
          </ul>
        </form>
        <p className="mt-2 border-t border-ink/10 px-3 pt-2 text-xs text-slate">{t("charged")}</p>
        {rates ? (
          <p className="px-3 pb-1 pt-1 text-xs text-slate">
            <a href={rates.attribution.url} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2">
              {t("rates", { source: rates.attribution.name })}
            </a>
          </p>
        ) : null}
      </div>
    </details>
  );
}
