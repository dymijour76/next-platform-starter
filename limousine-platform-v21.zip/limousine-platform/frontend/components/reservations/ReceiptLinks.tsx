import { getTranslations } from "next-intl/server";

/** Descargar el comprobante en PDF o abrirlo en el navegador para imprimirlo. */
export async function ReceiptLinks({ href }: { href: string }) {
  const [t, footer] = await Promise.all([getTranslations("receipt"), getTranslations("footer")]);
  const button = "inline-flex items-center gap-2 rounded-sm border border-ink/25 px-4 py-2 text-sm text-ink hover:border-ink/50";
  return (
    <div className="flex flex-wrap gap-3">
      <a href={`${href}?download=1`} className={button}>
        <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
          <path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14" />
        </svg>
        {t("download")}
      </a>
      <a href={href} target="_blank" rel="noopener" className={button}>
        <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
          <path d="M7 9V4h10v5M7 17H5a1 1 0 0 1-1-1v-5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a1 1 0 0 1-1 1h-2M7 14h10v6H7z" />
        </svg>
        {t("print")}<span className="sr-only"> {footer("newTab")}</span>
      </a>
    </div>
  );
}
