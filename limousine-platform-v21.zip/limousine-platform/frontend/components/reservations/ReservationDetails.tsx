import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import type { Reservation } from "@/lib/types";

/** Formato de la hora de recogida ("miércoles, 7 de octubre de 2026, 12:00"), para fmt.wall(). */
export const PICKUP_FORMAT: Intl.DateTimeFormatOptions = {
  weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
};

/** Datos del viaje y desglose del precio guardado al reservar. */
export async function ReservationDetails({ r }: { r: Reservation }) {
  const [t, q, s, fmt] = await Promise.all([
    getTranslations("details"), getTranslations("quote"), getTranslations("service"), getFormat(),
  ]);
  const rows: [string, string][] = [
    [q("pickup"), fmt.wall(r.pickup_local, PICKUP_FORMAT)],
    [t("address"), r.pickup_address],
    [t("destination"), r.dropoff_address ?? t("byTheHour")],
    [q("duration"), fmt.duration(r.duration_minutes)],
    [s("passengers"), String(r.passenger_count)],
    [t("contact"), `${r.contact_name}, ${r.contact_phone}, ${r.contact_email}`],
  ];
  if (r.notes) rows.push([t("notes"), r.notes]);
  const hours = Number(r.pricing.billed_hours);
  // Línea de horas armada aquí: número y monto con el formato del idioma.
  const label = (line: Reservation["pricing"]["lines"][number]) =>
    line.code === "HOURS" && hours
      ? q("hoursLine", { hours: fmt.hours(hours), rate: fmt.money(Number(line.amount) / hours, r.currency) })
      : line.label;

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
      <dl className="divide-y divide-ink/10 border-y border-ink/10">
        {rows.map(([term, value]) => (
          <div key={term} className="grid gap-1 py-3 sm:grid-cols-[8rem_minmax(0,1fr)]">
            <dt className="text-sm text-slate">{term}</dt>
            <dd className="break-words text-ink first-letter:uppercase">{value}</dd>
          </div>
        ))}
      </dl>
      <div className="border border-ink/10 bg-paper">
        <table className="w-full text-sm">
          <caption className="sr-only">{q("breakdown")}</caption>
          <tbody>
            {r.pricing.lines.map((line, i) => (
              <tr key={i} className="border-b border-ink/5">
                <th scope="row" className="px-5 py-2.5 text-left font-normal text-slate">{label(line)}</th>
                <td className="px-5 py-2.5 text-right tabular-nums">{fmt.money(line.amount, r.currency)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th scope="row" className="px-5 pt-4 pb-1 text-left font-display text-lg font-normal">{q("total")}</th>
              <td className="px-5 pt-4 pb-1 text-right font-display text-2xl tabular-nums">
                {fmt.money(r.total_amount, r.currency)}
                {fmt.ref(r.total_amount) ? <span className="block font-sans text-xs font-medium text-navy">{fmt.ref(r.total_amount)}</span> : null}
              </td>
            </tr>
            <tr>
              <td colSpan={2} className="px-5 pb-4 text-right text-xs text-slate">
                {r.pricing.prices_include_tax
                  ? q("taxIncluded", { tax: r.pricing.tax_name, net: fmt.money(r.pricing.net, r.currency), amount: fmt.money(r.pricing.tax, r.currency) })
                  : null}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
