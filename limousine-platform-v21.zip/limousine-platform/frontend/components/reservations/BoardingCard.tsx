import { getTranslations } from "next-intl/server";
import QRCode from "qrcode";
import type { Reservation } from "@/lib/types";

const WITH_MESSAGE = ["CONFIRMED", "EN_ROUTE", "ARRIVED", "IN_PROGRESS"] as const;

/** Chófer, vehículo y QR de abordaje. El QR se genera en el servidor: no requiere JavaScript. */
export async function BoardingCard({ r }: { r: Reservation }) {
  const t = await getTranslations("boarding");
  const qr = r.qr_token && r.status !== "IN_PROGRESS"
    ? await QRCode.toString(r.qr_token, { type: "svg", margin: 1, errorCorrectionLevel: "M", color: { dark: "#1b2433", light: "#ffffff" } })
    : null;
  if (!r.driver_name && !r.vehicle_label && !qr) return null;
  const status = WITH_MESSAGE.find((s) => s === r.status);
  return (
    <section aria-labelledby="boarding-title" className="grid gap-6 border border-ink/10 bg-paper p-6 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
      <div>
        <h2 id="boarding-title" className="font-display text-xl text-ink">{t("title")}</h2>
        <dl className="mt-4 space-y-3 text-sm">
          <div><dt className="text-slate">{t("driver")}</dt><dd className="text-ink">{r.driver_name ?? t("driverPending")}</dd></div>
          <div><dt className="text-slate">{t("vehicle")}</dt><dd className="text-ink first-letter:uppercase">{r.vehicle_label ?? t("vehiclePending")}</dd></div>
        </dl>
        {status ? <p className="mt-4 text-sm text-ink">{t(status)}</p> : null}
        {r.driver_code ? (
          <div className="mt-5 border-l-2 border-champagne bg-pearl/60 px-4 py-3">
            <p className="text-sm font-medium text-ink">{t("verifyTitle")}</p>
            <p className="my-1 font-mono text-3xl tracking-[0.3em] text-ink" aria-label={r.driver_code.split("").join(" ")}>{r.driver_code}</p>
            <p className="text-xs text-slate">{t("verifyText")}</p>
          </div>
        ) : null}
      </div>
      {qr ? (
        <figure className="mx-auto w-44">
          <div className="border border-ink/10 p-2" role="img" aria-label={t("qrLabel", { code: r.code })}
            dangerouslySetInnerHTML={{ __html: qr }} />
          <figcaption className="mt-2 text-center text-xs text-slate">{t("booking", { code: r.code })}</figcaption>
        </figure>
      ) : null}
    </section>
  );
}
