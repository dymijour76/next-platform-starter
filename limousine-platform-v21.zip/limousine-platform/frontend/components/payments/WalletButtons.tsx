"use client";

import { useTranslations } from "next-intl";
import { useActionState } from "react";
import { payWithWalletAction, topupAction, type PayState } from "@/app/payments/actions";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { GatewayRedirect } from "./GatewayRedirect";

/** "Pagar con mi saldo": sólo se muestra si el saldo alcanza para el total. */
export function PayWithWalletButton({ code, available }: { code: string; available: string }) {
  const t = useTranslations("wallet");
  const [state, action] = useActionState<PayState, FormData>(payWithWalletAction, { status: "idle" });
  return (
    <form action={action} className="space-y-2">
      {state.status === "error" ? <FormAlert state={{ status: "error", message: state.message }} /> : null}
      <input type="hidden" name="code" value={code} />
      <SubmitButton variant="secondary" pendingLabel={t("paying")}>{t("payWith")}</SubmitButton>
      <p className="text-xs text-slate">{t("available", { amount: available })}</p>
    </form>
  );
}

/** Recarga con tarjeta: lleva a la pasarela igual que el pago de una reserva. */
export function TopupForm({ range }: { range: string }) {
  const t = useTranslations("wallet");
  const [state, action] = useActionState<PayState, FormData>(topupAction, { status: "idle" });
  if (state.status === "redirect" && state.redirect) return <GatewayRedirect redirect={state.redirect} />;
  return (
    <form action={action} noValidate className="space-y-4">
      {state.status === "error" ? <FormAlert state={{ status: "error", message: state.message }} /> : null}
      <Field label={t("topupAmount")} name="amount" inputMode="numeric" required hint={range} />
      <SubmitButton pendingLabel={t("topupPending")}>{t("topupButton")}</SubmitButton>
    </form>
  );
}
