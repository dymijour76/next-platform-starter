"use client";

import { useTranslations } from "next-intl";
import { useState } from "react";

/** Copia el número de la billetera y lo confirma (también al lector de pantalla). */
export function CopyNumber({ number }: { number: string }) {
  const t = useTranslations("wallet");
  const [copied, setCopied] = useState(false);
  async function copy() {
    try {
      await navigator.clipboard.writeText(number);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Sin permiso para el portapapeles: el número igual se puede seleccionar en la tarjeta.
    }
  }
  return (
    <div className="flex items-center gap-3">
      <button type="button" onClick={copy}
        className="rounded-sm border border-ink/25 px-3 py-1.5 text-sm text-ink hover:border-ink/50">
        {t("copy")}
      </button>
      <span aria-live="polite" className="text-sm text-ok">{copied ? t("copied") : ""}</span>
    </div>
  );
}
