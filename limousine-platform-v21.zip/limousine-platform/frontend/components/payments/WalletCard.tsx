import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import { CopyNumber } from "./CopyNumber";

/**
 * La billetera con aspecto de tarjeta: diseño propio de la marca (sin logos de redes de pago),
 * con texto real (no una imagen) para que los lectores de pantalla la lean completa.
 */
export async function WalletCard({ company, number, holder, balance, currency }: {
  company: string; number: string; holder: string; balance: string; currency: string;
}) {
  const [t, fmt] = await Promise.all([getTranslations("wallet"), getFormat()]);
  return (
    <div className="space-y-3">
      <section aria-label={t("cardLabel")}
        className="relative aspect-[1.586/1] w-full max-w-sm overflow-hidden rounded-xl bg-gradient-to-br from-ink via-ink-soft to-ink p-6 text-pearl shadow-lg">
        {/* Decoración: trazos de la marca (no representan ninguna red de pago). */}
        <svg aria-hidden="true" viewBox="0 0 320 200" className="pointer-events-none absolute inset-0 h-full w-full opacity-30">
          <path d="M-20 170 C 80 120, 160 210, 340 110" fill="none" stroke="#b8a374" strokeWidth="1.2" />
          <path d="M-20 190 C 90 140, 170 230, 340 130" fill="none" stroke="#b8a374" strokeWidth="0.8" />
          <circle cx="285" cy="35" r="70" fill="none" stroke="#e9ebee" strokeWidth="0.6" />
        </svg>
        <div className="relative flex h-full flex-col justify-between">
          <div className="flex items-start justify-between gap-4">
            <p className="font-display text-lg leading-tight">{company}</p>
            <p className="text-[11px] uppercase tracking-[0.2em] text-champagne">{t("cardBrand")}</p>
          </div>
          <div>
            <p className="sr-only">{t("number")}:</p>
            <p className="font-mono text-xl tracking-[0.18em] sm:text-2xl">{number}</p>
          </div>
          <div className="flex items-end justify-between gap-4">
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-widest text-pearl/60">{t("holder")}</p>
              <p className="truncate text-sm uppercase tracking-wider">{holder}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] uppercase tracking-widest text-pearl/60">{t("balance")}</p>
              <p className="font-display text-xl">{fmt.money(balance, currency)}</p>
              {fmt.ref(balance) ? <p className="text-[11px] font-medium text-navy-light">{fmt.ref(balance)}</p> : null}
            </div>
          </div>
        </div>
      </section>
      <CopyNumber number={number} />
      <p className="max-w-sm text-xs text-slate">{t("notBankCard", { company })}</p>
    </div>
  );
}
