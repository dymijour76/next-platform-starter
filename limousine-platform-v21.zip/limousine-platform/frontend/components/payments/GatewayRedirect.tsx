"use client";

import { useEffect, useRef } from "react";
import type { PaymentRedirect } from "@/lib/types";
import { useTranslations } from "next-intl";

/**
 * Envía al cliente a la pasarela con un formulario POST (así lo exige Webpay).
 * Se envía solo; el botón queda por si el navegador bloquea el envío automático.
 */
export function GatewayRedirect({ redirect, label }: { redirect: PaymentRedirect; label?: string }) {
  const t = useTranslations("pay");
  const form = useRef<HTMLFormElement>(null);
  useEffect(() => {
    form.current?.submit();
  }, []);
  return (
    <form ref={form} method="POST" action={redirect.url} className="space-y-4" aria-live="polite">
      {Object.entries(redirect.fields).map(([name, value]) => (
        <input key={name} type="hidden" name={name} value={value} />
      ))}
      <p className="text-ink">{t("redirecting")}</p>
      <button type="submit" className="rounded-sm bg-ink px-5 py-2.5 text-sm font-medium text-pearl hover:bg-ink-soft">
        {label ?? t("continue")}
      </button>
    </form>
  );
}
