import { getTranslations } from "next-intl/server";
import { getFormat } from "@/lib/format-server";
import type { PaymentInfo } from "@/lib/types";

/** Pagos y reembolsos de una reserva (comprobante para el cliente). */
export async function PaymentList({ payments, currency, actions }: {
  payments: PaymentInfo[];
  currency: string;
  actions?: (p: PaymentInfo) => React.ReactNode;
}) {
  const [t, labels, fmt] = await Promise.all([getTranslations("payments"), getTranslations("labels"), getFormat()]);
  if (!payments.length) return <p className="text-sm text-slate">{t("none")}</p>;
  const provider = (name: string) => (labels.has(`provider.${name}`) ? labels(`provider.${name}`) : name);
  const type = (code: string) => (labels.has(`paymentType.${code}`) ? labels(`paymentType.${code}`) : code);
  const status = (code: string) => (labels.has(`payment.${code}`) ? labels(`payment.${code}`) : code);
  return (
    <ul className="space-y-4">
      {payments.map((p) => (
        <li key={p.id} className="border border-ink/10 bg-paper px-5 py-4">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <p className="text-ink">
              {p.card_last4 ? t("card", { provider: provider(p.provider), last4: p.card_last4 }) : provider(p.provider)}
              {p.payment_type ? ` (${type(p.payment_type)})` : ""}
            </p>
            <p className="font-display text-lg tabular-nums text-ink">{fmt.money(p.amount, currency)}</p>
          </div>
          <p className="mt-1 text-sm text-slate">
            {status(p.status)}, {fmt.date(p.authorized_at ?? p.created_at)}
            {p.authorization_code ? `, ${t("authorization", { code: p.authorization_code })}` : ""}
          </p>
          {p.refunds.length ? (
            <ul className="mt-3 space-y-1 border-t border-ink/10 pt-3 text-sm">
              {p.refunds.map((f) => (
                <li key={f.id} className={f.status === "FAILED" ? "text-alert" : "text-slate"}>
                  {t("refundLine", { amount: fmt.money(f.amount, currency), status: t(`refund.${f.status}`), date: fmt.date(f.created_at) })}
                  {f.reason ? `. ${f.reason}` : ""}
                  {f.status === "FAILED" && f.error_message ? ` (${f.error_message})` : ""}
                </li>
              ))}
            </ul>
          ) : null}
          {actions ? <div className="mt-4">{actions(p)}</div> : null}
        </li>
      ))}
    </ul>
  );
}
