"use client";

import { useActionState } from "react";
import { payAction, type PayState } from "@/app/payments/actions";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { GatewayRedirect } from "./GatewayRedirect";
import { useTranslations } from "next-intl";

export function PayButton({ code, label }: { code: string; label?: string }) {
  const t = useTranslations("pay");
  const [state, action] = useActionState<PayState, FormData>(payAction, { status: "idle" });
  if (state.status === "redirect" && state.redirect) return <GatewayRedirect redirect={state.redirect} />;
  return (
    <form action={action} className="space-y-3">
      {state.status === "error" ? <FormAlert state={{ status: "error", message: state.message }} /> : null}
      <input type="hidden" name="code" value={code} />
      <SubmitButton pendingLabel={t("connecting")}>{label ?? t("now")}</SubmitButton>
    </form>
  );
}
