"use client";

import { useActionState, useState } from "react";
import { refundPaymentAction, retryRefundAction } from "@/app/admin/payment-actions";
import { Field } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { initialFormState } from "@/lib/form";
import type { PaymentInfo } from "@/lib/types";
import { useTranslations } from "next-intl";
import { useFormat } from "@/lib/format-client";

/** Reembolso manual y reintento de reembolsos fallidos (permiso payments:refund). */
export function RefundControls({ payment, currency }: { payment: PaymentInfo; currency: string }) {
  const t = useTranslations("refund");
  const fmt = useFormat();
  const available = Number(payment.amount) - Number(payment.refunded_amount);
  const failed = payment.refunds.filter((f) => f.status === "FAILED");
  const refundable = ["AUTHORIZED", "PARTIALLY_REFUNDED"].includes(payment.status) && available > 0;
  return (
    <div className="space-y-4">
      {failed.map((f) => <RetryRefund key={f.id} id={f.id} label={t("retry", { amount: fmt.money(f.amount, currency) })} />)}
      {refundable ? <ManualRefund paymentId={payment.id} max={available} currency={currency} /> : null}
    </div>
  );
}

function RetryRefund({ id, label }: { id: string; label: string }) {
  const t = useTranslations("refund");
  const [state, action] = useActionState(retryRefundAction, initialFormState);
  return (
    <form action={action} className="space-y-2">
      <FormAlert state={state} />
      <input type="hidden" name="refund_id" value={id} />
      <SubmitButton variant="secondary" pendingLabel={t("retrying")}>{label}</SubmitButton>
    </form>
  );
}

function ManualRefund({ paymentId, max, currency }: { paymentId: string; max: number; currency: string }) {
  const t = useTranslations("refund");
  const fmt = useFormat();
  const [state, action] = useActionState(refundPaymentAction, initialFormState);
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="text-sm text-ink underline decoration-champagne underline-offset-4">
        {t("manual")}
      </button>
    );
  }
  return (
    <form action={action} className="grid gap-4 sm:grid-cols-[10rem_minmax(0,1fr)] sm:items-start">
      <div className="sm:col-span-2"><FormAlert state={state} /></div>
      <input type="hidden" name="payment_id" value={paymentId} />
      <Field label={t("amount")} name="amount" id={`amount-${paymentId}`} inputMode="numeric" required defaultValue={state.values?.amount ?? String(max)}
        error={state.fields?.amount} hint={t("max", { amount: fmt.money(max, currency) })} />
      <Field label={t("reason")} name="reason" id={`reason-${paymentId}`} required defaultValue={state.values?.reason} error={state.fields?.reason}
        hint={t("reasonHint")} />
      <div className="sm:col-span-2">
        <SubmitButton variant="secondary" pendingLabel={t("processing")}>{t("submit")}</SubmitButton>
      </div>
    </form>
  );
}
