"use client";

import Link from "next/link";
import { useTranslations } from "next-intl";
import { useCallback, useEffect, useState } from "react";
import { ResponsiveImage } from "@/components/ResponsiveImage";
import type { Slide } from "@/lib/types";

const INTERVAL_MS = 7000;

/**
 * Carrusel de portada accesible:
 * - botón de pausa (el contenido que avanza solo debe poder detenerse, WCAG 2.2.2);
 * - se detiene al pasar el mouse o al navegar con el teclado por dentro;
 * - no avanza solo si la persona pidió reducir el movimiento;
 * - las diapositivas ocultas quedan inertes (ni foco ni lectores de pantalla).
 */
export function HeroCarousel({ slides }: { slides: Slide[] }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const count = slides.length;
  const t = useTranslations("carousel");

  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);

  const go = useCallback((i: number) => setIndex((i + count) % count), [count]);

  const autoplay = count > 1 && !paused && !hovering && !reducedMotion;
  useEffect(() => {
    if (!autoplay) return;
    const timer = window.setTimeout(() => go(index + 1), INTERVAL_MS);
    return () => window.clearTimeout(timer);
  }, [autoplay, index, go]);

  return (
    <section
      aria-roledescription={t("roleCarousel")}
      aria-label={t("label")}
      className="relative isolate h-[min(78vh,46rem)] min-h-[28rem] overflow-hidden bg-ink text-pearl"
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
      onFocus={() => setHovering(true)}
      onBlur={(e) => {
        if (!e.currentTarget.contains(e.relatedTarget)) setHovering(false);
      }}
    >
      <div aria-live={autoplay ? "off" : "polite"}>
        {slides.map((s, i) => {
          const active = i === index;
          return (
            <div
              key={s.id}
              role="group"
              aria-roledescription={t("roleSlide")}
              aria-label={t("slide", { n: i + 1, total: count, title: s.title })}
              aria-hidden={!active}
              inert={!active}
              className={`absolute inset-0 transition-opacity duration-700 motion-reduce:transition-none ${active ? "opacity-100" : "opacity-0"}`}
            >
              <ResponsiveImage image={s.image} sizes="100vw" priority={i === 0} className="h-full w-full object-cover" />
              {/* Degradado para que el texto se lea sobre cualquier foto */}
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-ink/10" aria-hidden="true" />
              <div className="absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-6 pb-24 sm:px-10">
                <h2 className="max-w-3xl font-display text-4xl leading-[1.05] sm:text-6xl">{s.title}</h2>
                {s.subtitle ? <p className="mt-4 max-w-xl text-lg text-pearl/85">{s.subtitle}</p> : null}
                {s.cta_label && s.cta_url ? (
                  <Link href={s.cta_url} className="mt-8 inline-block rounded-sm bg-champagne px-6 py-3 text-sm font-medium text-ink hover:bg-pearl">
                    {s.cta_label}
                  </Link>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {count > 1 ? (
        <div className="absolute inset-x-0 bottom-6 mx-auto flex max-w-6xl items-center gap-4 px-6 sm:px-10">
          <button type="button" onClick={() => setPaused((p) => !p)} aria-pressed={paused}
            className="rounded-sm border border-pearl/40 px-3 py-1.5 text-xs hover:border-pearl">
            {paused ? t("resume") : t("pause")}
          </button>
          <button type="button" onClick={() => go(index - 1)} aria-label={t("previous")}
            className="rounded-sm border border-pearl/40 px-3 py-1.5 text-xs hover:border-pearl">←</button>
          <button type="button" onClick={() => go(index + 1)} aria-label={t("next")}
            className="rounded-sm border border-pearl/40 px-3 py-1.5 text-xs hover:border-pearl">→</button>
          <div className="flex gap-2">
            {slides.map((s, i) => (
              <button key={s.id} type="button" onClick={() => go(i)}
                aria-label={t("goTo", { n: i + 1, title: s.title })} aria-current={i === index ? "true" : undefined}
                className={`h-1 w-8 rounded-full transition-colors ${i === index ? "bg-champagne" : "bg-pearl/35 hover:bg-pearl/60"}`} />
            ))}
          </div>
        </div>
      ) : null}
    </section>
  );
}
