"use client";

import { createContext, useContext } from "react";
import type { RefRate } from "@/lib/currency";

const Ctx = createContext<RefRate>(null);

/** Lleva a los componentes del navegador la moneda de referencia elegida y su tasa. */
export function CurrencyProvider({ value, children }: { value: RefRate; children: React.ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useRefRate(): RefRate {
  return useContext(Ctx);
}
