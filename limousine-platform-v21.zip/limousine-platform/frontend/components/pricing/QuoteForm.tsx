"use client";

import { useTranslations } from "next-intl";
import { useActionState } from "react";
import { useFormat } from "@/lib/format-client";
import { Field, Select } from "@/components/forms/Field";
import { FormAlert } from "@/components/forms/FormAlert";
import { SubmitButton } from "@/components/forms/SubmitButton";
import { quoteAction, type QuoteState } from "@/app/services/actions";
import { QuoteBreakdown } from "./QuoteBreakdown";

interface Props {
  serviceId?: string;
  services?: { id: string; name: string }[];
  durations: number[];
  minDate: string;
  mode?: "quote" | "simulate";
  note?: React.ReactNode;
}

export function QuoteForm({ serviceId, services, durations, minDate, mode = "quote", note }: Props) {
  const [state, action] = useActionState<QuoteState, FormData>(quoteAction, { status: "idle" });
  const t = useTranslations("quote");
  const fmt = useFormat();
  const v = state.values ?? {};
  const f = state.fields ?? {};
  const defaultDuration = v.duration || String(durations[0] ?? 120);

  return (
    <div className="space-y-6">
      <form action={action} className="space-y-5" noValidate key={JSON.stringify(v)}>
        {state.status === "error" && !Object.values(f).some(Boolean) ? <FormAlert state={state} /> : null}
        <input type="hidden" name="mode" value={mode} />
        {serviceId ? <input type="hidden" name="service_id" value={serviceId} /> : null}
        {services ? (
          <Select label={t("service")} name="service_id" defaultValue={services[0]?.id}>
            {services.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </Select>
        ) : null}
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label={t("date")} name="date" type="date" required min={mode === "quote" ? minDate : undefined}
            defaultValue={v.date} error={f.date || undefined} />
          <Field label={t("time")} name="time" type="time" required step={300}
            defaultValue={v.time} error={f.time || undefined} />
        </div>
        <Select label={t("duration")} name="duration" defaultValue={defaultDuration} error={f.duration_minutes}>
          {durations.map((m) => (
            <option key={m} value={m}>{fmt.duration(m)}</option>
          ))}
        </Select>
        <SubmitButton pendingLabel={t("calculating")} variant={mode === "quote" ? "primary" : "secondary"}>
          {mode === "quote" ? t("calculate") : t("simulate")}
        </SubmitButton>
      </form>
      {state.status === "success" && state.quote ? (
        <>
          <QuoteBreakdown quote={state.quote} />
          {note}
        </>
      ) : null}
    </div>
  );
}
