"use client";

import { useTranslations } from "next-intl";
import { useFormat } from "@/lib/format-client";
import type { Quote } from "@/lib/types";

const DATE_OPTIONS: Intl.DateTimeFormatOptions = {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
};

/** Desglose del precio tal como lo calculó la API. */
export function QuoteBreakdown({ quote }: { quote: Quote }) {
  const t = useTranslations("quote");
  const fmt = useFormat();
  // Línea de horas armada aquí: número y monto con el formato del idioma.
  const label = (line: Quote["lines"][number]) =>
    line.code === "HOURS" && Number(quote.billed_hours)
      ? t("hoursLine", {
          hours: fmt.hours(quote.billed_hours),
          rate: fmt.money(Number(line.amount) / Number(quote.billed_hours), quote.currency),
        })
      : line.label;
  const cur = quote.currency;
  return (
    <div className="border border-ink/10 bg-paper" aria-live="polite">
      <div className="border-b border-ink/10 px-5 py-4">
        <p className="text-sm text-slate">{t("pickup")}</p>
        <p className="text-ink first-letter:uppercase">{fmt.wall(quote.pickup_local, DATE_OPTIONS)}</p>
      </div>
      <table className="w-full text-sm">
        <caption className="sr-only">{t("breakdown")}</caption>
        <tbody>
          {quote.lines.map((line, i) => (
            <tr key={i} className="border-b border-ink/5">
              <th scope="row" className="px-5 py-2.5 text-left font-normal text-slate">
                {label(line)}
              </th>
              <td className={`px-5 py-2.5 text-right tabular-nums ${Number(line.amount) < 0 ? "text-ok" : "text-ink"}`}>
                {fmt.money(line.amount, cur)}
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <th scope="row" className="px-5 pt-4 pb-1 text-left font-display text-lg font-normal text-ink">
              {t("total")}
            </th>
            <td className="px-5 pt-4 pb-1 text-right font-display text-2xl text-ink tabular-nums">
              {fmt.money(quote.total, cur)}
              {fmt.ref(quote.total) ? <span className="block font-sans text-xs font-medium text-navy">{fmt.ref(quote.total)}</span> : null}
            </td>
          </tr>
          <tr>
            <td colSpan={2} className="px-5 pb-4 text-right text-xs text-slate">
              {quote.prices_include_tax
                ? t("taxIncluded", { tax: quote.tax_name, net: fmt.money(quote.net, cur), amount: fmt.money(quote.tax, cur) })
                : t("taxInLines", { tax: quote.tax_name })}
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
