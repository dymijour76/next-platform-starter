import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { api } from "@/lib/api-server";
import { config } from "@/lib/config";

interface SitePublic {
  name: string;
  address: string | null;
  phone: string | null;
  email: string | null;
  whatsapp_url: string | null;
  about: string | null;
  hours: string | null;
  social: Record<string, string>;
}

// Nombres de las redes: son marcas, no se traducen. Se muestran como texto (no logotipos).
const NETWORK: Record<string, string> = {
  instagram: "Instagram", facebook: "Facebook", tiktok: "TikTok", youtube: "YouTube", x: "X", threads: "Threads",
  linkedin: "LinkedIn", pinterest: "Pinterest", snapchat: "Snapchat", telegram: "Telegram", tripadvisor: "Tripadvisor",
  google: "Google",
};

/** Pie de página del sitio: datos de la empresa, contacto, enlaces y redes (editable en el panel). */
export async function SiteFooter() {
  const [res, t, nav, legal] = await Promise.all([
    api<SitePublic>("/site", { auth: false }),
    getTranslations("footer"),
    getTranslations("nav"),
    getTranslations("legal"),
  ]);
  const site = res.ok ? res.data : null;
  const name = site?.name ?? config.companyName;
  const social = Object.entries(site?.social ?? {});
  const link = "underline-offset-4 hover:text-pearl hover:underline";
  const heading = "mb-3 text-xs font-medium uppercase tracking-widest text-champagne";

  return (
    <footer className="bg-ink text-sm text-pearl/70">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-12 sm:grid-cols-2 sm:px-10 lg:grid-cols-4">
        <div>
          <p className="font-display text-lg text-pearl">{name}</p>
          {site?.about ? <p className="mt-3 leading-relaxed">{site.about}</p> : null}
          {site?.hours ? <p className="mt-3">{site.hours}</p> : null}
        </div>

        <nav aria-label={t("explore")}>
          <h2 className={heading}>{t("explore")}</h2>
          <ul className="space-y-2">
            <li><Link href="/services" className={link}>{nav("services")}</Link></li>
            <li><Link href="/book" className={link}>{nav("book")}</Link></li>
            <li><Link href="/account" className={link}>{t("myAccount")}</Link></li>
            <li><Link href="/terms" className={link}>{legal("termsTitle")}</Link></li>
            <li><Link href="/privacy" className={link}>{legal("privacyTitle")}</Link></li>
          </ul>
        </nav>

        {site && (site.address || site.phone || site.email || site.whatsapp_url) ? (
          <div>
            <h2 className={heading}>{t("contact")}</h2>
            <address className="space-y-2 not-italic">
              {site.address ? <p>{site.address}</p> : null}
              {site.phone ? <p><a href={`tel:${site.phone}`} className={link}>{site.phone}</a></p> : null}
              {site.email ? <p><a href={`mailto:${site.email}`} className={link}>{site.email}</a></p> : null}
              {site.whatsapp_url ? (
                <p>
                  <a href={site.whatsapp_url} target="_blank" rel="noopener noreferrer" className={link}>
                    {t("whatsapp")}<span className="sr-only"> {t("newTab")}</span>
                  </a>
                </p>
              ) : null}
            </address>
          </div>
        ) : null}

        {social.length ? (
          <div>
            <h2 className={heading}>{t("follow")}</h2>
            <ul className="flex flex-wrap gap-2">
              {social.map(([network, url]) => (
                <li key={network}>
                  <a href={url} target="_blank" rel="noopener noreferrer"
                    className="inline-block rounded-sm border border-pearl/25 px-3 py-1.5 text-pearl/90 hover:border-champagne hover:text-pearl">
                    {NETWORK[network] ?? network}<span className="sr-only"> {t("newTab")}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
      <div className="border-t border-pearl/10">
        <div className="mx-auto flex max-w-6xl flex-wrap justify-between gap-3 px-6 py-5 text-xs text-pearl/50 sm:px-10">
          <p>{t("rights", { year: new Date().getFullYear(), name })}</p>
          <Link href="/estado" className={link}>{t("status")}</Link>
        </div>
      </div>
    </footer>
  );
}
