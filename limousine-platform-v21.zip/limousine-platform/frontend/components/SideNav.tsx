"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export interface NavItem {
  href: string;
  label: string;
}

/** Navegación lateral (horizontal y desplazable en móvil). */
export function SideNav({ items, label }: { items: NavItem[]; label: string }) {
  const pathname = usePathname();
  const isActive = (href: string) =>
    pathname === href || (href !== items[0]?.href && pathname.startsWith(`${href}/`));

  return (
    <nav aria-label={label} className="-mx-6 overflow-x-auto px-6 lg:mx-0 lg:px-0">
      <ul className="flex gap-1 lg:flex-col">
        {items.map((item) => {
          const active = isActive(item.href);
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`block whitespace-nowrap border-b-2 px-3 py-2 text-sm lg:border-b-0 lg:border-l-2 ${
                  active
                    ? "border-champagne font-medium text-ink"
                    : "border-transparent text-slate hover:text-ink"
                }`}
              >
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
