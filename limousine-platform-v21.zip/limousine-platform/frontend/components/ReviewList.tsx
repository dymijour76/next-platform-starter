import { getTranslations } from "next-intl/server";
import { HTML_LANG, isLocale } from "@/i18n/config";
import { api } from "@/lib/api-server";
import { getFormat } from "@/lib/format-server";
import { Stars } from "./Stars";

interface PublicReview {
  display_name: string;
  service_rating: number;
  comment: string;
  service_name: string;
  created_at: string;
  locale: string | null;
}

/** Testimonios de clientes reales (reseñas publicadas). No se muestra nada si no hay. */
export async function ReviewList({ service, title, limit = 6 }: { service?: string; title: string; limit?: number }) {
  const query = new URLSearchParams({ limit: String(limit), ...(service ? { service } : {}) });
  const res = await api<PublicReview[]>(`/reviews?${query}`, { auth: false });
  if (!res.ok || !res.data.length) return null;
  const [t, fmt] = await Promise.all([getTranslations("reviews"), getFormat()]);
  return (
    <section aria-labelledby="reviews-title" className="mx-auto max-w-6xl px-6 py-16 sm:px-10">
      <h2 id="reviews-title" className="font-display text-3xl text-ink">{title}</h2>
      <ul className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {res.data.map((r, i) => (
          <li key={i} className="flex flex-col border border-ink/10 bg-paper p-6">
            <Stars rating={r.service_rating} />
            {/* El comentario va en el idioma en que se escribió. */}
            <blockquote lang={r.locale && isLocale(r.locale) ? HTML_LANG[r.locale] : undefined} className="mt-4 flex-1 leading-relaxed text-ink">
              {r.comment}
            </blockquote>
            <p className="mt-5 text-sm text-ink">{r.display_name}</p>
            <p className="text-xs text-slate">
              {t("verified")} · {r.service_name} · {fmt.dateTime(r.created_at, { month: "long", year: "numeric" })}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}
