/**
 * Genera messages/<idioma>.json desde messages/source.mjs y verifica las traducciones.
 *   node scripts/build-messages.mjs          genera
 *   node scripts/build-messages.mjs --check  sólo verifica (falla si hay diferencias o errores)
 */
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const LANGS = ["es", "en", "fr", "ht", "zh"];
const root = join(dirname(fileURLToPath(import.meta.url)), "..", "messages");
const source = (await import(join(root, "source.mjs"))).default;

// Argumentos de primer nivel: {nombre} o {nombre, plural, ...} (no las ramas "{# horas}").
const args = (text) => [...text.matchAll(/\{(\w+)[,}]/g)].map((m) => m[1]).sort().join(",");

const problems = [];
const trees = Object.fromEntries(LANGS.map((l) => [l, {}]));
for (const [key, values] of Object.entries(source)) {
  if (!Array.isArray(values) || values.length !== LANGS.length) {
    problems.push(`${key}: se esperaban ${LANGS.length} textos`);
    continue;
  }
  const expected = args(values[0]);
  values.forEach((text, i) => {
    if (typeof text !== "string" || !text.trim()) problems.push(`${key} [${LANGS[i]}]: vacío`);
    else if (args(text) !== expected) problems.push(`${key} [${LANGS[i]}]: marcadores {${args(text)}} ≠ {${expected}}`);
    const parts = key.split(".");
    let node = trees[LANGS[i]];
    for (const p of parts.slice(0, -1)) node = node[p] ??= {};
    node[parts.at(-1)] = text;
  });
}
if (problems.length) {
  console.error(problems.join("\n"));
  process.exit(1);
}

const check = process.argv.includes("--check");
let stale = false;
for (const lang of LANGS) {
  const path = join(root, `${lang}.json`);
  const content = JSON.stringify(trees[lang], null, 2) + "\n";
  if (check) {
    let current = "";
    try { current = readFileSync(path, "utf8"); } catch {}
    if (current !== content) { console.error(`${lang}.json no está al día: ejecute npm run messages`); stale = true; }
  } else writeFileSync(path, content);
}
if (stale) process.exit(1);
console.log(`${Object.keys(source).length} textos × ${LANGS.length} idiomas${check ? " (verificados)" : ""}`);
