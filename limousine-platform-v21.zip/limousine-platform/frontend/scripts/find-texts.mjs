/**
 * Lista los textos visibles que siguen escritos en el código (sin pasar por las traducciones).
 *   node scripts/find-texts.mjs app/admin          → archivo:línea  tipo  texto
 *   node scripts/find-texts.mjs app --count        → cantidad por archivo
 * Usa el analizador de TypeScript: encuentra también textos repartidos en varias líneas.
 */
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import ts from "typescript";

const ATTRS = new Set(["label", "title", "description", "hint", "placeholder", "aria-label", "pendingLabel", "alt", "message", "confirm", "empty", "caption", "help", "pending"]);
const letters = /[A-Za-zÁÉÍÓÚáéíóúÑñ]{3,}/;
// Marcas (redes sociales): se muestran tal cual en todos los idiomas.
const BRANDS = new Set(["Instagram", "Facebook", "TikTok", "LinkedIn", "YouTube", "WhatsApp", "Webpay", "Threads",
  "Pinterest", "Snapchat", "Telegram", "Tripadvisor", "Google"]);
const looksLikeCode = (s) => /^[a-z0-9_.:/#?=&\-[\]%@{}]*$/.test(s) || /^(text|bg|border|flex|grid|px|py|mt|mb|w-|h-|rounded)/.test(s) || /^[A-Z_]+$/.test(s);

function walk(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const path = join(dir, name);
    if (statSync(path).isDirectory()) walk(path, out);
    else if (/\.(tsx?|mts)$/.test(name)) out.push(path);
  }
  return out;
}

function scan(file) {
  const src = readFileSync(file, "utf8");
  const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const found = [];
  const add = (node, kind, text) => {
    const t = text.replace(/\s+/g, " ").trim();
    // El texto entre etiquetas JSX siempre lo ve el usuario: ahí una palabra suelta en minúscula
    // ("permiso", "usuario") no es código, así que no se descarta.
    if (!t || !letters.test(t) || (kind !== "jsx" && looksLikeCode(t)) || BRANDS.has(t)) return;
    found.push({ line: sf.getLineAndCharacterOfPosition(node.getStart()).line + 1, kind, text: t });
  };
  const visit = (node) => {
    if (ts.isJsxText(node)) add(node, "jsx", node.getText());
    else if (ts.isJsxAttribute(node) && node.initializer && ATTRS.has(node.name.getText())) {
      const init = node.initializer;
      if (ts.isStringLiteral(init)) add(init, `@${node.name.getText()}`, init.text);
    } else if ((ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) && !ts.isImportDeclaration(node.parent)
      && !ts.isJsxAttribute(node.parent) && !ts.isExternalModuleReference(node.parent)) {
      // Textos en código: sólo frases (con espacio y mayúscula inicial o signos de español).
      const t = node.text;
      if (/\s/.test(t.trim()) && /^[¿¡A-ZÁÉÍÓÚ]/.test(t.trim()) && !/^(use |GET|POST)/.test(t)) add(node, "str", t);
      else if (/^[A-ZÁÉÍÓÚ][a-záéíóúñ]{2,}$/.test(t) && ts.isPropertyAssignment(node.parent)) add(node, "str", t);
    } else if (ts.isTemplateExpression(node)) {
      const text = node.head.text + node.templateSpans.map((s) => "{…}" + s.literal.text).join("");
      const isClasses = /(^|\s)(text|bg|border|px|py|flex|grid|rounded|inline|block|absolute|w|h)-?[\w/.]*(\s|$)/.test(text);
      // También palabras pegadas a una parte variable: "{…} viaje{…} próximo{…}".
      const words = text.replace(/\{…\}/g, " ");
      // Rutas, parámetros y cabeceras no son textos para personas.
      const isPath = /^(\{…\})*\//.test(text) || /^'nonce-|filename=|[?&]\w+=/.test(text);
      if (/[a-záéíóúñ]{3,}/.test(words) && /\s/.test(words.trim()) && !isClasses && !isPath && !/^Bearer /.test(text)) add(node, "tpl", text);
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return found;
}

const [target = "app", flag] = process.argv.slice(2);
const files = statSync(target).isDirectory() ? walk(target) : [target];
let total = 0;
for (const file of files.sort()) {
  const found = scan(file).filter((f) => !/^(Limousine Platform)$/.test(f.text));
  total += found.length;
  if (!found.length) continue;
  if (flag === "--count") console.log(String(found.length).padStart(4), file);
  else for (const f of found) console.log(`${file}:${f.line}\t${f.kind}\t${f.text}`);
}
console.error(`${total} textos`);
