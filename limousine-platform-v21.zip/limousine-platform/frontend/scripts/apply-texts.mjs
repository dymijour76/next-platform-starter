/**
 * Reemplaza textos en español por traducciones, a partir de una tabla.
 *   node scripts/apply-texts.mjs tabla.json
 * tabla.json: { "ns": "adm.pricing", "files": ["app/admin/pricing/page.tsx", ...],
 *               "texts": { "Texto en español": "clave", ... } }
 * - Texto JSX y atributos (label, title, hint…) → {tx("clave")}
 * - Textos en código dentro de un componente → tx("clave")
 * - `export const metadata = { title: "…" }` → generateMetadata()
 * Declara `tx` al inicio de cada función que lo usa: await getTranslations(ns) en las
 * funciones asíncronas del servidor, useTranslations(ns) en las demás. Informa lo que no
 * pudo reemplazar (textos fuera de componentes, textos armados con variables).
 */
import { readFileSync, writeFileSync } from "node:fs";
import ts from "typescript";

const ATTRS = new Set(["label", "title", "description", "hint", "placeholder", "aria-label", "pendingLabel", "alt", "help", "pending", "confirm", "caption", "empty"]);
const spec = JSON.parse(readFileSync(process.argv[2], "utf8"));
const norm = (s) => s.replace(/\s+/g, " ").trim();
const keyOf = (text) => spec.texts[norm(text)];
const call = (key) => `tx(${JSON.stringify(key)})`;
let pending = 0;

for (const file of spec.files) {
  let src = readFileSync(file, "utf8");
  const client = /^["']use client["']/.test(src.trimStart());
  // metadata estático → generateMetadata
  src = src.replace(/export const metadata: Metadata = \{ title: "([^"]+)"(, robots: \{ index: false \})? \};/, (m, title, robots) => {
    const key = keyOf(title);
    if (!key) return m;
    return `export async function generateMetadata(): Promise<Metadata> {\n  const tx = await getTranslations(${JSON.stringify(spec.ns)});\n  return { title: ${call(key)}${robots ?? ""} };\n}`;
  });
  const sf = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const edits = [];
  const users = new Map(); // función → necesita tx
  const leftovers = [];
  const owner = (node) => {
    let fn = null;
    for (let n = node.parent; n; n = n.parent) {
      if (ts.isFunctionDeclaration(n) || ts.isArrowFunction(n) || ts.isFunctionExpression(n)) {
        // la función de nivel superior (componente), no un callback interior
        const top = n.parent && (ts.isSourceFile(n.parent) || (ts.isVariableDeclaration(n.parent) && ts.isSourceFile(n.parent.parent.parent.parent)));
        if (ts.isFunctionDeclaration(n) && ts.isSourceFile(n.parent)) fn = n;
        else if (top) fn = n;
      }
    }
    return fn;
  };
  const replaceAt = (node, start, end, text) => {
    const fn = owner(node);
    if (!fn || !fn.body || !ts.isBlock(fn.body)) return false;
    edits.push({ start, end, text });
    users.set(fn, true);
    return true;
  };
  const visit = (node) => {
    if (ts.isJsxText(node)) {
      const raw = node.getText();
      const key = keyOf(raw);
      if (key) {
        const lead = raw.match(/^\s*/)[0], trail = raw.match(/\s*$/)[0];
        // Conserva un espacio si había texto pegado al lado ("Desde <span>")
        const l = lead.includes("\n") ? lead : lead ? " " : "";
        const r = trail.includes("\n") ? trail : trail ? " " : "";
        if (!replaceAt(node, node.getStart(), node.getEnd(), `${l}{${call(key)}}${r}`)) leftovers.push(norm(raw));
      }
    } else if (ts.isJsxAttribute(node) && node.initializer && ts.isStringLiteral(node.initializer) && ATTRS.has(node.name.getText())) {
      const key = keyOf(node.initializer.text);
      if (key && !replaceAt(node, node.initializer.getStart(), node.initializer.getEnd(), `{${call(key)}}`)) leftovers.push(node.initializer.text);
    } else if ((ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) && !ts.isJsxAttribute(node.parent) && !ts.isImportDeclaration(node.parent)) {
      const key = keyOf(node.text);
      if (key && !replaceAt(node, node.getStart(), node.getEnd(), call(key))) leftovers.push(node.text);
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  // Declaración de tx en cada función que lo usa
  for (const fn of users.keys()) {
    const isAsync = (fn.modifiers ?? []).some((m) => m.kind === ts.SyntaxKind.AsyncKeyword);
    const decl = !client && isAsync
      ? `\n  const tx = await getTranslations(${JSON.stringify(spec.ns)});`
      : `\n  const tx = useTranslations(${JSON.stringify(spec.ns)});`;
    const pos = fn.body.getStart() + 1;
    edits.push({ start: pos, end: pos, text: decl });
  }
  edits.sort((a, b) => b.start - a.start);
  for (const e of edits) src = src.slice(0, e.start) + e.text + src.slice(e.end);
  // Imports
  const need = [];
  if (/await getTranslations\(/.test(src) && !/import \{[^}]*getTranslations[^}]*\} from "next-intl\/server"/.test(src)) need.push('import { getTranslations } from "next-intl/server";');
  if (/useTranslations\(/.test(src) && !/import \{[^}]*useTranslations[^}]*\} from "next-intl"/.test(src)) need.push('import { useTranslations } from "next-intl";');
  if (need.length) {
    const lines = src.split("\n");
    let last = -1;
    lines.forEach((l, i) => { if (/^import /.test(l)) last = i; });
    // importaciones de varias líneas
    while (last >= 0 && last + 1 < lines.length && !/;\s*$/.test(lines[last])) last++;
    lines.splice(last + 1, 0, ...need);
    src = lines.join("\n");
  }
  writeFileSync(file, src);
  const n = edits.length - users.size;
  if (leftovers.length) { pending += leftovers.length; console.log(`${file}: ${n} reemplazos; pendientes a mano: ${leftovers.map((x) => JSON.stringify(x)).join(", ")}`); }
  else console.log(`${file}: ${n} reemplazos`);
}
if (pending) console.log(`${pending} textos para revisar a mano`);
