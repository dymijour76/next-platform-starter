import { NextResponse, type NextRequest } from "next/server";
import { proxyHeaders, visitorIp } from "@/lib/client-ip";
import { buildCsp, newNonce } from "@/lib/csp";

/**
 * Se ejecuta antes de cada página y Server Action.
 *
 * 1. Si el token de acceso está por vencer (o ya venció) y hay refresh token,
 *    obtiene uno nuevo de la API y lo deja disponible para esta misma petición.
 * 2. Redirige al login si se intenta entrar a /account o /admin sin sesión.
 *
 * La autorización real (permisos) se verifica en cada layout, página y Server
 * Action, nunca sólo aquí.
 */

const ACCESS = "lp_at";
const REFRESH = "lp_rt";
const REFRESH_MARGIN_SECONDS = 60;
const PROTECTED = ["/account", "/admin", "/book", "/driver"];
const GUEST_ONLY = ["/login", "/register"];

const apiUrl = () =>
  process.env.API_INTERNAL_URL ?? process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  path: "/",
};

/** Lee la expiración del JWT sin verificarlo (la API es quien lo valida). */
function secondsLeft(token: string | undefined): number {
  if (!token) return -1;
  try {
    const payload = JSON.parse(atob(token.split(".")[1]!.replace(/-/g, "+").replace(/_/g, "/")));
    return typeof payload.exp === "number" ? payload.exp - Date.now() / 1000 : -1;
  } catch {
    return -1;
  }
}

interface Pair {
  access_token: string;
  expires_in: number;
  refresh_token: string;
  refresh_expires_in: number;
}

type RefreshOutcome = { kind: "ok"; pair: Pair } | { kind: "invalid" } | { kind: "unavailable" };

async function refresh(refreshToken: string, request: NextRequest): Promise<RefreshOutcome> {
  try {
    const res = await fetch(`${apiUrl()}/api/v1/auth/refresh`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": request.headers.get("user-agent") ?? "",
        ...proxyHeaders(visitorIp(request.headers)),
      },
      body: JSON.stringify({ refresh_token: refreshToken }),
      cache: "no-store",
      signal: AbortSignal.timeout(5000),
    });
    if (res.ok) return { kind: "ok", pair: (await res.json()) as Pair };
    return res.status === 401 ? { kind: "invalid" } : { kind: "unavailable" };
  } catch {
    return { kind: "unavailable" };
  }
}

export async function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;
  // CSP con un nonce nuevo por petición. Va en la petición (Next.js lo lee al
  // renderizar y lo pone en sus scripts) y en la respuesta (la aplica el navegador).
  const nonce = newNonce();
  const csp = buildCsp(nonce, process.env.NODE_ENV === "development");
  request.headers.set("Content-Security-Policy", csp);
  request.headers.set("x-nonce", nonce);
  const access = request.cookies.get(ACCESS)?.value;
  const refreshToken = request.cookies.get(REFRESH)?.value;

  let hasSession = secondsLeft(access) > 0;
  let setCookies: ((res: NextResponse) => void) | null = null;

  if (refreshToken && secondsLeft(access) < REFRESH_MARGIN_SECONDS) {
    const outcome = await refresh(refreshToken, request);
    if (outcome.kind === "ok") {
      const { pair } = outcome;
      // La petición en curso ve los tokens nuevos...
      request.cookies.set(ACCESS, pair.access_token);
      request.cookies.set(REFRESH, pair.refresh_token);
      hasSession = true;
      // ...y el navegador los guarda para las siguientes.
      setCookies = (res) => {
        res.cookies.set(ACCESS, pair.access_token, { ...cookieOptions, maxAge: pair.expires_in });
        res.cookies.set(REFRESH, pair.refresh_token, {
          ...cookieOptions,
          maxAge: pair.refresh_expires_in,
        });
      };
    } else if (outcome.kind === "invalid") {
      request.cookies.delete(ACCESS);
      request.cookies.delete(REFRESH);
      hasSession = false;
      setCookies = (res) => {
        res.cookies.delete(ACCESS);
        res.cookies.delete(REFRESH);
      };
    }
    // "unavailable": la API no responde; se deja todo igual y se reintentará.
  }

  let response: NextResponse;
  if (!hasSession && PROTECTED.some((p) => pathname === p || pathname.startsWith(`${p}/`))) {
    const login = new URL("/login", request.url);
    login.searchParams.set("next", pathname + search);
    response = NextResponse.redirect(login);
  } else if (hasSession && GUEST_ONLY.includes(pathname) && request.method === "GET") {
    response = NextResponse.redirect(new URL("/account", request.url));
  } else {
    response = NextResponse.next({ request: { headers: request.headers } });
  }
  setCookies?.(response);
  response.headers.set("Content-Security-Policy", csp);
  return response;
}

export const config = {
  matcher: [
    // Todo excepto archivos estáticos, imágenes y el healthcheck.
    "/((?!_next/static|_next/image|api/health|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|webp|ico|woff2?)$).*)",
  ],
};
