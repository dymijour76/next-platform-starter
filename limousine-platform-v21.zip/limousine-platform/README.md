# Limousine Platform

Plataforma de reservas de limusinas: sitio público, reservas con pago en línea,
panel del cliente, panel del conductor y panel administrativo.

| Componente | Tecnología |
|---|---|
| Frontend | Next.js 16, React 19, TypeScript, Tailwind CSS 4 |
| Backend | Python 3.12, FastAPI, SQLAlchemy 2 (async), Alembic |
| Base de datos | PostgreSQL 16 |
| Caché y cola | Redis 7 + arq (worker) |
| Contenedores | Docker / Docker Compose |
| CI | GitHub Actions |

## Inicio rápido

```bash
cp .env.example .env
docker compose up --build
```

- Sitio: http://localhost:3000
- Estado del sistema: http://localhost:3000/estado
- API (documentación interactiva): http://localhost:8000/docs
- Salud de la API: http://localhost:8000/api/v1/health/ready

Guía completa, incluida la instalación sin Docker: [docs/INSTALLATION.md](docs/INSTALLATION.md).
Ejecute `make help` para ver los comandos disponibles.

## Estructura

```text
limousine-platform/
├── backend/          API FastAPI, worker, migraciones y tests
├── frontend/         Aplicación Next.js
├── database/         Scripts de base de datos (seeds, backups)
├── docs/             Documentación del proyecto
├── infrastructure/   Despliegue (Fase 10)
├── tests/            Pruebas de extremo a extremo (Fase 9)
├── .github/          Pipeline de CI
├── docker-compose.yml
└── .env.example
```

## Estado del proyecto

| Fase | Estado |
|---|---|
| 1. Arquitectura | ✅ Completa |
| 2. Autenticación y usuarios | ✅ Completa |
| 3. Servicios y precios | ✅ Completa |
| 4. Reservas | ✅ Completa (pago en línea: Fase 5) |
| 5. Pagos | ✅ Completa (Webpay por verificar en integración) |
| 6. Vehículos y conductores | ✅ Completa |
| 7. Carrusel y contenido | ✅ Completa |
| 8. Panel de indicadores y reportes | ✅ Completa |
| 9. Seguridad y pruebas | ✅ Completa |
| 10. Producción | ✅ Completa (Docker sin probar en ejecución: ver GO_LIVE) |
| 11. Cinco idiomas (es, en, fr, ht, zh) | ✅ Completa (traducciones al creole y al chino: pendiente revisión nativa) |
| 12. Comprobante en PDF, pie de página y redes sociales | ✅ Completa |
| 13. Calificaciones y reseñas | ✅ Completa |
| 14. Billetera (saldo a favor; recarga construida y desactivada) | ✅ Completa |
| 15. Chat entre cliente y chófer | ✅ Completa |
| 16. Monedas de referencia (USD, EUR, BRL) y tasas manuales | ✅ Completa |

## Documentación

[Instalación](docs/INSTALLATION.md) ·
[Arquitectura](docs/ARCHITECTURE.md) ·
[Base de datos](docs/DATABASE.md) ·
[Seguridad](docs/SECURITY.md) ·
[API](docs/API.md) ·
[Despliegue](docs/DEPLOYMENT.md) ·
[Netlify + Render](docs/NETLIFY.md) ·
[Demo en servidor](docs/DEMO.md) ·
[Operación](docs/OPERATIONS.md) ·
[Antes de salir en vivo](docs/GO_LIVE.md) ·
[Idiomas](docs/I18N.md) ·
[Pruebas en navegador](e2e/README.md) ·
[Guía de administración](docs/ADMIN_GUIDE.md) ·
[Guía de usuario](docs/USER_GUIDE.md)
