# database/

Las migraciones viven en `backend/migrations/` (Alembic). Esta carpeta guardará
datos iniciales (servicios Standard, Professional y Premium; roles y permisos)
y los scripts de backup y restauración.
