#!/bin/sh
# Arranque en Render (plan gratuito): un solo servicio corre la API y el worker.
# Lo usa render.yaml (raíz del repositorio). En un servidor propio no se usa.
set -e

echo "[render] Migraciones"
alembic upgrade head

if [ "${SEED_DEMO:-false}" = "true" ]; then
  echo "[render] Datos de ejemplo (no pisa lo que ya exista)"
  python -m app.cli seed-demo
fi

# Administrador inicial: con ADMIN_EMAIL y ADMIN_PASSWORD definidos se crea (o se le
# repone la contraseña) en cada arranque. Borre ADMIN_PASSWORD en Render tras entrar.
if [ -n "${ADMIN_EMAIL:-}" ] && [ -n "${ADMIN_PASSWORD:-}" ]; then
  echo "[render] Administrador $ADMIN_EMAIL"
  python -m app.cli create-admin --email "$ADMIN_EMAIL" || echo "[render] No se pudo crear el administrador (revise la contraseña)"
fi

echo "[render] Worker"
arq app.worker.WorkerSettings &

echo "[render] API en el puerto ${PORT:-10000}"
exec uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-10000}"
