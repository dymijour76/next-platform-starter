"""Número único de cada billetera ("LP-4821-7730"), con dígito de verificación.

Revision ID: 0014
Revises: 0013
Create Date: 2026-10-04 22:20:29.131754
"""

import secrets
from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "0014"
down_revision: str | None = "0013"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _luhn_digit(digits: str) -> int:
    # Copia del algoritmo de app/wallet/numbers.py: la migración no depende del código de la app.
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (10 - total % 10) % 10


def _generate() -> str:
    body = "".join(secrets.choice("0123456789") for _ in range(7))
    digits = body + str(_luhn_digit(body))
    return f"LP-{digits[:4]}-{digits[4:]}"


def upgrade() -> None:
    op.add_column("wallets", sa.Column("number", sa.String(length=12), nullable=True))
    # Las billeteras que ya existen reciben su número antes de hacerlo obligatorio.
    conn = op.get_bind()
    used: set[str] = set()
    for (wallet_id,) in conn.execute(sa.text("SELECT id FROM wallets")).all():
        number = _generate()
        while number in used:
            number = _generate()
        used.add(number)
        conn.execute(
            sa.text("UPDATE wallets SET number = :n WHERE id = :id"), {"n": number, "id": wallet_id}
        )
    op.alter_column("wallets", "number", nullable=False)
    op.create_unique_constraint(op.f("uq_wallets_number"), "wallets", ["number"])


def downgrade() -> None:
    op.drop_constraint(op.f("uq_wallets_number"), "wallets", type_="unique")
    op.drop_column("wallets", "number")
