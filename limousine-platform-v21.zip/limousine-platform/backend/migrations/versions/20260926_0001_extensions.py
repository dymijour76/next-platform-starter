"""Extensiones base de PostgreSQL.

- pgcrypto   : gen_random_uuid() para las claves primarias UUID.
- citext     : emails sin distinción de mayúsculas (users.email).
- btree_gist : restricciones de exclusión por rango horario, que impedirán a nivel
               de base de datos asignar el mismo vehículo o conductor a dos reservas
               que se solapan (Fase 4 / Fase 6).

Revision ID: 0001
Revises:
Create Date: 2026-09-26
"""

from collections.abc import Sequence

from alembic import op

revision: str = "0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None

EXTENSIONS = ("pgcrypto", "citext", "btree_gist")


def upgrade() -> None:
    for ext in EXTENSIONS:
        op.execute(f'CREATE EXTENSION IF NOT EXISTS "{ext}"')


def downgrade() -> None:
    for ext in reversed(EXTENSIONS):
        op.execute(f'DROP EXTENSION IF EXISTS "{ext}"')
