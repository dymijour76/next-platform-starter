"""Módulo promotions (se implementa en fases posteriores)."""
