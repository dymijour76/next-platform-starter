"""Flota: vehículos, mantenciones y cuántos hay disponibles en un periodo."""

import uuid
from datetime import UTC, datetime

from sqlalchemy import exists, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.core.errors import AppError, Conflict, NotFound
from app.core.request_context import RequestMeta
from app.reservations.models import ACTIVE_TRIP, Reservation
from app.services.models import Service
from app.users.models import User
from app.vehicles.models import Vehicle, VehicleBlock, VehicleStatus
from app.vehicles.schemas import BlockIn, BlockOut, VehicleIn, VehicleOut


def _blocked(start: datetime, end: datetime):  # type: ignore[no-untyped-def]
    return exists().where(
        VehicleBlock.vehicle_id == Vehicle.id,
        VehicleBlock.starts_at < end,
        VehicleBlock.ends_at > start,
    )


async def available_count(
    db: AsyncSession, service_id: uuid.UUID, start: datetime, end: datetime
) -> int:
    """Vehículos activos del servicio que no están en mantención en [start, end)."""
    return (
        await db.scalar(
            select(func.count()).where(
                Vehicle.service_id == service_id,
                Vehicle.status == VehicleStatus.ACTIVE,
                ~_blocked(start, end),
            )
        )
        or 0
    )


def to_out(v: Vehicle) -> VehicleOut:
    return VehicleOut(
        id=v.id,
        plate=v.plate,
        service_id=v.service_id,
        service_name=v.service.name,
        brand=v.brand,
        model=v.model,
        year=v.year,
        color=v.color,
        passenger_capacity=v.passenger_capacity,
        status=VehicleStatus(v.status),
        notes=v.notes,
        label=v.label,
        created_at=v.created_at,
        blocks=[
            BlockOut(id=b.id, starts_at=b.starts_at, ends_at=b.ends_at, reason=b.reason)
            for b in v.blocks
            if b.ends_at > datetime.now(UTC)
        ],
    )


async def list_vehicles(db: AsyncSession, service_id: uuid.UUID | None = None) -> list[Vehicle]:
    query = select(Vehicle).order_by(Vehicle.status, Vehicle.brand, Vehicle.model, Vehicle.plate)
    if service_id:
        query = query.where(Vehicle.service_id == service_id)
    return list((await db.scalars(query)).unique())


async def get_vehicle(db: AsyncSession, vehicle_id: uuid.UUID) -> Vehicle:
    # populate_existing: recarga el vehículo con su servicio y bloqueos, aunque esté en memoria.
    v = await db.get(Vehicle, vehicle_id, populate_existing=True)
    if v is None:
        raise NotFound("El vehículo no existe.")
    return v


async def _check(db: AsyncSession, data: VehicleIn, exclude: uuid.UUID | None = None) -> None:
    if await db.get(Service, data.service_id) is None:
        raise AppError(
            "El servicio no existe.",
            code="UNKNOWN_SERVICE",
            fields={"service_id": "Elija un servicio."},
        )
    query = select(Vehicle.id).where(Vehicle.plate == data.plate)
    if exclude:
        query = query.where(Vehicle.id != exclude)
    if await db.scalar(query):
        raise Conflict(
            code="PLATE_TAKEN", fields={"plate": "Ya existe un vehículo con esta patente."}
        )


async def _future_trips(
    db: AsyncSession, vehicle_id: uuid.UUID, start: datetime, end: datetime
) -> list[str]:
    rows = await db.scalars(
        select(Reservation.code).where(
            Reservation.vehicle_id == vehicle_id,
            Reservation.status.in_(ACTIVE_TRIP),
            Reservation.pickup_at < end,
            Reservation.blocks_until > start,
        )
    )
    return list(rows)


async def create_vehicle(
    db: AsyncSession, actor: User, data: VehicleIn, meta: RequestMeta
) -> Vehicle:
    await _check(db, data)
    v = Vehicle(**data.model_dump())
    db.add(v)
    await db.flush()
    record(
        db,
        actor_id=actor.id,
        action="VEHICLE_CREATE",
        entity_type="vehicle",
        entity_id=v.id,
        meta=meta,
        after=v.audit_snapshot(),
    )
    await db.commit()
    return await get_vehicle(db, v.id)


async def update_vehicle(
    db: AsyncSession, actor: User, vehicle_id: uuid.UUID, data: VehicleIn, meta: RequestMeta
) -> Vehicle:
    v = await get_vehicle(db, vehicle_id)
    await _check(db, data, exclude=v.id)
    now = datetime.now(UTC)
    far = datetime(9999, 1, 1, tzinfo=UTC)
    if data.status != VehicleStatus.ACTIVE or data.service_id != v.service_id:
        pending = await _future_trips(db, v.id, now, far)
        if pending:
            raise Conflict(
                f"El vehículo tiene viajes asignados ({', '.join(pending[:5])}). "
                "Reasígnelos antes de desactivarlo o cambiarlo de servicio.",
                code="VEHICLE_IN_USE",
            )
    before = v.audit_snapshot()
    for key, value in data.model_dump().items():
        setattr(v, key, value)
    record(
        db,
        actor_id=actor.id,
        action="VEHICLE_UPDATE",
        entity_type="vehicle",
        entity_id=v.id,
        meta=meta,
        before=before,
        after=v.audit_snapshot(),
    )
    await db.commit()
    return await get_vehicle(db, v.id)


async def add_block(
    db: AsyncSession, actor: User, vehicle_id: uuid.UUID, data: BlockIn, meta: RequestMeta
) -> Vehicle:
    v = await get_vehicle(db, vehicle_id)
    trips = await _future_trips(db, v.id, data.starts_at, data.ends_at)
    if trips:
        raise Conflict(
            f"En ese periodo el vehículo tiene viajes asignados: {', '.join(trips[:5])}. "
            "Reasígnelos primero.",
            code="VEHICLE_IN_USE",
        )
    db.add(
        VehicleBlock(
            vehicle_id=v.id,
            starts_at=data.starts_at,
            ends_at=data.ends_at,
            reason=data.reason,
            created_by=actor.id,
            created_at=datetime.now(UTC),
        )
    )
    record(
        db,
        actor_id=actor.id,
        action="VEHICLE_BLOCK_CREATE",
        entity_type="vehicle",
        entity_id=v.id,
        meta=meta,
        after=data.model_dump(mode="json"),
    )
    await db.commit()
    return await get_vehicle(db, v.id)


async def delete_block(
    db: AsyncSession, actor: User, vehicle_id: uuid.UUID, block_id: uuid.UUID, meta: RequestMeta
) -> Vehicle:
    block = await db.get(VehicleBlock, block_id)
    if block is None or block.vehicle_id != vehicle_id:
        raise NotFound("El bloqueo no existe.")
    record(
        db,
        actor_id=actor.id,
        action="VEHICLE_BLOCK_DELETE",
        entity_type="vehicle",
        entity_id=vehicle_id,
        meta=meta,
        before={"reason": block.reason},
    )
    await db.delete(block)
    await db.commit()
    return await get_vehicle(db, vehicle_id)
