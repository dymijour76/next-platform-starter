"""Vehículos de la flota y sus bloqueos por mantención."""

import enum
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Integer, SmallInteger, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.services.models import Service


class VehicleStatus(enum.StrEnum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"  # fuera de servicio sin fecha de regreso
    RETIRED = "RETIRED"  # dado de baja; se conserva por el historial


class Vehicle(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "vehicles"
    __table_args__ = (
        CheckConstraint("status IN ('ACTIVE', 'INACTIVE', 'RETIRED')", name="status_valid"),
        CheckConstraint("passenger_capacity > 0", name="capacity_positive"),
        CheckConstraint("year BETWEEN 1950 AND 2100", name="year_valid"),
    )

    plate: Mapped[str] = mapped_column(String(10), unique=True, nullable=False)
    service_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("services.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    brand: Mapped[str] = mapped_column(String(60), nullable=False)
    model: Mapped[str] = mapped_column(String(60), nullable=False)
    year: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    color: Mapped[str] = mapped_column(String(40), nullable=False)
    passenger_capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, server_default="ACTIVE")
    notes: Mapped[str | None] = mapped_column(Text)

    service: Mapped[Service] = relationship(lazy="joined", innerjoin=True)
    blocks: Mapped[list["VehicleBlock"]] = relationship(
        back_populates="vehicle",
        lazy="selectin",
        order_by="VehicleBlock.starts_at",
        cascade="all, delete-orphan",
    )

    @property
    def label(self) -> str:
        """En español: es la versión que queda en historiales y auditoría."""
        return f"{self.brand} {self.model} {self.color.lower()}, patente {self.plate}"

    @property
    def display_label(self) -> str:
        """Para mostrar, en el idioma de la petición (el color queda como lo escribió el equipo)."""
        return self.label_for(None)

    def label_for(self, locale: str | None) -> str:
        """En el idioma pedido (None: el de la petición en curso)."""
        from app.core.i18n import t

        return t(
            "{vehicle}, patente {plate}",
            locale,
            vehicle=f"{self.brand} {self.model} {self.color.lower()}",
            plate=self.plate,
        )

    def audit_snapshot(self) -> dict[str, Any]:
        return {
            "plate": self.plate,
            "service_id": str(self.service_id),
            "brand": self.brand,
            "model": self.model,
            "year": self.year,
            "color": self.color,
            "passenger_capacity": self.passenger_capacity,
            "status": self.status,
        }


class VehicleBlock(UUIDPrimaryKeyMixin, Base):
    """Periodo en que el vehículo no está disponible (mantención, revisión técnica…)."""

    __tablename__ = "vehicle_blocks"
    __table_args__ = (CheckConstraint("ends_at > starts_at", name="period_valid"),)

    vehicle_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("vehicles.id", ondelete="CASCADE"), nullable=False, index=True
    )
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ends_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    reason: Mapped[str] = mapped_column(String(200), nullable=False)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    vehicle: Mapped[Vehicle] = relationship(back_populates="blocks")
