"""Módulo vehicles (se implementa en fases posteriores)."""
