import uuid
from datetime import datetime
from typing import Annotated, Self

from pydantic import AfterValidator, AwareDatetime, BaseModel, Field, model_validator

from app.core.validators import clean_text, normalize_plate
from app.vehicles.models import VehicleStatus

Text60 = Annotated[str, Field(min_length=1, max_length=60), AfterValidator(clean_text)]
Plate = Annotated[str, Field(max_length=12), AfterValidator(normalize_plate)]


class VehicleIn(BaseModel):
    plate: Plate
    service_id: uuid.UUID
    brand: Text60
    model: Text60
    year: int = Field(ge=1950, le=2100)
    color: Annotated[str, Field(min_length=1, max_length=40), AfterValidator(clean_text)]
    passenger_capacity: int = Field(ge=1, le=60)
    status: VehicleStatus = VehicleStatus.ACTIVE
    notes: str | None = Field(default=None, max_length=2000)


class BlockIn(BaseModel):
    starts_at: AwareDatetime
    ends_at: AwareDatetime
    reason: Annotated[str, Field(min_length=3, max_length=200), AfterValidator(clean_text)]

    @model_validator(mode="after")
    def _order(self) -> Self:
        if self.ends_at <= self.starts_at:
            raise ValueError("El término debe ser posterior al inicio.")
        return self


class BlockOut(BaseModel):
    id: uuid.UUID
    starts_at: datetime
    ends_at: datetime
    reason: str


class VehicleOut(BaseModel):
    id: uuid.UUID
    plate: str
    service_id: uuid.UUID
    service_name: str
    brand: str
    model: str
    year: int
    color: str
    passenger_capacity: int
    status: VehicleStatus
    notes: str | None
    label: str
    blocks: list[BlockOut]
    created_at: datetime
