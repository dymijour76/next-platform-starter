"""Vehículos: /admin/vehicles."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.auth.deps import DB, require
from app.auth.router import Meta
from app.users.models import User
from app.vehicles import service
from app.vehicles.schemas import BlockIn, VehicleIn, VehicleOut

router = APIRouter(prefix="/admin/vehicles", tags=["vehicles"])
Read = Annotated[User, Depends(require("vehicles:read"))]
Write = Annotated[User, Depends(require("vehicles:write"))]


@router.get("", response_model=list[VehicleOut])
async def list_vehicles(_: Read, db: DB, service_id: uuid.UUID | None = None) -> list[VehicleOut]:
    return [service.to_out(v) for v in await service.list_vehicles(db, service_id)]


@router.post("", response_model=VehicleOut, status_code=status.HTTP_201_CREATED)
async def create(data: VehicleIn, actor: Write, db: DB, meta: Meta) -> VehicleOut:
    return service.to_out(await service.create_vehicle(db, actor, data, meta))


@router.get("/{vehicle_id}", response_model=VehicleOut)
async def get(vehicle_id: uuid.UUID, _: Read, db: DB) -> VehicleOut:
    return service.to_out(await service.get_vehicle(db, vehicle_id))


@router.put("/{vehicle_id}", response_model=VehicleOut)
async def update(
    vehicle_id: uuid.UUID, data: VehicleIn, actor: Write, db: DB, meta: Meta
) -> VehicleOut:
    return service.to_out(await service.update_vehicle(db, actor, vehicle_id, data, meta))


@router.post("/{vehicle_id}/blocks", response_model=VehicleOut, status_code=status.HTTP_201_CREATED)
async def add_block(
    vehicle_id: uuid.UUID, data: BlockIn, actor: Write, db: DB, meta: Meta
) -> VehicleOut:
    return service.to_out(await service.add_block(db, actor, vehicle_id, data, meta))


@router.delete("/{vehicle_id}/blocks/{block_id}", response_model=VehicleOut)
async def delete_block(
    vehicle_id: uuid.UUID, block_id: uuid.UUID, actor: Write, db: DB, meta: Meta
) -> VehicleOut:
    return service.to_out(await service.delete_block(db, actor, vehicle_id, block_id, meta))
