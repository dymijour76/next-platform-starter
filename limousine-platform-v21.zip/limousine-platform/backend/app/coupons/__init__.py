"""Módulo coupons (se implementa en fases posteriores)."""
