import uuid
from datetime import datetime
from typing import Annotated, Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.auth.passwords import MAX_LENGTH
from app.auth.schemas import Email, Name, NewPassword, PasswordConfirmation
from app.core.config import get_settings
from app.core.i18n import translate_message
from app.core.validators import clean_text, normalize_phone, normalize_rut
from app.users.models import UserStatus

OptionalText = Annotated[str | None, Field(default=None, max_length=255)]


class RoleBrief(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    code: str
    name: str

    @field_validator("name")
    @classmethod
    def _translate(cls, value: str) -> str:
        # Roles del sistema en el idioma de quien consulta; los creados por el equipo, tal cual.
        return translate_message(value)


class ProfileOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    address: str | None
    city: str | None
    region: str | None
    company: str | None
    billing_tax_id: str | None
    billing_name: str | None
    billing_activity: str | None
    billing_address: str | None
    preferences: dict[str, Any]
    marketing_consent: bool


Locale = Literal["es", "en", "fr", "ht", "zh"]

_USER_FIELDS = (
    "id", "email", "first_name", "last_name", "phone", "status", "roles", "last_login_at",
    "created_at", "locale",
)  # fmt: skip


def _user_dict(user: Any) -> dict[str, Any]:
    data = {k: getattr(user, k) for k in _USER_FIELDS}
    data["email_verified"] = user.email_verified_at is not None
    data["mfa_enabled"] = user.mfa_enabled_at is not None
    return data


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    email: str
    first_name: str
    last_name: str
    phone: str | None
    status: UserStatus
    email_verified: bool
    locale: Locale | None = None
    mfa_enabled: bool = False
    roles: list[RoleBrief]
    last_login_at: datetime | None
    created_at: datetime

    @model_validator(mode="before")
    @classmethod
    def _from_model(cls, data: Any) -> Any:
        return _user_dict(data) if hasattr(data, "email_verified_at") else data


class MeOut(UserOut):
    permissions: list[str]
    profile: ProfileOut | None
    # El personal debe activarla antes de usar el panel (REQUIRE_STAFF_MFA).
    mfa_setup_required: bool = False
    mfa_backup_codes_left: int = 0

    @model_validator(mode="before")
    @classmethod
    def _from_model(cls, data: Any) -> Any:
        if hasattr(data, "permission_codes"):
            return {
                **_user_dict(data),
                "permissions": sorted(data.permission_codes),
                "profile": data.profile,
                "mfa_setup_required": get_settings().require_staff_mfa
                and data.is_staff
                and not data.mfa_enabled,
                "mfa_backup_codes_left": len(data.mfa_backup_hashes),
            }
        return data


def _opt_clean(v: str | None) -> str | None:
    if v is None:
        return None
    v = clean_text(v)
    return v or None


class ProfileUpdateIn(BaseModel):
    """Todos los campos son opcionales: sólo se modifica lo que se envía."""

    locale: Locale | None = None
    first_name: Name | None = None
    last_name: Name | None = None
    phone: str | None = Field(default=None, max_length=25)
    address: OptionalText
    city: str | None = Field(default=None, max_length=100)
    region: str | None = Field(default=None, max_length=100)
    company: str | None = Field(default=None, max_length=150)
    billing_tax_id: str | None = Field(default=None, max_length=20)
    billing_name: str | None = Field(default=None, max_length=150)
    billing_activity: str | None = Field(default=None, max_length=150)
    billing_address: OptionalText
    preferences: dict[str, Any] | None = None
    marketing_consent: bool | None = None

    _phone = field_validator("phone")(lambda cls, v: normalize_phone(v))
    _rut = field_validator("billing_tax_id")(lambda cls, v: normalize_rut(v))
    _texts = field_validator(
        "address", "city", "region", "company", "billing_name", "billing_activity",
        "billing_address",
    )(lambda cls, v: _opt_clean(v))  # fmt: skip

    @field_validator("preferences")
    @classmethod
    def _prefs(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is not None and len(str(v)) > 2000:
            raise ValueError("Las preferencias son demasiado extensas.")
        return v


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=MAX_LENGTH)
    password: NewPassword
    password_confirmation: PasswordConfirmation


class ChangeEmailIn(BaseModel):
    email: Email
    current_password: str = Field(min_length=1, max_length=MAX_LENGTH)


# ---- Administración ----

RoleCode = Annotated[str, Field(pattern=r"^[a-z][a-z0-9_]{2,63}$")]


class AdminUserCreateIn(BaseModel):
    email: Email
    first_name: Name
    last_name: Name
    phone: str | None = Field(default=None, max_length=25)
    roles: list[RoleCode] = Field(min_length=1, max_length=10)

    _phone = field_validator("phone")(lambda cls, v: normalize_phone(v))


class AdminUserUpdateIn(BaseModel):
    first_name: Name | None = None
    last_name: Name | None = None
    phone: str | None = Field(default=None, max_length=25)
    status: UserStatus | None = None
    roles: list[RoleCode] | None = Field(default=None, min_length=1, max_length=10)

    _phone = field_validator("phone")(lambda cls, v: normalize_phone(v))


class PermissionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    code: str
    module: str
    description: str

    @field_validator("description")
    @classmethod
    def _translate(cls, value: str) -> str:
        return translate_message(value)


class RoleOut(BaseModel):
    """`name` y `description` son los originales (los edita el formulario); para mostrar,
    `display_name` y `display_description`, en el idioma de quien consulta."""

    id: uuid.UUID
    code: str
    name: str
    description: str | None
    is_system: bool
    permissions: list[str]
    user_count: int
    display_name: str = ""
    display_description: str | None = None

    @model_validator(mode="after")
    def _display(self) -> Self:
        self.display_name = translate_message(self.name)
        self.display_description = translate_message(self.description) if self.description else None
        return self


class RoleCreateIn(BaseModel):
    code: RoleCode
    name: Name
    description: str | None = Field(default=None, max_length=500)
    permissions: list[str] = Field(default_factory=list, max_length=100)


class RoleUpdateIn(BaseModel):
    name: Name | None = None
    description: str | None = Field(default=None, max_length=500)
    permissions: list[str] | None = Field(default=None, max_length=100)

    @model_validator(mode="after")
    def _not_empty(self) -> Self:
        if not self.model_fields_set:
            raise ValueError("No se indicó ningún cambio.")
        return self
