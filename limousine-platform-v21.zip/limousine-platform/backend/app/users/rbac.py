"""Catálogo de permisos y roles iniciales.

Los permisos son fijos (los define el código, porque cada uno protege
endpoints concretos). Los roles son datos: el administrador puede crear roles
nuevos y combinar permisos desde el panel. Los cinco roles de la
especificación se crean en la migración inicial y se marcan como de sistema.

Al añadir un permiso nuevo en una fase futura, la migración correspondiente
debe insertarlo y asignarlo a los roles que lo necesiten (al menos super_admin).
"""

from typing import Final

PERMISSIONS: Final[dict[str, tuple[str, str]]] = {
    # código: (módulo, descripción)
    "dashboard:view": ("dashboard", "Ver el panel de indicadores"),
    "users:read": ("users", "Ver usuarios del personal"),
    "users:write": ("users", "Crear y modificar usuarios del personal y sus roles"),
    "roles:read": ("roles", "Ver roles y permisos"),
    "roles:write": ("roles", "Crear y modificar roles"),
    "customers:read": ("customers", "Ver clientes"),
    "customers:write": ("customers", "Modificar y bloquear clientes"),
    "reservations:read": ("reservations", "Ver reservas"),
    "reservations:write": ("reservations", "Crear y modificar reservas"),
    "reservations:cancel": ("reservations", "Cancelar reservas"),
    "reservations:assign": ("reservations", "Asignar vehículos y conductores"),
    "services:read": ("services", "Ver servicios"),
    "services:write": ("services", "Crear y modificar servicios"),
    "pricing:read": ("pricing", "Ver tarifas y reglas de precio"),
    "pricing:write": ("pricing", "Modificar tarifas y reglas de precio"),
    "vehicles:read": ("vehicles", "Ver vehículos"),
    "vehicles:write": ("vehicles", "Crear y modificar vehículos"),
    "drivers:read": ("drivers", "Ver conductores"),
    "drivers:write": ("drivers", "Crear y modificar conductores"),
    "payments:read": ("payments", "Ver pagos y transacciones"),
    "payments:refund": ("payments", "Emitir reembolsos"),
    "reports:read": ("reports", "Ver reportes operativos"),
    "reports:financial": ("reports", "Ver reportes financieros"),
    "content:write": ("content", "Administrar carrusel y fotografías"),
    "promotions:write": ("promotions", "Administrar promociones y cupones"),
    "settings:write": ("settings", "Modificar la configuración general"),
    "audit:read": ("audit", "Consultar el registro de auditoría"),
    "driver_portal:access": ("driver_portal", "Acceder al panel del conductor"),
}

ROLE_SUPER_ADMIN: Final = "super_admin"
ROLE_CUSTOMER: Final = "customer"
ROLE_DRIVER: Final = "driver"

ROLES: Final[dict[str, tuple[str, str, list[str]]]] = {
    # código: (nombre, descripción, permisos)
    ROLE_SUPER_ADMIN: (
        "Administrador general",
        "Acceso completo a todos los módulos.",
        list(PERMISSIONS),
    ),
    "reservations_admin": (
        "Administrador de reservas",
        "Gestiona reservas y asignaciones. Sin acceso a configuración financiera.",
        [
            "dashboard:view",
            "customers:read",
            "reservations:read",
            "reservations:write",
            "reservations:cancel",
            "reservations:assign",
            "services:read",
            "vehicles:read",
            "drivers:read",
        ],
    ),
    "finance_admin": (
        "Administrador financiero",
        "Consulta pagos, ingresos, reembolsos y reportes financieros.",
        ["dashboard:view", "payments:read", "reports:read", "reports:financial"],
    ),
    ROLE_DRIVER: (
        "Conductor",
        "Ve sus servicios asignados y actualiza su estado.",
        ["driver_portal:access"],
    ),
    ROLE_CUSTOMER: (
        "Cliente",
        "Reserva y gestiona sus propias reservas.",
        [],
    ),
}

# Permisos que dan acceso al panel administrativo (cualquiera de ellos basta).
STAFF_ROLES_EXCLUDED: Final = frozenset({ROLE_CUSTOMER, ROLE_DRIVER})
