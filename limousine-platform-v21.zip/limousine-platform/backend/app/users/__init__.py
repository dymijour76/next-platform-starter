"""Módulo users (se implementa en fases posteriores)."""
