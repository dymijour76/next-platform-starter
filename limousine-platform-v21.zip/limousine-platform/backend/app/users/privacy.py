"""Derechos del titular (Ley 21.719): acceso y portabilidad, y supresión de la cuenta.

La supresión anonimiza en vez de borrar filas: la ley tributaria obliga a
conservar los registros contables (reservas pagadas, pagos y reembolsos), que
quedan sin datos personales. Esto es una implementación técnica; los plazos de
retención y los textos deben revisarse con asesoría legal.
"""

import secrets
from datetime import UTC, datetime
from typing import Any

from fastapi import status
from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.models import AuditLog
from app.audit.service import record
from app.auth.models import OneTimeToken, RefreshToken, RevokeReason
from app.auth.security import hash_password, verify_password
from app.chat.models import Message
from app.core.errors import AppError, Conflict
from app.core.request_context import RequestMeta
from app.payments.models import Payment
from app.reservations.models import OCCUPYING, Reservation
from app.reviews.models import Review
from app.users.models import User
from app.users.service import WrongPassword
from app.wallet.service import balance as wallet_balance
from app.wallet.service import entries as wallet_entries

REDACTED = "[eliminado]"
DELETED_DOMAIN = "cuentas-eliminadas.invalid"  # .invalid: dominio reservado, nunca recibe correo


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value else None


async def export(db: AsyncSession, user: User) -> dict[str, Any]:
    """Todos los datos personales de la cuenta, en un formato legible y reutilizable."""
    reservations = list(
        (
            await db.scalars(
                select(Reservation)
                .where(Reservation.user_id == user.id)
                .order_by(Reservation.created_at)
            )
        ).unique()
    )
    p = user.profile
    reviews = list((await db.scalars(select(Review).where(Review.user_id == user.id))).all())
    sent = list((await db.scalars(select(Message).where(Message.sender_user_id == user.id))).all())
    movements = await wallet_entries(db, user.id, limit=10_000)
    return {
        "exportado_el": datetime.now(UTC).isoformat(),
        "billetera": {
            "saldo": str(await wallet_balance(db, user.id)),
            "movimientos": [
                {
                    "fecha": _iso(m.created_at),
                    "monto": str(m.amount),
                    "saldo_resultante": str(m.balance_after),
                    "tipo": m.kind,
                    "detalle": m.description,
                }
                for m in movements
            ],
        },
        "mensajes": [
            {"reserva_id": str(m.reservation_id), "fecha": _iso(m.created_at), "texto": m.body}
            for m in sent
            if not m.deleted
        ],
        "resenas": [
            {
                "reserva_id": str(rv.reservation_id),
                "calificacion_servicio": rv.service_rating,
                "calificacion_chofer": rv.driver_rating,
                "comentario": rv.comment,
                "autorizo_publicar": rv.consent_publish,
                "estado": rv.status,
                "creada_el": _iso(rv.created_at),
            }
            for rv in reviews
        ],
        "cuenta": {
            "email": user.email,
            "nombre": user.first_name,
            "apellido": user.last_name,
            "telefono": user.phone,
            "estado": user.status,
            "email_verificado": user.email_verified_at is not None,
            "verificacion_en_dos_pasos": user.mfa_enabled,
            "creada_el": _iso(user.created_at),
            "ultimo_acceso": _iso(user.last_login_at),
            "roles": user.role_codes,
        },
        "perfil": None
        if p is None
        else {
            "direccion": p.address,
            "comuna": p.city,
            "region": p.region,
            "empresa": p.company,
            "rut_facturacion": p.billing_tax_id,
            "razon_social": p.billing_name,
            "giro": p.billing_activity,
            "direccion_facturacion": p.billing_address,
            "preferencias": p.preferences,
            "acepta_promociones": p.marketing_consent,
            "terminos_aceptados_el": _iso(p.terms_accepted_at),
        },
        "reservas": [
            {
                "codigo": r.code,
                "estado": r.status,
                "servicio": r.service.name,
                "recogida": _iso(r.pickup_at),
                "duracion_minutos": r.duration_minutes,
                "direccion_recogida": r.pickup_address,
                "destino": r.dropoff_address,
                "pasajeros": r.passenger_count,
                "indicaciones": r.notes,
                "contacto": {
                    "nombre": r.contact_name,
                    "email": r.contact_email,
                    "telefono": r.contact_phone,
                },
                "total": str(r.total_amount),
                "moneda": r.currency,
                "creada_el": _iso(r.created_at),
                "pagos": [
                    {
                        "monto": str(pay.amount),
                        "estado": pay.status,
                        "fecha": _iso(pay.authorized_at),
                        "tarjeta_terminada_en": pay.card_last4,
                        "autorizacion": pay.authorization_code,
                        "reembolsos": [
                            {
                                "monto": str(f.amount),
                                "estado": f.status,
                                "fecha": _iso(f.created_at),
                            }
                            for f in pay.refunds
                        ],
                    }
                    for pay in r.payments
                    if pay.authorized_at
                ],
            }
            for r in reservations
        ],
    }


class DeletionNotAllowed(AppError):
    status_code = status.HTTP_409_CONFLICT
    code = "ACCOUNT_DELETE_NOT_ALLOWED"


async def delete_account(db: AsyncSession, user: User, password: str, meta: RequestMeta) -> str:
    """Anonimiza la cuenta. Devuelve el email original (para el aviso final)."""
    if not verify_password(password, user.password_hash):
        raise WrongPassword()
    if set(user.role_codes) - {"customer"}:
        raise DeletionNotAllowed(
            "Las cuentas del personal y de los conductores las da de baja un administrador."
        )
    if await wallet_balance(db, user.id) > 0:
        # El saldo es dinero del cliente: no se pierde al eliminar la cuenta sin darse cuenta.
        raise DeletionNotAllowed(
            "Tiene saldo en su billetera. Úselo o contáctenos para devolverlo antes de "
            "eliminar la cuenta."
        )
    active = list(
        await db.scalars(
            select(Reservation.code).where(
                Reservation.user_id == user.id, Reservation.status.in_(OCCUPYING)
            )
        )
    )
    if active:
        raise Conflict(
            f"Tiene reservas pendientes o en curso ({', '.join(active)}). "
            "Cancélelas o espere a que terminen antes de eliminar su cuenta.",
            code="ACTIVE_RESERVATIONS",
        )

    original_email = user.email
    # Reservas: se conservan como registro contable, sin datos personales.
    await db.execute(
        update(Reservation)
        .where(Reservation.user_id == user.id)
        .values(
            contact_name="Cliente eliminado",
            contact_email=f"reserva@{DELETED_DOMAIN}",
            contact_phone="",
            pickup_address=REDACTED,
            dropoff_address=None,
            notes=None,
            cancellation_reason=None,
        )
    )
    # Mensajes que escribió: se borra el texto (la conversación del chófer conserva la marca).
    await db.execute(
        update(Message).where(Message.sender_user_id == user.id).values(body="", deleted=True)
    )
    # Reseñas: se borran el comentario y el nombre; las estrellas siguen contando en el promedio.
    await db.execute(
        update(Review)
        .where(Review.user_id == user.id)
        .values(comment=None, consent_publish=False, display_name="Cliente", status="PUBLISHED")
    )
    reservation_ids = select(Reservation.id).where(Reservation.user_id == user.id).scalar_subquery()
    await db.execute(
        update(Payment)
        .where(Payment.reservation_id.in_(reservation_ids))
        .values(card_last4=None, provider_response={"redactado": True}, session_id="eliminado")
    )
    # Cuenta
    user.email = f"eliminada-{user.id}@{DELETED_DOMAIN}"
    user.first_name, user.last_name, user.phone = "Cuenta", "eliminada", None
    user.password_hash = hash_password(secrets.token_urlsafe(32))
    user.status = "INACTIVE"
    user.email_verified_at = None
    user.mfa_secret = user.mfa_pending_secret = None
    user.mfa_enabled_at = user.mfa_last_step = None
    user.mfa_backup_hashes = []
    user.token_version += 1
    if user.profile is not None:
        for field in (
            "address",
            "city",
            "region",
            "company",
            "billing_tax_id",
            "billing_name",
            "billing_activity",
            "billing_address",
        ):
            setattr(user.profile, field, None)
        user.profile.preferences = {}
        user.profile.marketing_consent = False
    await db.execute(
        update(RefreshToken)
        .where(RefreshToken.user_id == user.id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=datetime.now(UTC), revoked_reason=RevokeReason.ACCOUNT_DISABLED)
    )
    await db.execute(delete(OneTimeToken).where(OneTimeToken.user_id == user.id))
    # La auditoría conserva que hubo cambios, pero no los datos personales que contenía.
    await db.execute(
        update(AuditLog)
        .where(AuditLog.entity_type == "user", AuditLog.entity_id == str(user.id))
        .values(before=None, after=None)
    )
    record(
        db,
        actor_id=user.id,
        action="ACCOUNT_DELETED",
        entity_type="user",
        entity_id=user.id,
        meta=meta,
    )
    await db.commit()
    return original_email
