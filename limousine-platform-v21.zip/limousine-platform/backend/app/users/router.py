"""Endpoints de usuarios: perfil propio (/users/me), usuarios (/users) y roles (/roles)."""

import json
import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Response, status
from pydantic import BaseModel, Field

from app.auth.deps import DB, CurrentUser, RedisDep, require
from app.auth.router import Mailer, Meta, _pair
from app.auth.schemas import TokenPairOut
from app.core.errors import AppError
from app.core.pagination import Page, PageParams, page_params
from app.core.rate_limit import hit
from app.notifications import templates
from app.users import privacy, service
from app.users.models import User, UserStatus
from app.users.schemas import (
    AdminUserCreateIn,
    AdminUserUpdateIn,
    ChangeEmailIn,
    ChangePasswordIn,
    MeOut,
    PermissionOut,
    ProfileUpdateIn,
    RoleCreateIn,
    RoleOut,
    RoleUpdateIn,
    UserOut,
)

router = APIRouter(tags=["users"])


# ------------------------------------------------------------------ perfil propio


@router.get("/users/me", response_model=MeOut)
async def get_me(user: CurrentUser) -> MeOut:
    return MeOut.model_validate(user)


@router.patch("/users/me", response_model=MeOut)
async def update_me(data: ProfileUpdateIn, user: CurrentUser, db: DB) -> MeOut:
    return MeOut.model_validate(await service.update_own_profile(db, user, data))


@router.post("/users/me/password", response_model=TokenPairOut)
async def change_password(
    data: ChangePasswordIn, user: CurrentUser, db: DB, redis: RedisDep, meta: Meta, mailer: Mailer
) -> TokenPairOut:
    """Cambia la contraseña, cierra las demás sesiones y devuelve tokens nuevos."""
    await hit(redis, "change-password", str(user.id), limit=5, window_seconds=900)
    return _pair(await service.change_own_password(db, user, data, meta, mailer))


@router.post("/users/me/email", response_model=MeOut)
async def change_email(
    data: ChangeEmailIn, user: CurrentUser, db: DB, redis: RedisDep, mailer: Mailer
) -> MeOut:
    await hit(redis, "change-email", str(user.id), limit=5, window_seconds=3600)
    return MeOut.model_validate(await service.change_own_email(db, user, data, mailer))


# ------------------------------------------------------------------ administración


@router.get("/users", response_model=Page[UserOut])
async def list_users(
    _: Annotated[User, Depends(require("users:read"))],
    db: DB,
    params: Annotated[PageParams, Depends(page_params)],
    q: Annotated[str | None, Query(max_length=100)] = None,
    role: Annotated[str | None, Query(max_length=64)] = None,
    status_filter: Annotated[UserStatus | None, Query(alias="status")] = None,
) -> Page[UserOut]:
    return await service.list_users(db, params, q=q, role=role, status_filter=status_filter)


@router.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(
    data: AdminUserCreateIn,
    actor: Annotated[User, Depends(require("users:write"))],
    db: DB,
    meta: Meta,
    mailer: Mailer,
) -> UserOut:
    """Crea una cuenta de personal y envía la invitación para definir la contraseña."""
    return UserOut.model_validate(await service.create_staff_user(db, actor, data, meta, mailer))


@router.get("/users/{user_id}", response_model=UserOut)
async def get_user(
    user_id: uuid.UUID, _: Annotated[User, Depends(require("users:read"))], db: DB
) -> UserOut:
    return UserOut.model_validate(await service.get_user(db, user_id))


@router.patch("/users/{user_id}", response_model=UserOut)
async def update_user(
    user_id: uuid.UUID,
    data: AdminUserUpdateIn,
    actor: Annotated[User, Depends(require("users:write"))],
    db: DB,
    meta: Meta,
) -> UserOut:
    return UserOut.model_validate(await service.update_user(db, actor, user_id, data, meta))


@router.get("/permissions", response_model=list[PermissionOut])
async def list_permissions(
    _: Annotated[User, Depends(require("roles:read"))], db: DB
) -> list[PermissionOut]:
    return [PermissionOut.model_validate(p) for p in await service.list_permissions(db)]


@router.get("/roles", response_model=list[RoleOut])
async def list_roles(_: Annotated[User, Depends(require("roles:read"))], db: DB) -> list[RoleOut]:
    return await service.list_roles(db)


@router.post("/roles", response_model=RoleOut, status_code=status.HTTP_201_CREATED)
async def create_role(
    data: RoleCreateIn, actor: Annotated[User, Depends(require("roles:write"))], db: DB, meta: Meta
) -> RoleOut:
    return await service.create_role(db, actor, data, meta)


@router.put("/roles/{role_id}", response_model=RoleOut)
async def update_role(
    role_id: uuid.UUID,
    data: RoleUpdateIn,
    actor: Annotated[User, Depends(require("roles:write"))],
    db: DB,
    meta: Meta,
) -> RoleOut:
    return await service.update_role(db, actor, role_id, data, meta)


@router.delete("/roles/{role_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_role(
    role_id: uuid.UUID, actor: Annotated[User, Depends(require("roles:write"))], db: DB, meta: Meta
) -> Response:
    await service.delete_role(db, actor, role_id, meta)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ------------------------------------------------------ Ley 21.719: derechos del titular


class DeleteAccountIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    confirmation: str = Field(max_length=20)


@router.get("/users/me/export")
async def export_my_data(user: CurrentUser, db: DB, redis: RedisDep) -> Response:
    """Acceso y portabilidad: todos los datos de la cuenta en JSON."""
    await hit(redis, "export", str(user.id), limit=10, window_seconds=3600)
    data = await privacy.export(db, user)
    return Response(
        json.dumps(data, ensure_ascii=False, indent=2),
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="mis-datos.json"'},
    )


@router.post("/users/me/delete", status_code=status.HTTP_204_NO_CONTENT)
async def delete_my_account(
    data: DeleteAccountIn, user: CurrentUser, db: DB, redis: RedisDep, meta: Meta, mailer: Mailer
) -> Response:
    """Supresión: anonimiza la cuenta. Irreversible."""
    await hit(redis, "delete-account", str(user.id), limit=5, window_seconds=3600)
    if data.confirmation.strip().upper() != "ELIMINAR":
        raise AppError(
            "Escriba ELIMINAR para confirmar.",
            code="CONFIRMATION_REQUIRED",
            fields={"confirmation": "Escriba ELIMINAR para confirmar."},
        )
    first_name, locale = user.first_name, user.locale  # antes de anonimizar
    email = await privacy.delete_account(db, user, data.current_password, meta)
    await mailer.send(templates.account_deleted_email(email, first_name, locale))
    return Response(status_code=status.HTTP_204_NO_CONTENT)
