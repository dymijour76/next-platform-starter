"""Gestión de usuarios, perfil propio y roles."""

import secrets
import uuid
from datetime import timedelta
from typing import Any

from fastapi import status
from sqlalchemy import delete, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.auth import service as auth_service
from app.auth.models import RevokeReason, TokenPurpose
from app.auth.security import hash_password, verify_password
from app.core.errors import AppError, Conflict, NotFound, PermissionDenied
from app.core.pagination import Page, PageParams
from app.core.request_context import RequestMeta
from app.notifications import templates
from app.notifications.email import EmailDispatcher
from app.users.models import CustomerProfile, Permission, Role, User, UserRole, UserStatus
from app.users.rbac import ROLE_SUPER_ADMIN
from app.users.schemas import (
    AdminUserCreateIn,
    AdminUserUpdateIn,
    ChangeEmailIn,
    ChangePasswordIn,
    ProfileUpdateIn,
    RoleCreateIn,
    RoleOut,
    RoleUpdateIn,
    UserOut,
)
from app.wallet import numbers as wallet_numbers
from app.wallet.models import Wallet

INVITATION_TTL = timedelta(hours=72)
PROFILE_FIELDS = (
    "address", "city", "region", "company", "billing_tax_id", "billing_name",
    "billing_activity", "billing_address", "preferences", "marketing_consent",
)  # fmt: skip


class WrongPassword(AppError):
    code = "INVALID_CURRENT_PASSWORD"
    message = "La contraseña actual no es correcta."

    def __init__(self) -> None:
        super().__init__(fields={"current_password": "La contraseña actual no es correcta."})


def snapshot(user: User) -> dict[str, Any]:
    return {
        "email": user.email,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "phone": user.phone,
        "status": user.status,
        "roles": user.role_codes,
    }


# ------------------------------------------------------------------ perfil propio


async def update_own_profile(db: AsyncSession, user: User, data: ProfileUpdateIn) -> User:
    changes = data.model_dump(exclude_unset=True)
    for field in ("first_name", "last_name"):
        if changes.get(field) is not None:
            setattr(user, field, changes[field])
    if "phone" in changes:
        user.phone = changes["phone"]
    if changes.get("locale"):
        user.locale = changes["locale"]

    profile_changes = {k: v for k, v in changes.items() if k in PROFILE_FIELDS}
    if profile_changes:
        if user.profile is None:
            user.profile = CustomerProfile(user_id=user.id)
        for key, value in profile_changes.items():
            if key == "marketing_consent" and value is None:
                continue
            if key == "preferences" and value is None:
                value = {}
            setattr(user.profile, key, value)
    await db.commit()
    await db.refresh(user)
    return user


async def change_own_password(
    db: AsyncSession, user: User, data: ChangePasswordIn, meta: RequestMeta, mailer: EmailDispatcher
) -> auth_service.TokenPair:
    if not verify_password(data.current_password, user.password_hash):
        raise WrongPassword()
    if verify_password(data.password, user.password_hash):
        raise AppError(
            "La nueva contraseña debe ser distinta de la actual.",
            code="PASSWORD_UNCHANGED",
            fields={"password": "Debe ser distinta de la actual."},
        )
    await auth_service.set_new_password(db, user, data.password, mailer)
    # Se cierran las demás sesiones, pero quien hizo el cambio sigue conectado.
    pair = await auth_service.issue_tokens(db, user, meta)
    await db.commit()
    return pair


async def change_own_email(
    db: AsyncSession, user: User, data: ChangeEmailIn, mailer: EmailDispatcher
) -> User:
    if not verify_password(data.current_password, user.password_hash):
        raise WrongPassword()
    if data.email == user.email:
        return user
    if await auth_service.get_user_by_email(db, data.email):
        raise Conflict(code="EMAIL_TAKEN", fields={"email": "Este email ya está registrado."})
    old_email = user.email
    user.email = data.email
    user.email_verified_at = None
    await auth_service.send_verification(db, user, mailer)  # hace commit
    await mailer.send(
        templates.email_changed_notice(old_email, user.first_name, data.email, user.locale)
    )
    await db.refresh(user)
    return user


# ------------------------------------------------------------------ administración de usuarios


async def list_users(
    db: AsyncSession,
    params: PageParams,
    *,
    q: str | None,
    role: str | None,
    status_filter: UserStatus | None,
) -> Page[UserOut]:
    query = select(User)
    if q:
        pattern = f"%{q.strip()}%"
        conditions = [
            User.email.ilike(pattern),
            (User.first_name + " " + User.last_name).ilike(pattern),
            User.phone.ilike(pattern),
        ]
        # También por número de billetera ("LP-4821-7730", con o sin guiones).
        if number := wallet_numbers.normalize(q):
            wallet_owner = select(Wallet.user_id).where(Wallet.number == number)
            conditions.append(User.id.in_(wallet_owner))
        query = query.where(or_(*conditions))
    if role:
        query = query.where(
            User.id.in_(
                select(UserRole.user_id)
                .join(Role, Role.id == UserRole.role_id)
                .where(Role.code == role)
            )
        )
    if status_filter:
        query = query.where(User.status == status_filter)

    total = await db.scalar(select(func.count()).select_from(query.subquery())) or 0
    rows = await db.scalars(
        query.order_by(User.created_at.desc(), User.id)
        .offset(params.offset)
        .limit(params.page_size)
    )
    return Page[UserOut](
        items=[UserOut.model_validate(u) for u in rows],
        total=total,
        page=params.page,
        page_size=params.page_size,
    )


async def get_user(db: AsyncSession, user_id: uuid.UUID) -> User:
    user = await db.get(User, user_id)
    if user is None:
        raise NotFound("El usuario no existe.")
    return user


async def _resolve_roles(db: AsyncSession, codes: list[str]) -> list[Role]:
    unique = list(dict.fromkeys(codes))
    roles = list(await db.scalars(select(Role).where(Role.code.in_(unique))))
    missing = set(unique) - {r.code for r in roles}
    if missing:
        raise AppError(
            f"Roles inexistentes: {', '.join(sorted(missing))}.",
            code="UNKNOWN_ROLE",
            fields={"roles": "Contiene roles que no existen."},
        )
    return roles


def _ensure_can_grant(actor: User, permissions: set[str]) -> None:
    """Nadie puede otorgar permisos que no tiene (evita la escalada de privilegios)."""
    if not permissions <= actor.permission_codes:
        raise PermissionDenied(
            "No puede otorgar permisos que usted no tiene.", code="PRIVILEGE_ESCALATION"
        )


async def _active_super_admins(db: AsyncSession) -> int:
    return (
        await db.scalar(
            select(func.count())
            .select_from(UserRole)
            .join(Role, Role.id == UserRole.role_id)
            .join(User, User.id == UserRole.user_id)
            .where(Role.code == ROLE_SUPER_ADMIN, User.status == UserStatus.ACTIVE)
        )
        or 0
    )


async def _set_roles(db: AsyncSession, user: User, roles: list[Role], actor: User) -> None:
    await db.execute(delete(UserRole).where(UserRole.user_id == user.id))
    for role in roles:
        db.add(UserRole(user_id=user.id, role_id=role.id, assigned_by=actor.id))
    await db.flush()
    db.expire(user, ["roles"])


async def create_staff_user(
    db: AsyncSession,
    actor: User,
    data: AdminUserCreateIn,
    meta: RequestMeta,
    mailer: EmailDispatcher,
) -> User:
    roles = await _resolve_roles(db, data.roles)
    _ensure_can_grant(actor, {p.code for r in roles for p in r.permissions})
    if await auth_service.get_user_by_email(db, data.email):
        raise Conflict(code="EMAIL_TAKEN", fields={"email": "Este email ya está registrado."})

    # Contraseña aleatoria que nadie conoce: la persona define la suya con el enlace de invitación.
    user = User(
        email=data.email,
        password_hash=hash_password(secrets.token_urlsafe(32)),
        first_name=data.first_name,
        last_name=data.last_name,
        phone=data.phone,
    )
    db.add(user)
    await db.flush()
    await _set_roles(db, user, roles, actor)
    await db.refresh(user, ["roles"])
    record(
        db, actor_id=actor.id, action="USER_CREATE", entity_type="user", entity_id=user.id,
        meta=meta, after=snapshot(user),
    )  # fmt: skip
    raw = await auth_service.create_one_time_token(
        db, user, TokenPurpose.PASSWORD_RESET, INVITATION_TTL
    )
    await db.commit()
    await mailer.send(
        templates.invitation_email(
            user.email, user.first_name, [r.name for r in roles], raw, user.locale
        )
    )
    return user


async def update_user(
    db: AsyncSession,
    actor: User,
    user_id: uuid.UUID,
    data: AdminUserUpdateIn,
    meta: RequestMeta,
) -> User:
    user = await get_user(db, user_id)
    changes = data.model_dump(exclude_unset=True)
    is_self = user.id == actor.id

    if is_self and ("status" in changes or "roles" in changes):
        raise PermissionDenied(
            "No puede cambiar su propio estado ni sus roles. Pídaselo a otro administrador.",
            code="SELF_MODIFICATION",
        )
    # No se puede administrar a alguien con más permisos que uno mismo.
    _ensure_can_grant(actor, user.permission_codes)

    before = snapshot(user)
    was_super_admin = ROLE_SUPER_ADMIN in user.role_codes and user.is_active

    for field in ("first_name", "last_name"):
        if changes.get(field) is not None:
            setattr(user, field, changes[field])
    if "phone" in changes:
        user.phone = changes["phone"]
    if changes.get("locale"):
        user.locale = changes["locale"]

    if changes.get("roles") is not None:
        roles = await _resolve_roles(db, changes["roles"])
        _ensure_can_grant(actor, {p.code for r in roles for p in r.permissions})
        await _set_roles(db, user, roles, actor)
        await db.refresh(user, ["roles"])

    new_status = changes.get("status")
    if new_status is not None and new_status != user.status:
        user.status = new_status
        if new_status != UserStatus.ACTIVE:
            await auth_service.invalidate_sessions(db, user, RevokeReason.ACCOUNT_DISABLED)

    still_super_admin = ROLE_SUPER_ADMIN in user.role_codes and user.is_active
    if was_super_admin and not still_super_admin:
        await db.flush()
        if await _active_super_admins(db) == 0:
            await db.rollback()
            raise Conflict(
                "Debe existir al menos un administrador general activo.",
                code="LAST_SUPER_ADMIN",
            )

    after = snapshot(user)
    if after != before:
        record(
            db, actor_id=actor.id, action="USER_UPDATE", entity_type="user", entity_id=user.id,
            meta=meta, before=before, after=after,
        )  # fmt: skip
    await db.commit()
    await db.refresh(user)
    return user


# ------------------------------------------------------------------ roles


async def list_permissions(db: AsyncSession) -> list[Permission]:
    return list(await db.scalars(select(Permission).order_by(Permission.module, Permission.code)))


async def _role_out(db: AsyncSession, role: Role) -> RoleOut:
    count = await db.scalar(select(func.count()).where(UserRole.role_id == role.id)) or 0
    return RoleOut(
        id=role.id,
        code=role.code,
        name=role.name,
        description=role.description,
        is_system=role.is_system,
        permissions=[p.code for p in role.permissions],
        user_count=count,
    )


async def list_roles(db: AsyncSession) -> list[RoleOut]:
    counts = dict(
        (await db.execute(select(UserRole.role_id, func.count()).group_by(UserRole.role_id))).all()
    )
    roles = await db.scalars(select(Role).order_by(Role.is_system.desc(), Role.name))
    return [
        RoleOut(
            id=r.id,
            code=r.code,
            name=r.name,
            description=r.description,
            is_system=r.is_system,
            permissions=[p.code for p in r.permissions],
            user_count=counts.get(r.id, 0),
        )
        for r in roles
    ]


async def _resolve_permissions(db: AsyncSession, codes: list[str]) -> list[Permission]:
    unique = set(codes)
    perms = list(await db.scalars(select(Permission).where(Permission.code.in_(unique))))
    missing = unique - {p.code for p in perms}
    if missing:
        raise AppError(
            f"Permisos inexistentes: {', '.join(sorted(missing))}.",
            code="UNKNOWN_PERMISSION",
            fields={"permissions": "Contiene permisos que no existen."},
        )
    return perms


def _role_snapshot(role: Role) -> dict[str, Any]:
    return {
        "code": role.code,
        "name": role.name,
        "description": role.description,
        "permissions": sorted(p.code for p in role.permissions),
    }


async def create_role(
    db: AsyncSession, actor: User, data: RoleCreateIn, meta: RequestMeta
) -> RoleOut:
    if await db.scalar(select(Role).where(Role.code == data.code)):
        raise Conflict(code="ROLE_EXISTS", fields={"code": "Ya existe un rol con este código."})
    perms = await _resolve_permissions(db, data.permissions)
    _ensure_can_grant(actor, {p.code for p in perms})
    role = Role(code=data.code, name=data.name, description=data.description, permissions=perms)
    db.add(role)
    await db.flush()
    record(
        db, actor_id=actor.id, action="ROLE_CREATE", entity_type="role", entity_id=role.id,
        meta=meta, after=_role_snapshot(role),
    )  # fmt: skip
    await db.commit()
    return await _role_out(db, role)


async def _get_role(db: AsyncSession, role_id: uuid.UUID) -> Role:
    role = await db.get(Role, role_id)
    if role is None:
        raise NotFound("El rol no existe.")
    return role


async def update_role(
    db: AsyncSession, actor: User, role_id: uuid.UUID, data: RoleUpdateIn, meta: RequestMeta
) -> RoleOut:
    role = await _get_role(db, role_id)
    _ensure_can_grant(actor, {p.code for p in role.permissions})
    before = _role_snapshot(role)
    changes = data.model_dump(exclude_unset=True)
    if changes.get("name") is not None:
        role.name = changes["name"]
    if "description" in changes:
        role.description = changes["description"]
    if changes.get("permissions") is not None:
        if role.code == ROLE_SUPER_ADMIN:
            raise AppError(
                "Los permisos del administrador general no se pueden modificar.",
                code="ROLE_PROTECTED",
                status_code=status.HTTP_409_CONFLICT,
            )
        perms = await _resolve_permissions(db, changes["permissions"])
        _ensure_can_grant(actor, {p.code for p in perms})
        role.permissions = perms
    record(
        db, actor_id=actor.id, action="ROLE_UPDATE", entity_type="role", entity_id=role.id,
        meta=meta, before=before, after=_role_snapshot(role),
    )  # fmt: skip
    await db.commit()
    await db.refresh(role)
    return await _role_out(db, role)


async def delete_role(db: AsyncSession, actor: User, role_id: uuid.UUID, meta: RequestMeta) -> None:
    role = await _get_role(db, role_id)
    if role.is_system:
        raise Conflict("Los roles del sistema no se pueden eliminar.", code="ROLE_PROTECTED")
    if await db.scalar(select(func.count()).where(UserRole.role_id == role.id)):
        raise Conflict(
            "El rol tiene usuarios asignados. Reasígnelos antes de eliminarlo.", code="ROLE_IN_USE"
        )
    _ensure_can_grant(actor, {p.code for p in role.permissions})
    record(
        db, actor_id=actor.id, action="ROLE_DELETE", entity_type="role", entity_id=role.id,
        meta=meta, before=_role_snapshot(role),
    )  # fmt: skip
    await db.delete(role)
    await db.commit()
