"""Número de billetera: "LP-4821-7730".

Ocho dígitos: siete al azar y uno de verificación (algoritmo de Luhn), para detectar un número
mal dictado o mal copiado. Es deliberadamente distinto de un número de tarjeta bancaria (16
dígitos y sin prefijo), para que nadie lo confunda con una tarjeta real.
"""

import re
import secrets

PREFIX = "LP"
_FORMAT = re.compile(r"^LP-?(\d{4})-?(\d{4})$")


def _luhn_digit(digits: str) -> int:
    """Dígito que hace válida la secuencia según Luhn."""
    total = 0
    for i, ch in enumerate(reversed(digits)):
        d = int(ch)
        if i % 2 == 0:  # posiciones que se duplican, contando desde el dígito de verificación
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (10 - total % 10) % 10


def generate() -> str:
    body = "".join(secrets.choice("0123456789") for _ in range(7))
    digits = body + str(_luhn_digit(body))
    return f"{PREFIX}-{digits[:4]}-{digits[4:]}"


def normalize(value: str) -> str | None:
    """ "lp48217730", "LP-4821-7730" o "LP 4821 7730" → "LP-4821-7730"; None si no es válido."""
    m = _FORMAT.match(re.sub(r"\s+", "-", value.strip().upper()))
    if not m:
        return None
    digits = m.group(1) + m.group(2)
    if _luhn_digit(digits[:7]) != int(digits[7]):
        return None  # dígito de verificación incorrecto: número mal escrito
    return f"{PREFIX}-{digits[:4]}-{digits[4:]}"
