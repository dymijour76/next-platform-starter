"""Billetera: una por cuenta, con un libro de movimientos que no se modifica.

El saldo de `wallets` se actualiza en la misma transacción que cada movimiento, con la fila
bloqueada (SELECT … FOR UPDATE): dos pagos simultáneos no pueden gastar el mismo saldo. La
base de datos impide saldos negativos (CHECK) y modificar o borrar movimientos (trigger, ver
la migración 0012): el saldo siempre se puede reconstruir sumando los movimientos.
"""

import uuid
from decimal import Decimal

from sqlalchemy import CheckConstraint, ForeignKey, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

CREDIT, PAYMENT, REFUND, TOPUP, TOPUP_REFUND = (
    "CREDIT",
    "PAYMENT",
    "REFUND",
    "TOPUP",
    "TOPUP_REFUND",
)
KINDS = (CREDIT, PAYMENT, REFUND, TOPUP, TOPUP_REFUND)


class Wallet(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "wallets"
    __table_args__ = (CheckConstraint("balance >= 0", name="balance_not_negative"),)

    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), unique=True
    )
    # "LP-4821-7730": se muestra en la tarjeta de la billetera (ver wallet/numbers.py).
    number: Mapped[str] = mapped_column(String(12), unique=True, nullable=False)
    balance: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False, default=Decimal(0))
    currency: Mapped[str] = mapped_column(String(3), nullable=False, default="CLP")


class WalletEntry(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "wallet_entries"
    __table_args__ = (
        CheckConstraint("amount <> 0", name="amount_not_zero"),
        CheckConstraint("balance_after >= 0", name="balance_after_not_negative"),
        CheckConstraint(f"kind IN {KINDS}", name="kind_valid"),
    )

    wallet_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("wallets.id", ondelete="CASCADE"), index=True
    )
    amount: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), nullable=False
    )  # positivo entra, negativo sale
    balance_after: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    kind: Mapped[str] = mapped_column(String(16), nullable=False)
    # En español; se traduce al mostrarlo ("Pago de la reserva RES-2026-000123").
    description: Mapped[str] = mapped_column(String(200), nullable=False)
    reason: Mapped[str | None] = mapped_column(String(300))  # motivo escrito por el personal
    reservation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("reservations.id", ondelete="SET NULL")
    )
    payment_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("payments.id", ondelete="SET NULL")
    )
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
