import uuid
from datetime import datetime
from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select

from app.audit.service import record
from app.auth.deps import DB, CurrentUser, RedisDep, require
from app.auth.router import Mailer, Meta
from app.core.config import get_settings
from app.core.errors import NotFound
from app.core.i18n import translate_message
from app.core.rate_limit import hit
from app.core.validators import clean_text
from app.payments import service as payments
from app.payments.router import RedirectOut
from app.reservations import service as reservations
from app.reservations.models import Reservation
from app.reservations.schemas import ReservationOut
from app.users.models import User
from app.wallet import service
from app.wallet.models import WalletEntry

router = APIRouter(tags=["billetera"])


class EntryOut(BaseModel):
    id: uuid.UUID
    amount: Decimal
    balance_after: Decimal
    kind: str
    description: str  # en el idioma de quien consulta
    reason: str | None
    reservation_code: str | None
    created_at: datetime


class WalletOut(BaseModel):
    number: str  # "LP-4821-7730"
    holder: str  # nombre del titular, como en la tarjeta
    balance: Decimal
    currency: str
    topup_enabled: bool
    topup_min: int
    topup_max: int
    entries: list[EntryOut]


class TopupIn(BaseModel):
    amount: Decimal = Field(gt=0, max_digits=14, decimal_places=0)


class CreditIn(BaseModel):
    amount: Decimal = Field(gt=0, max_digits=14, decimal_places=0)
    reason: Annotated[str, Field(min_length=5, max_length=300)]


async def _wallet_out(db: DB, user_id: uuid.UUID) -> WalletOut:
    w = await service.get_or_create(db, user_id)
    rows: list[WalletEntry] = await service.entries(db, user_id)
    ids = {e.reservation_id for e in rows if e.reservation_id}
    codes = (
        dict(
            (
                await db.execute(
                    select(Reservation.id, Reservation.code).where(Reservation.id.in_(ids))
                )
            ).all()
        )
        if ids
        else {}
    )
    settings = get_settings()
    holder = await db.scalar(
        select(User.first_name + " " + User.last_name).where(User.id == user_id)
    )
    return WalletOut(
        number=w.number,
        holder=holder or "",
        balance=w.balance,
        currency=w.currency,
        topup_enabled=settings.wallet_topup_enabled,
        topup_min=settings.wallet_topup_min,
        topup_max=settings.wallet_topup_max,
        entries=[
            EntryOut(
                id=e.id,
                amount=e.amount,
                balance_after=e.balance_after,
                kind=e.kind,
                description=translate_message(e.description),
                reason=e.reason,
                reservation_code=codes.get(e.reservation_id) if e.reservation_id else None,
                created_at=e.created_at,
            )
            for e in rows
        ],
    )


@router.get("/wallet", response_model=WalletOut)
async def my_wallet(user: CurrentUser, db: DB) -> WalletOut:
    out = await _wallet_out(db, user.id)
    await db.commit()  # la billetera se crea la primera vez que se consulta
    return out


@router.post("/wallet/topups", response_model=RedirectOut)
async def topup(data: TopupIn, user: CurrentUser, db: DB, redis: RedisDep) -> RedirectOut:
    await hit(redis, "topup", str(user.id), limit=10, window_seconds=600)
    redirect = await payments.start_topup(db, payments.get_provider(redis), user, data.amount)
    return RedirectOut(url=redirect.url, fields=redirect.fields)


@router.post("/reservations/{code}/pay-with-wallet", response_model=ReservationOut)
async def pay_with_wallet(code: str, user: CurrentUser, db: DB, mailer: Mailer) -> ReservationOut:
    r = await payments.pay_with_wallet(db, user, code)
    await reservations.notify(db, r, "confirmed", mailer)
    return reservations.to_out(await reservations.get_own(db, user, code))


@router.get("/admin/users/{user_id}/wallet", response_model=WalletOut)
async def user_wallet(
    user_id: uuid.UUID, _: Annotated[User, Depends(require("payments:read"))], db: DB
) -> WalletOut:
    out = await _wallet_out(db, user_id)
    await db.commit()
    return out


@router.post("/admin/users/{user_id}/wallet/credits", response_model=WalletOut, status_code=201)
async def grant_credit(
    user_id: uuid.UUID,
    data: CreditIn,
    actor: Annotated[User, Depends(require("payments:refund"))],
    db: DB,
    meta: Meta,
) -> WalletOut:
    if await db.get(User, user_id) is None:
        raise NotFound("El usuario no existe.")
    entry = await service.grant_credit(db, user_id, data.amount, clean_text(data.reason), actor.id)
    record(
        db,
        actor_id=actor.id,
        action="WALLET_CREDIT",
        entity_type="user",
        entity_id=user_id,
        meta=meta,
        after={
            "amount": str(data.amount),
            "reason": entry.reason,
            "balance": str(entry.balance_after),
        },
    )
    await db.commit()
    return await _wallet_out(db, user_id)
