"""Billetera: saldo, movimientos, créditos del personal, pago de reservas y recargas."""

import uuid
from decimal import Decimal

from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.errors import AppError
from app.wallet import numbers
from app.wallet.models import CREDIT, Wallet, WalletEntry


class InsufficientBalance(AppError):
    status_code = 409
    code = "INSUFFICIENT_BALANCE"
    message = "El saldo de la billetera no alcanza para esta operación."


class TopupDisabled(AppError):
    status_code = 409
    code = "TOPUP_DISABLED"
    message = "La recarga de saldo no está habilitada."


async def get_or_create(db: AsyncSession, user_id: uuid.UUID) -> Wallet:
    """La billetera de la cuenta (se crea vacía la primera vez, sin carreras)."""
    # Si por azar el número ya existe, se intenta con otro (la inserción no hace nada).
    for _ in range(5):
        await db.execute(
            insert(Wallet)
            .values(id=uuid.uuid4(), user_id=user_id, number=numbers.generate())
            .on_conflict_do_nothing()
        )
        if await db.scalar(select(Wallet.id).where(Wallet.user_id == user_id)):
            break
    wallet = await db.scalar(
        select(Wallet).where(Wallet.user_id == user_id).execution_options(populate_existing=True)
    )
    assert wallet is not None
    return wallet


async def balance(db: AsyncSession, user_id: uuid.UUID) -> Decimal:
    value = await db.scalar(select(Wallet.balance).where(Wallet.user_id == user_id))
    return value or Decimal(0)


async def post(
    db: AsyncSession,
    user_id: uuid.UUID,
    amount: Decimal,
    kind: str,
    description: str,
    *,
    reason: str | None = None,
    reservation_id: uuid.UUID | None = None,
    payment_id: uuid.UUID | None = None,
    created_by: uuid.UUID | None = None,
) -> WalletEntry:
    """Registra un movimiento y actualiza el saldo en una sola instrucción atómica.

    El saldo nuevo lo calcula la base de datos sobre el valor vigente, con la fila bloqueada,
    y sólo si no queda negativo ("UPDATE … WHERE balance + monto >= 0 RETURNING balance").
    Así dos operaciones simultáneas nunca parten del mismo saldo, aunque cada sesión tenga en
    memoria un valor leído antes (eso permitió un doble gasto en una versión anterior).
    Debe llamarse dentro de la transacción de la operación que lo origina.
    """
    wallet = await get_or_create(db, user_id)
    row = (
        await db.execute(
            update(Wallet)
            .where(Wallet.id == wallet.id, Wallet.balance + amount >= 0)
            .values(balance=Wallet.balance + amount)
            .returning(Wallet.balance)
            .execution_options(synchronize_session=False)
        )
    ).first()
    if row is None:
        raise InsufficientBalance()
    new_balance = row[0]
    entry = WalletEntry(
        wallet_id=wallet.id,
        amount=amount,
        balance_after=new_balance,
        kind=kind,
        description=description,
        reason=reason,
        reservation_id=reservation_id,
        payment_id=payment_id,
        created_by=created_by,
    )
    db.add(entry)
    await db.flush()
    return entry


async def grant_credit(
    db: AsyncSession, user_id: uuid.UUID, amount: Decimal, reason: str, actor_id: uuid.UUID
) -> WalletEntry:
    limit = Decimal(get_settings().wallet_credit_max)
    if amount <= 0 or amount > limit:
        raise AppError(
            "El monto debe ser mayor que cero y no superar el tope de créditos.",
            code="INVALID_AMOUNT",
            fields={"amount": "Monto fuera de rango."},
        )
    return await post(
        db, user_id, amount, CREDIT, "Crédito otorgado", reason=reason, created_by=actor_id
    )


async def entries(db: AsyncSession, user_id: uuid.UUID, limit: int = 50) -> list[WalletEntry]:
    return list(
        (
            await db.scalars(
                select(WalletEntry)
                .join(Wallet, Wallet.id == WalletEntry.wallet_id)
                .where(Wallet.user_id == user_id)
                .order_by(WalletEntry.created_at.desc(), WalletEntry.id.desc())
                .limit(limit)
            )
        ).all()
    )
