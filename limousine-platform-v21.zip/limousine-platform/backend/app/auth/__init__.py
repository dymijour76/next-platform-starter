"""Módulo auth (se implementa en fases posteriores)."""
