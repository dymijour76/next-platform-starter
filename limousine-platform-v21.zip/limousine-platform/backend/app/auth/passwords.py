"""Política de contraseñas.

Sigue la recomendación NIST SP 800-63B: priorizar la longitud y rechazar
contraseñas conocidas, en vez de exigir combinaciones de símbolos que llevan a
contraseñas predecibles como "Password1!".
"""

MIN_LENGTH = 10
MAX_LENGTH = 128

_COMMON = {
    "1234567890", "12345678910", "0123456789", "qwertyuiop", "password123",
    "contraseña", "contrasena", "contrasena1", "contraseña1", "administrador",
    "passwordpassword", "1111111111", "abcdefghij", "iloveyou12", "qwerty1234",
    "asdfghjkl1", "limousine1", "limusina123", "chile12345", "santiago123",
}  # fmt: skip


def validate_password(password: str, *, email: str | None = None) -> str:
    """Devuelve la contraseña si cumple la política; si no, lanza ValueError."""
    if len(password) < MIN_LENGTH:
        raise ValueError(f"La contraseña debe tener al menos {MIN_LENGTH} caracteres.")
    if len(password) > MAX_LENGTH:
        raise ValueError(f"La contraseña no puede superar {MAX_LENGTH} caracteres.")
    lowered = password.lower()
    if lowered in _COMMON or len(set(lowered)) <= 2:
        raise ValueError("Esa contraseña es demasiado común. Elija otra.")
    if email and email.split("@", 1)[0].lower() in lowered and len(email.split("@", 1)[0]) >= 4:
        raise ValueError("La contraseña no puede contener su email.")
    return password
