"""Primitivas criptográficas: contraseñas, JWT y tokens opacos."""

import hashlib
import secrets
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from app.core.config import get_settings

# Parámetros recomendados por OWASP para Argon2id (19 MiB, 2 iteraciones).
_hasher = PasswordHasher(time_cost=2, memory_cost=19456, parallelism=1)

# Hash de una contraseña aleatoria. Se verifica contra él cuando el email no
# existe, para que el login tarde lo mismo y no revele qué emails están registrados.
_DUMMY_HASH = _hasher.hash(secrets.token_urlsafe(16))


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str | None) -> bool:
    try:
        return _hasher.verify(password_hash or _DUMMY_HASH, password) and password_hash is not None
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def password_needs_rehash(password_hash: str) -> bool:
    """True si el hash se creó con parámetros más débiles que los actuales."""
    return _hasher.check_needs_rehash(password_hash)


def create_access_token(user_id: uuid.UUID, token_version: int) -> tuple[str, int]:
    """Devuelve (token, segundos de validez)."""
    settings = get_settings()
    now = datetime.now(UTC)
    ttl = timedelta(minutes=settings.access_token_minutes)
    payload: dict[str, Any] = {
        "sub": str(user_id),
        "ver": token_version,
        "type": "access",
        "iss": settings.jwt_issuer,
        "iat": now,
        "exp": now + ttl,
        "jti": uuid.uuid4().hex,
    }
    token = jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)
    return token, int(ttl.total_seconds())


MFA_TOKEN_MINUTES = 5


def create_mfa_token(user_id: uuid.UUID, token_version: int) -> str:
    """Permiso temporal tras la contraseña correcta: sólo sirve para enviar el código."""
    settings = get_settings()
    now = datetime.now(UTC)
    payload = {
        "sub": str(user_id),
        "ver": token_version,
        "type": "mfa",
        "iss": settings.jwt_issuer,
        "iat": now,
        "exp": now + timedelta(minutes=MFA_TOKEN_MINUTES),
        "jti": uuid.uuid4().hex,
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_mfa_token(token: str) -> dict[str, Any] | None:
    return _decode(token, "mfa")


def decode_access_token(token: str) -> dict[str, Any] | None:
    return _decode(token, "access")


def _decode(token: str, expected_type: str) -> dict[str, Any] | None:
    """Devuelve el contenido si el token es válido; None en cualquier otro caso."""
    settings = get_settings()
    try:
        payload: dict[str, Any] = jwt.decode(
            token,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm],  # lista fija: impide el ataque "alg: none"
            issuer=settings.jwt_issuer,
            options={"require": ["sub", "exp", "iat", "type", "ver"]},
        )
    except jwt.PyJWTError:
        return None
    # Un token de un tipo nunca sirve como otro (el de MFA no abre la API).
    if payload.get("type") != expected_type:
        return None
    return payload


def generate_opaque_token() -> str:
    """Token aleatorio de 256 bits para refresh tokens y enlaces de un solo uso."""
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()
