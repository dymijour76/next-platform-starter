"""Endpoints de autenticación: /api/v1/auth/*"""

from typing import Annotated

from fastapi import APIRouter, Depends, Request, Response, status

from app.auth import lockout, service
from app.auth.deps import DB, CurrentUser, RedisDep
from app.auth.models import RevokeReason
from app.auth.schemas import (
    ForgotPasswordIn,
    LoginIn,
    MfaChallengeOut,
    MfaLoginIn,
    RefreshIn,
    RegisterIn,
    ResetPasswordIn,
    TokenIn,
    TokenPairOut,
)
from app.auth.security import MFA_TOKEN_MINUTES
from app.core.i18n import t
from app.core.rate_limit import client_ip, hit
from app.core.request_context import RequestMeta, get_request_meta
from app.notifications import templates
from app.notifications.email import EmailDispatcher, get_email_dispatcher
from app.users.schemas import MeOut

router = APIRouter(prefix="/auth", tags=["auth"])

Meta = Annotated[RequestMeta, Depends(get_request_meta)]
Mailer = Annotated[EmailDispatcher, Depends(get_email_dispatcher)]

FORGOT_RESPONSE_TEXT = (
    "Si el email está registrado, recibirá un enlace para crear una nueva contraseña."
)
MINUTE = 60
HOUR = 3600


def _pair(pair: service.TokenPair) -> TokenPairOut:
    return TokenPairOut(
        access_token=pair.access_token,
        expires_in=pair.expires_in,
        refresh_token=pair.refresh_token,
        refresh_expires_in=pair.refresh_expires_in,
    )


@router.post("/register", response_model=MeOut, status_code=status.HTTP_201_CREATED)
async def register(
    data: RegisterIn, request: Request, db: DB, redis: RedisDep, mailer: Mailer
) -> MeOut:
    await hit(redis, "register", client_ip(request), limit=5, window_seconds=HOUR)
    user = await service.register(db, data, mailer)
    return MeOut.model_validate(user)


@router.post("/login", response_model=TokenPairOut | MfaChallengeOut)
async def login(
    data: LoginIn, request: Request, db: DB, redis: RedisDep, meta: Meta, mailer: Mailer
) -> TokenPairOut | MfaChallengeOut:
    ip = client_ip(request)
    # Dos límites: por cuenta (fuerza bruta a un usuario) y por IP (barrido de cuentas).
    await hit(redis, "login", f"{ip}|{data.email}", limit=10, window_seconds=15 * MINUTE)
    await hit(redis, "login-ip", ip, limit=50, window_seconds=15 * MINUTE)
    await lockout.check(redis, data.email)
    try:
        pair = await service.login(db, data.email, data.password, meta)
    except service.InvalidCredentials:
        locked_for = await lockout.register_failure(redis, data.email)
        if locked_for:
            # Aviso al titular sólo en el primer escalón, para no llenar su bandeja.
            user = await service.get_user_by_email(db, data.email)
            if user is not None and locked_for == lockout.STEPS[-1][1]:
                await mailer.send(
                    templates.failed_logins_email(user.email, user.first_name, user.locale)
                )
            raise lockout._locked_error(locked_for) from None
        raise
    await lockout.clear(redis, data.email)
    if isinstance(pair, service.MfaChallenge):
        return MfaChallengeOut(mfa_token=pair.mfa_token, expires_in=MFA_TOKEN_MINUTES * 60)
    return _pair(pair)


@router.post("/mfa", response_model=TokenPairOut)
async def login_mfa(
    data: MfaLoginIn, request: Request, db: DB, redis: RedisDep, meta: Meta
) -> TokenPairOut:
    """Segundo paso del inicio de sesión: código de la aplicación o de respaldo."""
    await hit(redis, "mfa-ip", client_ip(request), limit=30, window_seconds=15 * MINUTE)
    await hit(redis, "mfa-token", data.mfa_token[-24:], limit=5, window_seconds=15 * MINUTE)
    return _pair(await service.login_second_factor(db, data.mfa_token, data.code, meta))


@router.post("/refresh", response_model=TokenPairOut)
async def refresh(
    data: RefreshIn, request: Request, db: DB, redis: RedisDep, meta: Meta
) -> TokenPairOut:
    await hit(redis, "refresh", client_ip(request), limit=120, window_seconds=5 * MINUTE)
    return _pair(await service.refresh_session(db, data.refresh_token, meta))


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(data: RefreshIn, db: DB) -> Response:
    await service.logout(db, data.refresh_token)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/logout-all", status_code=status.HTTP_204_NO_CONTENT)
async def logout_all(user: CurrentUser, db: DB) -> Response:
    """Cierra la sesión en todos los dispositivos."""
    await service.invalidate_sessions(db, user, RevokeReason.LOGOUT)
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/forgot-password", status_code=status.HTTP_202_ACCEPTED)
async def forgot_password(
    data: ForgotPasswordIn, request: Request, db: DB, redis: RedisDep, mailer: Mailer
) -> dict[str, str]:
    await hit(redis, "forgot-ip", client_ip(request), limit=10, window_seconds=HOUR)
    await hit(redis, "forgot-email", data.email, limit=3, window_seconds=HOUR)
    await service.request_password_reset(db, data.email, mailer)
    # Misma respuesta exista o no la cuenta.
    return {"message": t(FORGOT_RESPONSE_TEXT)}


@router.post("/reset-password", status_code=status.HTTP_204_NO_CONTENT)
async def reset_password(
    data: ResetPasswordIn, request: Request, db: DB, redis: RedisDep, mailer: Mailer
) -> Response:
    await hit(redis, "token-ip", client_ip(request), limit=20, window_seconds=HOUR)
    user = await service.reset_password(db, data.token, data.password, mailer)
    await lockout.clear(redis, user.email)  # quien recupera su contraseña queda desbloqueado
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/verify-email", status_code=status.HTTP_204_NO_CONTENT)
async def verify_email(data: TokenIn, request: Request, db: DB, redis: RedisDep) -> Response:
    await hit(redis, "token-ip", client_ip(request), limit=20, window_seconds=HOUR)
    await service.verify_email(db, data.token)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/resend-verification", status_code=status.HTTP_204_NO_CONTENT)
async def resend_verification(
    user: CurrentUser, db: DB, redis: RedisDep, mailer: Mailer
) -> Response:
    await hit(redis, "resend-verify", str(user.id), limit=3, window_seconds=HOUR)
    if user.email_verified_at is None:
        await service.send_verification(db, user, mailer)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/me", response_model=MeOut)
async def me(user: CurrentUser) -> MeOut:
    return MeOut.model_validate(user)
