"""Bloqueo progresivo por cuenta ante intentos fallidos de inicio de sesión.

Complementa el límite por IP: un ataque distribuido desde muchas direcciones
contra una misma cuenta también se frena. Se cuenta por email (exista o no la
cuenta), así la respuesta no revela qué cuentas existen.

Escalones: 5 fallos → 1 minuto; 10 → 15 minutos; 15 o más → 60 minutos.
Las esperas son cortas a propósito: un bloqueo por cuenta permite a un tercero
molestar a alguien, y la recuperación de contraseña siempre sigue disponible.
"""

import hashlib
import logging

from redis.asyncio import Redis
from redis.exceptions import RedisError

from app.core.errors import AppError

logger = logging.getLogger("app.auth.lockout")

WINDOW_SECONDS = 3600
STEPS = ((15, 3600), (10, 900), (5, 60))  # (fallos, segundos de bloqueo), de mayor a menor


def _key(kind: str, email: str) -> str:
    return f"lock:{kind}:{hashlib.sha256(email.lower().encode()).hexdigest()[:32]}"


class AccountLocked(AppError):
    status_code = 429
    code = "ACCOUNT_LOCKED"


def _locked_error(seconds: int) -> AccountLocked:
    minutes = max(1, round(seconds / 60))
    text = "1 minuto" if minutes == 1 else f"{minutes} minutos"
    return AccountLocked(
        f"Demasiados intentos fallidos. Espere {text} o recupere su contraseña.",
        headers={"Retry-After": str(max(1, seconds))},
    )


async def check(redis: Redis, email: str) -> None:
    """Lanza AccountLocked si la cuenta está en espera."""
    try:
        ttl = await redis.ttl(_key("until", email))
    except RedisError:
        return  # sin Redis no se bloquea: preferimos no dejar a todos afuera
    if ttl and ttl > 0:
        raise _locked_error(int(ttl))


async def register_failure(redis: Redis, email: str) -> int | None:
    """Suma un fallo. Devuelve los segundos de bloqueo si se alcanzó un escalón."""
    try:
        count = int(await redis.incr(_key("fails", email)))
        if count == 1:
            await redis.expire(_key("fails", email), WINDOW_SECONDS)
        for threshold, seconds in STEPS:
            if count >= threshold and count % 5 == 0:
                await redis.set(_key("until", email), "1", ex=seconds)
                logger.warning("Cuenta bloqueada %ss tras %s intentos fallidos", seconds, count)
                return seconds
    except RedisError:
        logger.warning("No se pudo registrar el intento fallido: Redis no responde")
    return None


async def clear(redis: Redis, email: str) -> None:
    try:
        await redis.delete(_key("fails", email), _key("until", email))
    except RedisError:
        pass
