"""Lógica de autenticación: registro, login, rotación de tokens y recuperación."""

import logging
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from fastapi import status
from sqlalchemy import or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.models import OneTimeToken, RefreshToken, RevokeReason, TokenPurpose
from app.auth.schemas import RegisterIn
from app.auth.security import (
    create_access_token,
    create_mfa_token,
    decode_mfa_token,
    generate_opaque_token,
    hash_password,
    hash_token,
    password_needs_rehash,
    verify_password,
)
from app.core.config import get_settings
from app.core.errors import AppError, Conflict
from app.core.i18n import get_locale
from app.core.request_context import RequestMeta
from app.notifications import templates
from app.notifications.email import EmailDispatcher
from app.users.models import CustomerProfile, Role, User, UserRole, UserStatus
from app.users.rbac import ROLE_CUSTOMER

logger = logging.getLogger("app.auth")


class InvalidCredentials(AppError):
    status_code = status.HTTP_401_UNAUTHORIZED
    code = "INVALID_CREDENTIALS"
    message = "El email o la contraseña no son correctos."


class InvalidRefreshToken(AppError):
    status_code = status.HTTP_401_UNAUTHORIZED
    code = "INVALID_REFRESH_TOKEN"
    message = "La sesión expiró. Inicie sesión nuevamente."


class InvalidOneTimeToken(AppError):
    code = "INVALID_TOKEN"
    message = "El enlace no es válido o ya expiró. Solicite uno nuevo."


class AccountDisabled(AppError):
    status_code = status.HTTP_403_FORBIDDEN
    code = "ACCOUNT_DISABLED"
    message = "Esta cuenta está desactivada. Contacte con nosotros si cree que es un error."


class EmailNotVerified(AppError):
    status_code = status.HTTP_403_FORBIDDEN
    code = "EMAIL_NOT_VERIFIED"
    message = "Confirme su email para iniciar sesión. Revise su bandeja de entrada."


@dataclass(frozen=True)
class MfaChallenge:
    mfa_token: str


@dataclass(frozen=True)
class TokenPair:
    access_token: str
    expires_in: int
    refresh_token: str
    refresh_expires_in: int


def _now() -> datetime:
    return datetime.now(UTC)


async def get_user_by_email(db: AsyncSession, email: str) -> User | None:
    return await db.scalar(select(User).where(User.email == email))


async def get_role(db: AsyncSession, code: str) -> Role:
    role = await db.scalar(select(Role).where(Role.code == code))
    if role is None:  # sólo ocurre si no se aplicaron las migraciones
        raise RuntimeError(f"Falta el rol '{code}'. Ejecute las migraciones.")
    return role


# ---------------------------------------------------------------- tokens


async def issue_tokens(
    db: AsyncSession, user: User, meta: RequestMeta, family_id: uuid.UUID | None = None
) -> TokenPair:
    settings = get_settings()
    access, access_ttl = create_access_token(user.id, user.token_version)
    raw_refresh = generate_opaque_token()
    refresh_ttl = timedelta(days=settings.refresh_token_days)
    db.add(
        RefreshToken(
            user_id=user.id,
            token_hash=hash_token(raw_refresh),
            family_id=family_id or uuid.uuid4(),
            expires_at=_now() + refresh_ttl,
            ip_address=meta.ip,
            user_agent=meta.user_agent,
        )
    )
    return TokenPair(access, access_ttl, raw_refresh, int(refresh_ttl.total_seconds()))


async def revoke_family(db: AsyncSession, family_id: uuid.UUID, reason: RevokeReason) -> None:
    # También se re-etiquetan los tokens ya rotados, para cerrar la ventana de gracia.
    await db.execute(
        update(RefreshToken)
        .where(
            RefreshToken.family_id == family_id,
            or_(
                RefreshToken.revoked_at.is_(None),
                RefreshToken.revoked_reason == RevokeReason.ROTATED,
            ),
        )
        .values(revoked_at=_now(), revoked_reason=reason)
    )


async def revoke_all_for_user(db: AsyncSession, user_id: uuid.UUID, reason: RevokeReason) -> None:
    await db.execute(
        update(RefreshToken)
        .where(
            RefreshToken.user_id == user_id,
            or_(
                RefreshToken.revoked_at.is_(None),
                RefreshToken.revoked_reason == RevokeReason.ROTATED,
            ),
        )
        .values(revoked_at=_now(), revoked_reason=reason)
    )


async def invalidate_sessions(db: AsyncSession, user: User, reason: RevokeReason) -> None:
    """Cierra todas las sesiones: refresh tokens revocados y access tokens invalidados."""
    user.token_version += 1
    await revoke_all_for_user(db, user.id, reason)


async def refresh_session(db: AsyncSession, raw_token: str, meta: RequestMeta) -> TokenPair:
    settings = get_settings()
    token = await db.scalar(
        select(RefreshToken)
        .where(RefreshToken.token_hash == hash_token(raw_token))
        .with_for_update()
    )
    if token is None:
        raise InvalidRefreshToken()

    now = _now()
    if token.revoked_at is not None:
        in_grace = (
            token.revoked_reason == RevokeReason.ROTATED
            and token.revoked_at > now - timedelta(seconds=settings.refresh_reuse_grace_seconds)
        )
        if not in_grace:
            # Un token ya usado vuelve a aparecer: posible robo. Se cierra la familia completa.
            logger.warning("Reutilización de refresh token detectada (familia %s)", token.family_id)
            await revoke_family(db, token.family_id, RevokeReason.REUSE_DETECTED)
            await db.commit()
            raise InvalidRefreshToken()
        # Dentro de la ventana de gracia: peticiones paralelas del mismo cliente.
    elif token.expires_at <= now:
        raise InvalidRefreshToken()

    user = await db.get(User, token.user_id)
    if user is None or not user.is_active:
        await revoke_family(db, token.family_id, RevokeReason.ACCOUNT_DISABLED)
        await db.commit()
        raise InvalidRefreshToken()

    if token.revoked_at is None:
        token.revoked_at = now
        token.revoked_reason = RevokeReason.ROTATED
    pair = await issue_tokens(db, user, meta, family_id=token.family_id)
    await db.commit()
    return pair


async def logout(db: AsyncSession, raw_token: str) -> None:
    token = await db.scalar(
        select(RefreshToken).where(RefreshToken.token_hash == hash_token(raw_token))
    )
    if token is not None:
        await revoke_family(db, token.family_id, RevokeReason.LOGOUT)
        await db.commit()


# ---------------------------------------------------------------- tokens de un solo uso


async def create_one_time_token(
    db: AsyncSession, user: User, purpose: TokenPurpose, ttl: timedelta
) -> str:
    # Invalida enlaces anteriores del mismo tipo: sólo el último es válido.
    await db.execute(
        update(OneTimeToken)
        .where(
            OneTimeToken.user_id == user.id,
            OneTimeToken.purpose == purpose,
            OneTimeToken.used_at.is_(None),
        )
        .values(used_at=_now())
    )
    raw = generate_opaque_token()
    db.add(
        OneTimeToken(
            user_id=user.id, purpose=purpose, token_hash=hash_token(raw), expires_at=_now() + ttl
        )
    )
    return raw


async def consume_one_time_token(db: AsyncSession, raw: str, purpose: TokenPurpose) -> User:
    token = await db.scalar(
        select(OneTimeToken)
        .where(OneTimeToken.token_hash == hash_token(raw), OneTimeToken.purpose == purpose)
        .with_for_update()
    )
    if token is None or token.used_at is not None or token.expires_at <= _now():
        raise InvalidOneTimeToken()
    user = await db.get(User, token.user_id)
    if user is None or user.status == UserStatus.SUSPENDED:
        raise InvalidOneTimeToken()
    token.used_at = _now()
    return user


async def send_verification(db: AsyncSession, user: User, mailer: EmailDispatcher) -> None:
    ttl = timedelta(hours=get_settings().email_verification_hours)
    raw = await create_one_time_token(db, user, TokenPurpose.EMAIL_VERIFICATION, ttl)
    await db.commit()
    await mailer.send(templates.verification_email(user.email, user.first_name, raw, user.locale))


# ---------------------------------------------------------------- casos de uso


async def register(db: AsyncSession, data: RegisterIn, mailer: EmailDispatcher) -> User:
    if await get_user_by_email(db, data.email):
        raise Conflict(
            "Ya existe una cuenta con este email. Inicie sesión o recupere su contraseña.",
            code="EMAIL_TAKEN",
            fields={"email": "Este email ya está registrado."},
        )
    user = User(
        email=data.email,
        password_hash=hash_password(data.password),
        first_name=data.first_name,
        last_name=data.last_name,
        phone=data.phone,
        locale=get_locale(),  # el idioma en que navegaba al registrarse
    )
    db.add(user)
    await db.flush()
    db.add(UserRole(user_id=user.id, role_id=(await get_role(db, ROLE_CUSTOMER)).id))
    db.add(
        CustomerProfile(
            user_id=user.id,
            marketing_consent=data.marketing_consent,
            terms_accepted_at=_now(),
        )
    )
    await send_verification(db, user, mailer)  # hace commit
    await db.refresh(user)
    return user


async def login(
    db: AsyncSession, email: str, password: str, meta: RequestMeta
) -> "TokenPair | MfaChallenge":
    user = await get_user_by_email(db, email)
    # verify_password compara contra un hash ficticio si el usuario no existe,
    # para que ambos casos tarden lo mismo.
    if not verify_password(password, user.password_hash if user else None) or user is None:
        raise InvalidCredentials()
    # El estado se revela sólo a quien conoce la contraseña.
    if not user.is_active:
        raise AccountDisabled()
    if get_settings().require_email_verification and user.email_verified_at is None:
        raise EmailNotVerified()

    if password_needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)
    if user.mfa_enabled:
        await db.commit()
        return MfaChallenge(create_mfa_token(user.id, user.token_version))
    user.last_login_at = _now()
    pair = await issue_tokens(db, user, meta)
    await db.commit()
    return pair


class InvalidMfaCode(AppError):
    code = "INVALID_MFA_CODE"
    message = (
        "El código no es correcto o ya se usó. Revise la hora de su teléfono e inténtelo de nuevo."
    )

    def __init__(self) -> None:
        super().__init__(fields={"code": self.message})


def check_second_factor(user: User, code: str) -> str:
    """Valida un código TOTP o de respaldo y lo consume. Devuelve cuál se usó."""
    from app.auth import mfa
    from app.core.crypto import decrypt

    if mfa.looks_like_backup(code):
        digest = mfa.hash_backup(code)
        if digest in user.mfa_backup_hashes:
            user.mfa_backup_hashes = [h for h in user.mfa_backup_hashes if h != digest]
            return "backup"
        raise InvalidMfaCode()
    if not user.mfa_secret:
        raise InvalidMfaCode()
    step = mfa.verify(decrypt(user.mfa_secret), code, user.mfa_last_step)
    if step is None:
        raise InvalidMfaCode()
    user.mfa_last_step = step
    return "totp"


async def login_second_factor(
    db: AsyncSession, token: str, code: str, meta: RequestMeta
) -> TokenPair:
    payload = decode_mfa_token(token)
    if payload is None:
        raise InvalidRefreshToken(
            "El tiempo para ingresar el código terminó. Inicie sesión de nuevo.",
            code="MFA_TOKEN_INVALID",
        )
    user = await db.scalar(
        select(User).where(User.id == uuid.UUID(payload["sub"])).with_for_update()
    )
    if (
        user is None
        or not user.is_active
        or payload["ver"] != user.token_version
        or not user.mfa_enabled
    ):
        raise InvalidRefreshToken(code="MFA_TOKEN_INVALID")
    check_second_factor(user, code)
    user.last_login_at = _now()
    pair = await issue_tokens(db, user, meta)
    await db.commit()
    return pair


async def request_password_reset(db: AsyncSession, email: str, mailer: EmailDispatcher) -> None:
    """No revela si el email existe: el endpoint responde igual en ambos casos."""
    user = await get_user_by_email(db, email)
    if user is None or user.status == UserStatus.SUSPENDED:
        return
    ttl = timedelta(minutes=get_settings().password_reset_minutes)
    raw = await create_one_time_token(db, user, TokenPurpose.PASSWORD_RESET, ttl)
    await db.commit()
    await mailer.send(templates.password_reset_email(user.email, user.first_name, raw, user.locale))


async def set_new_password(
    db: AsyncSession, user: User, new_password: str, mailer: EmailDispatcher
) -> None:
    user.password_hash = hash_password(new_password)
    await invalidate_sessions(db, user, RevokeReason.PASSWORD_CHANGED)
    await db.commit()
    await mailer.send(templates.password_changed_email(user.email, user.first_name, user.locale))


async def reset_password(
    db: AsyncSession, raw_token: str, new_password: str, mailer: EmailDispatcher
) -> User:
    user = await consume_one_time_token(db, raw_token, TokenPurpose.PASSWORD_RESET)
    # Quien usa el enlace demostró acceso al buzón: el email queda verificado.
    if user.email_verified_at is None:
        user.email_verified_at = _now()
    await set_new_password(db, user, new_password, mailer)
    return user


async def verify_email(db: AsyncSession, raw_token: str) -> None:
    user = await consume_one_time_token(db, raw_token, TokenPurpose.EMAIL_VERIFICATION)
    user.email_verified_at = user.email_verified_at or _now()
    await db.commit()
