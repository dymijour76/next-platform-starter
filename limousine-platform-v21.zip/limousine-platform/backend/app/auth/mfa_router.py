"""Gestión de la verificación en dos pasos: /users/me/mfa/* y restablecimiento por el personal."""

import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.audit.service import record
from app.auth import mfa
from app.auth.deps import DB, CurrentUser, RedisDep, require
from app.auth.router import Mailer, Meta
from app.auth.security import verify_password
from app.auth.service import check_second_factor
from app.core.config import get_settings
from app.core.crypto import decrypt, encrypt
from app.core.errors import AppError, Conflict, PermissionDenied
from app.core.rate_limit import hit
from app.notifications import templates
from app.users.models import User
from app.users.service import WrongPassword, get_user

router = APIRouter(tags=["mfa"])


class PasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)


class CodeIn(BaseModel):
    code: str = Field(min_length=6, max_length=12)


class DisableIn(PasswordIn, CodeIn):
    pass


class SetupOut(BaseModel):
    secret: str  # para ingresarlo a mano si no se puede escanear el QR
    otpauth_uri: str


class BackupCodesOut(BaseModel):
    backup_codes: list[str]  # se muestran una sola vez


async def _limit(redis: RedisDep, user: User) -> None:
    await hit(redis, "mfa-manage", str(user.id), limit=10, window_seconds=900)


@router.post("/users/me/mfa/setup", response_model=SetupOut)
async def setup(data: PasswordIn, user: CurrentUser, db: DB, redis: RedisDep) -> SetupOut:
    """Primer paso: genera un secreto nuevo (aún no activo) para escanear con la aplicación."""
    await _limit(redis, user)
    if not verify_password(data.current_password, user.password_hash):
        raise WrongPassword()
    if user.mfa_enabled:
        raise Conflict("La verificación en dos pasos ya está activa.", code="MFA_ALREADY_ENABLED")
    secret = mfa.new_secret()
    user.mfa_pending_secret = encrypt(secret)
    await db.commit()
    issuer = "Limousine Platform"
    return SetupOut(secret=secret, otpauth_uri=mfa.provisioning_uri(secret, user.email, issuer))


@router.post("/users/me/mfa/enable", response_model=BackupCodesOut)
async def enable(
    data: CodeIn, user: CurrentUser, db: DB, redis: RedisDep, meta: Meta, mailer: Mailer
) -> BackupCodesOut:
    """Segundo paso: confirma con un código de la aplicación y entrega los códigos de respaldo."""
    await _limit(redis, user)
    if not user.mfa_pending_secret:
        raise AppError("Primero inicie la configuración.", code="MFA_NOT_STARTED")
    secret = decrypt(user.mfa_pending_secret)
    step = mfa.verify(secret, data.code, None)
    if step is None:
        raise AppError(
            "El código no es correcto. Revise la hora de su teléfono.",
            code="INVALID_MFA_CODE",
            fields={"code": "Código incorrecto."},
        )
    codes = mfa.new_backup_codes()
    user.mfa_secret, user.mfa_pending_secret = encrypt(secret), None
    user.mfa_last_step = step
    user.mfa_backup_hashes = [mfa.hash_backup(c) for c in codes]
    user.mfa_enabled_at = datetime.now(UTC)
    record(
        db, actor_id=user.id, action="MFA_ENABLE", entity_type="user", entity_id=user.id, meta=meta
    )
    await db.commit()
    await mailer.send(
        templates.mfa_changed_email(user.email, user.first_name, enabled=True, locale=user.locale)
    )
    return BackupCodesOut(backup_codes=codes)


@router.post("/users/me/mfa/disable", status_code=204)
async def disable(
    data: DisableIn, user: CurrentUser, db: DB, redis: RedisDep, meta: Meta, mailer: Mailer
) -> None:
    await _limit(redis, user)
    if get_settings().require_staff_mfa and user.is_staff:
        raise Conflict(
            "El personal debe mantener activa la verificación en dos pasos.",
            code="MFA_REQUIRED_FOR_STAFF",
        )
    if not verify_password(data.current_password, user.password_hash):
        raise WrongPassword()
    if not user.mfa_enabled:
        return
    check_second_factor(user, data.code)
    _clear(user)
    record(
        db, actor_id=user.id, action="MFA_DISABLE", entity_type="user", entity_id=user.id, meta=meta
    )
    await db.commit()
    await mailer.send(
        templates.mfa_changed_email(user.email, user.first_name, enabled=False, locale=user.locale)
    )


@router.post("/users/me/mfa/backup-codes", response_model=BackupCodesOut)
async def regenerate(data: CodeIn, user: CurrentUser, db: DB, redis: RedisDep) -> BackupCodesOut:
    """Genera códigos nuevos; los anteriores dejan de servir."""
    await _limit(redis, user)
    if not user.mfa_enabled:
        raise AppError("La verificación en dos pasos no está activa.", code="MFA_NOT_ENABLED")
    check_second_factor(user, data.code)
    codes = mfa.new_backup_codes()
    user.mfa_backup_hashes = [mfa.hash_backup(c) for c in codes]
    await db.commit()
    return BackupCodesOut(backup_codes=codes)


def _clear(user: User) -> None:
    user.mfa_secret = user.mfa_pending_secret = None
    user.mfa_enabled_at = user.mfa_last_step = None
    user.mfa_backup_hashes = []


@router.post("/users/{user_id}/mfa/reset", status_code=204)
async def admin_reset(
    user_id: uuid.UUID,
    actor: Annotated[User, Depends(require("users:write"))],
    db: DB,
    meta: Meta,
    mailer: Mailer,
) -> None:
    """Para quien perdió el teléfono y los códigos de respaldo. Queda en la auditoría."""
    target = await get_user(db, user_id)
    if target.id == actor.id:
        raise PermissionDenied(
            "Pídale a otro administrador que restablezca su verificación.", code="SELF_MODIFICATION"
        )
    if not target.permission_codes <= actor.permission_codes:
        raise PermissionDenied(code="PRIVILEGE_ESCALATION")
    _clear(target)
    target.token_version += 1  # cierra sus sesiones
    record(
        db,
        actor_id=actor.id,
        action="MFA_RESET",
        entity_type="user",
        entity_id=target.id,
        meta=meta,
    )
    await db.commit()
    await mailer.send(
        templates.mfa_changed_email(
            target.email, target.first_name, enabled=False, locale=target.locale
        )
    )
