from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, EmailStr, Field, ValidationInfo, field_validator

from app.auth.passwords import MAX_LENGTH, validate_password
from app.core.validators import clean_text, normalize_phone

Name = Annotated[str, Field(min_length=1, max_length=100), AfterValidator(clean_text)]


def _lower_email(value: str) -> str:
    return value.strip().lower()


Email = Annotated[EmailStr, AfterValidator(_lower_email)]


def _check_new_password(value: str, info: ValidationInfo) -> str:
    return validate_password(value, email=info.data.get("email"))


def _check_confirmation(value: str, info: ValidationInfo) -> str:
    if "password" in info.data and value != info.data["password"]:
        raise ValueError("Las contraseñas no coinciden.")
    return value


NewPassword = Annotated[str, Field(max_length=MAX_LENGTH), AfterValidator(_check_new_password)]
PasswordConfirmation = Annotated[
    str, Field(max_length=MAX_LENGTH), AfterValidator(_check_confirmation)
]


class NewPasswordMixin(BaseModel):
    """Contraseña nueva con confirmación. Cada error queda asociado a su propio campo."""

    password: NewPassword
    password_confirmation: PasswordConfirmation


class RegisterIn(BaseModel):
    # El email va antes que la contraseña para que la política pueda compararlos.
    email: Email
    password: NewPassword
    password_confirmation: PasswordConfirmation
    first_name: Name
    last_name: Name
    phone: str | None = Field(default=None, max_length=25)
    accept_terms: bool
    marketing_consent: bool = False

    _phone = field_validator("phone")(lambda cls, v: normalize_phone(v))

    @field_validator("accept_terms")
    @classmethod
    def _terms(cls, v: bool) -> bool:
        if not v:
            raise ValueError("Debe aceptar los términos y condiciones.")
        return v


class LoginIn(BaseModel):
    email: Email
    password: str = Field(min_length=1, max_length=MAX_LENGTH)


class MfaChallengeOut(BaseModel):
    """La contraseña es correcta, pero falta el código de verificación."""

    mfa_required: Literal[True] = True
    mfa_token: str
    expires_in: int


class MfaLoginIn(BaseModel):
    mfa_token: str = Field(min_length=20, max_length=1000)
    # Código de la aplicación (6 dígitos) o código de respaldo (xxxx-xxxx).
    code: str = Field(min_length=6, max_length=12)


class RefreshIn(BaseModel):
    refresh_token: str = Field(min_length=20, max_length=200)


class TokenPairOut(BaseModel):
    access_token: str
    token_type: Literal["bearer"] = "bearer"  # noqa: S105
    expires_in: int
    refresh_token: str
    refresh_expires_in: int


class ForgotPasswordIn(BaseModel):
    email: Email


class TokenIn(BaseModel):
    token: str = Field(min_length=20, max_length=200)


class ResetPasswordIn(NewPasswordMixin):
    token: str = Field(min_length=20, max_length=200)
