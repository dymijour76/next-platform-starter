"""Dependencias de autenticación y autorización.

Uso en un endpoint:

    @router.get("/reservations")
    async def list_reservations(user: Annotated[User, Depends(require("reservations:read"))]):
        ...

El usuario se carga de la base de datos en cada petición (no se confía en los
roles del token), así que un cambio de roles o una suspensión rige de inmediato.
"""

import uuid
from collections.abc import Awaitable, Callable
from typing import Annotated

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.security import decode_access_token
from app.core.config import get_settings
from app.core.errors import NotAuthenticated, PermissionDenied
from app.core.redis import redis_client
from app.db.session import get_db
from app.users.models import User

_bearer = HTTPBearer(auto_error=False)

DB = Annotated[AsyncSession, Depends(get_db)]


def get_redis() -> Redis:
    return redis_client


RedisDep = Annotated[Redis, Depends(get_redis)]

_UNAUTH_HEADERS = {"WWW-Authenticate": "Bearer"}


async def get_current_user(
    db: DB, credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)]
) -> User:
    if credentials is None:
        raise NotAuthenticated(headers=_UNAUTH_HEADERS)
    payload = decode_access_token(credentials.credentials)
    if payload is None:
        raise NotAuthenticated(
            "La sesión expiró. Inicie sesión nuevamente.",
            code="TOKEN_INVALID",
            headers=_UNAUTH_HEADERS,
        )
    try:
        user_id = uuid.UUID(payload["sub"])
    except ValueError:
        raise NotAuthenticated(code="TOKEN_INVALID", headers=_UNAUTH_HEADERS) from None

    user = await db.get(User, user_id)
    # token_version distinto: la contraseña cambió o la cuenta se desactivó después
    # de emitir el token.
    if user is None or not user.is_active or payload["ver"] != user.token_version:
        raise NotAuthenticated(
            "La sesión ya no es válida. Inicie sesión nuevamente.",
            code="TOKEN_REVOKED",
            headers=_UNAUTH_HEADERS,
        )
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


def require(*permissions: str) -> Callable[[User], Awaitable[User]]:
    """Exige que el usuario tenga todos los permisos indicados."""
    required = frozenset(permissions)

    async def dependency(user: CurrentUser) -> User:
        if not required <= user.permission_codes:
            raise PermissionDenied()
        if get_settings().require_staff_mfa and user.is_staff and not user.mfa_enabled:
            raise PermissionDenied(
                "Active la verificación en dos pasos para usar el panel de administración.",
                code="MFA_REQUIRED",
            )
        return user

    return dependency
