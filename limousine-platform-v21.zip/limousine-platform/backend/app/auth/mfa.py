"""Verificación en dos pasos (TOTP, RFC 6238) y códigos de respaldo."""

import hashlib
import secrets
from datetime import UTC, datetime

import pyotp

INTERVAL = 30
# Se acepta el código del intervalo anterior y del siguiente (relojes desfasados).
DRIFT = 1
BACKUP_COUNT = 10
_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"  # sin 0/o, 1/l/i: se dictan y copian sin errores


def new_secret() -> str:
    return pyotp.random_base32()


def provisioning_uri(secret: str, email: str, issuer: str) -> str:
    return pyotp.TOTP(secret, interval=INTERVAL).provisioning_uri(name=email, issuer_name=issuer)


def verify(secret: str, code: str, last_step: int | None) -> int | None:
    """Devuelve el intervalo del código si es válido y no se usó antes; si no, None."""
    code = code.strip().replace(" ", "")
    if not (code.isdigit() and len(code) == 6):
        return None
    totp = pyotp.TOTP(secret, interval=INTERVAL)
    now = datetime.now(UTC)
    current = totp.timecode(now)
    for step in range(current - DRIFT, current + DRIFT + 1):
        if secrets.compare_digest(totp.generate_otp(step), code):
            # Un código ya usado (o anterior al último usado) no vale otra vez.
            if last_step is not None and step <= last_step:
                return None
            return step
    return None


def new_backup_codes() -> list[str]:
    def one() -> str:
        raw = "".join(secrets.choice(_ALPHABET) for _ in range(8))
        return f"{raw[:4]}-{raw[4:]}"

    return [one() for _ in range(BACKUP_COUNT)]


def hash_backup(code: str) -> str:
    normalized = code.strip().lower().replace("-", "").replace(" ", "")
    return hashlib.sha256(normalized.encode()).hexdigest()


def looks_like_backup(code: str) -> bool:
    normalized = code.strip().lower().replace("-", "").replace(" ", "")
    return len(normalized) == 8 and all(c in _ALPHABET for c in normalized)
