"""Middleware transversal: identificador de request y cabeceras de seguridad."""

import logging
import re
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

from app.core.config import get_settings
from app.core.i18n import negotiate, set_locale

logger = logging.getLogger("app.request")

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), camera=(), microphone=()",
    # La API sólo entrega JSON e imágenes: nada se ejecuta ni se incrusta.
    "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'",
    "Cross-Origin-Resource-Policy": "same-origin",
}

# Un X-Request-ID que venga de afuera se acepta sólo si es corto y sin caracteres
# raros: si no, un cliente podría inyectar saltos de línea en los registros.
_REQUEST_ID = re.compile(r"[A-Za-z0-9._-]{1,64}")


def _request_id(value: str | None) -> str:
    return value if value and _REQUEST_ID.fullmatch(value) else str(uuid.uuid4())


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        request_id = _request_id(request.headers.get("X-Request-ID"))
        # Idioma de la petición (el sitio lo envía en Accept-Language).
        set_locale(negotiate(request.headers.get("Accept-Language")))
        request.state.request_id = request_id
        start = time.perf_counter()
        response = await call_next(request)
        elapsed_ms = round((time.perf_counter() - start) * 1000, 1)

        response.headers["X-Request-ID"] = request_id
        path = request.url.path
        for header, value in SECURITY_HEADERS.items():
            response.headers.setdefault(header, value)
        if path.startswith("/media/"):
            # Las imágenes las muestra el sitio, que está en otro origen.
            response.headers["Cross-Origin-Resource-Policy"] = "cross-origin"
        if path.startswith(("/docs", "/redoc")):
            # La documentación interactiva (sólo en desarrollo) necesita scripts.
            del response.headers["Content-Security-Policy"]
        if get_settings().is_production:
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"

        logger.info(
            "%s %s -> %s (%sms)",
            request.method,
            request.url.path,
            response.status_code,
            elapsed_ms,
            extra={"request_id": request_id},
        )
        return response
