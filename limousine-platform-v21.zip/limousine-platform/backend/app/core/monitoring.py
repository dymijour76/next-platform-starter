"""Reporte de errores a Sentry (opcional: sólo si SENTRY_DSN está configurado).

No se envían datos personales: ni IP, ni cuerpo de las peticiones, ni cookies ni
cabeceras de autorización. Sí el tipo de error, dónde ocurrió y el request_id,
para cruzarlo con los registros.
"""

import logging
from typing import Any

from app.core.config import get_settings

logger = logging.getLogger("app.monitoring")
_SENSITIVE = {"authorization", "cookie", "x-proxy-secret", "x-client-ip"}


def _scrub(event: dict[str, Any], _hint: dict[str, Any]) -> dict[str, Any]:
    request = event.get("request") or {}
    headers = request.get("headers") or {}
    request["headers"] = {
        k: ("[filtrado]" if k.lower() in _SENSITIVE else v) for k, v in headers.items()
    }
    request.pop("data", None)
    request.pop("cookies", None)
    event.get("user", {}).pop("ip_address", None)
    return event


def init_monitoring(component: str) -> None:
    settings = get_settings()
    if not settings.sentry_dsn:
        return
    import sentry_sdk

    sentry_sdk.init(
        dsn=settings.sentry_dsn,
        environment=settings.environment,
        release=settings.app_version,
        send_default_pii=False,
        traces_sample_rate=settings.sentry_traces_sample_rate,
        before_send=_scrub,  # type: ignore[arg-type]
    )
    sentry_sdk.set_tag("component", component)
    logger.info("Reporte de errores activo (%s)", component)
