"""Validadores reutilizables para los esquemas de entrada."""

import re
import unicodedata

from pydantic import BeforeValidator

_PHONE_RE = re.compile(r"^\+?[0-9]{8,15}$")


def clean_text(value: str) -> str:
    """Quita espacios sobrantes y rechaza caracteres de control."""
    value = " ".join(value.split())
    if any(unicodedata.category(c) == "Cc" for c in value):
        raise ValueError("Contiene caracteres no permitidos.")
    return value


def normalize_phone(value: str | None) -> str | None:
    if value is None:
        return None
    compact = re.sub(r"[\s\-().]", "", value)
    if not compact:
        return None
    if not _PHONE_RE.match(compact):
        raise ValueError("Ingrese un teléfono válido, por ejemplo +56 9 1234 5678.")
    return compact


def normalize_rut(value: str | None) -> str | None:
    """Valida un RUT chileno (módulo 11) y lo devuelve como 12345678-K."""
    if value is None:
        return None
    compact = re.sub(r"[.\s]", "", value).upper().replace("\u2010", "-")
    if not compact:
        return None
    match = re.fullmatch(r"(\d{7,8})-?([\dK])", compact)
    if not match:
        raise ValueError("Ingrese un RUT válido, por ejemplo 12.345.678-5.")
    body, dv = match.groups()
    total, factor = 0, 2
    for digit in reversed(body):
        total += int(digit) * factor
        factor = 2 if factor == 7 else factor + 1
    expected = 11 - total % 11
    expected_dv = {11: "0", 10: "K"}.get(expected, str(expected))
    if dv != expected_dv:
        raise ValueError("El RUT no es válido: revise el dígito verificador.")
    return f"{body}-{dv}"


def normalize_plate(value: str) -> str:
    """Patente chilena: formato antiguo AB1234 o actual BCDF12, sin puntos ni guiones."""
    compact = re.sub(r"[\s\-·.]", "", value).upper()
    if not re.fullmatch(r"[A-Z]{2}\d{4}|[A-Z]{4}\d{2}", compact):
        raise ValueError("Ingrese una patente válida, por ejemplo BCDF12 o AB1234.")
    return compact


def _blank_to_none(value: object) -> object:
    """Texto limpio, o None si viene vacío (antes de aplicar el largo máximo)."""
    if isinstance(value, str):
        return clean_text(value) or None
    return value


# Uso: Annotated[Annotated[str, Field(max_length=N)] | None, BlankToNone]
# El largo va sólo en la rama de texto ("texto de hasta N caracteres, o nada"). Si se pone sobre
# un tipo que admite None, Pydantic falla con TypeError ante None: un error interno (500) en vez
# de un error de validación.
BlankToNone = BeforeValidator(_blank_to_none)
