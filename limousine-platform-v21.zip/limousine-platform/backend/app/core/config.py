"""Configuración de la aplicación, leída exclusivamente desde variables de entorno.

Ningún secreto se define en el código: los valores por defecto sólo sirven para
desarrollo local y la validación impide arrancar en producción con valores inseguros.
"""

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

INSECURE_SECRET = "change-me"  # noqa: S105 - marcador de desarrollo, rechazado en producción


def normalize_database_url(url: str) -> str:
    """Acepta la URL tal como la entregan los proveedores (Render, Neon, Supabase:
    postgres://…?sslmode=require) y la adapta al controlador asyncpg."""
    from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

    for prefix in ("postgres://", "postgresql://"):
        if url.startswith(prefix):
            url = "postgresql+asyncpg://" + url[len(prefix) :]
            break
    parts = urlsplit(url)
    if not parts.query:
        return url
    query = []
    for key, value in parse_qsl(parts.query, keep_blank_values=True):
        if key == "sslmode":
            # asyncpg usa "ssl"; disable/allow/prefer no exigen cifrado.
            if value in ("require", "verify-ca", "verify-full"):
                query.append(("ssl", value))
        elif key not in ("channel_binding",):
            query.append((key, value))
    return urlunsplit(parts._replace(query=urlencode(query)))


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    # Aplicación
    app_name: str = "Limousine Platform API"
    # Versión desplegada (la fija el despliegue, p. ej. el commit): aparece en los errores.
    app_version: str = "dev"
    environment: Literal["development", "test", "staging", "production"] = "development"
    debug: bool = False
    api_v1_prefix: str = "/api/v1"
    log_level: str = "INFO"

    # Seguridad
    jwt_secret: str = INSECURE_SECRET
    jwt_algorithm: str = "HS256"
    jwt_issuer: str = "limousine-platform"
    access_token_minutes: int = 15
    refresh_token_days: int = 30
    # Ventana en la que un refresh token recién rotado aún se acepta (peticiones paralelas).
    refresh_reuse_grace_seconds: int = 30
    password_reset_minutes: int = 60
    email_verification_hours: int = 48
    # Si es true, no se puede iniciar sesión sin verificar el email.
    require_email_verification: bool = False
    # Secreto compartido con el sitio: sólo con él la API acepta la IP del cliente que el
    # sitio reenvía en X-Client-IP. Sin él, la API vería la IP del sitio en todas las
    # peticiones y los límites por IP se aplicarían a todos los usuarios juntos.
    internal_proxy_secret: str = ""
    # Tasas de cambio para precios de referencia (acceso abierto de ExchangeRate-API; requiere
    # mostrar la atribución). Base CLP: la respuesta trae unidades de cada moneda por 1 peso.
    exchange_rate_url: str = "https://open.er-api.com/v6/latest/CLP"
    # Billetera. La recarga con dinero queda desactivada hasta que un abogado confirme que la
    # empresa puede custodiar fondos de clientes (Ley 20.950: medios de pago con provisión
    # de fondos).
    wallet_topup_enabled: bool = False
    wallet_topup_min: int = 10_000
    wallet_topup_max: int = 1_000_000
    wallet_credit_max: int = (
        1_000_000  # tope de un crédito otorgado por el personal (evita errores de tipeo)
    )
    # Tipografías del comprobante en PDF (paquetes fonts-wqy-microhei y fonts-dejavu-core).
    pdf_font_body: str = "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc"
    pdf_font_bold: str = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
    # Reporte de errores (opcional). Vacío: desactivado.
    sentry_dsn: str = ""
    sentry_traces_sample_rate: float = 0.0
    # Si es true, el personal debe activar la verificación en dos pasos para usar el panel.
    require_staff_mfa: bool = False
    # Clave para cifrar datos sensibles en la base (secretos TOTP). Fernet, base64 de 32 bytes:
    # python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    field_encryption_key: str = ""
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000"])

    # URL pública del sitio, usada en los enlaces de los emails
    frontend_url: str = "http://localhost:3000"

    # Pagos
    # simulated: pantalla de prueba para desarrollo (prohibido en producción).
    payment_provider: Literal["simulated", "webpay"] = "simulated"
    # Webpay Plus (Transbank). Los valores por defecto son las credenciales
    # públicas del ambiente de integración que publica Transbank.
    webpay_environment: Literal["integration", "production"] = "integration"
    webpay_commerce_code: str = "597055555532"
    webpay_api_key: str = "579B532A7440BB0C9079DED94D31EA1615BACEB56610332264630D42D0A36B1C"
    # Minutos para completar el pago en la pasarela antes de dar el intento por abandonado.
    payment_window_minutes: int = 15

    # Imágenes
    # local: disco (desarrollo); s3: S3 o compatible (MinIO, Cloudflare R2) en producción.
    storage_backend: Literal["local", "s3"] = "local"
    media_root: str = "./media"
    # Base pública de las imágenes: URL = MEDIA_BASE_URL + "/" + clave ("media/<id>/960.webp").
    # Local: el origen de la API. S3: el bucket o su CDN (p. ej. https://cdn.empresa.cl).
    media_base_url: str = "http://localhost:8000"
    s3_bucket: str = ""
    s3_region: str = "us-east-1"
    s3_endpoint_url: str | None = None
    s3_access_key: str = ""
    s3_secret_key: str = ""
    upload_max_mb: int = 10

    # Email
    email_backend: Literal["console", "smtp"] = "console"
    email_host: str = "localhost"
    email_port: int = 1025
    email_user: str = ""
    email_password: str = ""
    email_use_tls: bool = False
    email_from: str = "Limousine Platform <no-reply@example.com>"

    # Infraestructura
    database_url: str = "postgresql+asyncpg://limo:limo@localhost:5432/limo"
    database_pool_size: int = 10
    database_max_overflow: int = 10
    redis_url: str = "redis://localhost:6379/0"

    # Regionales (valores iniciales; luego serán configurables desde Admin > Configuración)
    default_currency: str = "CLP"
    default_timezone: str = "America/Santiago"

    @field_validator("database_url")
    @classmethod
    def _asyncpg_url(cls, url: str) -> str:
        return normalize_database_url(url)

    @model_validator(mode="after")
    def _check_production_secrets(self) -> "Settings":
        if self.environment == "production":
            if self.jwt_secret == INSECURE_SECRET or len(self.jwt_secret) < 32:
                raise ValueError("JWT_SECRET debe definirse (mínimo 32 caracteres) en producción")
            if self.debug:
                raise ValueError("DEBUG no puede estar activo en producción")
            if self.email_backend == "console":
                raise ValueError("EMAIL_BACKEND=console no es válido en producción")
            if len(self.internal_proxy_secret) < 32:
                raise ValueError(
                    "INTERNAL_PROXY_SECRET es obligatoria en producción (mínimo 32 caracteres)"
                )
            if not self.field_encryption_key:
                raise ValueError("FIELD_ENCRYPTION_KEY es obligatoria en producción")
            if self.storage_backend == "local":
                raise ValueError(
                    "STORAGE_BACKEND=local no es válido en producción: use s3 (las réplicas "
                    "de la API no comparten disco)"
                )
            if self.payment_provider == "simulated":
                raise ValueError("PAYMENT_PROVIDER=simulated no es válido en producción")
            if self.payment_provider == "webpay" and (
                self.webpay_environment != "production"
                or self.webpay_commerce_code == "597055555532"
            ):
                raise ValueError(
                    "Webpay en producción requiere WEBPAY_ENVIRONMENT=production "
                    "y credenciales propias"
                )
        return self

    @property
    def is_production(self) -> bool:
        return self.environment == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()
