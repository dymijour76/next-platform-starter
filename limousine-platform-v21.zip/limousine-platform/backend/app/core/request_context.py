"""Datos de la petición que se registran en auditoría y en los refresh tokens."""

from dataclasses import dataclass

from fastapi import Request

from app.core.rate_limit import client_ip


@dataclass(frozen=True)
class RequestMeta:
    ip: str | None
    user_agent: str | None
    request_id: str | None


def get_request_meta(request: Request) -> RequestMeta:
    ip = client_ip(request)
    return RequestMeta(
        ip=None if ip == "unknown" else ip,
        user_agent=(request.headers.get("user-agent") or "")[:512] or None,
        request_id=getattr(request.state, "request_id", None),
    )
