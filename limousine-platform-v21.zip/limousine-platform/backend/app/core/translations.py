"""Traducciones del contenido administrable (servicios, reglas de precio, carrusel).

Se guardan como {"en": {"name": "...", ...}, "fr": {...}}. El español son las
columnas normales; si falta una traducción se muestra el español.
"""

from collections.abc import Mapping
from typing import Annotated, Any, Literal

from pydantic import BaseModel, BeforeValidator, Field

from app.core.i18n import DEFAULT_LOCALE, get_locale
from app.core.validators import BlankToNone

TargetLocale = Literal["en", "fr", "ht", "zh"]


class ServiceTranslation(BaseModel):
    name: Annotated[Annotated[str, Field(max_length=100)] | None, BlankToNone] = None
    tagline: Annotated[Annotated[str, Field(max_length=200)] | None, BlankToNone] = None
    description: Annotated[str | None, Field(max_length=5000)] = None
    features: list[Annotated[str, Field(max_length=120)]] | None = Field(
        default=None, max_length=20
    )


class RuleTranslation(BaseModel):
    name: Annotated[Annotated[str, Field(max_length=100)] | None, BlankToNone] = None


class SlideTranslation(BaseModel):
    title: Annotated[Annotated[str, Field(max_length=80)] | None, BlankToNone] = None
    subtitle: Annotated[Annotated[str, Field(max_length=200)] | None, BlankToNone] = None
    cta_label: Annotated[Annotated[str, Field(max_length=30)] | None, BlankToNone] = None


def clean_translations(value: Mapping[Any, Any] | None) -> dict[str, dict[str, Any]]:
    """Quita campos vacíos e idiomas sin nada: un campo vacío no debe tapar al español."""
    out: dict[str, dict[str, Any]] = {}
    for locale, fields in (value or {}).items():
        data = fields.model_dump() if isinstance(fields, BaseModel) else dict(fields or {})
        kept: dict[str, Any] = {}
        for key, item in data.items():
            if isinstance(item, list):
                item = [x.strip() for x in item if isinstance(x, str) and x.strip()]
            elif isinstance(item, str):
                item = item.strip()
            if item:
                kept[key] = item
        if kept:
            out[locale] = kept
    return out


def localized(
    translations: Mapping[Any, Any] | None, field: str, base: Any, locale: str | None = None
) -> Any:
    """El campo en el idioma pedido, o el español si no está traducido."""
    loc = locale or get_locale()
    if loc == DEFAULT_LOCALE or not translations:
        return base
    value = (translations.get(loc) or {}).get(field)
    return value if value else base


def _validator(model: type[BaseModel]) -> Any:
    """Valida cada idioma con su modelo y guarda el resultado limpio como diccionario simple."""

    def validate(value: Any) -> Any:
        if value is None:
            return value
        if not isinstance(value, dict):
            raise ValueError("Las traducciones deben ser un objeto por idioma.")
        return clean_translations({k: model.model_validate(v or {}) for k, v in value.items()})

    return BeforeValidator(validate)


# El resultado es {"en": {"name": "..."}}; las claves se validan contra los idiomas permitidos.
ServiceTranslations = Annotated[dict[TargetLocale, dict[str, Any]], _validator(ServiceTranslation)]
RuleTranslations = Annotated[dict[TargetLocale, dict[str, Any]], _validator(RuleTranslation)]
SlideTranslations = Annotated[dict[TargetLocale, dict[str, Any]], _validator(SlideTranslation)]
