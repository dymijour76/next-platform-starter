"""Errores de la API con un formato único.

Toda respuesta de error tiene la forma:

    {"error": {"code": "INVALID_CREDENTIALS", "message": "...", "fields": {...}}}

`code` es estable y lo usan los clientes (web, móvil) para decidir qué hacer;
`message` está en español y se puede mostrar directamente al usuario;
`fields` sólo aparece en errores de validación.
"""

from typing import Any

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.i18n import translate_message


class AppError(Exception):
    status_code: int = status.HTTP_400_BAD_REQUEST
    code: str = "BAD_REQUEST"
    message: str = "La solicitud no es válida."

    def __init__(
        self,
        message: str | None = None,
        *,
        code: str | None = None,
        status_code: int | None = None,
        fields: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.message = message or self.message
        self.code = code or self.code
        self.status_code = status_code or self.status_code
        self.fields = fields
        self.headers = headers
        super().__init__(self.message)


class NotAuthenticated(AppError):
    status_code = status.HTTP_401_UNAUTHORIZED
    code = "NOT_AUTHENTICATED"
    message = "Debe iniciar sesión para continuar."


class PermissionDenied(AppError):
    status_code = status.HTTP_403_FORBIDDEN
    code = "PERMISSION_DENIED"
    message = "No tiene permisos para realizar esta acción."


class NotFound(AppError):
    status_code = status.HTTP_404_NOT_FOUND
    code = "NOT_FOUND"
    message = "El recurso solicitado no existe."


class Conflict(AppError):
    status_code = status.HTTP_409_CONFLICT
    code = "CONFLICT"


class RateLimited(AppError):
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    code = "RATE_LIMITED"
    message = "Demasiados intentos. Espere unos minutos e inténtelo de nuevo."


def _body(code: str, message: str, fields: dict[str, str] | None = None) -> dict[str, Any]:
    # Todas las respuestas de error pasan por aquí: se traducen al idioma de la petición.
    error: dict[str, Any] = {"code": code, "message": translate_message(message)}
    if fields:
        error["fields"] = {k: translate_message(v) for k, v in fields.items()}
    return {"error": error}


def _field_name(loc: tuple[Any, ...]) -> str:
    # ("body", "password") -> "password"; ("query", "page") -> "page"
    parts = [str(p) for p in loc if p not in ("body", "query", "path")]
    return ".".join(parts) or "_"


def _translate(err: dict[str, Any]) -> str:
    kind = err.get("type", "")
    ctx = err.get("ctx") or {}
    # Un campo vacío en un formulario llega como "", no como ausente.
    if kind == "missing" or err.get("input") == "":
        return "Este campo es obligatorio."
    if kind == "string_too_short":
        return f"Debe tener al menos {ctx.get('min_length')} caracteres."
    if kind == "string_too_long":
        return f"No puede superar {ctx.get('max_length')} caracteres."
    if kind == "value_error" and "email" in str(err.get("msg", "")).lower():
        return "El email no tiene un formato válido."
    if kind == "value_error":
        # Mensajes propios de los validadores: "Value error, <mensaje>"
        return str(err.get("msg", "")).removeprefix("Value error, ")
    if kind in ("uuid_parsing", "uuid_type"):
        return "Identificador no válido."
    return "Valor no válido."


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError) -> JSONResponse:
        return JSONResponse(
            _body(exc.code, exc.message, exc.fields),
            status_code=exc.status_code,
            headers=exc.headers,
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError) -> JSONResponse:
        fields: dict[str, str] = {}
        for err in exc.errors():
            fields.setdefault(_field_name(tuple(err.get("loc", ()))), _translate(err))
        return JSONResponse(
            _body("VALIDATION_ERROR", "Revise los datos ingresados.", fields),
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        messages = {404: "La ruta solicitada no existe.", 405: "Método no permitido."}
        code = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED"}.get(exc.status_code, "HTTP_ERROR")
        return JSONResponse(
            _body(code, messages.get(exc.status_code, str(exc.detail))),
            status_code=exc.status_code,
        )
