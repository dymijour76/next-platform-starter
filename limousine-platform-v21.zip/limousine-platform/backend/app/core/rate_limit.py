"""Limitación de intentos con ventana fija en Redis.

Se usa en endpoints sensibles (login, registro, recuperación de contraseña).
Al vivir en Redis, el límite se comparte entre todas las réplicas de la API.
"""

import hashlib
import hmac
import ipaddress
import logging

from fastapi import Request
from redis.asyncio import Redis
from redis.exceptions import RedisError

from app.core.config import get_settings
from app.core.errors import RateLimited

logger = logging.getLogger("app.rate_limit")


def client_ip(request: Request) -> str:
    """IP del cliente final.

    El navegador no habla con la API: habla con el sitio (Next.js), que llama a la
    API desde el servidor. El sitio reenvía la IP real en X-Client-IP junto con el
    secreto compartido; sólo entonces se acepta. Sin secreto válido, se usa la IP
    de la conexión (nadie puede falsificar su IP mandando la cabecera).
    """
    secret = get_settings().internal_proxy_secret
    if secret and hmac.compare_digest(request.headers.get("X-Proxy-Secret", ""), secret):
        forwarded = request.headers.get("X-Client-IP", "").strip()
        try:
            return str(ipaddress.ip_address(forwarded))
        except ValueError:
            pass
    return request.client.host if request.client else "unknown"


async def hit(redis: Redis, bucket: str, key: str, *, limit: int, window_seconds: int) -> None:
    """Registra un intento y lanza RateLimited si se superó el límite.

    Si Redis no responde, se permite la petición (fail-open) y se registra el
    problema: preferimos no bloquear el login de todos los clientes por una
    caída de la caché.
    """
    digest = hashlib.sha256(key.encode()).hexdigest()[:32]
    redis_key = f"rl:{bucket}:{digest}"
    try:
        async with redis.pipeline(transaction=True) as pipe:
            pipe.incr(redis_key)
            pipe.expire(redis_key, window_seconds, nx=True)
            count, _ = await pipe.execute()
            ttl = await redis.ttl(redis_key)
    except RedisError:
        logger.warning("Rate limiting deshabilitado temporalmente: Redis no responde")
        return
    if int(count) > limit:
        retry_after = max(int(ttl), 1)
        raise RateLimited(headers={"Retry-After": str(retry_after)})
