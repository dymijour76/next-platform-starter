"""Tipos para montos en los esquemas de la API.

Los montos viajan como texto decimal exacto ("125000", "19.99"), nunca como
número de coma flotante, para que ningún cliente los redondee mal.
"""

from decimal import Decimal
from typing import Annotated

from pydantic import Field, PlainSerializer


def _to_str(value: Decimal) -> str:
    return format(value.normalize(), "f")


# Monto de salida: "125000.00" se envía como "125000".
Amount = Annotated[Decimal, PlainSerializer(_to_str, return_type=str)]
# Monto de entrada: no negativo, hasta 2 decimales.
AmountIn = Annotated[Decimal, Field(ge=0, le=Decimal("999999999999"), decimal_places=2)]


def num(value: Decimal) -> str:
    """Decimal a texto sin ceros sobrantes: 60000.00 → "60000"."""
    return _to_str(value)
