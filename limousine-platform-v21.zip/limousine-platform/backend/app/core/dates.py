"""Fechas y montos en el idioma de quien los lee, sin depender de los idiomas instalados en
el servidor (los nombres de días y meses están aquí)."""

from datetime import datetime
from decimal import Decimal
from zoneinfo import ZoneInfo

_DAYS = {
    "es": ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"],
    "en": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    "fr": ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"],
    "ht": ["lendi", "madi", "mèkredi", "jedi", "vandredi", "samdi", "dimanch"],
    "zh": ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
}
_MONTHS = {
    "es": ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
           "septiembre", "octubre", "noviembre", "diciembre"],
    "en": ["January", "February", "March", "April", "May", "June", "July", "August",
           "September", "October", "November", "December"],
    "fr": ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
           "septembre", "octobre", "novembre", "décembre"],
    "ht": ["janvye", "fevriye", "mas", "avril", "me", "jen", "jiyè", "out",
           "septanm", "oktòb", "novanm", "desanm"],
}  # fmt: skip


def format_local(dt: datetime, timezone: str, locale: str | None = "es") -> str:
    """'sábado 10 de octubre de 2026, 23:00' en el idioma pedido."""
    loc = locale if locale in _DAYS else "es"
    local = dt.astimezone(ZoneInfo(timezone))
    day, hour = _DAYS[loc][local.weekday()], f"{local:%H:%M}"
    if loc == "zh":
        return f"{local.year}年{local.month}月{local.day}日（{day}）{hour}"  # noqa: RUF001
    month = _MONTHS[loc][local.month - 1]
    if loc == "es":
        return f"{day} {local.day} de {month} de {local.year}, {hour}"
    if loc == "en":
        return f"{day}, {month} {local.day}, {local.year}, {hour}"
    return f"{day} {local.day} {month} {local.year}, {hour}"  # fr, ht


def format_time(dt: datetime, timezone: str) -> str:
    return f"{dt.astimezone(ZoneInfo(timezone)):%H:%M}"


def format_money(value: Decimal, currency: str, locale: str | None = "es") -> str:
    """$125.000 (es) · CLP 125,000 (en, zh) · 125 000 CLP (fr, ht)."""
    from app.pricing.engine import CURRENCY_EXPONENT, format_amount, money

    loc = locale or "es"
    if loc == "es":
        return format_amount(value, currency)
    exponent = CURRENCY_EXPONENT.get(currency, 2)
    q = money(value, currency)
    sign = "-" if q < 0 else ""
    text = f"{abs(q):,.{exponent}f}"
    if loc in {"en", "zh"}:
        return f"{sign}{currency} {text}"
    integer, _, frac = text.partition(".")
    return f"{sign}{integer.replace(',', '\u202f')}{',' + frac if frac else ''} {currency}"
