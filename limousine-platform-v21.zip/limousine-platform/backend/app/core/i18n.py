"""Idiomas de la API: es (origen), en, fr, ht (creole haitiano), zh (chino simplificado).

Los textos del código están escritos en español y actúan como clave. Cada idioma
tiene un catálogo `app/locales/<idioma>.json` con {"texto en español": "traducción"}.
Los textos con partes variables usan marcadores: {"Ocupado en {code}": "Busy on {code}"}.

Dos formas de traducir:
- `t("Plantilla {x}", x=...)`: traduce y rellena (emails, textos armados a propósito).
- `translate_message(texto)`: reconoce un texto ya armado por su plantilla y lo
  traduce, traduciendo también las partes variables que sean textos conocidos. Lo
  usa el manejador de errores, así los mensajes de toda la API se traducen sin
  cambiar cada `raise`.
"""

import json
import re
from contextvars import ContextVar
from functools import lru_cache
from pathlib import Path
from typing import Any

LOCALES = ("es", "en", "fr", "ht", "zh")
DEFAULT_LOCALE = "es"
_current: ContextVar[str] = ContextVar("locale", default=DEFAULT_LOCALE)
_DIR = Path(__file__).resolve().parent.parent / "locales"
_PLACEHOLDER = re.compile(r"\{(\w+)\}")


def negotiate(accept_language: str | None) -> str:
    """Primer idioma soportado de la cabecera Accept-Language (respetando q=)."""
    if not accept_language:
        return DEFAULT_LOCALE
    ranked = []
    for part in accept_language.split(","):
        tag, _, q = part.strip().partition(";q=")
        try:
            weight = float(q) if q else 1.0
        except ValueError:
            weight = 0.0
        ranked.append((weight, tag.split("-")[0].lower()))
    for _, base in sorted(ranked, key=lambda x: -x[0]):
        if base in LOCALES:
            return base
    return DEFAULT_LOCALE


def set_locale(locale: str) -> None:
    _current.set(locale if locale in LOCALES else DEFAULT_LOCALE)


def get_locale() -> str:
    return _current.get()


@lru_cache
def catalog(locale: str) -> dict[str, str]:
    if locale == DEFAULT_LOCALE:
        return {}
    path = _DIR / f"{locale}.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def t(template: str, locale: str | None = None, **params: Any) -> str:
    """Traduce una plantilla y la rellena. Sin traducción, queda en español."""
    loc = locale or get_locale()
    text = catalog(loc).get(template, template)
    return text.format(**params) if params else text


@lru_cache
def _patterns() -> list[tuple[re.Pattern[str], str]]:
    """Plantillas con marcadores convertidas en expresiones regulares (las más largas primero)."""
    templates = set(catalog("en"))  # todas las claves están en todos los catálogos
    out = []
    for template in sorted(templates, key=len, reverse=True):
        if not _PLACEHOLDER.search(template):
            continue
        regex = ""
        last = 0
        seen: set[str] = set()
        for m in _PLACEHOLDER.finditer(template):
            name = m.group(1)
            # Un marcador repetido ("{tax} … {tax}") debe valer lo mismo las dos veces.
            group = f"(?P={name})" if name in seen else f"(?P<{name}>.+?)"
            seen.add(name)
            regex += re.escape(template[last : m.start()]) + group
            last = m.end()
        regex += re.escape(template[last:])
        out.append((re.compile(regex + r"\Z", re.S), template))
    return out


def translate_message(text: str, locale: str | None = None, _depth: int = 0) -> str:
    """Traduce un texto ya armado: primero exacto, luego reconociendo su plantilla."""
    loc = locale or get_locale()
    if loc == DEFAULT_LOCALE or not text or _depth > 3:
        return text
    table = catalog(loc)
    if text in table:
        return table[text]
    for pattern, template in _patterns():
        match = pattern.match(text)
        if match and template in table:
            # Las partes variables también pueden ser textos traducibles (p. ej. un motivo).
            values = {
                k: translate_message(v, loc, _depth + 1) for k, v in match.groupdict().items()
            }
            return table[template].format(**values)
    return text
