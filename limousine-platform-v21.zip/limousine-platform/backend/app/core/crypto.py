"""Cifrado de campos sensibles en la base de datos (Fernet: AES-128-CBC + HMAC-SHA256)."""

import base64
import hashlib
from functools import lru_cache

from cryptography.fernet import Fernet, InvalidToken

from app.core.config import get_settings


@lru_cache
def _fernet() -> Fernet:
    s = get_settings()
    # En producción la clave es obligatoria (config.py). En desarrollo se deriva del
    # secreto de los tokens para no pedir una variable más.
    key = (
        s.field_encryption_key
        or base64.urlsafe_b64encode(
            hashlib.sha256(f"field-encryption:{s.jwt_secret}".encode()).digest()
        ).decode()
    )
    return Fernet(key.encode())


def encrypt(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()


def decrypt(token: str) -> str:
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken as exc:
        # Clave cambiada o dato alterado: no se puede usar este secreto.
        raise ValueError("No se pudo descifrar el dato") from exc
