"""Router raíz de la API v1. Cada módulo de dominio se registra aquí."""

from fastapi import APIRouter

from app.api.v1 import health
from app.auth.mfa_router import router as mfa_router
from app.auth.router import router as auth_router
from app.carousel.router import router as carousel_router
from app.chat.router import router as chat_router
from app.currency.router import router as currency_router
from app.drivers.portal import router as driver_portal_router
from app.drivers.router import router as drivers_router
from app.media.router import router as media_router
from app.payments.router import router as payments_router
from app.pricing.router import router as pricing_router
from app.reports.router import router as reports_router
from app.reservations.router import router as reservations_router
from app.reviews.router import router as reviews_router
from app.services.router import router as services_router
from app.settings.company import router as site_router
from app.users.router import router as users_router
from app.vehicles.router import router as vehicles_router
from app.wallet.router import router as wallet_router

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth_router)
api_router.include_router(users_router)
api_router.include_router(mfa_router)
api_router.include_router(services_router)
api_router.include_router(pricing_router)
api_router.include_router(reservations_router)
api_router.include_router(payments_router)
api_router.include_router(vehicles_router)
api_router.include_router(drivers_router)
api_router.include_router(driver_portal_router)
api_router.include_router(media_router)
api_router.include_router(carousel_router)
api_router.include_router(reports_router)
api_router.include_router(site_router)
api_router.include_router(reviews_router)
api_router.include_router(wallet_router)
api_router.include_router(chat_router)
api_router.include_router(currency_router)
