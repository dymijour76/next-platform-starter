"""Endpoints de salud.

- /health/live  : el proceso responde (lo usa el orquestador para reiniciar).
- /health/ready : dependencias disponibles (lo usa el balanceador para enrutar tráfico).
"""

import asyncio
from collections.abc import Awaitable, Callable
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Response, status
from pydantic import BaseModel
from sqlalchemy import text

from app.core.config import get_settings
from app.core.redis import redis_client
from app.db.session import engine

router = APIRouter(prefix="/health", tags=["health"])

CHECK_TIMEOUT_SECONDS = 2.0

Check = Callable[[], Awaitable[None]]


async def check_database() -> None:
    async with engine.connect() as conn:
        await conn.execute(text("SELECT 1"))


async def check_redis() -> None:
    await redis_client.ping()


def get_checks() -> dict[str, Check]:
    return {"database": check_database, "redis": check_redis}


class LiveResponse(BaseModel):
    status: Literal["ok"]
    service: str
    environment: str


class ReadyResponse(BaseModel):
    status: Literal["ok", "degraded"]
    checks: dict[str, Literal["ok", "error"]]


@router.get("/live", response_model=LiveResponse)
async def live() -> LiveResponse:
    settings = get_settings()
    return LiveResponse(status="ok", service=settings.app_name, environment=settings.environment)


@router.get("/ready", response_model=ReadyResponse)
async def ready(
    response: Response, checks: Annotated[dict[str, Check], Depends(get_checks)]
) -> ReadyResponse:
    async def run(check: Check) -> Literal["ok", "error"]:
        try:
            await asyncio.wait_for(check(), timeout=CHECK_TIMEOUT_SECONDS)
            return "ok"
        except Exception:
            return "error"

    names = list(checks)
    outcomes = await asyncio.gather(*(run(checks[n]) for n in names))
    results = dict(zip(names, outcomes, strict=True))
    healthy = all(r == "ok" for r in results.values())
    if not healthy:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return ReadyResponse(status="ok" if healthy else "degraded", checks=results)


HEARTBEAT_KEY = "worker:heartbeat"
HEARTBEAT_MAX_AGE = 180  # segundos: el worker late cada minuto


class WorkerResponse(BaseModel):
    status: Literal["ok", "stale"]
    last_heartbeat: str | None
    age_seconds: int | None


@router.get("/worker", response_model=WorkerResponse)
async def worker(response: Response) -> WorkerResponse:
    """¿Está vivo el worker? Para el monitoreo externo (503 si no late hace más de 3 minutos).

    Separado de /ready a propósito: si el worker se cae, la API sigue sirviendo y no
    debe salir de circulación; pero hay que enterarse, porque sin worker no se envían
    emails ni vencen las reservas impagas.
    """
    from datetime import UTC, datetime

    from app.core.redis import redis_client

    try:
        raw = await redis_client.get(HEARTBEAT_KEY)
    except Exception:
        raw = None
    last = datetime.fromisoformat(raw.decode() if isinstance(raw, bytes) else raw) if raw else None
    age = int((datetime.now(UTC) - last).total_seconds()) if last else None
    ok = age is not None and age <= HEARTBEAT_MAX_AGE
    if not ok:
        response.status_code = 503
    return WorkerResponse(
        status="ok" if ok else "stale",
        last_heartbeat=last.isoformat() if last else None,
        age_seconds=age,
    )
