"""Módulo audit (se implementa en fases posteriores)."""
