"""Registro de operaciones administrativas.

El registro se agrega a la misma sesión que la operación, así queda guardado
en la misma transacción: o se guardan ambos, o ninguno.
"""

import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.models import AuditLog
from app.core.request_context import RequestMeta


def record(
    db: AsyncSession,
    *,
    actor_id: uuid.UUID | None,
    action: str,
    entity_type: str,
    entity_id: uuid.UUID | str | None,
    meta: RequestMeta,
    before: dict[str, Any] | None = None,
    after: dict[str, Any] | None = None,
) -> None:
    db.add(
        AuditLog(
            actor_user_id=actor_id,
            action=action,
            entity_type=entity_type,
            entity_id=str(entity_id) if entity_id is not None else None,
            before=before,
            after=after,
            ip_address=meta.ip,
            user_agent=meta.user_agent,
            request_id=meta.request_id,
        )
    )
