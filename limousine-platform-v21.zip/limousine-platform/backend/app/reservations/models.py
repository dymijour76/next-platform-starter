"""Reservas, su historial de estados y la numeración correlativa por año."""

import enum
import uuid
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Any

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    SmallInteger,
    String,
    Text,
    column,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import CITEXT, JSONB, ExcludeConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.services.models import Service

if TYPE_CHECKING:
    from app.drivers.models import Driver
    from app.payments.models import Payment
    from app.vehicles.models import Vehicle


class ReservationStatus(enum.StrEnum):
    PENDING_PAYMENT = "PENDING_PAYMENT"  # cupo retenido hasta hold_expires_at
    CONFIRMED = "CONFIRMED"
    EN_ROUTE = "EN_ROUTE"  # el chófer va hacia el punto de recogida
    ARRIVED = "ARRIVED"  # el chófer está en el punto de recogida
    IN_PROGRESS = "IN_PROGRESS"  # pasajero a bordo
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"  # no se pagó a tiempo
    NO_SHOW = "NO_SHOW"  # el cliente no se presentó


# Estados que ocupan un vehículo (PENDING_PAYMENT sólo mientras no venza el cupo retenido).
ACTIVE_TRIP = (
    ReservationStatus.CONFIRMED,
    ReservationStatus.EN_ROUTE,
    ReservationStatus.ARRIVED,
    ReservationStatus.IN_PROGRESS,
)
OCCUPYING = (ReservationStatus.PENDING_PAYMENT, *ACTIVE_TRIP)
_ACTIVE_SQL = ", ".join(f"'{s.value}'" for s in ACTIVE_TRIP)

STATUS_VALUES = ", ".join(f"'{s.value}'" for s in ReservationStatus)


class Reservation(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "reservations"
    __table_args__ = (
        CheckConstraint(f"status IN ({STATUS_VALUES})", name="status_valid"),
        CheckConstraint("passenger_count > 0", name="passenger_count_positive"),
        CheckConstraint("duration_minutes > 0", name="duration_positive"),
        CheckConstraint("end_at > pickup_at AND blocks_until >= end_at", name="period_valid"),
        CheckConstraint("total_amount >= 0", name="total_non_negative"),
        # Búsqueda de solapamientos al calcular la disponibilidad.
        Index("ix_reservations_service_period", "service_id", "pickup_at", "blocks_until"),
        Index("ix_reservations_status_hold", "status", "hold_expires_at"),
        # Un vehículo o un conductor no puede estar en dos viajes que se solapen (incluida la
        # preparación entre viajes). Lo garantiza PostgreSQL, aunque falle la aplicación.
        ExcludeConstraint(
            ("vehicle_id", "="),
            (func.tstzrange(column("pickup_at"), column("blocks_until")), "&&"),
            name="ex_reservations_vehicle_no_overlap",
            using="gist",
            where=text(f"vehicle_id IS NOT NULL AND status IN ({_ACTIVE_SQL})"),
        ),
        ExcludeConstraint(
            ("driver_id", "="),
            (func.tstzrange(column("pickup_at"), column("blocks_until")), "&&"),
            name="ex_reservations_driver_no_overlap",
            using="gist",
            where=text(f"driver_id IS NOT NULL AND status IN ({_ACTIVE_SQL})"),
        ),
    )

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), index=True
    )
    service_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("services.id", ondelete="RESTRICT"), nullable=False
    )
    status: Mapped[str] = mapped_column(String(24), nullable=False)
    vehicle_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("vehicles.id", ondelete="RESTRICT"), index=True
    )
    driver_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("drivers.id", ondelete="RESTRICT"), index=True
    )
    boarded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Viaje
    pickup_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    duration_minutes: Mapped[int] = mapped_column(Integer, nullable=False)
    end_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    # Fin del servicio más el tiempo de preparación: hasta aquí la unidad está ocupada.
    blocks_until: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    pickup_address: Mapped[str] = mapped_column(String(300), nullable=False)
    dropoff_address: Mapped[str | None] = mapped_column(String(300))
    passenger_count: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text)

    # Pasajero de contacto (independiente de la cuenta: puede reservar para otra persona)
    contact_name: Mapped[str] = mapped_column(String(200), nullable=False)
    contact_email: Mapped[str] = mapped_column(CITEXT, nullable=False)
    contact_phone: Mapped[str] = mapped_column(String(20), nullable=False)

    # Precio: copia inmutable del cálculo y de la política vigente al reservar
    currency: Mapped[str] = mapped_column(String(3), nullable=False)
    total_amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    pricing_snapshot: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)
    cancellation_policy_snapshot: Mapped[dict[str, Any]] = mapped_column(JSONB, nullable=False)

    hold_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    confirmed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cancelled_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    cancellation_reason: Mapped[str | None] = mapped_column(String(500))
    refund_amount: Mapped[Decimal | None] = mapped_column(Numeric(14, 2))

    # Token aleatorio para el QR del abordaje (no se deriva del código visible)
    qr_token: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    # Evita duplicados por doble clic: el cliente envía un identificador por intento.
    idempotency_key: Mapped[uuid.UUID | None] = mapped_column(unique=True)

    service: Mapped[Service] = relationship(lazy="joined", innerjoin=True)
    vehicle: Mapped["Vehicle | None"] = relationship(lazy="joined")
    driver: Mapped["Driver | None"] = relationship(lazy="joined")
    payments: Mapped[list["Payment"]] = relationship(
        lazy="selectin", order_by="Payment.created_at", viewonly=True
    )
    events: Mapped[list["ReservationEvent"]] = relationship(
        back_populates="reservation",
        lazy="selectin",
        order_by="ReservationEvent.created_at",
        cascade="all, delete-orphan",
    )


class ReservationEvent(UUIDPrimaryKeyMixin, Base):
    """Historial de cambios de estado: quién, cuándo y por qué."""

    __tablename__ = "reservation_events"

    reservation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("reservations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    from_status: Mapped[str | None] = mapped_column(String(24))
    to_status: Mapped[str] = mapped_column(String(24), nullable=False)
    actor_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    actor_label: Mapped[str] = mapped_column(String(100), nullable=False)
    note: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.clock_timestamp(), nullable=False
    )

    reservation: Mapped[Reservation] = relationship(back_populates="events")


class ReservationCounter(Base):
    """Último correlativo usado por año: RES-2026-000125."""

    __tablename__ = "reservation_counters"

    year: Mapped[int] = mapped_column(SmallInteger, primary_key=True)
    last_value: Mapped[int] = mapped_column(Integer, nullable=False)
