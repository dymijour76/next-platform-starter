"""Emails de reserva, en el idioma del destinatario (`locale`)."""

from app.core.dates import format_local, format_money, format_time
from app.core.i18n import LOCALES, t, translate_message
from app.core.translations import localized
from app.notifications.email import Email
from app.notifications.templates import build_email, site_url
from app.reservations.models import Reservation


def _loc(locale: str | None) -> str:
    return locale if locale in LOCALES else "es"


def _details(r: Reservation, tz: str, loc: str) -> list[str]:
    service = localized(r.service.translations, "name", r.service.name, loc)
    lines = [
        t("Reserva {code}: {service}.", loc, code=r.code, service=service),
        t(
            "Recogida: {when}, en {address}.",
            loc,
            when=format_local(r.pickup_at, tz, loc),
            address=r.pickup_address,
        ),
    ]
    if r.dropoff_address:
        lines.append(t("Destino: {address}.", loc, address=r.dropoff_address))
    lines.append(
        t(
            "Pasajeros: {count}. Total: {total}.",
            loc,
            count=r.passenger_count,
            total=format_money(r.total_amount, r.currency, loc),
        )
    )
    return lines


def build(kind: str, to: str, r: Reservation, tz: str, locale: str | None = None) -> Email:
    loc = _loc(locale)
    link = (t("Ver mi reserva", loc), site_url(f"/account/reservations/{r.code}"))
    hello = t("Hola, {name}", loc, name=r.contact_name.split()[0])
    # La política se guardó en español al reservar: se traduce al enviarla.
    policy = translate_message(r.cancellation_policy_snapshot["text"], loc)

    if kind == "created":
        until = format_time(r.hold_expires_at, tz) if r.hold_expires_at else ""
        return build_email(
            to,
            t("Recibimos su reserva {code}", loc, code=r.code),
            hello,
            [
                *_details(r, tz, loc),
                t(
                    "La reserva está pendiente de pago. Mantenemos el cupo hasta las {time}; "
                    "si no se confirma a tiempo, se libera automáticamente.",
                    loc,
                    time=until,
                ),
            ],
            link,
            policy,
            loc,
        )
    if kind == "confirmed":
        paid = next((p for p in r.payments if p.status == "AUTHORIZED"), None)
        payment_line = (
            [
                t(
                    "Pago recibido: tarjeta terminada en {last4}, autorización {code}.",
                    loc,
                    last4=paid.card_last4,
                    code=paid.authorization_code,
                )
            ]
            if paid and paid.card_last4
            else []
        )
        return build_email(
            to,
            t("Reserva {code} confirmada", loc, code=r.code),
            t("Su reserva está confirmada, {name}", loc, name=r.contact_name.split()[0]),
            [
                *_details(r, tz, loc),
                *payment_line,
                t("Le enviaremos los datos del chófer y del vehículo antes del viaje.", loc),
            ],
            link,
            policy,
            loc,
        )
    if kind == "cancelled":
        if r.refund_amount:
            refund = t(
                "Se le devolverán {amount} por el mismo medio de pago; "
                "el plazo depende de su banco.",
                loc,
                amount=format_money(r.refund_amount, r.currency, loc),
            )
        elif r.refund_amount is not None:
            refund = t("No corresponde reembolso.", loc)
        else:
            refund = t("No se había realizado ningún cobro.", loc)
        return build_email(
            to,
            t("Reserva {code} cancelada", loc, code=r.code),
            hello,
            [*_details(r, tz, loc), t("La reserva fue cancelada. {refund}", loc, refund=refund)],
            link,
            t("Si no solicitó esta cancelación, contáctenos de inmediato.", loc),
            loc,
        )
    if kind == "expired":
        return build_email(
            to,
            t("Reserva {code} vencida", loc, code=r.code),
            hello,
            [
                *_details(r, tz, loc),
                t(
                    "El plazo para confirmar esta reserva terminó y el cupo se liberó. "
                    "Si aún necesita el servicio, puede reservar nuevamente.",
                    loc,
                ),
            ],
            (t("Reservar de nuevo", loc), site_url(f"/book?service={r.service.slug}")),
            t("No se realizó ningún cobro.", loc),
            loc,
        )
    if kind == "assigned":
        assert r.driver is not None and r.vehicle is not None
        return build_email(
            to,
            t("Su chófer para la reserva {code}", loc, code=r.code),
            hello,
            [
                *_details(r, tz, loc),
                t(
                    "Su chófer será {driver}, en {vehicle}.",
                    loc,
                    driver=r.driver.user.first_name,
                    vehicle=r.vehicle.label_for(loc),
                ),
                t(
                    "El día del viaje, muestre el código QR de su reserva al subir al vehículo.",
                    loc,
                ),
            ],
            link,
            policy,
            loc,
        )
    if kind == "en_route":
        driver = r.driver.user.first_name if r.driver else t("Su chófer", loc)
        return build_email(
            to,
            t("Su chófer va en camino ({code})", loc, code=r.code),
            hello,
            [
                t(
                    "{driver} va en camino a {address} para la recogida de las {time}.",
                    loc,
                    driver=driver,
                    address=r.pickup_address,
                    time=format_time(r.pickup_at, tz),
                ),
                t("Vehículo: {vehicle}.", loc, vehicle=r.vehicle.label_for(loc))
                if r.vehicle
                else "",
            ],
            (t("Ver mi reserva y el código QR", loc), site_url(f"/account/reservations/{r.code}")),
            t("Tenga a mano el código QR de su reserva.", loc),
            loc,
        )
    if kind == "review_request":
        return build_email(
            to,
            t("¿Cómo estuvo su viaje? ({code})", loc, code=r.code),
            hello,
            [
                t(
                    "Gracias por viajar con nosotros. Su opinión nos ayuda a mejorar y orienta "
                    "a otros clientes.",
                    loc,
                ),
                t("Puede calificar el servicio y a su chófer durante los próximos 30 días.", loc),
            ],
            (t("Calificar mi viaje", loc), site_url(f"/account/reservations/{r.code}#calificar")),
            t("Si prefiere no hacerlo, ignore este mensaje.", loc),
            loc,
        )
    if kind == "message":
        driver = r.driver.user.first_name if r.driver else t("Su chófer", loc)
        return build_email(
            to,
            t("Tiene un mensaje de su chófer ({code})", loc, code=r.code),
            hello,
            [
                t(
                    "{driver} le escribió sobre su reserva. "
                    "Para leerlo y responder, abra su reserva.",
                    loc,
                    driver=driver,
                )
            ],
            (t("Ver el mensaje", loc), site_url(f"/account/reservations/{r.code}#mensajes")),
            t("Por seguridad, no incluimos el mensaje en este email.", loc),
            loc,
        )
    if kind == "unavailable_refunded":
        return build_email(
            to,
            t("No pudimos confirmar la reserva {code}", loc, code=r.code),
            hello,
            [
                *_details(r, tz, loc),
                t(
                    "Mientras se completaba el pago, el horario dejó de estar disponible. "
                    "Anulamos el cargo de inmediato; la devolución depende de su banco.",
                    loc,
                ),
            ],
            (t("Reservar otro horario", loc), site_url(f"/book?service={r.service.slug}")),
            t("Lamentamos el inconveniente.", loc),
            loc,
        )
    raise ValueError(f"Tipo de email desconocido: {kind}")


def driver_email(r: Reservation, tz: str) -> Email:
    """Aviso al conductor de un viaje asignado (sin precios ni datos de pago), en su idioma."""
    assert r.driver is not None
    loc = _loc(r.driver.user.locale)
    service = localized(r.service.translations, "name", r.service.name, loc)
    lines = [
        t(
            "Viaje {code}: {service}, 1 pasajero."
            if r.passenger_count == 1
            else "Viaje {code}: {service}, {count} pasajeros.",
            loc,
            code=r.code,
            service=service,
            count=r.passenger_count,
        ),
        t(
            "Recogida: {when}, en {address}.",
            loc,
            when=format_local(r.pickup_at, tz, loc),
            address=r.pickup_address,
        ),
    ]
    if r.dropoff_address:
        lines.append(t("Destino: {address}.", loc, address=r.dropoff_address))
    if r.vehicle:
        lines.append(t("Vehículo: {vehicle}.", loc, vehicle=r.vehicle.label_for(loc)))
    return build_email(
        r.driver.user.email,
        t("Nuevo viaje asignado: {code}", loc, code=r.code),
        t("Hola, {name}", loc, name=r.driver.user.first_name),
        lines,
        (t("Ver en el panel del conductor", loc), site_url("/driver")),
        t("Los datos de contacto del pasajero están en el panel.", loc),
        loc,
    )


def driver_message_email(r: Reservation, tz: str) -> Email:
    """Aviso al chófer de un mensaje del pasajero (sin el texto del mensaje), en su idioma."""
    assert r.driver is not None
    loc = _loc(r.driver.user.locale)
    return build_email(
        r.driver.user.email,
        t("Mensaje del pasajero ({code})", loc, code=r.code),
        t("Hola, {name}", loc, name=r.driver.user.first_name),
        [
            t(
                "{name} le escribió sobre el viaje {code}.",
                loc,
                name=r.contact_name.split()[0],
                code=r.code,
            )
        ],
        (t("Ver en el panel del conductor", loc), site_url(f"/driver/trips/{r.id}#mensajes")),
        t("Por seguridad, no incluimos el mensaje en este email.", loc),
        loc,
    )
