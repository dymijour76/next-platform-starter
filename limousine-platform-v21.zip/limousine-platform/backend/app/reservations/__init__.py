"""Módulo reservations (se implementa en fases posteriores)."""
