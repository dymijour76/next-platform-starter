"""Reservas: disponibilidad, creación, cambios de estado y cancelación.

Doble reserva: al crear o confirmar, la fila del servicio se bloquea
(SELECT ... FOR UPDATE) antes de contar las reservas que se solapan. Dos
peticiones simultáneas para el mismo servicio se ejecutan una tras otra, así
que nunca se supera la cantidad de unidades de la flota.
"""

import logging
import secrets
import uuid
from datetime import UTC, date, datetime, time, timedelta
from decimal import Decimal
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import status
from sqlalchemy import and_, func, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import AppError, Conflict, NotFound
from app.core.i18n import translate_message
from app.core.pagination import PageParams
from app.core.translations import localized
from app.pricing import engine
from app.pricing import service as pricing
from app.pricing.schemas import QuoteIn
from app.pricing.service import line_label
from app.reservations import emails
from app.reservations.models import (
    ACTIVE_TRIP,
    OCCUPYING,
    Reservation,
    ReservationEvent,
    ReservationStatus,
)
from app.reservations.schemas import (
    AssignmentBrief,
    CustomerBrief,
    EventOut,
    PaymentOut,
    PricingSummary,
    RefundOut,
    ReservationAdminOut,
    ReservationFilters,
    ReservationIn,
    ReservationOut,
    ReservationSummary,
    ServiceBrief,
    TripIn,
)
from app.reservations.verification import driver_code
from app.services.models import Service
from app.settings.schemas import BookingSettings
from app.settings.service import get_booking_settings, get_pricing_settings
from app.users.models import User

logger = logging.getLogger("app.reservations")

S = ReservationStatus

# Transiciones permitidas. Las fases 5 y 6 agregan pago y asignación.
TRANSITIONS: dict[ReservationStatus, set[ReservationStatus]] = {
    S.PENDING_PAYMENT: {S.CONFIRMED, S.CANCELLED, S.EXPIRED},
    S.CONFIRMED: {S.EN_ROUTE, S.COMPLETED, S.CANCELLED, S.NO_SHOW},
    S.EN_ROUTE: {S.ARRIVED, S.COMPLETED, S.CANCELLED, S.NO_SHOW},
    S.ARRIVED: {S.IN_PROGRESS, S.COMPLETED, S.CANCELLED, S.NO_SHOW},
    S.IN_PROGRESS: {S.COMPLETED},
}

STATUS_LABELS = {
    S.PENDING_PAYMENT: "Pendiente de pago",
    S.CONFIRMED: "Confirmada",
    S.EN_ROUTE: "Chófer en camino",
    S.ARRIVED: "Chófer en el lugar",
    S.IN_PROGRESS: "En viaje",
    S.COMPLETED: "Completada",
    S.CANCELLED: "Cancelada",
    S.EXPIRED: "Vencida",
    S.NO_SHOW: "No se presentó",
}


class SlotUnavailable(AppError):
    status_code = status.HTTP_409_CONFLICT
    code = "SLOT_UNAVAILABLE"
    message = (
        "No quedan unidades disponibles para ese horario. Pruebe con otra hora o con otro servicio."
    )


class InvalidTransition(AppError):
    status_code = status.HTTP_409_CONFLICT
    code = "INVALID_TRANSITION"


def _now() -> datetime:
    return datetime.now(UTC)


# ------------------------------------------------------------------ política de cancelación


def policy_snapshot(settings: BookingSettings) -> dict[str, Any]:
    hours = settings.free_cancellation_hours
    late = settings.late_cancellation_refund_percent
    after = (
        "después no hay reembolso" if late == 0 else f"después se devuelve el {late} % del total"
    )
    return {
        "free_cancellation_hours": hours,
        "late_cancellation_refund_percent": late,
        "text": f"Cancelación sin costo hasta {hours} horas antes de la recogida; {after}.",
    }


def refund_for_customer(r: Reservation, now: datetime) -> Decimal | None:
    """Monto a devolver si el cliente cancela ahora. None si no hay nada pagado."""
    if r.status not in ACTIVE_TRIP:
        return None
    policy = r.cancellation_policy_snapshot
    deadline = r.pickup_at - timedelta(hours=int(policy["free_cancellation_hours"]))
    if now <= deadline:
        return r.total_amount
    pct = Decimal(int(policy["late_cancellation_refund_percent"]))
    return engine.money(r.total_amount * pct / 100, r.currency)


def customer_can_cancel(r: Reservation, now: datetime) -> bool:
    return r.status in (S.PENDING_PAYMENT, S.CONFIRMED) and now < r.pickup_at


# ------------------------------------------------------------------ disponibilidad


async def _lock_service(db: AsyncSession, service_id: uuid.UUID) -> Service:
    service = await db.scalar(select(Service).where(Service.id == service_id).with_for_update())
    if service is None:
        raise NotFound("El servicio no existe o no está disponible.")
    return service


async def overlapping_count(
    db: AsyncSession,
    service_id: uuid.UUID,
    start: datetime,
    blocks_until: datetime,
    exclude: uuid.UUID | None = None,
) -> int:
    now = _now()
    query = select(func.count()).where(
        Reservation.service_id == service_id,
        Reservation.pickup_at < blocks_until,
        Reservation.blocks_until > start,
        or_(
            Reservation.status.in_(ACTIVE_TRIP),
            and_(Reservation.status == S.PENDING_PAYMENT, Reservation.hold_expires_at > now),
        ),
    )
    if exclude:
        query = query.where(Reservation.id != exclude)
    return await db.scalar(query) or 0


async def has_capacity(
    db: AsyncSession,
    service_id: uuid.UUID,
    start: datetime,
    blocks_until: datetime,
    exclude: uuid.UUID | None = None,
) -> bool:
    """¿Queda algún vehículo del servicio libre en ese periodo?

    Vehículos activos y sin mantención en el periodo, menos las reservas que ya lo
    ocupan (asignadas o no). Es conservador: cuenta cualquier reserva que se
    solape, aunque esas reservas no se solapen entre sí.
    """
    from app.vehicles.service import available_count

    vehicles = await available_count(db, service_id, start, blocks_until)
    used = await overlapping_count(db, service_id, start, blocks_until, exclude=exclude)
    return used < vehicles


def _period(
    pickup_at: datetime, billed_hours: Decimal, booking: BookingSettings
) -> tuple[datetime, datetime]:
    end_at = pickup_at + timedelta(minutes=int(billed_hours * 60))
    return end_at, end_at + timedelta(minutes=booking.turnaround_minutes)


async def preview(db: AsyncSession, data: TripIn) -> tuple[engine.Quote, Service, bool]:
    quote, _tariff, service = await pricing.quote(db, QuoteIn(**data.model_dump()))
    booking = await get_booking_settings(db)
    _end_at, blocks_until = _period(data.pickup_at, quote.billed_hours, booking)
    return quote, service, await has_capacity(db, service.id, data.pickup_at, blocks_until)


# ------------------------------------------------------------------ creación


async def _next_code(db: AsyncSession, timezone: str) -> str:
    year = datetime.now(ZoneInfo(timezone)).year
    value = await db.scalar(
        text(
            "INSERT INTO reservation_counters (year, last_value) VALUES (:y, 1) "
            "ON CONFLICT (year) DO UPDATE SET last_value = reservation_counters.last_value + 1 "
            "RETURNING last_value"
        ),
        {"y": year},
    )
    return f"RES-{year}-{int(value or 0):06d}"


def _event(
    r: Reservation, to: ReservationStatus, actor: User | None, label: str, note: str | None = None
) -> None:
    r.events.append(
        ReservationEvent(
            from_status=r.status if r.status else None,
            to_status=to,
            actor_user_id=actor.id if actor else None,
            actor_label=label,
            note=note,
        )
    )
    r.status = to


async def create(db: AsyncSession, user: User, data: ReservationIn) -> tuple[Reservation, bool]:
    """Devuelve (reserva, creada). Si la clave de idempotencia ya se usó, la reserva existente."""
    existing = await db.scalar(
        select(Reservation).where(Reservation.idempotency_key == data.idempotency_key)
    )
    if existing is not None:
        if existing.user_id != user.id:
            raise Conflict("Solicitud duplicada.", code="IDEMPOTENCY_CONFLICT")
        return existing, False

    # 1. Precio recalculado en el servidor (el del navegador sólo sirve para comparar).
    quote, tariff, service = await pricing.quote(
        db, QuoteIn(**TripIn(**data.model_dump()).model_dump())
    )
    if quote.total != data.expected_total:
        raise Conflict(
            f"El precio cambió a {engine.format_amount(quote.total, quote.currency)}. "
            "Revíselo antes de confirmar.",
            code="PRICE_CHANGED",
        )
    if data.passenger_count > service.passenger_capacity:
        raise AppError(
            f"Este servicio admite hasta {service.passenger_capacity} pasajeros.",
            code="TOO_MANY_PASSENGERS",
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            fields={"passenger_count": f"Máximo {service.passenger_capacity} pasajeros."},
        )

    booking = await get_booking_settings(db)
    pricing_settings = await get_pricing_settings(db)
    end_at, blocks_until = _period(data.pickup_at, quote.billed_hours, booking)

    # 2. Disponibilidad con el servicio bloqueado: las reservas simultáneas esperan su turno.
    service = await _lock_service(db, service.id)
    if not await has_capacity(db, service.id, data.pickup_at, blocks_until):
        raise SlotUnavailable()

    reservation = Reservation(
        code=await _next_code(db, pricing_settings.timezone),
        user_id=user.id,
        service_id=service.id,
        status="",
        pickup_at=data.pickup_at,
        duration_minutes=data.duration_minutes,
        end_at=end_at,
        blocks_until=blocks_until,
        pickup_address=data.pickup_address,
        dropoff_address=data.dropoff_address,
        passenger_count=data.passenger_count,
        notes=data.notes,
        contact_name=data.contact_name,
        contact_email=data.contact_email,
        contact_phone=data.contact_phone,
        currency=quote.currency,
        total_amount=quote.total,
        pricing_snapshot=quote.snapshot(tariff),
        cancellation_policy_snapshot=policy_snapshot(booking),
        hold_expires_at=_now() + timedelta(minutes=booking.hold_minutes),
        qr_token=secrets.token_urlsafe(24),
        idempotency_key=data.idempotency_key,
        events=[],
    )
    _event(reservation, S.PENDING_PAYMENT, user, "Cliente")
    db.add(reservation)
    await db.commit()
    await db.refresh(reservation)
    return reservation, True


# ------------------------------------------------------------------ cambios de estado


async def _get_locked(db: AsyncSession, reservation_id: uuid.UUID) -> Reservation:
    r = await db.scalar(
        select(Reservation).where(Reservation.id == reservation_id).with_for_update(of=Reservation)
    )
    if r is None:
        raise NotFound("La reserva no existe.")
    return r


def _check_transition(r: Reservation, to: ReservationStatus) -> None:
    if to not in TRANSITIONS.get(S(r.status), set()):
        raise InvalidTransition(
            f"Una reserva «{STATUS_LABELS[S(r.status)].lower()}» no puede pasar a "
            f"«{STATUS_LABELS[to].lower()}»."
        )


async def confirm(
    db: AsyncSession, actor: User, reservation_id: uuid.UUID, note: str | None
) -> Reservation:
    r = await _get_locked(db, reservation_id)
    _check_transition(r, S.CONFIRMED)
    # Si el cupo retenido ya venció, otra reserva pudo tomarlo: se vuelve a comprobar.
    if r.hold_expires_at is not None and r.hold_expires_at <= _now():
        await _lock_service(db, r.service_id)
        if not await has_capacity(db, r.service_id, r.pickup_at, r.blocks_until, exclude=r.id):
            raise SlotUnavailable(
                "El cupo retenido venció y ese horario ya no tiene unidades libres."
            )
    _event(r, S.CONFIRMED, actor, _staff_label(actor), note or "Confirmada manualmente")
    r.confirmed_at = _now()
    r.hold_expires_at = None
    await db.commit()
    await db.refresh(r)
    return r


async def close(
    db: AsyncSession,
    actor: User,
    reservation_id: uuid.UUID,
    to: ReservationStatus,
    note: str | None,
) -> Reservation:
    """Completada o no se presentó: sólo después de la hora de recogida."""
    r = await _get_locked(db, reservation_id)
    _check_transition(r, to)
    if _now() < r.pickup_at:
        raise InvalidTransition("Sólo se puede cerrar una reserva después de la hora de recogida.")
    _event(r, to, actor, _staff_label(actor), note)
    await db.commit()
    await db.refresh(r)
    return r


async def cancel(
    db: AsyncSession,
    actor: User,
    r: Reservation,
    *,
    reason: str | None,
    by_customer: bool,
    apply_policy: bool = True,
) -> Reservation:
    now = _now()
    r = await _get_locked(db, r.id)
    if by_customer and not customer_can_cancel(r, now):
        raise InvalidTransition(
            "Esta reserva ya no se puede cancelar desde su cuenta. Contáctenos para ayudarle."
        )
    _check_transition(r, S.CANCELLED)
    if r.status in ACTIVE_TRIP:
        r.refund_amount = refund_for_customer(r, now) if apply_policy else r.total_amount
    r.cancelled_at = now
    r.cancellation_reason = reason
    r.hold_expires_at = None
    _event(r, S.CANCELLED, actor, "Cliente" if by_customer else _staff_label(actor), reason)
    await db.commit()
    await db.refresh(r)
    return r


async def expire_holds(db: AsyncSession) -> list[Reservation]:
    """Vence las reservas pendientes cuyo cupo retenido expiró. Lo ejecuta el worker."""
    now = _now()
    rows = list(
        await db.scalars(
            select(Reservation)
            .where(Reservation.status == S.PENDING_PAYMENT, Reservation.hold_expires_at <= now)
            .with_for_update(skip_locked=True, of=Reservation)
        )
    )
    for r in rows:
        _event(r, S.EXPIRED, None, "Sistema", "No se completó el pago a tiempo")
    await db.commit()
    return rows


def _staff_label(actor: User) -> str:
    return f"{actor.first_name} {actor.last_name}"[:100]


# ------------------------------------------------------------------ consultas


async def get_own(db: AsyncSession, user: User, code: str) -> Reservation:
    """Una reserva del propio cliente. Si es de otro, responde igual que si no existiera."""
    r = await db.scalar(
        select(Reservation).where(Reservation.code == code.upper(), Reservation.user_id == user.id)
    )
    if r is None:
        raise NotFound("La reserva no existe.")
    return r


async def list_own(db: AsyncSession, user: User, scope: str) -> list[Reservation]:
    now = _now()
    query = select(Reservation).where(Reservation.user_id == user.id)
    if scope == "upcoming":
        query = query.where(
            Reservation.end_at > now,
            Reservation.status.in_(OCCUPYING),
        ).order_by(Reservation.pickup_at)
    else:
        query = query.where(
            or_(
                Reservation.end_at <= now,
                Reservation.status.notin_(OCCUPYING),
            )
        ).order_by(Reservation.pickup_at.desc())
    return list(await db.scalars(query.limit(100)))


async def list_admin(
    db: AsyncSession, params: PageParams, f: ReservationFilters, timezone: str
) -> tuple[list[Reservation], int]:
    query = select(Reservation)
    tz = ZoneInfo(timezone)
    if f.status:
        query = query.where(Reservation.status == f.status)
    if f.service_id:
        query = query.where(Reservation.service_id == f.service_id)
    if f.date_from:
        query = query.where(Reservation.pickup_at >= _local_midnight(f.date_from, tz))
    if f.date_to:
        query = query.where(
            Reservation.pickup_at < _local_midnight(f.date_to + timedelta(days=1), tz)
        )
    if f.unassigned:
        query = query.where(
            Reservation.status == S.CONFIRMED,
            or_(Reservation.vehicle_id.is_(None), Reservation.driver_id.is_(None)),
        )
    if f.q:
        pattern = f"%{f.q.strip()}%"
        query = query.where(
            or_(
                Reservation.code.ilike(pattern),
                Reservation.contact_name.ilike(pattern),
                Reservation.contact_email.ilike(pattern),
                Reservation.contact_phone.ilike(pattern),
            )
        )
    total = await db.scalar(select(func.count()).select_from(query.subquery())) or 0
    rows = await db.scalars(
        query.order_by(Reservation.pickup_at.desc()).offset(params.offset).limit(params.page_size)
    )
    return list(rows), total


def _local_midnight(day: date, tz: ZoneInfo) -> datetime:
    return datetime.combine(day, time(0), tzinfo=tz)


async def get_admin(db: AsyncSession, reservation_id: uuid.UUID) -> Reservation:
    r = await db.get(Reservation, reservation_id)
    if r is None:
        raise NotFound("La reserva no existe.")
    return r


# ------------------------------------------------------------------ salida


def _pickup_local(r: Reservation) -> str:
    return str(r.pricing_snapshot.get("pickup_local") or r.pickup_at.isoformat())


def to_summary(r: Reservation) -> ReservationSummary:
    return ReservationSummary(
        id=r.id,
        code=r.code,
        status=S(r.status),
        service=ServiceBrief(
            id=r.service.id,
            name=localized(r.service.translations, "name", r.service.name),
            slug=r.service.slug,
        ),
        pickup_at=r.pickup_at,
        pickup_local=_pickup_local(r),
        duration_minutes=r.duration_minutes,
        passenger_count=r.passenger_count,
        contact_name=r.contact_name,
        currency=r.currency,
        total_amount=r.total_amount,
        hold_expires_at=r.hold_expires_at if r.status == S.PENDING_PAYMENT else None,
        driver_name=r.driver.user.first_name if r.driver else None,
        vehicle_label=r.vehicle.display_label if r.vehicle else None,
        driver_code=driver_code(r),
    )


def to_out(r: Reservation) -> ReservationOut:
    now = _now()
    snap = r.pricing_snapshot
    can_cancel = customer_can_cancel(r, now)
    return ReservationOut(
        **to_summary(r).model_dump(),
        end_at=r.end_at,
        pickup_address=r.pickup_address,
        dropoff_address=r.dropoff_address,
        notes=r.notes,
        contact_email=r.contact_email,
        contact_phone=r.contact_phone,
        pricing=PricingSummary(
            lines=[
                {
                    "code": ln.get("code"),
                    "label": line_label(ln["label"], ln.get("labels")),
                    "amount": ln["amount"],
                }
                for ln in snap["lines"]
            ],
            net=Decimal(snap["net"]),
            tax=Decimal(snap["tax"]),
            tax_name=translate_message(snap["tax_name"]),
            prices_include_tax=snap["prices_include_tax"],
            billed_hours=Decimal(snap["billed_hours"]),
        ),
        cancellation_policy=translate_message(r.cancellation_policy_snapshot["text"]),
        confirmed_at=r.confirmed_at,
        cancelled_at=r.cancelled_at,
        cancellation_reason=r.cancellation_reason,
        refund_amount=r.refund_amount,
        created_at=r.created_at,
        can_cancel=can_cancel,
        refund_if_cancelled_now=refund_for_customer(r, now) if can_cancel else None,
        can_pay=r.status == S.PENDING_PAYMENT and now < r.pickup_at,
        boarded_at=r.boarded_at,
        # Los intentos abandonados no se muestran; los aprobados, rechazados y reembolsos sí.
        payments=[
            PaymentOut(
                id=p.id,
                provider=p.provider,
                status=p.status,
                amount=p.amount,
                refunded_amount=p.refunded_amount,
                card_last4=p.card_last4,
                authorization_code=p.authorization_code,
                payment_type=p.payment_type,
                installments=p.installments,
                authorized_at=p.authorized_at,
                created_at=p.created_at,
                refunds=[
                    RefundOut(
                        id=f.id,
                        amount=f.amount,
                        status=f.status,
                        reason=f.reason,
                        error_message=f.error_message,
                        created_at=f.created_at,
                    )
                    for f in p.refunds
                ],
            )
            for p in r.payments
            if p.status not in ("CREATED", "ABORTED", "EXPIRED")
        ],
    )


async def to_admin_out(db: AsyncSession, r: Reservation) -> ReservationAdminOut:
    customer = await db.get(User, r.user_id) if r.user_id else None
    return ReservationAdminOut(
        **to_out(r).model_dump(),
        vehicle=AssignmentBrief(id=r.vehicle.id, label=r.vehicle.display_label)
        if r.vehicle
        else None,
        driver=AssignmentBrief(id=r.driver.id, label=r.driver.name, phone=r.driver.user.phone)
        if r.driver
        else None,
        customer=CustomerBrief(
            id=customer.id, email=customer.email, name=f"{customer.first_name} {customer.last_name}"
        )
        if customer
        else None,
        events=[
            EventOut(
                from_status=S(e.from_status) if e.from_status else None,
                to_status=S(e.to_status),
                actor_label=e.actor_label,
                note=e.note,
                created_at=e.created_at,
            )
            for e in r.events
        ],
    )


# ------------------------------------------------------------------ notificaciones


async def notify(db: AsyncSession, r: Reservation, kind: str, mailer: Any) -> None:
    tz = (await get_pricing_settings(db)).timezone
    recipients = {r.contact_email}
    locale = None  # el idioma de la cuenta que reservó (sin cuenta: español)
    if r.user_id:
        owner = await db.get(User, r.user_id)
        if owner:
            recipients.add(owner.email)
            locale = owner.locale
    for to in sorted(recipients):
        await mailer.send(emails.build(kind, to, r, tz, locale))
