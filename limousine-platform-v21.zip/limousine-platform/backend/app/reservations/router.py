"""Reservas: del cliente (/reservations) y de administración (/admin/reservations)."""

import uuid
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query, Response, status
from pydantic import BaseModel

from app.audit.service import record
from app.auth.deps import DB, CurrentUser, RedisDep, require
from app.auth.router import Mailer, Meta
from app.core.i18n import translate_message
from app.core.pagination import Page, PageParams, page_params
from app.core.rate_limit import hit
from app.payments import service as payments
from app.pricing.service import quote_out
from app.reservations import assignment, service
from app.reservations.emails import driver_email
from app.reservations.models import ACTIVE_TRIP, ReservationStatus
from app.reservations.receipt import build_receipt
from app.reservations.schemas import (
    AdminCancelIn,
    AssignIn,
    AssignmentOptionsOut,
    CancelIn,
    NoteIn,
    OptionOut,
    PreviewOut,
    ReservationAdminOut,
    ReservationFilters,
    ReservationIn,
    ReservationOut,
    ReservationSummary,
    TripIn,
)
from app.settings.company import get_company
from app.settings.schemas import BookingSettings
from app.settings.service import get_booking_settings, get_pricing_settings, save_booking_settings
from app.users.models import User

router = APIRouter(tags=["reservations"])


# ------------------------------------------------------------------ cliente


class PolicyOut(BaseModel):
    text: str
    hold_minutes: int
    free_cancellation_hours: int
    late_cancellation_refund_percent: int


@router.get("/booking/policy", response_model=PolicyOut)
async def policy(db: DB) -> PolicyOut:
    """Política de cancelación vigente, para mostrarla antes de reservar."""
    booking = await get_booking_settings(db)
    return PolicyOut(
        text=translate_message(service.policy_snapshot(booking)["text"]),
        **booking.model_dump(
            include={"hold_minutes", "free_cancellation_hours", "late_cancellation_refund_percent"}
        ),
    )


@router.post("/reservations/preview", response_model=PreviewOut)
async def preview(data: TripIn, user: CurrentUser, db: DB, redis: RedisDep) -> PreviewOut:
    """Precio y disponibilidad antes de pedir los datos del viaje."""
    await hit(redis, "preview", str(user.id), limit=60, window_seconds=60)
    quote, svc, available = await service.preview(db, data)
    return PreviewOut(
        quote=quote_out(quote, svc), available=available, passenger_capacity=svc.passenger_capacity
    )


@router.post("/reservations", response_model=ReservationOut, status_code=status.HTTP_201_CREATED)
async def create(
    data: ReservationIn, user: CurrentUser, db: DB, redis: RedisDep, mailer: Mailer,
    response: Response,
) -> ReservationOut:  # fmt: skip
    await hit(redis, "reserve", str(user.id), limit=10, window_seconds=3600)
    reservation, created = await service.create(db, user, data)
    if created:
        await service.notify(db, reservation, "created", mailer)
    else:
        response.status_code = status.HTTP_200_OK
    return service.to_out(reservation)


@router.get("/reservations", response_model=list[ReservationSummary])
async def list_own(
    user: CurrentUser, db: DB, scope: Literal["upcoming", "past"] = "upcoming"
) -> list[ReservationSummary]:
    return [service.to_summary(r) for r in await service.list_own(db, user, scope)]


@router.get("/reservations/{code}", response_model=ReservationOut)
async def get_own(code: str, user: CurrentUser, db: DB) -> ReservationOut:
    r = await service.get_own(db, user, code)
    out = service.to_out(r)
    if r.status in ACTIVE_TRIP:
        out.qr_token = r.qr_token
    return out


async def _receipt(db: DB, out: ReservationOut) -> Response:
    """PDF en el idioma de quien lo descarga; se abre en el navegador (imprimir o guardar)."""
    pdf = build_receipt(out, await get_company(db), (await get_pricing_settings(db)).timezone)
    return Response(
        pdf,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'inline; filename="comprobante-{out.code}.pdf"',
            "Cache-Control": "private, no-store",
        },
    )


@router.get("/reservations/{code}/receipt", response_class=Response)
async def own_receipt(code: str, user: CurrentUser, db: DB) -> Response:
    return await _receipt(db, service.to_out(await service.get_own(db, user, code)))


@router.post("/reservations/{code}/cancel", response_model=ReservationOut)
async def cancel_own(
    code: str, data: CancelIn, user: CurrentUser, db: DB, mailer: Mailer, redis: RedisDep
) -> ReservationOut:
    r = await service.get_own(db, user, code)
    r = await service.cancel(db, user, r, reason=data.reason, by_customer=True)
    await payments.refund_after_cancellation(db, payments.get_provider(redis), r, user)
    await db.refresh(r)
    await service.notify(db, r, "cancelled", mailer)
    return service.to_out(r)


# ------------------------------------------------------------------ administración


@router.get("/admin/reservations", response_model=Page[ReservationSummary])
async def list_admin(
    _: Annotated[User, Depends(require("reservations:read"))],
    db: DB,
    params: Annotated[PageParams, Depends(page_params)],
    filters: Annotated[ReservationFilters, Query()],
) -> Page[ReservationSummary]:
    tz = (await get_pricing_settings(db)).timezone
    rows, total = await service.list_admin(db, params, filters, tz)
    return Page[ReservationSummary](
        items=[service.to_summary(r) for r in rows],
        total=total,
        page=params.page,
        page_size=params.page_size,
    )


@router.get("/admin/reservations/{reservation_id}", response_model=ReservationAdminOut)
async def get_admin(
    reservation_id: uuid.UUID, _: Annotated[User, Depends(require("reservations:read"))], db: DB
) -> ReservationAdminOut:
    return await service.to_admin_out(db, await service.get_admin(db, reservation_id))


@router.get("/admin/reservations/{reservation_id}/receipt", response_class=Response)
async def admin_receipt(
    reservation_id: uuid.UUID, _: Annotated[User, Depends(require("reservations:read"))], db: DB
) -> Response:
    return await _receipt(db, service.to_out(await service.get_admin(db, reservation_id)))


@router.post("/admin/reservations/{reservation_id}/confirm", response_model=ReservationAdminOut)
async def confirm(
    reservation_id: uuid.UUID,
    data: NoteIn,
    actor: Annotated[User, Depends(require("reservations:write"))],
    db: DB,
    mailer: Mailer,
) -> ReservationAdminOut:
    r = await service.confirm(db, actor, reservation_id, data.note)
    await service.notify(db, r, "confirmed", mailer)
    return await service.to_admin_out(db, r)


@router.post("/admin/reservations/{reservation_id}/complete", response_model=ReservationAdminOut)
async def complete(
    reservation_id: uuid.UUID,
    data: NoteIn,
    actor: Annotated[User, Depends(require("reservations:write"))],
    db: DB,
    mailer: Mailer,
) -> ReservationAdminOut:
    r = await service.close(db, actor, reservation_id, ReservationStatus.COMPLETED, data.note)
    await service.notify(db, r, "review_request", mailer)  # invitación a calificar
    return await service.to_admin_out(db, r)


@router.post("/admin/reservations/{reservation_id}/no-show", response_model=ReservationAdminOut)
async def no_show(
    reservation_id: uuid.UUID,
    data: NoteIn,
    actor: Annotated[User, Depends(require("reservations:write"))],
    db: DB,
) -> ReservationAdminOut:
    r = await service.close(db, actor, reservation_id, ReservationStatus.NO_SHOW, data.note)
    return await service.to_admin_out(db, r)


@router.post("/admin/reservations/{reservation_id}/cancel", response_model=ReservationAdminOut)
async def cancel_admin(
    reservation_id: uuid.UUID,
    data: AdminCancelIn,
    actor: Annotated[User, Depends(require("reservations:cancel"))],
    db: DB,
    mailer: Mailer,
    redis: RedisDep,
) -> ReservationAdminOut:
    r = await service.get_admin(db, reservation_id)
    r = await service.cancel(
        db, actor, r, reason=data.reason, by_customer=False, apply_policy=data.apply_policy
    )
    await payments.refund_after_cancellation(db, payments.get_provider(redis), r, actor)
    await db.refresh(r)
    await service.notify(db, r, "cancelled", mailer)
    return await service.to_admin_out(db, r)


@router.get("/admin/booking/settings", response_model=BookingSettings)
async def get_settings(
    _: Annotated[User, Depends(require("reservations:read"))], db: DB
) -> BookingSettings:
    return await get_booking_settings(db)


@router.put("/admin/booking/settings", response_model=BookingSettings)
async def put_settings(
    data: BookingSettings,
    actor: Annotated[User, Depends(require("settings:write"))],
    db: DB,
    meta: Meta,
) -> BookingSettings:
    before, after = await save_booking_settings(db, data)
    if before != after:
        record(
            db, actor_id=actor.id, action="BOOKING_SETTINGS_UPDATE", entity_type="settings",
            entity_id="booking", meta=meta, before=before, after=after,
        )  # fmt: skip
    await db.commit()
    return await get_booking_settings(db)


# ------------------------------------------------------------------ asignación


@router.get("/admin/reservations/{reservation_id}/assignment", response_model=AssignmentOptionsOut)
async def assignment_options(
    reservation_id: uuid.UUID, _: Annotated[User, Depends(require("reservations:assign"))], db: DB
) -> AssignmentOptionsOut:
    """Vehículos del servicio y conductores, con el motivo si alguno no está disponible."""
    r = await service.get_admin(db, reservation_id)
    return AssignmentOptionsOut(
        vehicles=[OptionOut(**o.__dict__) for o in await assignment.vehicle_options(db, r)],
        drivers=[OptionOut(**o.__dict__) for o in await assignment.driver_options(db, r)],
    )


@router.put("/admin/reservations/{reservation_id}/assignment", response_model=ReservationAdminOut)
async def assign(
    reservation_id: uuid.UUID,
    data: AssignIn,
    actor: Annotated[User, Depends(require("reservations:assign"))],
    db: DB,
    meta: Meta,
    mailer: Mailer,
) -> ReservationAdminOut:
    r, vehicle_changed, driver_changed = await assignment.assign(
        db, actor, reservation_id, data.vehicle_id, data.driver_id, meta
    )
    if (vehicle_changed or driver_changed) and r.vehicle and r.driver:
        await service.notify(db, r, "assigned", mailer)
    if driver_changed and r.driver:
        await mailer.send(driver_email(r, (await get_pricing_settings(db)).timezone))
    return await service.to_admin_out(db, r)
