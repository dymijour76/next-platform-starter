"""Comprobante de reserva en PDF, en el idioma de quien lo descarga.

Usa la misma información que muestra la página de la reserva (ya traducida), así el PDF y
la pantalla nunca dicen cosas distintas. No es una boleta ni factura electrónica (SII): el
documento lo dice expresamente.

Tipografías: WenQuanYi Micro Hei para el cuerpo (cubre los acentos del español, francés y
creole, y el chino: también los nombres que escriban los clientes) y DejaVu Sans negrita para
los títulos en idiomas latinos. En Debian/Ubuntu: fonts-wqy-microhei y fonts-dejavu-core.
"""

import io
import logging
from datetime import datetime
from decimal import Decimal
from functools import lru_cache
from html import escape
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.core.config import get_settings
from app.core.dates import format_local, format_money
from app.core.i18n import get_locale, t, translate_message
from app.reservations.schemas import ReservationOut
from app.settings.company import CompanySettings

logger = logging.getLogger(__name__)
INK = colors.HexColor("#1b2433")
SLATE = colors.HexColor("#6b7483")
CHAMPAGNE = colors.HexColor("#b8a374")
LINE = colors.HexColor("#d9dce1")

STATUS = {
    "PENDING_PAYMENT": "Pendiente de pago",
    "CONFIRMED": "Confirmada",
    "EN_ROUTE": "Chófer en camino",
    "ARRIVED": "Chófer en el lugar",
    "IN_PROGRESS": "En viaje",
    "COMPLETED": "Completada",
    "CANCELLED": "Cancelada",
    "EXPIRED": "Vencida",
    "NO_SHOW": "No se presentó",
}
PAYMENT_STATUS = {
    "CREATED": "En la pasarela",
    "AUTHORIZED": "Pagado",
    "REJECTED": "Rechazado",
    "ABORTED": "Abandonado",
    "EXPIRED": "Vencido",
    "ERROR": "Con error",
    "REFUNDED": "Reembolsado",
    "PARTIALLY_REFUNDED": "Reembolso parcial",
}
PROVIDER = {
    "webpay": "Webpay",
    "simulated": "pasarela de prueba",
    "wallet": "saldo de la billetera",
}


@lru_cache
def _fonts() -> tuple[str, str]:
    """(cuerpo, títulos). Si faltan las tipografías, Helvetica (sin chino) y un aviso."""
    settings = get_settings()
    body, bold = "Helvetica", "Helvetica-Bold"
    try:
        if Path(settings.pdf_font_body).exists():
            pdfmetrics.registerFont(TTFont("Body", settings.pdf_font_body, subfontIndex=0))
            body = bold = "Body"
        if Path(settings.pdf_font_bold).exists():
            pdfmetrics.registerFont(TTFont("Bold", settings.pdf_font_bold))
            bold = "Bold"
    except Exception:  # pragma: no cover - tipografía dañada
        logger.exception("No se pudieron cargar las tipografías del comprobante")
    if body == "Helvetica":
        logger.warning("Comprobantes sin tipografía Unicode: instale fonts-wqy-microhei")
    return body, bold


def _hours(hours: Decimal, loc: str) -> str:
    number = f"{hours.normalize():f}"
    if loc not in {"en", "zh"}:
        number = number.replace(".", ",")
    return t("{hours} hora" if hours == 1 else "{hours} horas", loc, hours=number)


def _duration(minutes: int, loc: str) -> str:
    h, m = divmod(minutes, 60)
    if m:
        return t("{hours} h {minutes} min", loc, hours=h, minutes=m)
    return _hours(Decimal(h), loc)


def build_receipt(r: ReservationOut, company: CompanySettings, tz: str) -> bytes:
    loc = get_locale()
    body_font, bold_font = _fonts()
    title_font = body_font if loc == "zh" else bold_font
    base = ParagraphStyle("base", fontName=body_font, fontSize=9.5, leading=13, textColor=INK)
    small = ParagraphStyle("small", parent=base, fontSize=8.5, leading=11, textColor=SLATE)
    h1 = ParagraphStyle("h1", parent=base, fontName=title_font, fontSize=17, leading=22)
    h2 = ParagraphStyle(
        "h2",
        parent=base,
        fontName=title_font,
        fontSize=11.5,
        leading=15,
        spaceBefore=10,
        spaceAfter=4,
    )
    brand = ParagraphStyle("brand", parent=base, fontName=title_font, fontSize=14, leading=18)

    def p(text: str, style: ParagraphStyle = base) -> Paragraph:
        return Paragraph(escape(text), style)

    def money(value: Decimal) -> str:
        return format_money(Decimal(value), r.currency, loc)

    def when(value: datetime | str) -> str:
        dt = datetime.fromisoformat(value) if isinstance(value, str) else value
        return format_local(dt, tz, loc)

    def rows(pairs: list[tuple[str, str]]) -> Table:
        table = Table([[p(k, small), p(v)] for k, v in pairs], colWidths=[42 * mm, None])
        table.setStyle(
            TableStyle(
                [
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ]
            )
        )
        return table

    story: list = []  # type: ignore[type-arg]
    # Empresa
    story.append(p(company.name, brand))
    details = [
        company.legal_name,
        t("RUT {rut}", loc, rut=company.tax_id) if company.tax_id else None,
        company.address,
        " · ".join(x for x in (company.phone, company.email) if x) or None,
    ]
    for line in filter(None, details):
        story.append(p(line, small))
    story.append(Spacer(1, 6 * mm))
    # Título
    story.append(p(t("Comprobante de reserva", loc), h1))
    story.append(
        p(t("Reserva {code}", loc, code=r.code) + " · " + translate_message(STATUS[r.status], loc))
    )
    story.append(p(t("Emitido el {date}", loc, date=when(datetime.now().astimezone())), small))
    # Viaje
    story.append(p(t("Datos del viaje", loc), h2))
    trip = [
        (t("Servicio", loc), r.service.name),
        (t("Recogida", loc), when(r.pickup_local)),
        (t("Dirección de recogida", loc), r.pickup_address),
        (t("Destino", loc), r.dropoff_address or t("Por horas, sin destino fijo", loc)),
        (t("Duración", loc), _duration(r.duration_minutes, loc)),
        (t("Pasajeros", loc), str(r.passenger_count)),
        (t("Contacto", loc), f"{r.contact_name} · {r.contact_phone} · {r.contact_email}"),
    ]
    if r.vehicle_label:
        trip.append((t("Vehículo", loc), r.vehicle_label))
    if r.driver_name:
        trip.append((t("Chófer", loc), r.driver_name))
    story.append(rows(trip))
    # Precio
    story.append(p(t("Detalle del precio", loc), h2))
    hours = Decimal(r.pricing.billed_hours)
    lines = []
    for ln in r.pricing.lines:
        label = ln["label"]
        if ln.get("code") == "HOURS" and hours:
            rate = Decimal(ln["amount"]) / hours
            label = t("{hours} × {rate}", loc, hours=_hours(hours, loc), rate=money(rate))
        lines.append([p(label), p(money(ln["amount"]))])
    lines.append(
        [Paragraph(escape(t("Total", loc)), h2), Paragraph(escape(money(r.total_amount)), h2)]
    )
    price = Table(lines, colWidths=[None, 40 * mm])
    price.setStyle(
        TableStyle(
            [
                ("ALIGN", (1, 0), (1, -1), "RIGHT"),
                ("LINEBELOW", (0, 0), (-1, -2), 0.4, LINE),
                ("LINEABOVE", (0, -1), (-1, -1), 1, INK),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ]
        )
    )
    story.append(price)
    if r.pricing.prices_include_tax:
        story.append(
            p(
                t(
                    "Incluye {tax}: neto {net} + {tax} {amount}",
                    loc,
                    tax=r.pricing.tax_name,
                    net=money(r.pricing.net),
                    amount=money(r.pricing.tax),
                ),
                small,
            )
        )
    # Pagos
    story.append(p(t("Pagos", loc), h2))
    if not r.payments:
        story.append(p(t("Sin pagos registrados.", loc), small))
    for pay in r.payments:
        provider = translate_message(PROVIDER.get(pay.provider, pay.provider), loc)
        what = (
            t(
                "{provider}, tarjeta terminada en {last4}",
                loc,
                provider=provider,
                last4=pay.card_last4,
            )
            if pay.card_last4
            else provider
        )
        status = translate_message(PAYMENT_STATUS.get(pay.status, pay.status), loc)
        auth = (
            f" · {t('autorización {code}', loc, code=pay.authorization_code)}"
            if pay.authorization_code
            else ""
        )
        what = what[:1].upper() + what[1:]  # "pasarela de prueba" → "Pasarela de prueba"
        story.append(p(f"{what} — {money(pay.amount)}"))
        story.append(p(f"{status} · {when(pay.authorized_at or pay.created_at)}{auth}", small))
        for f in pay.refunds:
            story.append(
                p(
                    t("Reembolso de {amount}", loc, amount=money(f.amount))
                    + f" · {when(f.created_at)}",
                    small,
                )
            )
    # Política y aviso legal
    story.append(p(t("Política de cancelación", loc), h2))
    story.append(p(r.cancellation_policy))
    story.append(Spacer(1, 8 * mm))
    story.append(p(t("Este comprobante no es una boleta ni factura electrónica.", loc), small))

    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title=t("Comprobante de reserva", loc) + f" {r.code}",
        author=company.name,
        lang=loc,
    )

    def decorate(canvas, _doc) -> None:  # type: ignore[no-untyped-def]
        canvas.setStrokeColor(CHAMPAGNE)
        canvas.setLineWidth(1.5)
        canvas.line(18 * mm, A4[1] - 10 * mm, A4[0] - 18 * mm, A4[1] - 10 * mm)

    doc.build(story, onFirstPage=decorate, onLaterPages=decorate)
    return buf.getvalue()
