import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Any

from pydantic import AfterValidator, AwareDatetime, BaseModel, Field, field_validator

from app.auth.schemas import Email
from app.core.i18n import translate_message
from app.core.money import Amount
from app.core.validators import clean_text, normalize_phone
from app.pricing.schemas import QuoteOut
from app.reservations.models import ReservationStatus

Text300 = Annotated[str, Field(min_length=5, max_length=300), AfterValidator(clean_text)]


class TripIn(BaseModel):
    service_id: uuid.UUID
    pickup_at: AwareDatetime
    duration_minutes: int = Field(ge=15, le=24 * 60)


class PreviewOut(BaseModel):
    quote: QuoteOut
    available: bool
    passenger_capacity: int


class ReservationIn(TripIn):
    pickup_address: Text300
    dropoff_address: Annotated[str | None, Field(default=None, max_length=300)] = None
    passenger_count: int = Field(ge=1, le=60)
    contact_name: Annotated[str, Field(min_length=2, max_length=200), AfterValidator(clean_text)]
    contact_email: Email
    contact_phone: str = Field(max_length=25)
    notes: str | None = Field(default=None, max_length=1000)
    # El total que vio el cliente: si el precio cambió entretanto, se le avisa.
    expected_total: Decimal = Field(ge=0)
    accept_policy: bool
    idempotency_key: uuid.UUID

    @field_validator("contact_phone")
    @classmethod
    def _phone(cls, v: str) -> str:
        phone = normalize_phone(v)
        if not phone:
            raise ValueError("Este campo es obligatorio.")
        return phone

    @field_validator("dropoff_address", "notes")
    @classmethod
    def _optional_text(cls, v: str | None) -> str | None:
        return clean_text(v) or None if v is not None else None

    @field_validator("accept_policy")
    @classmethod
    def _policy(cls, v: bool) -> bool:
        if not v:
            raise ValueError("Debe aceptar la política de cancelación.")
        return v


class CancelIn(BaseModel):
    reason: str | None = Field(default=None, max_length=500)


class AdminCancelIn(BaseModel):
    reason: Annotated[str, Field(min_length=3, max_length=500), AfterValidator(clean_text)]
    # Por defecto, si cancela la empresa se devuelve todo; se puede aplicar la política.
    apply_policy: bool = False


class NoteIn(BaseModel):
    note: str | None = Field(default=None, max_length=500)


class ServiceBrief(BaseModel):
    id: uuid.UUID
    name: str
    slug: str


class PricingSummary(BaseModel):
    lines: list[dict[str, Any]]
    net: Amount
    tax: Amount
    tax_name: str
    prices_include_tax: bool
    billed_hours: Amount


class ReservationSummary(BaseModel):
    id: uuid.UUID
    code: str
    status: ReservationStatus
    service: ServiceBrief
    pickup_at: datetime
    pickup_local: str
    duration_minutes: int
    passenger_count: int
    contact_name: str
    currency: str
    total_amount: Amount
    hold_expires_at: datetime | None
    driver_name: str | None = None
    vehicle_label: str | None = None
    driver_code: str | None = None  # 4 dígitos que el chófer le dirá al llegar


class EventOut(BaseModel):
    from_status: ReservationStatus | None
    to_status: ReservationStatus
    actor_label: str
    note: str | None
    created_at: datetime

    @field_validator("actor_label", "note")
    @classmethod
    def _translate(cls, value: str | None) -> str | None:
        # Autores y notas que arma el sistema ("Cliente", "Abordaje validado con QR"), en el
        # idioma de quien consulta. Lo que escribe una persona queda tal cual.
        return translate_message(value) if value else value


class RefundOut(BaseModel):
    id: uuid.UUID
    amount: Amount
    status: str
    reason: str | None
    error_message: str | None
    created_at: datetime

    @field_validator("reason", "error_message")
    @classmethod
    def _translate(cls, value: str | None) -> str | None:
        # Motivos automáticos ("Cancelación de la reserva") y errores de la pasarela, en el
        # idioma de la persona. Un motivo escrito a mano por el personal queda tal cual.
        return translate_message(value) if value else value


class PaymentOut(BaseModel):
    id: uuid.UUID
    provider: str
    status: str
    amount: Amount
    refunded_amount: Amount
    card_last4: str | None
    authorization_code: str | None
    payment_type: str | None
    installments: int | None
    authorized_at: datetime | None
    created_at: datetime
    refunds: list[RefundOut]


class ReservationOut(ReservationSummary):
    end_at: datetime
    pickup_address: str
    dropoff_address: str | None
    notes: str | None
    contact_email: str
    contact_phone: str
    pricing: PricingSummary
    cancellation_policy: str
    confirmed_at: datetime | None
    cancelled_at: datetime | None
    cancellation_reason: str | None
    refund_amount: Amount | None
    created_at: datetime
    # Lo que puede hacer el cliente ahora mismo
    can_cancel: bool
    refund_if_cancelled_now: Amount | None
    can_pay: bool
    payments: list[PaymentOut]
    # Asignación visible para el cliente
    driver_name: str | None = None
    vehicle_label: str | None = None
    boarded_at: datetime | None = None
    # Token del QR de abordaje: sólo en la respuesta al dueño de la reserva.
    qr_token: str | None = None


class CustomerBrief(BaseModel):
    id: uuid.UUID
    email: str
    name: str


class AssignmentBrief(BaseModel):
    id: uuid.UUID
    label: str
    phone: str | None = None


class ReservationAdminOut(ReservationOut):
    customer: CustomerBrief | None
    events: list[EventOut]
    vehicle: AssignmentBrief | None
    driver: AssignmentBrief | None


class OptionOut(BaseModel):
    id: uuid.UUID
    label: str
    available: bool
    reason: str | None

    @field_validator("reason")
    @classmethod
    def _translate(cls, value: str | None) -> str | None:
        return translate_message(value) if value else value  # "Ocupado en RES-…", "Inactivo"…


class AssignmentOptionsOut(BaseModel):
    vehicles: list[OptionOut]
    drivers: list[OptionOut]


class AssignIn(BaseModel):
    vehicle_id: uuid.UUID | None = None
    driver_id: uuid.UUID | None = None


class ReservationFilters(BaseModel):
    status: ReservationStatus | None = None
    service_id: uuid.UUID | None = None
    date_from: date | None = None
    date_to: date | None = None
    q: str | None = Field(default=None, max_length=100)
    # Confirmadas sin vehículo o sin conductor: lo que falta despachar.
    unassigned: bool = False
