"""Código de verificación del chófer: 4 dígitos que el chófer le dice al pasajero al llegar.

El pasajero lo ve en su reserva y el chófer en su viaje; si no coinciden, el pasajero sabe que
no debe subir. Se calcula (no se guarda) con una clave del servidor a partir de la reserva y del
chófer asignado: si cambia el chófer, cambia el código. Funciona sin cámara ni conexión.
"""

import hashlib
import hmac

from app.core.config import get_settings
from app.reservations.models import Reservation
from app.reservations.models import ReservationStatus as S

# Sólo tiene sentido antes de subir: desde la confirmación hasta que el chófer llega.
_VISIBLE = {S.CONFIRMED, S.EN_ROUTE, S.ARRIVED}


def driver_code(r: Reservation) -> str | None:
    if r.driver_id is None or r.status not in _VISIBLE:
        return None
    key = f"driver-code:{get_settings().jwt_secret}".encode()
    digest = hmac.new(key, f"{r.id}:{r.driver_id}".encode(), hashlib.sha256).digest()
    return f"{int.from_bytes(digest[:4], 'big') % 10_000:04d}"
