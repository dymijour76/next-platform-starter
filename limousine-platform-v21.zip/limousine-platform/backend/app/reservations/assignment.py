"""Asignación de vehículo y conductor a una reserva confirmada.

Las validaciones de aquí dan mensajes claros; la garantía final contra la doble
asignación son las restricciones de exclusión de PostgreSQL (ver models.py):
si dos personas asignan el mismo vehículo a la vez, una de las dos falla.
"""

import uuid
from dataclasses import dataclass
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.core.errors import AppError, Conflict, NotFound
from app.core.i18n import t
from app.core.request_context import RequestMeta
from app.drivers.models import Driver, DriverStatus
from app.reservations import service as reservations
from app.reservations.models import ACTIVE_TRIP, Reservation, ReservationEvent, ReservationStatus
from app.settings.service import get_pricing_settings
from app.users.models import User
from app.vehicles.models import Vehicle, VehicleBlock, VehicleStatus


@dataclass
class Option:
    id: uuid.UUID
    label: str
    available: bool
    reason: str | None


async def _busy(db: AsyncSession, r: Reservation, column: str) -> dict[uuid.UUID, str]:
    """Vehículos o conductores ocupados en el periodo de la reserva → código del otro viaje."""
    col = getattr(Reservation, column)
    rows = await db.execute(
        select(col, Reservation.code).where(
            col.is_not(None),
            Reservation.id != r.id,
            Reservation.status.in_(ACTIVE_TRIP),
            Reservation.pickup_at < r.blocks_until,
            Reservation.blocks_until > r.pickup_at,
        )
    )
    return {k: code for k, code in rows.all()}


async def _pickup_date(db: AsyncSession, r: Reservation):  # type: ignore[no-untyped-def]
    tz = ZoneInfo((await get_pricing_settings(db)).timezone)
    return r.pickup_at.astimezone(tz).date()


async def vehicle_options(db: AsyncSession, r: Reservation) -> list[Option]:
    busy = await _busy(db, r, "vehicle_id")
    blocked = set(
        await db.scalars(
            select(VehicleBlock.vehicle_id).where(
                VehicleBlock.starts_at < r.blocks_until, VehicleBlock.ends_at > r.pickup_at
            )
        )
    )
    vehicles = (
        await db.scalars(
            select(Vehicle).where(Vehicle.service_id == r.service_id).order_by(Vehicle.plate)
        )
    ).unique()
    options = []
    for v in vehicles:
        reason = None
        if v.status != VehicleStatus.ACTIVE:
            reason = "Fuera de servicio"
        elif v.id in blocked:
            reason = "En mantención en ese horario"
        elif v.passenger_capacity < r.passenger_count:
            reason = f"Capacidad {v.passenger_capacity} pasajeros"
        elif v.id in busy and v.id != r.vehicle_id:
            reason = f"Ocupado en {busy[v.id]}"
        options.append(Option(v.id, v.display_label, reason is None, reason))
    return options


async def driver_options(db: AsyncSession, r: Reservation) -> list[Option]:
    busy = await _busy(db, r, "driver_id")
    day = await _pickup_date(db, r)
    drivers = (await db.scalars(select(Driver))).unique()
    options = []
    for d in sorted(drivers, key=lambda d: d.name):
        reason = None
        if d.status != DriverStatus.ACTIVE or not d.user.is_active:
            reason = "Inactivo"
        elif d.license_expires_on < day:
            reason = f"Licencia vencida el {d.license_expires_on:%d-%m-%Y}"
        elif d.id in busy and d.id != r.driver_id:
            reason = f"Ocupado en {busy[d.id]}"
        options.append(
            Option(
                d.id,
                t("{name} (licencia {cls})", name=d.name, cls=d.license_class),
                reason is None,
                reason,
            )
        )
    return options


async def assign(
    db: AsyncSession,
    actor: User,
    reservation_id: uuid.UUID,
    vehicle_id: uuid.UUID | None,
    driver_id: uuid.UUID | None,
    meta: RequestMeta,
) -> tuple[Reservation, bool, bool]:
    """Devuelve (reserva, cambió el vehículo, cambió el conductor)."""
    r = await reservations._get_locked(db, reservation_id)
    if r.status != ReservationStatus.CONFIRMED:
        raise Conflict(
            "Sólo se asigna vehículo y conductor a reservas confirmadas que aún no comienzan.",
            code="NOT_ASSIGNABLE",
        )
    if vehicle_id is not None:
        option = next((o for o in await vehicle_options(db, r) if o.id == vehicle_id), None)
        if option is None:
            raise AppError(
                "Ese vehículo no pertenece al servicio reservado.",
                code="INVALID_VEHICLE",
                fields={"vehicle_id": "Elija un vehículo del servicio."},
            )
        if not option.available:
            raise Conflict(
                f"Vehículo no disponible: {option.reason}.",
                code="VEHICLE_UNAVAILABLE",
                fields={"vehicle_id": option.reason or ""},
            )
    if driver_id is not None:
        option = next((o for o in await driver_options(db, r) if o.id == driver_id), None)
        if option is None:
            raise NotFound("El conductor no existe.")
        if not option.available:
            raise Conflict(
                f"Conductor no disponible: {option.reason}.",
                code="DRIVER_UNAVAILABLE",
                fields={"driver_id": option.reason or ""},
            )

    vehicle_changed = vehicle_id != r.vehicle_id
    driver_changed = driver_id != r.driver_id
    if not (vehicle_changed or driver_changed):
        return r, False, False

    before = {"vehicle_id": str(r.vehicle_id), "driver_id": str(r.driver_id)}
    r.vehicle_id, r.driver_id = vehicle_id, driver_id
    try:
        await db.flush()
    except IntegrityError as exc:
        # Otra persona asignó ese vehículo o conductor a un viaje que se solapa.
        await db.rollback()
        raise Conflict(
            "Ese vehículo o conductor acaba de quedar ocupado en ese horario. "
            "Recargue y elija otro.",
            code="ASSIGNMENT_CONFLICT",
        ) from exc

    await db.refresh(r, ["vehicle", "driver"])
    parts = [
        f"vehículo {r.vehicle.label}" if r.vehicle else "sin vehículo",
        f"conductor {r.driver.name}" if r.driver else "sin conductor",
    ]
    r.events.append(
        ReservationEvent(
            from_status=r.status,
            to_status=r.status,
            actor_user_id=actor.id,
            actor_label=reservations._staff_label(actor),
            note=f"Asignación: {', '.join(parts)}",
        )
    )
    record(
        db,
        actor_id=actor.id,
        action="RESERVATION_ASSIGN",
        entity_type="reservation",
        entity_id=r.id,
        meta=meta,
        before=before,
        after={"vehicle_id": str(vehicle_id), "driver_id": str(driver_id)},
    )
    await db.commit()
    await db.refresh(r)
    return r, vehicle_changed, driver_changed
