"""Carrusel: público (/content/carousel) y administración (/admin/carousel)."""

import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Response, status
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.auth.deps import DB, require
from app.auth.router import Meta
from app.carousel.models import CarouselSlide
from app.carousel.schemas import OrderIn, SlideAdminOut, SlideIn, SlideOut
from app.core.errors import AppError, NotFound
from app.core.translations import localized
from app.media.models import MediaAsset
from app.media.service import image_out
from app.media.storage import Storage, get_storage
from app.users.models import User

router = APIRouter(tags=["content"])
Writer = Annotated[User, Depends(require("content:write"))]
StorageDep = Annotated[Storage, Depends(get_storage)]
MAX_PUBLIC_SLIDES = 8


def _live(s: CarouselSlide, now: datetime) -> bool:
    return (
        s.is_active
        and (s.starts_at is None or s.starts_at <= now)
        and (s.ends_at is None or s.ends_at > now)
    )


def _out(s: CarouselSlide, storage: Storage, *, translate: bool = True) -> SlideOut:
    """En la portada, en el idioma de la persona; en el panel, el texto base (español)."""
    tr = s.translations if translate else None
    return SlideOut(
        id=s.id,
        title=localized(tr, "title", s.title),
        subtitle=localized(tr, "subtitle", s.subtitle),
        cta_label=localized(tr, "cta_label", s.cta_label),
        cta_url=s.cta_url,
        image=image_out(s.image, storage),
    )


def _admin_out(s: CarouselSlide, storage: Storage) -> SlideAdminOut:
    return SlideAdminOut(
        **_out(s, storage, translate=False).model_dump(),
        image_id=s.image_id,
        translations=s.translations or {},
        sort_order=s.sort_order,
        is_active=s.is_active,
        starts_at=s.starts_at,
        ends_at=s.ends_at,
        live=_live(s, datetime.now(UTC)),
    )


@router.get("/content/carousel", response_model=list[SlideOut])
async def public_carousel(db: DB, storage: StorageDep) -> list[SlideOut]:
    now = datetime.now(UTC)
    rows = await db.scalars(
        select(CarouselSlide)
        .where(
            CarouselSlide.is_active.is_(True),
            or_(CarouselSlide.starts_at.is_(None), CarouselSlide.starts_at <= now),
            or_(CarouselSlide.ends_at.is_(None), CarouselSlide.ends_at > now),
        )
        .order_by(CarouselSlide.sort_order, CarouselSlide.created_at)
        .limit(MAX_PUBLIC_SLIDES)
    )
    return [_out(s, storage) for s in rows]


async def _all(db: AsyncSession) -> list[CarouselSlide]:
    return list(
        await db.scalars(
            select(CarouselSlide).order_by(CarouselSlide.sort_order, CarouselSlide.created_at)
        )
    )


async def _get(db: AsyncSession, slide_id: uuid.UUID) -> CarouselSlide:
    slide = await db.get(CarouselSlide, slide_id, populate_existing=True)
    if slide is None:
        raise NotFound("La diapositiva no existe.")
    return slide


async def _check_image(db: AsyncSession, image_id: uuid.UUID) -> None:
    if await db.get(MediaAsset, image_id) is None:
        raise AppError(
            "La imagen no existe.", code="UNKNOWN_IMAGE", fields={"image_id": "Elija una imagen."}
        )


def _snapshot(data: SlideIn) -> dict[str, object]:
    return data.model_dump(mode="json")


@router.get("/admin/carousel", response_model=list[SlideAdminOut])
async def list_slides(_: Writer, db: DB, storage: StorageDep) -> list[SlideAdminOut]:
    return [_admin_out(s, storage) for s in await _all(db)]


@router.post("/admin/carousel", response_model=SlideAdminOut, status_code=status.HTTP_201_CREATED)
async def create_slide(
    data: SlideIn, actor: Writer, db: DB, storage: StorageDep, meta: Meta
) -> SlideAdminOut:
    await _check_image(db, data.image_id)
    last = max((s.sort_order for s in await _all(db)), default=0)
    slide = CarouselSlide(**data.model_dump(), sort_order=last + 10)
    db.add(slide)
    await db.flush()
    record(
        db,
        actor_id=actor.id,
        action="SLIDE_CREATE",
        entity_type="carousel_slide",
        entity_id=slide.id,
        meta=meta,
        after=_snapshot(data),
    )
    await db.commit()
    return _admin_out(await _get(db, slide.id), storage)


@router.get("/admin/carousel/{slide_id}", response_model=SlideAdminOut)
async def get_slide(slide_id: uuid.UUID, _: Writer, db: DB, storage: StorageDep) -> SlideAdminOut:
    return _admin_out(await _get(db, slide_id), storage)


@router.put("/admin/carousel/{slide_id}", response_model=SlideAdminOut)
async def update_slide(
    slide_id: uuid.UUID, data: SlideIn, actor: Writer, db: DB, storage: StorageDep, meta: Meta
) -> SlideAdminOut:
    slide = await _get(db, slide_id)
    await _check_image(db, data.image_id)
    for key, value in data.model_dump().items():
        setattr(slide, key, value)
    record(
        db,
        actor_id=actor.id,
        action="SLIDE_UPDATE",
        entity_type="carousel_slide",
        entity_id=slide.id,
        meta=meta,
        after=_snapshot(data),
    )
    await db.commit()
    return _admin_out(await _get(db, slide.id), storage)


@router.delete("/admin/carousel/{slide_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_slide(slide_id: uuid.UUID, actor: Writer, db: DB, meta: Meta) -> Response:
    slide = await _get(db, slide_id)
    record(
        db,
        actor_id=actor.id,
        action="SLIDE_DELETE",
        entity_type="carousel_slide",
        entity_id=slide.id,
        meta=meta,
        before={"title": slide.title},
    )
    await db.delete(slide)
    await db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.put("/admin/carousel-order", response_model=list[SlideAdminOut])
async def reorder(
    data: OrderIn, actor: Writer, db: DB, storage: StorageDep, meta: Meta
) -> list[SlideAdminOut]:
    """Recibe los ids en el orden deseado; deben ser exactamente las diapositivas existentes."""
    slides = {s.id: s for s in await _all(db)}
    if set(data.ids) != set(slides) or len(data.ids) != len(slides):
        raise AppError("La lista debe incluir cada diapositiva una vez.", code="INVALID_ORDER")
    for position, slide_id in enumerate(data.ids):
        slides[slide_id].sort_order = (position + 1) * 10
    record(
        db,
        actor_id=actor.id,
        action="SLIDE_REORDER",
        entity_type="carousel_slide",
        entity_id=None,
        meta=meta,
        after={"ids": [str(i) for i in data.ids]},
    )
    await db.commit()
    return [_admin_out(s, storage) for s in await _all(db)]
