import re
import uuid
from datetime import datetime
from typing import Annotated, Any, Self

from pydantic import (
    AfterValidator,
    AwareDatetime,
    BaseModel,
    Field,
    field_validator,
    model_validator,
)

from app.core.translations import SlideTranslations
from app.core.validators import clean_text
from app.media.schemas import ImageOut


def _safe_url(value: str | None) -> str | None:
    """Sólo rutas internas (/services) o direcciones https: nunca javascript: ni data:."""
    if value is None or not value.strip():
        return None
    value = value.strip()
    if re.fullmatch(r"/(?!/)[^\s]*", value) or re.fullmatch(r"https://[^\s]+", value):
        return value
    raise ValueError("Use una ruta del sitio (/services) o una dirección https://.")


class SlideIn(BaseModel):
    image_id: uuid.UUID
    translations: SlideTranslations = Field(default_factory=dict)
    title: Annotated[str, Field(min_length=1, max_length=80), AfterValidator(clean_text)]
    subtitle: Annotated[str | None, Field(default=None, max_length=200)] = None
    cta_label: Annotated[str | None, Field(default=None, max_length=30)] = None
    cta_url: Annotated[
        str | None, Field(default=None, max_length=300), AfterValidator(_safe_url)
    ] = None
    is_active: bool = True
    starts_at: AwareDatetime | None = None
    ends_at: AwareDatetime | None = None

    @field_validator("subtitle", "cta_label")
    @classmethod
    def _clean(cls, v: str | None) -> str | None:
        return clean_text(v) or None if v is not None else None

    @model_validator(mode="after")
    def _consistency(self) -> Self:
        if (self.cta_label is None) != (self.cta_url is None):
            raise ValueError("El botón necesita texto y enlace, o ninguno de los dos.")
        if self.starts_at and self.ends_at and self.ends_at <= self.starts_at:
            raise ValueError("El término debe ser posterior al inicio.")
        return self


class SlideOut(BaseModel):
    id: uuid.UUID
    title: str
    subtitle: str | None
    cta_label: str | None
    cta_url: str | None
    image: ImageOut


class SlideAdminOut(SlideOut):
    image_id: uuid.UUID
    translations: dict[str, dict[str, Any]] = {}
    sort_order: int
    is_active: bool
    starts_at: datetime | None
    ends_at: datetime | None
    # Si hoy se muestra en la portada (activa y dentro de su programación)
    live: bool


class OrderIn(BaseModel):
    ids: list[uuid.UUID] = Field(min_length=1, max_length=50)
