"""Módulo carousel (se implementa en fases posteriores)."""
