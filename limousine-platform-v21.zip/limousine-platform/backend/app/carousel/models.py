"""Carrusel de la portada."""

import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Integer, String, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.media.models import MediaAsset


class CarouselSlide(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "carousel_slides"
    __table_args__ = (
        CheckConstraint(
            "starts_at IS NULL OR ends_at IS NULL OR ends_at > starts_at", name="schedule_valid"
        ),
        CheckConstraint("(cta_label IS NULL) = (cta_url IS NULL)", name="cta_complete"),
    )

    image_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("media_assets.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(80), nullable=False)
    subtitle: Mapped[str | None] = mapped_column(String(200))
    cta_label: Mapped[str | None] = mapped_column(String(30))
    cta_url: Mapped[str | None] = mapped_column(String(300))
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    # Programación opcional (campañas, fechas especiales)
    starts_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ends_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    # Traducciones: {"en": {"name": "...", ...}, "fr": {...}}. El español son las columnas.
    translations: Mapped[dict[str, Any]] = mapped_column(
        JSONB, nullable=False, server_default=text("'{}'::jsonb")
    )

    image: Mapped[MediaAsset] = relationship(lazy="joined", innerjoin=True)
