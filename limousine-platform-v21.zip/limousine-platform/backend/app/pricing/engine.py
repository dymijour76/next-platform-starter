"""Motor de precios: función pura, sin base de datos ni reloj.

Recibe la tarifa del servicio, las reglas vigentes, la configuración y los
datos del viaje, y devuelve un desglose línea por línea. Al no depender de nada
externo, el mismo cálculo se puede reproducir y probar de forma exacta.

Orden del cálculo:

1. Tarifa de salida + horas facturables × valor hora (= subtotal).
2. Recargos y descuentos que aplican. Los porcentajes se calculan todos sobre
   el subtotal (no se encadenan), así el cliente puede verificar la cuenta.
3. Ajuste al precio mínimo del servicio, si el total quedó por debajo.
4. Impuesto: si los precios lo incluyen (Chile: IVA incluido), se informa el
   neto y el IVA contenidos en el total; si no, se suma al final.

Cada línea se redondea a la unidad mínima de la moneda y el total es la suma
exacta de las líneas: lo que el cliente ve siempre cuadra.
"""

import math
from dataclasses import dataclass, field
from datetime import date, datetime, time
from decimal import ROUND_HALF_UP, Decimal
from enum import StrEnum
from typing import Any
from zoneinfo import ZoneInfo

# Decimales de cada moneda (ISO 4217). CLP no tiene centavos.
CURRENCY_EXPONENT = {"CLP": 0, "USD": 2, "EUR": 2}


class RuleKind(StrEnum):
    SURCHARGE = "SURCHARGE"
    DISCOUNT = "DISCOUNT"


class AdjustmentType(StrEnum):
    PERCENT = "PERCENT"
    FIXED = "FIXED"


@dataclass(frozen=True)
class Tariff:
    service_id: str
    service_name: str
    base_fare: Decimal
    hourly_rate: Decimal
    min_hours: Decimal
    minimum_fare: Decimal


@dataclass(frozen=True)
class Rule:
    id: str
    name: str
    kind: RuleKind
    adjustment_type: AdjustmentType
    value: Decimal
    service_ids: frozenset[str] | None = None  # None: todos los servicios
    days_of_week: frozenset[int] | None = None  # 0 = lunes ... 6 = domingo
    time_from: time | None = None
    time_until: time | None = None
    valid_from: date | None = None
    valid_until: date | None = None  # inclusive
    min_hours: Decimal | None = None
    priority: int = 100
    # Nombre en otros idiomas: ((idioma, nombre), ...). El español es `name`.
    names: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class Settings:
    currency: str = "CLP"
    timezone: str = "America/Santiago"
    tax_rate: Decimal = Decimal("0.19")
    tax_name: str = "IVA"
    prices_include_tax: bool = True
    billing_increment_minutes: int = 30


@dataclass(frozen=True)
class Line:
    code: str
    label: str
    amount: Decimal
    rule_id: str | None = None
    # Etiqueta en otros idiomas (reglas): se guarda con la reserva para mostrarla siempre igual.
    labels: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class Quote:
    currency: str
    pickup_local: datetime
    requested_minutes: int
    billed_hours: Decimal
    lines: list[Line]
    subtotal: Decimal
    total: Decimal
    net: Decimal
    tax: Decimal
    tax_rate: Decimal
    tax_name: str
    prices_include_tax: bool
    rules_applied: list[str] = field(default_factory=list)

    def snapshot(self, tariff: Tariff) -> dict[str, Any]:
        """Registro inmutable del cálculo, para guardar junto a la reserva."""
        s = str
        return {
            "version": 1,
            "currency": self.currency,
            "service": {"id": tariff.service_id, "name": tariff.service_name},
            "tariff": {
                "base_fare": s(tariff.base_fare),
                "hourly_rate": s(tariff.hourly_rate),
                "min_hours": s(tariff.min_hours),
                "minimum_fare": s(tariff.minimum_fare),
            },
            "pickup_local": self.pickup_local.isoformat(),
            "requested_minutes": self.requested_minutes,
            "billed_hours": s(self.billed_hours),
            "lines": [
                {
                    "code": ln.code,
                    "label": ln.label,
                    "amount": s(ln.amount),
                    "rule_id": ln.rule_id,
                    **({"labels": dict(ln.labels)} if ln.labels else {}),
                }
                for ln in self.lines
            ],
            "subtotal": s(self.subtotal),
            "total": s(self.total),
            "net": s(self.net),
            "tax": s(self.tax),
            "tax_rate": s(self.tax_rate),
            "tax_name": self.tax_name,
            "prices_include_tax": self.prices_include_tax,
            "rules_applied": self.rules_applied,
        }


class PricingError(ValueError):
    """Datos del viaje que no permiten calcular un precio."""


def money(value: Decimal, currency: str) -> Decimal:
    exponent = CURRENCY_EXPONENT.get(currency, 2)
    return value.quantize(Decimal(1).scaleb(-exponent), rounding=ROUND_HALF_UP)


def billed_hours(minutes: int, tariff: Tariff, increment: int) -> Decimal:
    """Horas a cobrar: redondea hacia arriba al tramo y respeta el mínimo."""
    if minutes <= 0:
        raise PricingError("La duración debe ser mayor que cero.")
    rounded = math.ceil(minutes / increment) * increment
    return max(Decimal(rounded) / Decimal(60), tariff.min_hours)


def _in_time_window(t: time, start: time | None, end: time | None) -> bool:
    if start is None or end is None:
        return True
    if start <= end:
        return start <= t < end
    return t >= start or t < end  # franja que cruza medianoche (p. ej. 22:00-06:00)


def rule_applies(rule: Rule, tariff: Tariff, pickup_local: datetime, hours: Decimal) -> bool:
    if rule.service_ids is not None and tariff.service_id not in rule.service_ids:
        return False
    day = pickup_local.date()
    if rule.valid_from and day < rule.valid_from:
        return False
    if rule.valid_until and day > rule.valid_until:
        return False
    if rule.days_of_week is not None and pickup_local.weekday() not in rule.days_of_week:
        return False
    if not _in_time_window(pickup_local.time(), rule.time_from, rule.time_until):
        return False
    return not (rule.min_hours is not None and hours < rule.min_hours)


def _format_hours(hours: Decimal) -> str:
    text = f"{hours.normalize():f}".replace(".", ",")
    return f"{text} hora" if hours == 1 else f"{text} horas"


def calculate(
    tariff: Tariff,
    rules: list[Rule],
    settings: Settings,
    pickup_at: datetime,
    duration_minutes: int,
) -> Quote:
    if pickup_at.tzinfo is None:
        raise PricingError("La fecha de recogida debe incluir zona horaria.")
    cur = settings.currency
    pickup_local = pickup_at.astimezone(ZoneInfo(settings.timezone))
    hours = billed_hours(duration_minutes, tariff, settings.billing_increment_minutes)

    lines: list[Line] = []
    if tariff.base_fare:
        lines.append(Line("BASE_FARE", "Tarifa de salida", money(tariff.base_fare, cur)))
    lines.append(
        Line(
            "HOURS",
            f"{_format_hours(hours)} × {format_amount(tariff.hourly_rate, cur)}",
            money(tariff.hourly_rate * hours, cur),
        )
    )
    subtotal = sum((ln.amount for ln in lines), Decimal(0))

    applied: list[str] = []
    matching = sorted(
        (r for r in rules if rule_applies(r, tariff, pickup_local, hours)),
        key=lambda r: (r.priority, r.name),
    )
    for rule in matching:
        percent = rule.adjustment_type == AdjustmentType.PERCENT
        suffix = f" ({format_percent(rule.value)})" if percent else ""
        amount = (
            money(subtotal * rule.value / Decimal(100), cur) if percent else money(rule.value, cur)
        )
        if rule.kind == RuleKind.DISCOUNT:
            amount = -amount
        labels = tuple((loc, f"{name}{suffix}") for loc, name in rule.names if name)
        lines.append(Line("RULE", f"{rule.name}{suffix}", amount, rule_id=rule.id, labels=labels))
        applied.append(rule.id)

    total = sum((ln.amount for ln in lines), Decimal(0))
    minimum = money(tariff.minimum_fare, cur)
    if total < minimum:
        lines.append(Line("MINIMUM_FARE", "Ajuste a tarifa mínima", minimum - total))
        total = minimum
    if total < 0:  # descuentos mayores que el precio
        lines.append(Line("FLOOR", "Ajuste", -total))
        total = Decimal(0)

    if settings.prices_include_tax:
        net = money(total / (1 + settings.tax_rate), cur)
        tax = total - net
    else:
        net = total
        tax = money(total * settings.tax_rate, cur)
        if tax:
            lines.append(
                Line("TAX", f"{settings.tax_name} ({format_percent(settings.tax_rate * 100)})", tax)
            )
        total = net + tax

    return Quote(
        currency=cur,
        pickup_local=pickup_local,
        requested_minutes=duration_minutes,
        billed_hours=hours,
        lines=lines,
        subtotal=subtotal,
        total=total,
        net=net,
        tax=tax,
        tax_rate=settings.tax_rate,
        tax_name=settings.tax_name,
        prices_include_tax=settings.prices_include_tax,
        rules_applied=applied,
    )


def format_amount(value: Decimal, currency: str) -> str:
    """Formato chileno: $125.000 (punto de miles, coma decimal)."""
    exponent = CURRENCY_EXPONENT.get(currency, 2)
    q = money(value, currency)
    integer, _, frac = f"{abs(q):,.{exponent}f}".partition(".")
    text = integer.replace(",", ".") + (f",{frac}" if frac else "")
    sign = "-" if q < 0 else ""
    return f"{sign}${text}" if currency == "CLP" else f"{sign}{text} {currency}"


def format_percent(value: Decimal) -> str:
    return f"{value.normalize():f}".replace(".", ",") + " %"
