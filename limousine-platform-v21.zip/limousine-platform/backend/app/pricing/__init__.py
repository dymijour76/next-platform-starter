"""Módulo pricing (se implementa en fases posteriores)."""
