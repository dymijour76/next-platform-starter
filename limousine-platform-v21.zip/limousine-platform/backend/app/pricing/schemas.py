import uuid
from datetime import date, datetime, time
from decimal import Decimal
from typing import Annotated, Self

from pydantic import AfterValidator, AwareDatetime, BaseModel, ConfigDict, Field, model_validator

from app.core.money import Amount
from app.core.translations import RuleTranslations
from app.core.validators import clean_text
from app.pricing.engine import AdjustmentType, RuleKind

Name = Annotated[str, Field(min_length=1, max_length=100), AfterValidator(clean_text)]


class _RuleFields(BaseModel):
    name: Name
    translations: RuleTranslations = Field(default_factory=dict)
    description: str | None = Field(default=None, max_length=500)
    kind: RuleKind
    adjustment_type: AdjustmentType
    value: Decimal = Field(gt=0, le=Decimal("999999999"), decimal_places=2)
    service_ids: list[uuid.UUID] | None = Field(default=None, max_length=50)
    days_of_week: list[Annotated[int, Field(ge=0, le=6)]] | None = Field(default=None, max_length=7)
    time_from: time | None = None
    time_until: time | None = None
    valid_from: date | None = None
    valid_until: date | None = None
    min_hours: Decimal | None = Field(default=None, gt=0, le=24, decimal_places=2)
    priority: int = Field(default=100, ge=0, le=10000)
    is_active: bool = True

    @model_validator(mode="after")
    def _consistency(self) -> Self:
        if self.adjustment_type == AdjustmentType.PERCENT and self.value > 100:
            raise ValueError("Un porcentaje no puede superar el 100 %.")
        if (self.time_from is None) != (self.time_until is None):
            raise ValueError("Indique la hora de inicio y la de término de la franja.")
        if self.time_from is not None and self.time_from == self.time_until:
            raise ValueError("La franja horaria no puede empezar y terminar a la misma hora.")
        if self.valid_from and self.valid_until and self.valid_from > self.valid_until:
            raise ValueError("La fecha de inicio debe ser anterior a la de término.")
        # Listas vacías equivalen a "sin restricción".
        if self.days_of_week is not None:
            self.days_of_week = sorted(set(self.days_of_week)) or None
        if self.service_ids is not None:
            self.service_ids = list(dict.fromkeys(self.service_ids)) or None
        return self


class RuleIn(_RuleFields):
    pass


class RuleOut(_RuleFields):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    value: Amount
    min_hours: Amount | None = None
    created_at: datetime
    updated_at: datetime


class QuoteIn(BaseModel):
    service_id: uuid.UUID
    pickup_at: AwareDatetime
    duration_minutes: int = Field(ge=15, le=24 * 60)


class QuoteLineOut(BaseModel):
    code: str
    label: str
    amount: Amount


class QuoteServiceOut(BaseModel):
    id: uuid.UUID
    name: str


class QuoteOut(BaseModel):
    service: QuoteServiceOut
    currency: str
    pickup_local: datetime
    duration_minutes: int
    billed_hours: Amount
    lines: list[QuoteLineOut]
    total: Amount
    net: Amount
    tax: Amount
    tax_rate: Amount
    tax_name: str
    prices_include_tax: bool
