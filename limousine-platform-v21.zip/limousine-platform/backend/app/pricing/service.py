"""Reglas de precio y cotización."""

import uuid
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from fastapi import status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.core.errors import AppError, NotFound
from app.core.i18n import get_locale, translate_message
from app.core.request_context import RequestMeta
from app.core.translations import localized
from app.pricing import engine
from app.pricing.models import PricingRule
from app.pricing.schemas import QuoteIn, QuoteLineOut, QuoteOut, QuoteServiceOut, RuleIn
from app.services.models import Service
from app.settings.schemas import PricingSettings
from app.settings.service import get_pricing_settings
from app.users.models import User


class QuoteRejected(AppError):
    status_code = status.HTTP_422_UNPROCESSABLE_CONTENT
    code = "QUOTE_REJECTED"


# ------------------------------------------------------------------ conversión a motor


def to_tariff(service: Service) -> engine.Tariff:
    return engine.Tariff(
        service_id=str(service.id),
        service_name=service.name,
        base_fare=service.base_fare,
        hourly_rate=service.hourly_rate,
        min_hours=service.min_hours,
        minimum_fare=service.minimum_fare,
    )


def to_rule(rule: PricingRule) -> engine.Rule:
    return engine.Rule(
        id=str(rule.id),
        name=rule.name,
        kind=engine.RuleKind(rule.kind),
        adjustment_type=engine.AdjustmentType(rule.adjustment_type),
        value=rule.value,
        service_ids=frozenset(str(s) for s in rule.service_ids) if rule.service_ids else None,
        days_of_week=frozenset(rule.days_of_week) if rule.days_of_week else None,
        time_from=rule.time_from,
        time_until=rule.time_until,
        valid_from=rule.valid_from,
        valid_until=rule.valid_until,
        min_hours=rule.min_hours,
        priority=rule.priority,
        names=tuple(
            (loc, fields["name"])
            for loc, fields in (rule.translations or {}).items()
            if fields.get("name")
        ),
    )


def to_engine_settings(s: PricingSettings) -> engine.Settings:
    return engine.Settings(
        currency=s.currency,
        timezone=s.timezone,
        tax_rate=s.tax_rate,
        tax_name=s.tax_name,
        prices_include_tax=s.prices_include_tax,
        billing_increment_minutes=s.billing_increment_minutes,
    )


# ------------------------------------------------------------------ cotización


async def active_rules(db: AsyncSession) -> list[engine.Rule]:
    rows = await db.scalars(select(PricingRule).where(PricingRule.is_active.is_(True)))
    return [to_rule(r) for r in rows]


def check_booking_window(
    pickup_at: datetime, settings: PricingSettings, now: datetime | None = None
) -> None:
    now = now or datetime.now(UTC)
    earliest = now + timedelta(minutes=settings.min_notice_minutes)
    if pickup_at < earliest:
        hours = settings.min_notice_minutes / 60
        text = f"{hours:g} hora" if hours == 1 else f"{hours:g} horas"
        raise QuoteRejected(
            f"Las reservas se hacen con al menos {text} de anticipación.",
            code="PICKUP_TOO_SOON",
            fields={"pickup_at": f"Elija una hora con al menos {text} de anticipación."},
        )
    if pickup_at > now + timedelta(days=settings.max_advance_days):
        raise QuoteRejected(
            f"Se puede reservar hasta {settings.max_advance_days} días antes.",
            code="PICKUP_TOO_FAR",
            fields={"pickup_at": "La fecha está demasiado lejos."},
        )


async def quote(
    db: AsyncSession, data: QuoteIn, *, simulation: bool = False
) -> tuple[engine.Quote, engine.Tariff, Service]:
    """Cotiza un viaje. En simulación (panel) se permiten servicios inactivos y cualquier fecha."""
    service = await db.get(Service, data.service_id)
    if service is None or (not service.is_active and not simulation):
        raise NotFound("El servicio no existe o no está disponible.")
    settings = await get_pricing_settings(db)
    if not simulation:
        check_booking_window(data.pickup_at, settings)
    if service.max_hours is not None and Decimal(data.duration_minutes) / 60 > service.max_hours:
        raise QuoteRejected(
            f"Este servicio se reserva por un máximo de {service.max_hours.normalize():f} horas.",
            code="DURATION_TOO_LONG",
            fields={"duration_minutes": "Supera el máximo de horas del servicio."},
        )
    tariff = to_tariff(service)
    result = engine.calculate(
        tariff, await active_rules(db), to_engine_settings(settings), data.pickup_at,
        data.duration_minutes,
    )  # fmt: skip
    return result, tariff, service


def line_label(label: str, labels: dict[str, str] | None = None) -> str:
    """Etiqueta de una línea del desglose en el idioma de la persona.

    Las reglas traen su nombre en cada idioma (guardado con la reserva); las demás
    líneas ("Tarifa de salida", "3 horas × $85.000") se traducen por plantilla.
    """
    locale = get_locale()
    if labels and locale in labels:
        return labels[locale]
    return translate_message(label)


def quote_out(result: engine.Quote, service: Service) -> QuoteOut:
    return QuoteOut(
        service=QuoteServiceOut(
            id=service.id, name=localized(service.translations, "name", service.name)
        ),
        currency=result.currency,
        pickup_local=result.pickup_local,
        duration_minutes=result.requested_minutes,
        billed_hours=result.billed_hours,
        lines=[
            QuoteLineOut(
                code=ln.code, label=line_label(ln.label, dict(ln.labels)), amount=ln.amount
            )
            for ln in result.lines
        ],
        total=result.total,
        net=result.net,
        tax=result.tax,
        tax_rate=result.tax_rate,
        tax_name=translate_message(result.tax_name),
        prices_include_tax=result.prices_include_tax,
    )


# ------------------------------------------------------------------ reglas


async def list_rules(db: AsyncSession) -> list[PricingRule]:
    return list(
        await db.scalars(
            select(PricingRule).order_by(
                PricingRule.is_active.desc(), PricingRule.priority, PricingRule.name
            )
        )
    )


async def get_rule(db: AsyncSession, rule_id: uuid.UUID) -> PricingRule:
    rule = await db.get(PricingRule, rule_id)
    if rule is None:
        raise NotFound("La regla no existe.")
    return rule


async def _check_services(db: AsyncSession, ids: list[uuid.UUID] | None) -> None:
    if not ids:
        return
    found = set(await db.scalars(select(Service.id).where(Service.id.in_(ids))))
    if found != set(ids):
        raise AppError(
            "Algunos servicios indicados no existen.",
            code="UNKNOWN_SERVICE",
            fields={"service_ids": "Contiene servicios que no existen."},
        )


async def create_rule(
    db: AsyncSession, actor: User, data: RuleIn, meta: RequestMeta
) -> PricingRule:
    await _check_services(db, data.service_ids)
    rule = PricingRule(**data.model_dump())
    db.add(rule)
    await db.flush()
    record(
        db, actor_id=actor.id, action="PRICING_RULE_CREATE", entity_type="pricing_rule",
        entity_id=rule.id, meta=meta, after=rule.audit_snapshot(),
    )  # fmt: skip
    await db.commit()
    await db.refresh(rule)
    return rule


async def update_rule(
    db: AsyncSession, actor: User, rule_id: uuid.UUID, data: RuleIn, meta: RequestMeta
) -> PricingRule:
    """Reemplaza la regla completa (PUT): las condiciones vacías quedan sin restricción."""
    rule = await get_rule(db, rule_id)
    await _check_services(db, data.service_ids)
    before = rule.audit_snapshot()
    for key, value in data.model_dump().items():
        setattr(rule, key, value)
    record(
        db, actor_id=actor.id, action="PRICING_RULE_UPDATE", entity_type="pricing_rule",
        entity_id=rule.id, meta=meta, before=before, after=rule.audit_snapshot(),
    )  # fmt: skip
    await db.commit()
    await db.refresh(rule)
    return rule


async def delete_rule(db: AsyncSession, actor: User, rule_id: uuid.UUID, meta: RequestMeta) -> None:
    rule = await get_rule(db, rule_id)
    record(
        db, actor_id=actor.id, action="PRICING_RULE_DELETE", entity_type="pricing_rule",
        entity_id=rule.id, meta=meta, before=rule.audit_snapshot(),
    )  # fmt: skip
    await db.delete(rule)
    await db.commit()
