"""Reglas de precio: recargos y descuentos administrables."""

import uuid
from datetime import date, time
from decimal import Decimal
from typing import Any

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    Integer,
    Numeric,
    SmallInteger,
    String,
    Text,
    Time,
    text,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.core.money import num
from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class PricingRule(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "pricing_rules"
    __table_args__ = (
        CheckConstraint("kind IN ('SURCHARGE', 'DISCOUNT')", name="kind_valid"),
        CheckConstraint("adjustment_type IN ('PERCENT', 'FIXED')", name="adjustment_type_valid"),
        CheckConstraint("value > 0", name="value_positive"),
        CheckConstraint("adjustment_type <> 'PERCENT' OR value <= 100", name="percent_at_most_100"),
        CheckConstraint(
            "(time_from IS NULL) = (time_until IS NULL) AND "
            "(time_from IS NULL OR time_from <> time_until)",
            name="time_window_valid",
        ),
        CheckConstraint(
            "valid_from IS NULL OR valid_until IS NULL OR valid_from <= valid_until",
            name="date_range_valid",
        ),
    )

    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    # Traducciones del nombre: {"en": {"name": "Night surcharge"}, ...}. El español es `name`.
    translations: Mapped[dict[str, Any]] = mapped_column(
        JSONB, nullable=False, server_default=text("'{}'::jsonb")
    )
    kind: Mapped[str] = mapped_column(String(16), nullable=False)
    adjustment_type: Mapped[str] = mapped_column(String(16), nullable=False)
    value: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    # Condiciones (NULL = sin restricción)
    service_ids: Mapped[list[uuid.UUID] | None] = mapped_column(ARRAY(UUID(as_uuid=True)))
    days_of_week: Mapped[list[int] | None] = mapped_column(ARRAY(SmallInteger))
    time_from: Mapped[time | None] = mapped_column(Time)
    time_until: Mapped[time | None] = mapped_column(Time)
    valid_from: Mapped[date | None] = mapped_column(Date)
    valid_until: Mapped[date | None] = mapped_column(Date)
    min_hours: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    priority: Mapped[int] = mapped_column(Integer, nullable=False, server_default="100")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))

    def audit_snapshot(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "adjustment_type": self.adjustment_type,
            "value": num(self.value),
            "service_ids": [str(s) for s in self.service_ids] if self.service_ids else None,
            "days_of_week": self.days_of_week,
            "time_from": self.time_from.isoformat() if self.time_from else None,
            "time_until": self.time_until.isoformat() if self.time_until else None,
            "valid_from": self.valid_from.isoformat() if self.valid_from else None,
            "valid_until": self.valid_until.isoformat() if self.valid_until else None,
            "min_hours": num(self.min_hours) if self.min_hours is not None else None,
            "is_active": self.is_active,
        }
