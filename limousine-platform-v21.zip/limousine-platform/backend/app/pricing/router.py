"""Cotización pública (/pricing/quote) y administración de precios (/admin/pricing/*)."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Request, Response, status

from app.audit.service import record
from app.auth.deps import DB, RedisDep, require
from app.auth.router import Meta
from app.core.i18n import translate_message
from app.core.rate_limit import client_ip, hit
from app.pricing import service
from app.pricing.schemas import QuoteIn, QuoteOut, RuleIn, RuleOut
from app.settings.schemas import PricingSettings, PublicPricingConfig
from app.settings.service import get_pricing_settings, save_pricing_settings
from app.users.models import User

router = APIRouter(tags=["pricing"])


@router.get("/pricing/config", response_model=PublicPricingConfig)
async def public_config(db: DB) -> PublicPricingConfig:
    config = PublicPricingConfig.model_validate((await get_pricing_settings(db)).model_dump())
    config.tax_name = translate_message(config.tax_name)  # "IVA" → "VAT", "TVA", "增值税"…
    return config


@router.post("/pricing/quote", response_model=QuoteOut)
async def quote(data: QuoteIn, request: Request, db: DB, redis: RedisDep) -> QuoteOut:
    """Cotiza un viaje. El precio siempre se calcula aquí, nunca en el navegador."""
    await hit(redis, "quote", client_ip(request), limit=60, window_seconds=60)
    result, _, svc = await service.quote(db, data)
    return service.quote_out(result, svc)


@router.post("/admin/pricing/simulate", response_model=QuoteOut)
async def simulate(
    data: QuoteIn, _: Annotated[User, Depends(require("pricing:read"))], db: DB
) -> QuoteOut:
    """Como /pricing/quote, pero admite servicios inactivos y cualquier fecha."""
    result, _t, svc = await service.quote(db, data, simulation=True)
    return service.quote_out(result, svc)


@router.get("/admin/pricing/rules", response_model=list[RuleOut])
async def list_rules(_: Annotated[User, Depends(require("pricing:read"))], db: DB) -> list[RuleOut]:
    return [RuleOut.model_validate(r) for r in await service.list_rules(db)]


@router.post("/admin/pricing/rules", response_model=RuleOut, status_code=status.HTTP_201_CREATED)
async def create_rule(
    data: RuleIn, actor: Annotated[User, Depends(require("pricing:write"))], db: DB, meta: Meta
) -> RuleOut:
    return RuleOut.model_validate(await service.create_rule(db, actor, data, meta))


@router.get("/admin/pricing/rules/{rule_id}", response_model=RuleOut)
async def get_rule(
    rule_id: uuid.UUID, _: Annotated[User, Depends(require("pricing:read"))], db: DB
) -> RuleOut:
    return RuleOut.model_validate(await service.get_rule(db, rule_id))


@router.put("/admin/pricing/rules/{rule_id}", response_model=RuleOut)
async def update_rule(
    rule_id: uuid.UUID,
    data: RuleIn,
    actor: Annotated[User, Depends(require("pricing:write"))],
    db: DB,
    meta: Meta,
) -> RuleOut:
    return RuleOut.model_validate(await service.update_rule(db, actor, rule_id, data, meta))


@router.delete("/admin/pricing/rules/{rule_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_rule(
    rule_id: uuid.UUID,
    actor: Annotated[User, Depends(require("pricing:write"))],
    db: DB,
    meta: Meta,
) -> Response:
    await service.delete_rule(db, actor, rule_id, meta)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/admin/pricing/settings", response_model=PricingSettings)
async def get_settings(
    _: Annotated[User, Depends(require("pricing:read"))], db: DB
) -> PricingSettings:
    return await get_pricing_settings(db)


@router.put("/admin/pricing/settings", response_model=PricingSettings)
async def put_settings(
    data: PricingSettings,
    actor: Annotated[User, Depends(require("pricing:write"))],
    db: DB,
    meta: Meta,
) -> PricingSettings:
    before, after = await save_pricing_settings(db, data)
    if before != after:
        record(
            db, actor_id=actor.id, action="PRICING_SETTINGS_UPDATE", entity_type="settings",
            entity_id="pricing", meta=meta, before=before, after=after,
        )  # fmt: skip
    await db.commit()
    return await get_pricing_settings(db)
