import uuid
from datetime import datetime
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from app.core.validators import BlankToNone

Stars = Annotated[int, Field(ge=1, le=5)]


class ReviewIn(BaseModel):
    service_rating: Stars
    driver_rating: Stars | None = None
    comment: Annotated[Annotated[str, Field(max_length=1000)] | None, BlankToNone] = None
    consent_publish: bool = False


class OwnReviewOut(BaseModel):
    service_rating: int
    driver_rating: int | None
    comment: str | None
    consent_publish: bool
    status: str
    created_at: datetime


class ReviewState(BaseModel):
    """Para el cliente: si puede calificar esta reserva, hasta cuándo, y su reseña si ya existe."""

    eligible: bool
    deadline: datetime | None
    has_driver: bool
    review: OwnReviewOut | None


class PublicReview(BaseModel):
    display_name: str
    service_rating: int
    comment: str
    service_name: str
    created_at: datetime
    locale: str | None


class Rating(BaseModel):
    average: float | None
    count: int


class AdminReview(BaseModel):
    id: uuid.UUID
    reservation_id: uuid.UUID
    reservation_code: str
    customer: str
    service_name: str
    driver_name: str | None
    service_rating: int
    driver_rating: int | None
    comment: str | None
    consent_publish: bool
    status: str
    display_name: str
    created_at: datetime
    moderated_at: datetime | None


class AdminReviewPage(BaseModel):
    items: list[AdminReview]
    total: int
    pending: int


class ModerateIn(BaseModel):
    action: Literal["publish", "hide"]
