import uuid
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, select

from app.audit.service import record
from app.auth.deps import DB, CurrentUser, require
from app.auth.router import Meta
from app.core.i18n import get_locale
from app.core.translations import localized
from app.drivers.models import Driver
from app.reservations import service as reservations
from app.reservations.models import Reservation
from app.reviews import service
from app.reviews.models import PENDING, PUBLISHED, Review
from app.reviews.schemas import (
    AdminReview,
    AdminReviewPage,
    ModerateIn,
    OwnReviewOut,
    PublicReview,
    ReviewIn,
    ReviewState,
)
from app.services.models import Service
from app.users.models import User

router = APIRouter(tags=["reseñas"])


def _own(review: Review) -> OwnReviewOut:
    return OwnReviewOut.model_validate(review, from_attributes=True)


@router.get("/reservations/{code}/review", response_model=ReviewState)
async def review_state(code: str, user: CurrentUser, db: DB) -> ReviewState:
    r = await reservations.get_own(db, user, code)
    review = await service.get_for(db, r)
    limit = await service.deadline(db, r)
    from datetime import UTC, datetime

    return ReviewState(
        eligible=review is None and limit is not None and datetime.now(UTC) <= limit,
        deadline=limit,
        has_driver=r.driver_id is not None,
        review=_own(review) if review else None,
    )


@router.post("/reservations/{code}/review", response_model=OwnReviewOut, status_code=201)
async def submit_review(code: str, data: ReviewIn, user: CurrentUser, db: DB) -> OwnReviewOut:
    r = await reservations.get_own(db, user, code)
    return _own(await service.create(db, r, user, data, get_locale()))


@router.get("/reviews", response_model=list[PublicReview])
async def public_reviews(
    db: DB,
    service_slug: Annotated[str | None, Query(alias="service")] = None,
    limit: Annotated[int, Query(ge=1, le=24)] = 6,
) -> list[PublicReview]:
    """Comentarios publicados (autorizados y revisados), los más recientes primero."""
    q = (
        select(Review, Service)
        .join(Service, Service.id == Review.service_id)
        .where(
            Review.status == PUBLISHED,
            Review.consent_publish.is_(True),
            Review.comment.is_not(None),
        )
        .order_by(Review.created_at.desc())
        .limit(limit)
    )
    if service_slug:
        q = q.where(Service.slug == service_slug)
    return [
        PublicReview(
            display_name=rv.display_name,
            service_rating=rv.service_rating,
            comment=rv.comment or "",
            service_name=localized(s.translations, "name", s.name),
            created_at=rv.created_at,
            locale=rv.locale,
        )
        for rv, s in (await db.execute(q)).all()
    ]


@router.get("/admin/reviews", response_model=AdminReviewPage)
async def admin_reviews(
    _: Annotated[User, Depends(require("content:write"))],
    db: DB,
    status: Literal["PENDING", "PUBLISHED", "HIDDEN", "all"] = "PENDING",
    page: Annotated[int, Query(ge=1)] = 1,
) -> AdminReviewPage:
    q = (
        select(Review, Reservation.code, User, Service, Driver)
        .join(Reservation, Reservation.id == Review.reservation_id)
        .join(Service, Service.id == Review.service_id)
        .outerjoin(User, User.id == Review.user_id)
        .outerjoin(Driver, Driver.id == Review.driver_id)
    )
    count = select(func.count()).select_from(Review)
    if status != "all":
        q, count = q.where(Review.status == status), count.where(Review.status == status)
    rows = (
        await db.execute(q.order_by(Review.created_at.desc()).offset((page - 1) * 20).limit(20))
    ).all()
    return AdminReviewPage(
        items=[
            AdminReview(
                id=rv.id,
                reservation_id=rv.reservation_id,
                reservation_code=code,
                customer=f"{u.first_name} {u.last_name} ({u.email})" if u else rv.display_name,
                service_name=s.name,
                driver_name=d.name if d else None,
                service_rating=rv.service_rating,
                driver_rating=rv.driver_rating,
                comment=rv.comment,
                consent_publish=rv.consent_publish,
                status=rv.status,
                display_name=rv.display_name,
                created_at=rv.created_at,
                moderated_at=rv.moderated_at,
            )
            for rv, code, u, s, d in rows
        ],
        total=await db.scalar(count) or 0,
        pending=await db.scalar(
            select(func.count()).select_from(Review).where(Review.status == PENDING)
        )
        or 0,
    )


@router.post("/admin/reviews/{review_id}/moderate", response_model=AdminReviewPage)
async def moderate_review(
    review_id: uuid.UUID,
    data: ModerateIn,
    actor: Annotated[User, Depends(require("content:write"))],
    db: DB,
    meta: Meta,
) -> AdminReviewPage:
    review = await service.moderate(db, review_id, actor, data.action)
    record(
        db,
        actor_id=actor.id,
        action=f"REVIEW_{data.action.upper()}",
        entity_type="review",
        entity_id=str(review.id),
        meta=meta,
        after={"status": review.status},
    )
    await db.commit()
    return await admin_reviews(actor, db, "PENDING", 1)
