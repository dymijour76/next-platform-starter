"""Reseñas: quién puede calificar, cómo se guardan, promedios y moderación."""

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import AppError, NotFound
from app.reservations.models import Reservation, ReservationEvent
from app.reservations.models import ReservationStatus as S
from app.reviews.models import HIDDEN, PENDING, PUBLISHED, Review
from app.reviews.schemas import Rating, ReviewIn
from app.users.models import User

WINDOW = timedelta(days=30)


class AlreadyReviewed(AppError):
    status_code = 409
    code = "ALREADY_REVIEWED"
    message = "Esta reserva ya tiene su calificación. Gracias."


class NotReviewable(AppError):
    status_code = 409
    code = "NOT_REVIEWABLE"
    message = "Sólo se pueden calificar viajes completados en los últimos 30 días."


def display_name(user: User) -> str:
    """ "Valentina M.": nombre y la inicial del apellido."""
    initial = (user.last_name or "").strip()[:1]
    return f"{user.first_name.strip()} {initial}." if initial else user.first_name.strip()


async def completed_at(db: AsyncSession, r: Reservation) -> datetime | None:
    if r.status != S.COMPLETED:
        return None
    return (
        await db.scalar(
            select(func.max(ReservationEvent.created_at)).where(
                ReservationEvent.reservation_id == r.id, ReservationEvent.to_status == S.COMPLETED
            )
        )
        or r.updated_at
    )


async def deadline(db: AsyncSession, r: Reservation) -> datetime | None:
    done = await completed_at(db, r)
    return done + WINDOW if done else None


async def get_for(db: AsyncSession, r: Reservation) -> Review | None:
    return await db.scalar(select(Review).where(Review.reservation_id == r.id))


async def create(
    db: AsyncSession, r: Reservation, user: User, data: ReviewIn, locale: str
) -> Review:
    if await get_for(db, r):
        raise AlreadyReviewed()
    limit = await deadline(db, r)
    if limit is None or datetime.now(UTC) > limit:
        raise NotReviewable()
    # Un comentario autorizado espera revisión; sin comentario (o sin autorización) no hay
    # nada que publicar y la reseña sólo suma sus estrellas.
    publishable = bool(data.comment and data.consent_publish)
    review = Review(
        reservation_id=r.id,
        user_id=user.id,
        service_id=r.service_id,
        driver_id=r.driver_id,
        service_rating=data.service_rating,
        driver_rating=data.driver_rating if r.driver_id else None,
        comment=data.comment,
        consent_publish=data.consent_publish,
        status=PENDING if publishable else PUBLISHED,
        display_name=display_name(user),
        locale=locale,
    )
    db.add(review)
    await db.commit()
    await db.refresh(review)
    return review


async def service_ratings(db: AsyncSession) -> dict[uuid.UUID, Rating]:
    """Promedio por servicio. Cuentan todas las calificaciones, incluidas las de comentarios
    ocultos: ocultar un comentario ofensivo no debe mejorar el promedio."""
    rows = await db.execute(
        select(Review.service_id, func.avg(Review.service_rating), func.count()).group_by(
            Review.service_id
        )
    )
    return {sid: Rating(average=round(float(avg), 1), count=n) for sid, avg, n in rows}


async def driver_rating(db: AsyncSession, driver_id: uuid.UUID) -> Rating:
    avg, n = (
        await db.execute(
            select(func.avg(Review.driver_rating), func.count(Review.driver_rating)).where(
                Review.driver_id == driver_id, Review.driver_rating.is_not(None)
            )
        )
    ).one()
    return Rating(average=round(float(avg), 1) if avg is not None else None, count=n)


async def moderate(db: AsyncSession, review_id: uuid.UUID, actor: User, action: str) -> Review:
    review = await db.get(Review, review_id)
    if review is None:
        raise NotFound("La reseña no existe.")
    if action == "publish" and not (review.comment and review.consent_publish):
        raise AppError(
            "Esta reseña no tiene un comentario autorizado para publicar.", code="NOT_PUBLISHABLE"
        )
    review.status = PUBLISHED if action == "publish" else HIDDEN
    review.moderated_by = actor.id
    review.moderated_at = datetime.now(UTC)
    return review
