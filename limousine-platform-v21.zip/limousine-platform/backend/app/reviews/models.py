"""Reseñas de clientes: una por reserva completada.

Las estrellas cuentan siempre en el promedio. El comentario sólo se publica si el cliente lo
autorizó y el equipo lo revisó; se oculta únicamente si es ofensivo o tiene datos personales,
nunca por ser negativo (el promedio no debe engañar).
"""

import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, SmallInteger, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

PENDING, PUBLISHED, HIDDEN = "PENDING", "PUBLISHED", "HIDDEN"


class Review(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "reviews"
    __table_args__ = (
        CheckConstraint("service_rating BETWEEN 1 AND 5", name="service_rating_range"),
        CheckConstraint(
            "driver_rating IS NULL OR driver_rating BETWEEN 1 AND 5", name="driver_rating_range"
        ),
        CheckConstraint("status IN ('PENDING', 'PUBLISHED', 'HIDDEN')", name="status_valid"),
    )

    reservation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("reservations.id", ondelete="CASCADE"), unique=True, nullable=False
    )
    user_id: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))
    service_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("services.id", ondelete="CASCADE"), index=True
    )
    driver_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("drivers.id", ondelete="SET NULL"), index=True
    )
    service_rating: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    driver_rating: Mapped[int | None] = mapped_column(SmallInteger)
    comment: Mapped[str | None] = mapped_column(Text)
    consent_publish: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, index=True)
    # "Valentina M.": se guarda al crear la reseña (si la persona cambia su nombre, no cambia).
    display_name: Mapped[str] = mapped_column(String(60), nullable=False)
    locale: Mapped[str | None] = mapped_column(String(5))
    moderated_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    moderated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
