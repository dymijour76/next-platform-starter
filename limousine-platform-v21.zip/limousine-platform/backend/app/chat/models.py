"""Mensajes entre el cliente y el chófer de una reserva."""

import uuid
from datetime import datetime

from sqlalchemy import Boolean, CheckConstraint, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

CUSTOMER, DRIVER = "customer", "driver"


class Message(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "messages"
    __table_args__ = (
        CheckConstraint("sender_role IN ('customer', 'driver')", name="sender_role_valid"),
        Index("ix_messages_reservation_created", "reservation_id", "created_at"),
    )

    reservation_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("reservations.id", ondelete="CASCADE"), nullable=False
    )
    sender_user_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )
    sender_role: Mapped[str] = mapped_column(String(10), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    read_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Si quien lo envió eliminó su cuenta (Ley 21.719), el texto se borra y queda la marca.
    deleted: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
