import re
import uuid
from datetime import datetime
from typing import Annotated, Literal

from fastapi import APIRouter, Depends
from pydantic import AfterValidator, BaseModel, Field

from app.auth.deps import DB, CurrentUser, RedisDep, require
from app.auth.router import Mailer
from app.chat import service
from app.chat.models import CUSTOMER, DRIVER, Message
from app.core.rate_limit import hit
from app.drivers.portal import Me, _mine
from app.reservations import emails
from app.reservations import service as reservations
from app.reservations.models import Reservation
from app.settings.service import get_pricing_settings
from app.users.models import User

router = APIRouter(tags=["chat"])
_CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")


def _clean(value: str) -> str:
    """Texto del mensaje: conserva saltos de línea, sin caracteres de control ni blancos de más."""
    text = value.replace("\r\n", "\n").replace("\r", "\n")
    if _CONTROL.search(text):
        raise ValueError("El mensaje contiene caracteres no permitidos.")
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        raise ValueError("Escriba un mensaje.")
    return text


class MessageIn(BaseModel):
    body: Annotated[str, Field(max_length=service.MAX_LENGTH), AfterValidator(_clean)]


class MessageOut(BaseModel):
    id: uuid.UUID
    mine: bool
    sender_role: Literal["customer", "driver"]
    body: str | None  # None: lo borró quien lo envió al eliminar su cuenta
    created_at: datetime
    read: bool


class ChatOut(BaseModel):
    open: bool
    closes_at: datetime | None
    counterpart: str | None  # nombre de pila del otro participante
    messages: list[MessageOut]


def _message(m: Message, role: str | None) -> MessageOut:
    return MessageOut(
        id=m.id,
        mine=m.sender_role == role,
        sender_role=m.sender_role,  # type: ignore[arg-type]
        body=None if m.deleted else m.body,
        created_at=m.created_at,
        read=m.read_at is not None,
    )


async def _chat(
    db: DB, r: Reservation, role: str | None, after: datetime | None, counterpart: str | None
) -> ChatOut:
    rows = await service.messages(db, r, after)
    if role is not None:
        await service.mark_read(db, r, role)
        await db.commit()
    return ChatOut(
        open=service.is_open(r),
        closes_at=service.closes_at(r),
        counterpart=counterpart,
        messages=[_message(m, role) for m in rows],
    )


def _first_name(full: str | None) -> str | None:
    return full.split()[0] if full else None


async def _deliver(
    db: DB, r: Reservation, role: str, user: User, data: MessageIn, redis: RedisDep, mailer: Mailer
) -> MessageOut:
    await hit(redis, "chat", str(user.id), limit=20, window_seconds=60)
    message, notify = await service.send(db, r, user.id, role, data.body)
    await db.commit()
    if notify:  # primer mensaje sin leer de una racha: un solo email
        await db.refresh(r)
        if role == DRIVER:
            await reservations.notify(db, r, "message", mailer)
        else:
            tz = (await get_pricing_settings(db)).timezone
            await mailer.send(emails.driver_message_email(r, tz))
    return _message(message, role)


# ------------------------------------------------------------------ cliente


@router.get("/reservations/{code}/messages", response_model=ChatOut)
async def customer_chat(
    code: str, user: CurrentUser, db: DB, after: datetime | None = None
) -> ChatOut:
    r = await reservations.get_own(db, user, code)
    if not service.visible(r):
        return ChatOut(open=False, closes_at=None, counterpart=None, messages=[])
    return await _chat(db, r, CUSTOMER, after, _first_name(r.driver.name if r.driver else None))


@router.post("/reservations/{code}/messages", response_model=MessageOut, status_code=201)
async def customer_send(
    code: str, data: MessageIn, user: CurrentUser, db: DB, redis: RedisDep, mailer: Mailer
) -> MessageOut:
    r = await reservations.get_own(db, user, code)
    return await _deliver(db, r, CUSTOMER, user, data, redis, mailer)


# ------------------------------------------------------------------ chófer


@router.get("/driver/trips/{trip_id}/messages", response_model=ChatOut)
async def driver_chat(trip_id: uuid.UUID, me: Me, db: DB, after: datetime | None = None) -> ChatOut:
    r = await _mine(db, me, trip_id)
    return await _chat(db, r, DRIVER, after, _first_name(r.contact_name))


@router.post("/driver/trips/{trip_id}/messages", response_model=MessageOut, status_code=201)
async def driver_send(
    trip_id: uuid.UUID, data: MessageIn, me: Me, db: DB, redis: RedisDep, mailer: Mailer
) -> MessageOut:
    r = await _mine(db, me, trip_id)
    return await _deliver(db, r, DRIVER, me.user, data, redis, mailer)


# ------------------------------------------------------------------ panel (sólo lectura)


@router.get("/admin/reservations/{reservation_id}/messages", response_model=ChatOut)
async def admin_chat(
    reservation_id: uuid.UUID, _: Annotated[User, Depends(require("reservations:read"))], db: DB
) -> ChatOut:
    r = await reservations.get_admin(db, reservation_id)
    # Sin "mine" ni marcar como leído: el equipo sólo consulta (reclamos, coordinación).
    return await _chat(db, r, None, None, None)
