"""Chat de una reserva: quién participa, cuándo está abierto, mensajes y avisos por email."""

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.chat.models import CUSTOMER, DRIVER, Message
from app.core.errors import AppError
from app.reservations.models import Reservation
from app.reservations.models import ReservationStatus as S

ACTIVE = {S.CONFIRMED, S.EN_ROUTE, S.ARRIVED, S.IN_PROGRESS}
AFTER_TRIP = timedelta(hours=2)
MAX_LENGTH = 1000


class ChatClosed(AppError):
    status_code = 409
    code = "CHAT_CLOSED"
    message = "La conversación de esta reserva está cerrada."


def closes_at(r: Reservation) -> datetime | None:
    """Hasta cuándo se puede escribir: 2 horas después del término del viaje."""
    return r.end_at + AFTER_TRIP if r.end_at else None


def is_open(r: Reservation, now: datetime | None = None) -> bool:
    """Abierta con chófer asignado, desde que se confirma hasta 2 horas después del viaje."""
    now = now or datetime.now(UTC)
    if r.driver_id is None:
        return False
    if r.status in ACTIVE:
        return True
    limit = closes_at(r)
    return r.status in (S.COMPLETED, S.NO_SHOW) and limit is not None and now <= limit


def visible(r: Reservation) -> bool:
    """La conversación existe (aunque esté cerrada) si hubo chófer asignado."""
    return r.driver_id is not None


async def messages(
    db: AsyncSession, r: Reservation, after: datetime | None = None
) -> list[Message]:
    q = select(Message).where(Message.reservation_id == r.id)
    if after is not None:
        q = q.where(Message.created_at > after)
    return list((await db.scalars(q.order_by(Message.created_at, Message.id).limit(500))).all())


async def mark_read(db: AsyncSession, r: Reservation, reader_role: str) -> None:
    """Marca como leídos los mensajes que recibió quien está leyendo."""
    await db.execute(
        update(Message)
        .where(
            Message.reservation_id == r.id,
            Message.sender_role != reader_role,
            Message.read_at.is_(None),
        )
        .values(read_at=datetime.now(UTC))
    )


async def unread(db: AsyncSession, reservation_id: uuid.UUID, reader_role: str) -> int:
    return (
        await db.scalar(
            select(func.count()).where(
                Message.reservation_id == reservation_id,
                Message.sender_role != reader_role,
                Message.read_at.is_(None),
            )
        )
        or 0
    )


async def send(
    db: AsyncSession, r: Reservation, sender_id: uuid.UUID, role: str, body: str
) -> tuple[Message, bool]:
    """Guarda el mensaje. Devuelve (mensaje, avisar): se avisa por email sólo al empezar una
    racha de mensajes sin leer, no por cada mensaje."""
    if role not in (CUSTOMER, DRIVER):
        raise ValueError(role)
    if not is_open(r):
        raise ChatClosed()
    pending = await db.scalar(
        select(func.count()).where(
            Message.reservation_id == r.id, Message.sender_role == role, Message.read_at.is_(None)
        )
    )
    message = Message(reservation_id=r.id, sender_user_id=sender_id, sender_role=role, body=body)
    db.add(message)
    await db.flush()
    return message, not pending
