"""Motor y sesiones asíncronas de SQLAlchemy."""

from collections.abc import AsyncIterator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import ORMExecuteState, Session

from app.core.config import get_settings

_settings = get_settings()

engine: AsyncEngine = create_async_engine(
    _settings.database_url,
    pool_size=_settings.database_pool_size,
    max_overflow=_settings.database_max_overflow,
    pool_pre_ping=True,
)

SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


@event.listens_for(Session, "do_orm_execute")
def _fresh_values_when_locking(state: ORMExecuteState) -> None:
    """Todo SELECT … FOR UPDATE relee los valores de la base de datos.

    Sin esto, si la sesión ya había leído la fila, SQLAlchemy devuelve el objeto que tenía en
    memoria con sus valores viejos, aunque el bloqueo haya esperado a que otra transacción
    cambiara la fila. Así ocurrió un doble gasto de saldo en una versión de la billetera.
    """
    if state.is_select and getattr(state.statement, "_for_update_arg", None) is not None:
        state.update_execution_options(populate_existing=True)


async def get_db() -> AsyncIterator[AsyncSession]:
    """Dependencia de FastAPI: una sesión por request."""
    async with SessionLocal() as session:
        yield session
