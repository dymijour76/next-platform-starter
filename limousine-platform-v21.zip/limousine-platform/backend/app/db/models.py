"""Punto único de importación de modelos para Alembic.

Cada módulo de dominio registra aquí sus modelos para que la autogeneración de
migraciones los detecte.
"""

from app.audit.models import AuditLog
from app.auth.models import OneTimeToken, RefreshToken
from app.carousel.models import CarouselSlide
from app.chat.models import Message
from app.currency.models import ExchangeRate
from app.db.base import Base
from app.drivers.models import Driver
from app.media.models import MediaAsset
from app.payments.models import Payment, Refund
from app.pricing.models import PricingRule
from app.reservations.models import Reservation, ReservationCounter, ReservationEvent
from app.reviews.models import Review
from app.services.models import Service, ServiceImage
from app.settings.models import AppSetting
from app.users.models import CustomerProfile, Permission, Role, User, UserRole
from app.vehicles.models import Vehicle, VehicleBlock
from app.wallet.models import Wallet, WalletEntry

__all__ = [
    "AppSetting",
    "AuditLog",
    "Base",
    "CarouselSlide",
    "CustomerProfile",
    "Driver",
    "ExchangeRate",
    "MediaAsset",
    "Message",
    "OneTimeToken",
    "Payment",
    "Permission",
    "PricingRule",
    "RefreshToken",
    "Refund",
    "Reservation",
    "ReservationCounter",
    "ReservationEvent",
    "Review",
    "Role",
    "Service",
    "ServiceImage",
    "User",
    "UserRole",
    "Vehicle",
    "VehicleBlock",
    "Wallet",
    "WalletEntry",
]
