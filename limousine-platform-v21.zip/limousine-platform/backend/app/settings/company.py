"""Datos de la empresa: pie de página, redes sociales, contacto y encabezado del comprobante.

Se guardan en app_settings (clave "company"); se editan desde el panel (settings:write).
La descripción y el horario se pueden traducir; el resto (nombre, RUT, contacto, redes)
es igual en todos los idiomas.
"""

from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends
from pydantic import AfterValidator, BaseModel, BeforeValidator, EmailStr, Field, field_validator
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.auth.deps import DB, require
from app.auth.router import Meta
from app.core.translations import _validator, localized
from app.core.validators import BlankToNone, clean_text, normalize_phone, normalize_rut
from app.settings.models import AppSetting
from app.users.models import User

KEY = "company"
SOCIAL = (
    "instagram", "facebook", "tiktok", "youtube", "x", "threads", "linkedin", "pinterest",
    "snapchat", "telegram", "tripadvisor", "google",
)  # fmt: skip


def _https(value: str | None) -> str | None:
    if not value or not value.strip():
        return None
    value = value.strip()
    if not value.startswith("https://") or " " in value or len(value) > 300:
        raise ValueError("Use una dirección https:// completa.")
    return value


class CompanyTranslation(BaseModel):
    about: Annotated[Annotated[str, Field(max_length=300)] | None, BlankToNone] = None
    hours: Annotated[Annotated[str, Field(max_length=120)] | None, BlankToNone] = None


CompanyTranslations = Annotated[
    dict[Literal["en", "fr", "ht", "zh"], dict[str, Any]], _validator(CompanyTranslation)
]


class CompanySettings(BaseModel):
    name: Annotated[str, AfterValidator(clean_text), Field(min_length=1, max_length=80)] = (
        "Limousine Platform"
    )
    legal_name: Annotated[Annotated[str, Field(max_length=120)] | None, BlankToNone] = None
    tax_id: Annotated[str | None, BeforeValidator(normalize_rut)] = None
    address: Annotated[Annotated[str, Field(max_length=200)] | None, BlankToNone] = None
    phone: Annotated[str | None, BeforeValidator(normalize_phone)] = None
    whatsapp: Annotated[str | None, BeforeValidator(normalize_phone)] = None
    email: EmailStr | None = None
    about: Annotated[Annotated[str, Field(max_length=300)] | None, BlankToNone] = None
    hours: Annotated[Annotated[str, Field(max_length=120)] | None, BlankToNone] = None
    social: dict[str, str] = Field(default_factory=dict)
    translations: CompanyTranslations = Field(default_factory=dict)

    @field_validator("email", mode="before")
    @classmethod
    def _blank_email(cls, value: Any) -> Any:
        return None if isinstance(value, str) and not value.strip() else value

    @field_validator("social")
    @classmethod
    def _social(cls, value: dict[str, str]) -> dict[str, str]:
        unknown = set(value) - set(SOCIAL)
        if unknown:
            raise ValueError("Red social desconocida.")
        return {k: url for k, v in value.items() if (url := _https(v))}


class SitePublic(BaseModel):
    """Lo que muestra el sitio: textos en el idioma del visitante y enlaces listos."""

    name: str
    legal_name: str | None
    tax_id: str | None
    address: str | None
    phone: str | None
    email: str | None
    whatsapp_url: str | None
    about: str | None
    hours: str | None
    social: dict[str, str]


async def get_company(db: AsyncSession) -> CompanySettings:
    row = await db.get(AppSetting, KEY)
    return CompanySettings.model_validate(row.value if row else {})


def to_public(c: CompanySettings, locale: str | None = None) -> SitePublic:
    digits = (c.whatsapp or "").lstrip("+")
    return SitePublic(
        name=c.name,
        legal_name=c.legal_name,
        tax_id=c.tax_id,
        address=c.address,
        phone=c.phone,
        email=c.email,
        whatsapp_url=f"https://wa.me/{digits}" if digits else None,
        about=localized(c.translations, "about", c.about, locale),
        hours=localized(c.translations, "hours", c.hours, locale),
        social={k: c.social[k] for k in SOCIAL if k in c.social},
    )


router = APIRouter(tags=["sitio"])


@router.get("/site", response_model=SitePublic)
async def public_site(db: DB) -> SitePublic:
    return to_public(await get_company(db))


@router.get("/admin/site", response_model=CompanySettings)
async def admin_site(
    _: Annotated[User, Depends(require("settings:write"))], db: DB
) -> CompanySettings:
    return await get_company(db)


@router.put("/admin/site", response_model=CompanySettings)
async def save_site(
    data: CompanySettings,
    actor: Annotated[User, Depends(require("settings:write"))],
    db: DB,
    meta: Meta,
) -> CompanySettings:
    row = await db.get(AppSetting, KEY)
    before = CompanySettings.model_validate(row.value if row else {}).model_dump(mode="json")
    after = data.model_dump(mode="json")  # las traducciones ya vienen limpias del esquema
    if row is None:
        db.add(AppSetting(key=KEY, value=after))
    else:
        row.value = after
    if before != after:
        record(
            db, actor_id=actor.id, action="SITE_SETTINGS_UPDATE", entity_type="settings",
            entity_id=KEY, meta=meta, before=before, after=after,
        )  # fmt: skip
    await db.commit()
    return await get_company(db)
