from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.settings.models import AppSetting
from app.settings.schemas import BookingSettings, PricingSettings

PRICING_KEY = "pricing"


async def get_pricing_settings(db: AsyncSession) -> PricingSettings:
    row = await db.get(AppSetting, PRICING_KEY)
    return PricingSettings.model_validate(row.value if row else {})


async def save_pricing_settings(
    db: AsyncSession, data: PricingSettings
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Guarda y devuelve (antes, después) para la auditoría. No hace commit."""
    row = await db.get(AppSetting, PRICING_KEY)
    before = PricingSettings.model_validate(row.value if row else {}).model_dump(mode="json")
    after = data.model_dump(mode="json")
    if row is None:
        db.add(AppSetting(key=PRICING_KEY, value=after))
    else:
        row.value = after
    return before, after


BOOKING_KEY = "booking"


async def get_booking_settings(db: AsyncSession) -> BookingSettings:
    row = await db.get(AppSetting, BOOKING_KEY)
    return BookingSettings.model_validate(row.value if row else {})


async def save_booking_settings(
    db: AsyncSession, data: BookingSettings
) -> tuple[dict[str, Any], dict[str, Any]]:
    row = await db.get(AppSetting, BOOKING_KEY)
    before = BookingSettings.model_validate(row.value if row else {}).model_dump(mode="json")
    after = data.model_dump(mode="json")
    if row is None:
        db.add(AppSetting(key=BOOKING_KEY, value=after))
    else:
        row.value = after
    return before, after
