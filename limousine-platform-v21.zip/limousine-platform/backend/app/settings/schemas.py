from decimal import Decimal
from typing import Literal
from zoneinfo import available_timezones

from pydantic import BaseModel, Field, field_validator

from app.core.money import Amount


class PricingSettings(BaseModel):
    currency: Literal["CLP", "USD", "EUR"] = "CLP"
    timezone: str = "America/Santiago"
    tax_rate: Amount = Field(default=Decimal("0.19"), ge=0, le=Decimal("0.5"))
    tax_name: str = Field(default="IVA", min_length=1, max_length=20)
    prices_include_tax: bool = True
    billing_increment_minutes: Literal[15, 30, 60] = 30
    # Anticipación mínima para reservar y máximo de días hacia adelante.
    min_notice_minutes: int = Field(default=120, ge=0, le=60 * 24 * 14)
    max_advance_days: int = Field(default=365, ge=1, le=730)

    @field_validator("timezone")
    @classmethod
    def _tz(cls, v: str) -> str:
        if v not in available_timezones():
            raise ValueError("Zona horaria desconocida.")
        return v


class PublicPricingConfig(BaseModel):
    """Lo que el sitio público necesita saber para armar el formulario de cotización."""

    currency: str
    timezone: str
    tax_name: str
    prices_include_tax: bool
    billing_increment_minutes: int
    min_notice_minutes: int
    max_advance_days: int


class BookingSettings(BaseModel):
    # Minutos que se retiene el cupo de una reserva pendiente de pago.
    hold_minutes: int = Field(default=30, ge=5, le=24 * 60)
    # Preparación entre viajes: la unidad queda ocupada este tiempo después del servicio.
    turnaround_minutes: int = Field(default=60, ge=0, le=8 * 60)
    # Cancelación gratuita hasta estas horas antes de la recogida.
    free_cancellation_hours: int = Field(default=24, ge=0, le=720)
    # Porcentaje que se devuelve si se cancela después de ese plazo.
    late_cancellation_refund_percent: int = Field(default=0, ge=0, le=100)
