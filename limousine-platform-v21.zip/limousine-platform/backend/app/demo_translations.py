"""Traducciones de los datos de ejemplo (servicios y recargos) a en, fr, ht y zh.

Las usa `python -m app.cli seed-demo`. Los nombres de servicio (Standard, Professional,
Premium) no se traducen: funcionan como marca.
"""

SERVICE_TRANSLATIONS: dict[str, dict[str, dict[str, object]]] = {
    "standard": {
        "en": {"tagline": "Executive transfers with a professional chauffeur",
               "description": "Luxury sedan or SUV for airport transfers, meetings and dinners.",
               "features": ["Professional chauffeur", "Mineral water", "Phone chargers"]},
        "fr": {"tagline": "Transferts d'affaires avec chauffeur professionnel",
               "description": "Berline ou SUV de luxe pour les transferts aéroport, les réunions et les dîners.",
               "features": ["Chauffeur professionnel", "Eau minérale", "Chargeurs de téléphone"]},
        "ht": {"tagline": "Transfè pou biznis ak yon chofè pwofesyonèl",
               "description": "Sedan oswa SUV liksye pou transfè ayewopò, reyinyon ak dine.",
               "features": ["Chofè pwofesyonèl", "Dlo mineral", "Chajè telefòn"]},
        "zh": {"tagline": "专业司机商务接送",
               "description": "豪华轿车或 SUV，适用于机场接送、会议和晚宴。",
               "features": ["专业司机", "矿泉水", "手机充电器"]},
    },
    "professional": {
        "en": {"tagline": "Limousine for groups and corporate events",
               "description": "8-passenger limousine for events, client tours and celebrations.",
               "features": ["8-passenger limousine", "Soft drinks", "Wi-Fi", "Music of your choice"]},
        "fr": {"tagline": "Limousine pour groupes et événements d'entreprise",
               "description": "Limousine de 8 passagers pour événements, visites de clients et célébrations.",
               "features": ["Limousine de 8 passagers", "Boissons sans alcool", "Wi-Fi", "Musique au choix"]},
        "ht": {"tagline": "Limouzin pou gwoup ak evènman konpayi",
               "description": "Limouzin 8 pasaje pou evènman, vizit kliyan ak fèt.",
               "features": ["Limouzin 8 pasaje", "Bwason san alkòl", "Wi-Fi", "Mizik ou chwazi"]},
        "zh": {"tagline": "适合团体与企业活动的豪华轿车",
               "description": "8 座豪华轿车，适用于活动、客户参访和庆典。",
               "features": ["8 座豪华轿车", "无酒精饮料", "Wi-Fi", "自选音乐"]},
    },
    "premium": {
        "en": {"tagline": "For once-in-a-lifetime occasions",
               "description": "Ultra-luxury limousine for weddings, anniversaries and galas.",
               "features": ["Ultra-luxury limousine", "Complimentary champagne", "Red carpet", "Decoration on request"]},
        "fr": {"tagline": "Pour les occasions uniques",
               "description": "Limousine de grand luxe pour mariages, anniversaires et galas.",
               "features": ["Limousine de grand luxe", "Champagne offert", "Tapis rouge", "Décoration sur demande"]},
        "ht": {"tagline": "Pou okazyon ki pa rive de fwa",
               "description": "Limouzin gwo liks pou maryaj, anivèsè ak gala.",
               "features": ["Limouzin gwo liks", "Chanpay gratis", "Tapi wouj", "Dekorasyon sou demann"]},
        "zh": {"tagline": "为人生难忘时刻而设",
               "description": "顶级豪华轿车，适用于婚礼、周年纪念和晚会。",
               "features": ["顶级豪华轿车", "免费香槟", "红毯", "可按需装饰"]},
    },
}  # fmt: skip

RULE_TRANSLATIONS: dict[str, dict[str, dict[str, str]]] = {
    "Recargo nocturno": {
        "en": {"name": "Night surcharge"}, "fr": {"name": "Supplément de nuit"},
        "ht": {"name": "Frè lannwit"}, "zh": {"name": "夜间附加费"},
    },
    "Recargo fin de semana": {
        "en": {"name": "Weekend surcharge"}, "fr": {"name": "Supplément week-end"},
        "ht": {"name": "Frè wikenn"}, "zh": {"name": "周末附加费"},
    },
}  # fmt: skip
