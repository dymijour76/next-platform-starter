"""Worker de tareas en segundo plano (arq + Redis).

Tareas: envío de emails y vencimiento de reservas pendientes de pago (cada
minuto). En fases posteriores: recordatorios de reserva y reportes.
"""

import logging
from typing import Any, ClassVar

from arq import cron
from arq.connections import RedisSettings

from app.core.config import get_settings
from app.core.logging import configure_logging
from app.db import (
    models as _all_models,  # noqa: F401  registra todos los modelos (relaciones por nombre)
)
from app.db.session import SessionLocal
from app.notifications.email import QueueEmailDispatcher, deliver

logger = logging.getLogger("app.worker")


async def ping(ctx: dict[str, Any]) -> str:
    """Tarea de diagnóstico para comprobar que el worker procesa trabajos."""
    logger.info("ping recibido (job %s)", ctx.get("job_id"))
    return "pong"


async def send_email(_: dict[str, Any], email: dict[str, Any]) -> None:
    """Entrega un email encolado por la API. arq lo reintenta si falla."""
    await deliver(email)


async def expire_reservation_holds(_: dict[str, Any]) -> int:
    """Cada minuto: vence las reservas pendientes de pago cuyo cupo retenido expiró."""
    from app.reservations import service as reservations

    mailer = QueueEmailDispatcher()
    async with SessionLocal() as db:
        expired = await reservations.expire_holds(db)
        for r in expired:
            await reservations.notify(db, r, "expired", mailer)
    if expired:
        logger.info("Reservas vencidas: %s", ", ".join(r.code for r in expired))
    return len(expired)


async def expire_abandoned_payments(_: dict[str, Any]) -> int:
    """Cada minuto: intentos de pago que nunca volvieron de la pasarela."""
    from app.payments import service as payments

    async with SessionLocal() as db:
        return await payments.expire_abandoned(db)


async def heartbeat(ctx: dict[str, Any]) -> None:
    """Cada minuto: "estoy vivo". /api/v1/health/worker lo vigila."""
    from datetime import UTC, datetime

    from app.api.v1.health import HEARTBEAT_KEY

    await ctx["redis"].set(HEARTBEAT_KEY, datetime.now(UTC).isoformat(), ex=3600)


async def startup(_: dict[str, Any]) -> None:
    configure_logging(get_settings().log_level)
    from app.core.monitoring import init_monitoring

    init_monitoring("worker")
    logger.info("Worker iniciado")


async def refresh_exchange_rates(ctx: dict[str, Any]) -> None:
    """Tasas de cambio para precios de referencia: una vez al día (y al arrancar)."""
    from app.currency import service as currency

    async with SessionLocal() as db:
        try:
            updated, rejected = await currency.refresh(db)
            logger.info("Tasas de cambio actualizadas: %s; descartadas: %s", updated, rejected)
        except currency.RatesUnavailable as exc:
            logger.warning("No se pudieron actualizar las tasas de cambio: %s", exc)


class WorkerSettings:
    functions: ClassVar[list[Any]] = [
        ping,
        send_email,
        expire_reservation_holds,
        expire_abandoned_payments,
        heartbeat,
    ]
    cron_jobs: ClassVar[list[Any]] = [
        cron(expire_reservation_holds, second=0),  # type: ignore[arg-type]
        cron(expire_abandoned_payments, second=30),  # type: ignore[arg-type]
        cron(heartbeat, second=15, run_at_startup=True),
        cron(refresh_exchange_rates, hour={10}, minute=0, run_at_startup=True),
    ]
    on_startup = startup
    redis_settings = RedisSettings.from_dsn(get_settings().redis_url)
    max_jobs = 10
    max_tries = 5
