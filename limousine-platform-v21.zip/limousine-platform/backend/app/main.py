"""Punto de entrada de la API."""

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.router import api_router
from app.core.config import get_settings
from app.core.errors import register_error_handlers
from app.core.logging import configure_logging
from app.core.middleware import RequestContextMiddleware
from app.core.monitoring import init_monitoring
from app.core.redis import redis_client
from app.db.session import engine
from app.notifications.email import QueueEmailDispatcher

logger = logging.getLogger("app")


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    settings = get_settings()
    logger.info("Iniciando %s (%s)", settings.app_name, settings.environment)
    yield
    await QueueEmailDispatcher.close()
    await redis_client.aclose()
    await engine.dispose()
    logger.info("API detenida")


def create_app() -> FastAPI:
    settings = get_settings()
    configure_logging(settings.log_level)
    init_monitoring("api")

    app = FastAPI(
        title=settings.app_name,
        version="0.1.0",
        lifespan=lifespan,
        # La documentación interactiva no se expone en producción.
        docs_url=None if settings.is_production else "/docs",
        redoc_url=None,
        openapi_url=None if settings.is_production else f"{settings.api_v1_prefix}/openapi.json",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
    )
    app.add_middleware(RequestContextMiddleware)
    if settings.storage_backend == "local":
        # Sólo desarrollo: en producción las imágenes las sirve S3 o su CDN.
        from pathlib import Path

        from fastapi.staticfiles import StaticFiles

        Path(settings.media_root, "media").mkdir(parents=True, exist_ok=True)
        app.mount("/media", StaticFiles(directory=Path(settings.media_root, "media")), name="media")
    register_error_handlers(app)
    app.include_router(api_router, prefix=settings.api_v1_prefix)
    return app


app = create_app()
