"""Biblioteca de imágenes: subir, listar, describir y eliminar."""

import asyncio
import logging
import uuid

from fastapi import UploadFile, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.carousel.models import CarouselSlide
from app.core.config import get_settings
from app.core.errors import AppError, Conflict, NotFound
from app.core.request_context import RequestMeta
from app.media.images import ImageRejected, process
from app.media.models import MediaAsset
from app.media.schemas import ImageOut, MediaAssetOut
from app.media.storage import Storage
from app.services.models import ServiceImage
from app.users.models import User

logger = logging.getLogger("app.media")


def image_out(asset: MediaAsset, storage: Storage) -> ImageOut:
    variants = asset.variants
    default = max(
        (v for v in variants if v["width"] <= 1600), key=lambda v: v["width"], default=variants[0]
    )
    return ImageOut(
        id=asset.id,
        alt=asset.alt_text,
        width=asset.width,
        height=asset.height,
        src=storage.url(default["key"]),
        srcset=", ".join(f"{storage.url(v['key'])} {v['width']}w" for v in variants),
    )


async def usage_counts(db: AsyncSession) -> dict[uuid.UUID, int]:
    counts: dict[uuid.UUID, int] = {}
    for column in (CarouselSlide.image_id, ServiceImage.image_id):
        for image_id, n in (await db.execute(select(column, func.count()).group_by(column))).all():
            counts[image_id] = counts.get(image_id, 0) + n
    return counts


def asset_out(asset: MediaAsset, storage: Storage, usage: int = 0) -> MediaAssetOut:
    return MediaAssetOut(
        **image_out(asset, storage).model_dump(),
        original_filename=asset.original_filename,
        bytes=asset.bytes,
        created_at=asset.created_at,
        usage=usage,
    )


async def _read_limited(upload: UploadFile) -> bytes:
    """Lee el archivo sin pasar del límite: no se carga en memoria un archivo gigante."""
    limit = get_settings().upload_max_mb * 1024 * 1024
    data = await upload.read(limit + 1)
    if len(data) > limit:
        raise AppError(
            f"La imagen supera los {get_settings().upload_max_mb} MB.",
            code="FILE_TOO_LARGE",
            status_code=status.HTTP_413_CONTENT_TOO_LARGE,
            fields={"file": f"Máximo {get_settings().upload_max_mb} MB."},
        )
    return data


async def upload(
    db: AsyncSession,
    storage: Storage,
    actor: User,
    file: UploadFile,
    alt_text: str,
    meta: RequestMeta,
) -> MediaAsset:
    data = await _read_limited(file)
    try:
        # Decodificar y redimensionar consume CPU: fuera del bucle de eventos.
        processed = await asyncio.to_thread(process, data)
    except ImageRejected as exc:
        raise AppError(
            str(exc),
            code="INVALID_IMAGE",
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            fields={"file": str(exc)},
        ) from exc

    asset_id = uuid.uuid4()
    variants = []
    for v in processed.variants:
        key = f"media/{asset_id}/{v.width}.webp"
        await storage.put(key, v.data, "image/webp")
        variants.append({"width": v.width, "height": v.height, "key": key})

    name = (file.filename or "imagen")[-255:]
    asset = MediaAsset(
        id=asset_id,
        original_filename=name,
        alt_text=alt_text,
        width=processed.width,
        height=processed.height,
        bytes=len(data),
        variants=variants,
        created_by=actor.id,
    )
    db.add(asset)
    record(
        db,
        actor_id=actor.id,
        action="MEDIA_UPLOAD",
        entity_type="media",
        entity_id=asset_id,
        meta=meta,
        after={"filename": name, "alt_text": alt_text},
    )
    await db.commit()
    await db.refresh(asset)
    return asset


async def list_assets(db: AsyncSession) -> list[MediaAsset]:
    return list(await db.scalars(select(MediaAsset).order_by(MediaAsset.created_at.desc())))


async def get_asset(db: AsyncSession, asset_id: uuid.UUID) -> MediaAsset:
    asset = await db.get(MediaAsset, asset_id)
    if asset is None:
        raise NotFound("La imagen no existe.")
    return asset


async def update_alt(
    db: AsyncSession, actor: User, asset_id: uuid.UUID, alt_text: str, meta: RequestMeta
) -> MediaAsset:
    asset = await get_asset(db, asset_id)
    record(
        db,
        actor_id=actor.id,
        action="MEDIA_UPDATE",
        entity_type="media",
        entity_id=asset.id,
        meta=meta,
        before={"alt_text": asset.alt_text},
        after={"alt_text": alt_text},
    )
    asset.alt_text = alt_text
    await db.commit()
    return asset


async def delete(
    db: AsyncSession, storage: Storage, actor: User, asset_id: uuid.UUID, meta: RequestMeta
) -> None:
    asset = await get_asset(db, asset_id)
    if (await usage_counts(db)).get(asset.id):
        raise Conflict(
            "La imagen está en uso en el carrusel o en un servicio. Quítela de ahí primero.",
            code="MEDIA_IN_USE",
        )
    keys = [v["key"] for v in asset.variants]
    record(
        db,
        actor_id=actor.id,
        action="MEDIA_DELETE",
        entity_type="media",
        entity_id=asset.id,
        meta=meta,
        before={"filename": asset.original_filename},
    )
    await db.delete(asset)
    await db.commit()
    for key in (
        keys
    ):  # tras confirmar en la base: en el peor caso queda un archivo huérfano, no un enlace roto
        try:
            await storage.delete(key)
        except Exception:
            logger.exception("No se pudo borrar %s del almacenamiento", key)
