import uuid
from datetime import datetime
from typing import Annotated

from pydantic import AfterValidator, BaseModel, Field

from app.core.validators import clean_text

AltText = Annotated[str, Field(min_length=3, max_length=200), AfterValidator(clean_text)]


class ImageOut(BaseModel):
    """Lo que necesita un <img>: src por defecto y srcset con todos los anchos."""

    id: uuid.UUID
    alt: str
    width: int
    height: int
    src: str
    srcset: str


class MediaAssetOut(ImageOut):
    original_filename: str
    bytes: int
    created_at: datetime
    usage: int = 0  # en cuántos lugares se usa (carrusel, servicios)


class MediaUpdateIn(BaseModel):
    alt_text: AltText
