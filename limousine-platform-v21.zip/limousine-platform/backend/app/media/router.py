"""Biblioteca de imágenes: /admin/media."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, Response, UploadFile, status

from app.auth.deps import DB, RedisDep, require
from app.auth.router import Meta
from app.core.errors import AppError
from app.core.rate_limit import hit
from app.media import service
from app.media.schemas import MediaAssetOut, MediaUpdateIn
from app.media.storage import Storage, get_storage
from app.users.models import User

router = APIRouter(prefix="/admin/media", tags=["content"])
Writer = Annotated[User, Depends(require("content:write"))]
StorageDep = Annotated[Storage, Depends(get_storage)]


@router.get("", response_model=list[MediaAssetOut])
async def list_media(_: Writer, db: DB, storage: StorageDep) -> list[MediaAssetOut]:
    usage = await service.usage_counts(db)
    return [
        service.asset_out(a, storage, usage.get(a.id, 0)) for a in await service.list_assets(db)
    ]


@router.post("", response_model=MediaAssetOut, status_code=status.HTTP_201_CREATED)
async def upload(
    actor: Writer,
    db: DB,
    storage: StorageDep,
    redis: RedisDep,
    meta: Meta,
    file: Annotated[UploadFile, File()],
    alt_text: Annotated[str, Form(max_length=200)] = "",
) -> MediaAssetOut:
    await hit(redis, "upload", str(actor.id), limit=60, window_seconds=3600)
    try:
        alt = MediaUpdateIn(alt_text=alt_text).alt_text
    except ValueError:
        raise AppError(
            "Describa la imagen en al menos 3 caracteres.",
            code="VALIDATION_ERROR",
            status_code=422,
            fields={"alt_text": "Describa la imagen (texto alternativo)."},
        ) from None
    return service.asset_out(await service.upload(db, storage, actor, file, alt, meta), storage)


@router.patch("/{asset_id}", response_model=MediaAssetOut)
async def update(
    asset_id: uuid.UUID, data: MediaUpdateIn, actor: Writer, db: DB, storage: StorageDep, meta: Meta
) -> MediaAssetOut:
    return service.asset_out(
        await service.update_alt(db, actor, asset_id, data.alt_text, meta), storage
    )


@router.delete("/{asset_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(
    asset_id: uuid.UUID, actor: Writer, db: DB, storage: StorageDep, meta: Meta
) -> Response:
    await service.delete(db, storage, actor, asset_id, meta)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
