"""Dónde se guardan las imágenes: disco local (desarrollo) o S3 y compatibles (producción)."""

import asyncio
from functools import lru_cache
from pathlib import Path
from typing import Any, Protocol

from app.core.config import get_settings


class Storage(Protocol):
    async def put(self, key: str, data: bytes, content_type: str) -> None: ...
    async def delete(self, key: str) -> None: ...
    def url(self, key: str) -> str: ...


class LocalStorage:
    """Archivos bajo MEDIA_ROOT; la API los sirve en /media (sólo desarrollo)."""

    def __init__(self, root: str, base_url: str) -> None:
        self.root = Path(root).resolve()
        self.base_url = base_url.rstrip("/")

    def _path(self, key: str) -> Path:
        path = (self.root / key).resolve()
        if not path.is_relative_to(self.root):  # nunca fuera de la carpeta de medios
            raise ValueError("Clave de archivo inválida")
        return path

    async def put(self, key: str, data: bytes, content_type: str) -> None:
        path = self._path(key)

        def write() -> None:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)

        await asyncio.to_thread(write)

    async def delete(self, key: str) -> None:
        await asyncio.to_thread(self._path(key).unlink, True)

    def url(self, key: str) -> str:
        return f"{self.base_url}/{key}"


class S3Storage:
    """S3 o compatible. boto3 es síncrono: cada llamada corre en un hilo aparte."""

    def __init__(
        self,
        bucket: str,
        base_url: str,
        region: str,
        endpoint_url: str | None = None,
        access_key: str = "",
        secret_key: str = "",
        client: Any = None,
    ) -> None:
        import boto3

        self.bucket = bucket
        self.base_url = base_url.rstrip("/")
        self.client = client or boto3.client(
            "s3",
            region_name=region,
            endpoint_url=endpoint_url,
            aws_access_key_id=access_key or None,
            aws_secret_access_key=secret_key or None,
        )

    async def put(self, key: str, data: bytes, content_type: str) -> None:
        await asyncio.to_thread(
            self.client.put_object,
            Bucket=self.bucket,
            Key=key,
            Body=data,
            ContentType=content_type,
            # Los nombres llevan el id de la imagen y no cambian: se pueden cachear un año.
            CacheControl="public, max-age=31536000, immutable",
        )

    async def delete(self, key: str) -> None:
        await asyncio.to_thread(self.client.delete_object, Bucket=self.bucket, Key=key)

    def url(self, key: str) -> str:
        return f"{self.base_url}/{key}"


@lru_cache
def get_storage() -> Storage:
    s = get_settings()
    if s.storage_backend == "s3":
        return S3Storage(
            s.s3_bucket,
            s.media_base_url,
            s.s3_region,
            s.s3_endpoint_url,
            s.s3_access_key,
            s.s3_secret_key,
        )
    return LocalStorage(s.media_root, s.media_base_url)
