"""Procesamiento seguro de imágenes subidas.

- El tipo se detecta abriendo la imagen, no por la extensión ni el Content-Type.
- Se rechazan las "bombas de descompresión" (pocos bytes, millones de píxeles)
  mirando las dimensiones antes de decodificar.
- Se aplica la rotación EXIF y se descarta todo metadato (en fotos de teléfono,
  el EXIF suele traer la ubicación GPS).
- Se generan varios anchos en WebP para servir a cada pantalla lo justo.
"""

import io
from dataclasses import dataclass

from PIL import Image, ImageOps, UnidentifiedImageError

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP"}
MAX_PIXELS = 40_000_000  # ~ 7700 × 5200
MIN_WIDTH, MIN_HEIGHT = 400, 300
WIDTHS = (480, 960, 1600, 2400)
QUALITY = 82


class ImageRejected(ValueError):
    """La imagen no se acepta; el mensaje se puede mostrar al usuario."""


@dataclass(frozen=True)
class Variant:
    width: int
    height: int
    data: bytes


@dataclass(frozen=True)
class Processed:
    width: int
    height: int
    source_format: str
    variants: list[Variant]


def process(data: bytes) -> Processed:
    try:
        probe = Image.open(io.BytesIO(data))
        fmt = probe.format or ""
        width, height = probe.size  # sólo lee la cabecera
    except (UnidentifiedImageError, OSError) as exc:
        raise ImageRejected("El archivo no es una imagen válida.") from exc
    if fmt not in ALLOWED_FORMATS:
        raise ImageRejected("Formato no admitido. Use JPG, PNG o WebP.")
    if width * height > MAX_PIXELS:
        raise ImageRejected(
            "La imagen tiene demasiados píxeles. Redúzcala a menos de 40 megapíxeles."
        )

    try:
        opened = Image.open(io.BytesIO(data))
        opened.load()
        image: Image.Image = ImageOps.exif_transpose(opened)
    except (OSError, Image.DecompressionBombError) as exc:
        raise ImageRejected("No se pudo leer la imagen; puede estar dañada.") from exc

    width, height = image.size
    if width < MIN_WIDTH or height < MIN_HEIGHT:
        raise ImageRejected(f"La imagen es muy pequeña: mínimo {MIN_WIDTH} × {MIN_HEIGHT} píxeles.")

    has_alpha = image.mode in ("RGBA", "LA") or (image.mode == "P" and "transparency" in image.info)
    image = image.convert("RGBA" if has_alpha else "RGB")

    targets = [w for w in WIDTHS if w < width] + [min(width, WIDTHS[-1])]
    variants = []
    for target in sorted(set(targets)):
        h = round(height * target / width)
        resized = image if target == width else image.resize((target, h), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        # Pillow no copia metadatos al guardar si no se le pasan: EXIF y GPS quedan fuera.
        resized.save(buf, "WEBP", quality=QUALITY, method=4)
        variants.append(Variant(target, h, buf.getvalue()))
    return Processed(width, height, fmt, variants)
