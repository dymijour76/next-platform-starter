"""Genera los catálogos JSON de la API desde source_api.py y verifica los marcadores.

python -m app.locales.build
"""

import json
import re
from pathlib import Path

from app.locales.source_api import MESSAGES

LANGS = ("en", "fr", "ht", "zh")
HERE = Path(__file__).resolve().parent
_PH = re.compile(r"\{(\w+)\}")


def check() -> list[str]:
    problems = []
    seen = set()
    for row in MESSAGES:
        es = row[0]
        if es in seen:
            problems.append(f"Duplicado: {es}")
        seen.add(es)
        expected = sorted(_PH.findall(es))
        for lang, text in zip(LANGS, row[1:], strict=True):
            if not text.strip():
                problems.append(f"[{lang}] vacío: {es}")
            if sorted(_PH.findall(text)) != expected:
                problems.append(f"[{lang}] marcadores distintos: {es!r} → {text!r}")
    return problems


def build() -> None:
    problems = check()
    if problems:
        raise SystemExit("\n".join(problems))
    for i, lang in enumerate(LANGS, start=1):
        data = {row[0]: row[i] for row in MESSAGES}
        (HERE / f"{lang}.json").write_text(
            json.dumps(data, ensure_ascii=False, indent=1, sort_keys=True) + "\n", encoding="utf-8"
        )
    print(f"{len(MESSAGES)} mensajes × {len(LANGS)} idiomas")


if __name__ == "__main__":
    build()
