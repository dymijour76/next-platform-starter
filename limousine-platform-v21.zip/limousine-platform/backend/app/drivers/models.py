"""Conductores: ficha profesional vinculada a una cuenta de usuario con rol de conductor."""

import enum
import uuid
from datetime import date
from typing import Any

from sqlalchemy import CheckConstraint, Date, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin
from app.users.models import User


class DriverStatus(enum.StrEnum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


# Clases de licencia chilenas. A1-A2: transporte de pasajeros en vehículos menores.
LICENSE_CLASSES = ("A1", "A2", "A3", "A4", "A5", "B")


class Driver(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "drivers"
    __table_args__ = (
        CheckConstraint("status IN ('ACTIVE', 'INACTIVE')", name="status_valid"),
        CheckConstraint(
            "license_class IN ('A1', 'A2', 'A3', 'A4', 'A5', 'B')", name="license_class_valid"
        ),
    )

    user_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), unique=True, nullable=False
    )
    license_number: Mapped[str] = mapped_column(String(20), nullable=False)
    license_class: Mapped[str] = mapped_column(String(2), nullable=False)
    license_expires_on: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False, server_default="ACTIVE")
    notes: Mapped[str | None] = mapped_column(Text)

    user: Mapped[User] = relationship(lazy="joined", innerjoin=True)

    @property
    def name(self) -> str:
        return f"{self.user.first_name} {self.user.last_name}"

    def audit_snapshot(self) -> dict[str, Any]:
        return {
            "user_id": str(self.user_id),
            "license_number": self.license_number,
            "license_class": self.license_class,
            "license_expires_on": self.license_expires_on.isoformat(),
            "status": self.status,
        }
