import uuid
from datetime import date
from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, Field, field_validator

from app.auth.schemas import Email, Name
from app.core.validators import clean_text, normalize_phone
from app.drivers.models import DriverStatus

LicenseClass = Literal["A1", "A2", "A3", "A4", "A5", "B"]


class DriverIn(BaseModel):
    email: Email
    first_name: Name
    last_name: Name
    phone: str = Field(max_length=25)
    license_number: Annotated[str, Field(min_length=3, max_length=20), AfterValidator(clean_text)]
    license_class: LicenseClass
    license_expires_on: date
    status: DriverStatus = DriverStatus.ACTIVE
    notes: str | None = Field(default=None, max_length=2000)

    @field_validator("phone")
    @classmethod
    def _phone(cls, v: str) -> str:
        phone = normalize_phone(v)
        if not phone:
            raise ValueError("Este campo es obligatorio.")
        return phone


class DriverOut(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    name: str
    email: str
    phone: str | None
    license_number: str
    license_class: str
    license_expires_on: date
    license_expired: bool
    status: DriverStatus
    notes: str | None
    upcoming_trips: int
    # Calificación de los clientes: sólo la ve el personal.
    rating_average: float | None = None
    rating_count: int = 0
