"""Conductores: /admin/drivers."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.auth.deps import DB, require
from app.auth.router import Mailer, Meta
from app.drivers import service
from app.drivers.schemas import DriverIn, DriverOut
from app.users.models import User

router = APIRouter(prefix="/admin/drivers", tags=["drivers"])
Read = Annotated[User, Depends(require("drivers:read"))]
Write = Annotated[User, Depends(require("drivers:write"))]


@router.get("", response_model=list[DriverOut])
async def list_drivers(_: Read, db: DB) -> list[DriverOut]:
    return [await service.to_out(db, d) for d in await service.list_drivers(db)]


@router.post("", response_model=DriverOut, status_code=status.HTTP_201_CREATED)
async def create(data: DriverIn, actor: Write, db: DB, meta: Meta, mailer: Mailer) -> DriverOut:
    return await service.to_out(db, await service.create_driver(db, actor, data, meta, mailer))


@router.get("/{driver_id}", response_model=DriverOut)
async def get(driver_id: uuid.UUID, _: Read, db: DB) -> DriverOut:
    return await service.to_out(db, await service.get_driver(db, driver_id))


@router.put("/{driver_id}", response_model=DriverOut)
async def update(
    driver_id: uuid.UUID, data: DriverIn, actor: Write, db: DB, meta: Meta
) -> DriverOut:
    return await service.to_out(db, await service.update_driver(db, actor, driver_id, data, meta))
