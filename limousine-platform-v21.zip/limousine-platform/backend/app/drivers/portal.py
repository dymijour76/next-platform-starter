"""Panel del conductor: /driver/*.

El conductor ve sólo los viajes que tiene asignados y, de cada pasajero, lo
necesario para el servicio (nombre, teléfono, direcciones, indicaciones); nunca
precios ni pagos.
"""

import secrets
import uuid
from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import or_, select

from app.auth.deps import DB, require
from app.auth.router import Mailer
from app.chat import service as chat
from app.core.errors import AppError, NotFound, PermissionDenied
from app.core.translations import localized
from app.drivers.models import Driver, DriverStatus
from app.drivers.service import get_by_user
from app.reservations import service as reservations
from app.reservations.models import ACTIVE_TRIP, Reservation, ReservationStatus
from app.reservations.verification import driver_code
from app.users.models import User

router = APIRouter(prefix="/driver", tags=["driver"])
S = ReservationStatus

# Desde cuánto antes de la recogida puede marcar "en camino".
EN_ROUTE_WINDOW = timedelta(hours=12)


async def current_driver(
    user: Annotated[User, Depends(require("driver_portal:access"))], db: DB
) -> Driver:
    driver = await get_by_user(db, user.id)
    if driver is None or driver.status != DriverStatus.ACTIVE:
        raise PermissionDenied(
            "Su ficha de conductor no está activa. Contacte a la oficina.", code="DRIVER_INACTIVE"
        )
    return driver


Me = Annotated[Driver, Depends(current_driver)]


class TripOut(BaseModel):
    id: uuid.UUID
    code: str
    status: ReservationStatus
    service_name: str
    pickup_at: datetime
    pickup_local: str
    end_at: datetime
    duration_minutes: int
    pickup_address: str
    dropoff_address: str | None
    passenger_count: int
    contact_name: str
    contact_phone: str
    notes: str | None
    vehicle: str | None
    boarded_at: datetime | None
    # Acciones disponibles ahora mismo
    actions: list[str]
    unread_messages: int = 0  # mensajes del pasajero sin leer
    driver_code: str | None = None  # dígaselo al pasajero cuando se lo pida


def _actions(r: Reservation, now: datetime) -> list[str]:
    status = S(r.status)
    if status == S.CONFIRMED and now >= r.pickup_at - EN_ROUTE_WINDOW:
        return ["EN_ROUTE"]
    if status == S.EN_ROUTE:
        return ["ARRIVED"]
    if status == S.ARRIVED:
        return ["BOARD", "NO_SHOW"] if now >= r.pickup_at else ["BOARD"]
    if status == S.IN_PROGRESS:
        return ["COMPLETED"]
    return []


def _out(r: Reservation) -> TripOut:
    return TripOut(
        id=r.id,
        code=r.code,
        status=S(r.status),
        service_name=localized(r.service.translations, "name", r.service.name),
        pickup_at=r.pickup_at,
        pickup_local=reservations._pickup_local(r),
        end_at=r.end_at,
        duration_minutes=r.duration_minutes,
        pickup_address=r.pickup_address,
        dropoff_address=r.dropoff_address,
        passenger_count=r.passenger_count,
        contact_name=r.contact_name,
        contact_phone=r.contact_phone,
        notes=r.notes,
        vehicle=r.vehicle.display_label if r.vehicle else None,
        driver_code=driver_code(r),
        boarded_at=r.boarded_at,
        actions=_actions(r, datetime.now(UTC)),
    )


async def _mine(db: DB, driver: Driver, trip_id: uuid.UUID, lock: bool = False) -> Reservation:
    query = select(Reservation).where(Reservation.id == trip_id, Reservation.driver_id == driver.id)
    if lock:
        query = query.with_for_update(of=Reservation)
    r = await db.scalar(query)
    if r is None:
        raise NotFound("El viaje no existe o no está asignado a usted.")
    return r


@router.get("/trips", response_model=list[TripOut])
async def trips(me: Me, db: DB, scope: Literal["upcoming", "past"] = "upcoming") -> list[TripOut]:
    query = select(Reservation).where(Reservation.driver_id == me.id)
    if scope == "upcoming":
        query = query.where(Reservation.status.in_(ACTIVE_TRIP)).order_by(Reservation.pickup_at)
    else:
        query = query.where(
            or_(
                Reservation.status.notin_(ACTIVE_TRIP),
                Reservation.end_at < datetime.now(UTC) - timedelta(days=1),
            )
        ).order_by(Reservation.pickup_at.desc())
    out = [_out(r) for r in (await db.scalars(query.limit(100))).unique()]
    for item in out:
        item.unread_messages = await chat.unread(db, item.id, "driver")
    return out


@router.get("/trips/{trip_id}", response_model=TripOut)
async def trip(trip_id: uuid.UUID, me: Me, db: DB) -> TripOut:
    return _out(await _mine(db, me, trip_id))


class StatusIn(BaseModel):
    status: Literal["EN_ROUTE", "ARRIVED", "NO_SHOW", "COMPLETED"]
    note: str | None = Field(default=None, max_length=500)


def _not_now() -> AppError:
    return AppError(
        "Esa acción no está disponible en este momento del viaje.",
        code="INVALID_TRANSITION",
        status_code=409,
    )


@router.post("/trips/{trip_id}/status", response_model=TripOut)
async def update_status(
    trip_id: uuid.UUID, data: StatusIn, me: Me, db: DB, mailer: Mailer
) -> TripOut:
    r = await _mine(db, me, trip_id, lock=True)
    if data.status not in _actions(r, datetime.now(UTC)):
        raise _not_now()
    reservations._event(r, S(data.status), me.user, f"Conductor {me.name}", data.note)
    await db.commit()
    await db.refresh(r)
    if data.status == "EN_ROUTE":
        await reservations.notify(db, r, "en_route", mailer)
    elif data.status == "COMPLETED":
        await reservations.notify(db, r, "review_request", mailer)
    return _out(r)


class BoardIn(BaseModel):
    qr_token: str | None = Field(default=None, max_length=100)
    # Si la cámara no funciona: el conductor verifica al pasajero por su nombre.
    without_qr: bool = False


@router.post("/trips/{trip_id}/board", response_model=TripOut)
async def board(trip_id: uuid.UUID, data: BoardIn, me: Me, db: DB) -> TripOut:
    r = await _mine(db, me, trip_id, lock=True)
    if "BOARD" not in _actions(r, datetime.now(UTC)):
        raise _not_now()
    if data.qr_token:
        if not secrets.compare_digest(data.qr_token.strip(), r.qr_token):
            raise AppError(
                "El código QR no corresponde a esta reserva.", code="QR_MISMATCH", status_code=422
            )
        note = "Abordaje validado con QR"
    elif data.without_qr:
        note = "Abordaje confirmado sin QR"
    else:
        raise AppError(
            "Escanee el QR del pasajero o confirme el abordaje sin QR.",
            code="QR_REQUIRED",
            status_code=422,
        )
    reservations._event(r, S.IN_PROGRESS, me.user, f"Conductor {me.name}", note)
    r.boarded_at = datetime.now(UTC)
    await db.commit()
    await db.refresh(r)
    return _out(r)
