"""Conductores."""

import secrets
import uuid
from datetime import UTC, date, datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.auth import service as auth_service
from app.auth.models import TokenPurpose
from app.auth.security import hash_password
from app.core.errors import Conflict, NotFound
from app.core.request_context import RequestMeta
from app.drivers.models import Driver, DriverStatus
from app.drivers.schemas import DriverIn, DriverOut
from app.notifications import templates
from app.notifications.email import EmailDispatcher
from app.reservations.models import ACTIVE_TRIP, Reservation
from app.reviews.service import driver_rating
from app.users.models import CustomerProfile, User, UserRole
from app.users.rbac import ROLE_DRIVER


def today() -> date:
    return datetime.now(UTC).date()


async def upcoming_count(db: AsyncSession, driver_id: uuid.UUID) -> int:
    return (
        await db.scalar(
            select(func.count()).where(
                Reservation.driver_id == driver_id,
                Reservation.status.in_(ACTIVE_TRIP),
                Reservation.blocks_until > datetime.now(UTC),
            )
        )
        or 0
    )


async def to_out(db: AsyncSession, d: Driver) -> DriverOut:
    return DriverOut(
        id=d.id,
        user_id=d.user_id,
        name=d.name,
        email=d.user.email,
        phone=d.user.phone,
        license_number=d.license_number,
        license_class=d.license_class,
        license_expires_on=d.license_expires_on,
        license_expired=d.license_expires_on < today(),
        status=DriverStatus(d.status),
        notes=d.notes,
        upcoming_trips=await upcoming_count(db, d.id),
        rating_average=(rating := await driver_rating(db, d.id)).average,
        rating_count=rating.count,
    )


async def list_drivers(db: AsyncSession) -> list[Driver]:
    return list(
        (
            await db.scalars(select(Driver).join(User).order_by(Driver.status, User.first_name))
        ).unique()
    )


async def get_driver(db: AsyncSession, driver_id: uuid.UUID) -> Driver:
    d = await db.get(Driver, driver_id, populate_existing=True)
    if d is None:
        raise NotFound("El conductor no existe.")
    return d


async def get_by_user(db: AsyncSession, user_id: uuid.UUID) -> Driver | None:
    return await db.scalar(select(Driver).where(Driver.user_id == user_id))


async def create_driver(
    db: AsyncSession, actor: User, data: DriverIn, meta: RequestMeta, mailer: EmailDispatcher
) -> Driver:
    """Registra un conductor. Si el email no tiene cuenta, la crea y envía la invitación.

    Excepción a la regla de no otorgar permisos propios: quien administra
    conductores puede darles el rol de conductor, que sólo permite ver sus viajes.
    """
    user = await auth_service.get_user_by_email(db, data.email)
    invite = user is None
    if user is None:
        user = User(
            email=data.email,
            password_hash=hash_password(secrets.token_urlsafe(32)),
            first_name=data.first_name,
            last_name=data.last_name,
            phone=data.phone,
        )
        db.add(user)
        await db.flush()
        db.add(CustomerProfile(user_id=user.id))
    elif await get_by_user(db, user.id):
        raise Conflict(
            code="DRIVER_EXISTS",
            fields={"email": "Esta persona ya está registrada como conductor."},
        )
    else:
        user.phone = data.phone

    role = await auth_service.get_role(db, ROLE_DRIVER)
    if not await db.scalar(
        select(UserRole).where(UserRole.user_id == user.id, UserRole.role_id == role.id)
    ):
        db.add(UserRole(user_id=user.id, role_id=role.id, assigned_by=actor.id))

    driver = Driver(
        user_id=user.id,
        license_number=data.license_number,
        license_class=data.license_class,
        license_expires_on=data.license_expires_on,
        status=data.status,
        notes=data.notes,
    )
    db.add(driver)
    await db.flush()
    record(
        db,
        actor_id=actor.id,
        action="DRIVER_CREATE",
        entity_type="driver",
        entity_id=driver.id,
        meta=meta,
        after=driver.audit_snapshot(),
    )
    token = None
    if invite:
        token = await auth_service.create_one_time_token(
            db, user, TokenPurpose.PASSWORD_RESET, timedelta(hours=72)
        )
    await db.commit()
    if token:
        await mailer.send(
            templates.invitation_email(
                user.email, user.first_name, ["Conductor"], token, user.locale
            )
        )
    return await get_driver(db, driver.id)


async def update_driver(
    db: AsyncSession, actor: User, driver_id: uuid.UUID, data: DriverIn, meta: RequestMeta
) -> Driver:
    d = await get_driver(db, driver_id)
    if data.email != d.user.email:
        raise Conflict(
            "El email se cambia desde la ficha del usuario.",
            code="EMAIL_IMMUTABLE",
            fields={"email": "No se puede cambiar aquí."},
        )
    if data.status != DriverStatus.ACTIVE and await upcoming_count(db, d.id):
        raise Conflict(
            "El conductor tiene viajes asignados. Reasígnelos antes de desactivarlo.",
            code="DRIVER_IN_USE",
        )
    before = d.audit_snapshot()
    d.user.first_name, d.user.last_name, d.user.phone = data.first_name, data.last_name, data.phone
    for key in ("license_number", "license_class", "license_expires_on", "status", "notes"):
        setattr(d, key, getattr(data, key))
    record(
        db,
        actor_id=actor.id,
        action="DRIVER_UPDATE",
        entity_type="driver",
        entity_id=d.id,
        meta=meta,
        before=before,
        after=d.audit_snapshot(),
    )
    await db.commit()
    return await get_driver(db, d.id)
