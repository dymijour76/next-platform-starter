"""Tasas de cambio: actualización automática (ExchangeRate-API, acceso abierto) y manual."""

import logging
from datetime import UTC, datetime
from decimal import Decimal, InvalidOperation
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.currency.models import ExchangeRate

logger = logging.getLogger(__name__)
SUPPORTED = ("USD", "EUR", "BRL")
# Pesos chilenos por unidad: fuera de estos márgenes, una tasa de la fuente se descarta (un
# error de la fuente no debe mostrar un dólar a 5 pesos). Amplios a propósito.
BOUNDS = {
    "USD": (Decimal(300), Decimal(3000)),
    "EUR": (Decimal(300), Decimal(3500)),
    "BRL": (Decimal(40), Decimal(800)),
}
ATTRIBUTION = {"name": "ExchangeRate-API", "url": "https://www.exchangerate-api.com"}


class RatesUnavailable(Exception):
    """La fuente no respondió o respondió algo inesperado."""


async def _get_json(url: str) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.get(url, headers={"Accept": "application/json"})
        res.raise_for_status()
        data: dict[str, Any] = res.json()
        return data


async def fetch_auto() -> tuple[dict[str, Decimal], list[str]]:
    """Tasas de la fuente, en pesos por unidad. Devuelve (válidas, descartadas)."""
    try:
        data = await _get_json(get_settings().exchange_rate_url)
    except (httpx.HTTPError, ValueError) as exc:
        raise RatesUnavailable(str(exc)) from exc
    if data.get("result") != "success" or data.get("base_code") != "CLP":
        raise RatesUnavailable("respuesta inesperada de la fuente")
    valid: dict[str, Decimal] = {}
    rejected: list[str] = []
    for code in SUPPORTED:
        try:
            per_clp = Decimal(str(data["rates"][code]))  # unidades por 1 CLP
            rate = (Decimal(1) / per_clp).quantize(Decimal("0.0001"))
        except (KeyError, InvalidOperation, ZeroDivisionError, TypeError):
            rejected.append(code)
            continue
        low, high = BOUNDS[code]
        if low <= rate <= high:
            valid[code] = rate
        else:
            logger.warning("Tasa descartada por fuera de rango: %s = %s CLP", code, rate)
            rejected.append(code)
    return valid, rejected


async def all_rates(db: AsyncSession) -> list[ExchangeRate]:
    rows = {r.currency: r for r in (await db.scalars(select(ExchangeRate))).all()}
    out = []
    for code in SUPPORTED:
        if code not in rows:
            rows[code] = ExchangeRate(currency=code)
            db.add(rows[code])
        out.append(rows[code])
    return out


async def refresh(db: AsyncSession) -> tuple[list[str], list[str]]:
    """Actualiza las tasas automáticas. Si la fuente falla, quedan las anteriores."""
    valid, rejected = await fetch_auto()
    now = datetime.now(UTC)
    for row in await all_rates(db):
        if row.currency in valid:
            row.auto_rate = valid[row.currency]
            row.auto_updated_at = now
    await db.commit()
    return sorted(valid), rejected
