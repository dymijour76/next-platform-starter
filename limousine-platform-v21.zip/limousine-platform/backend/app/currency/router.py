from datetime import datetime
from decimal import Decimal
from typing import Annotated, Literal

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.audit.service import record
from app.auth.deps import DB, require
from app.auth.router import Meta
from app.core.errors import AppError
from app.currency import service
from app.currency.models import ExchangeRate
from app.users.models import User

router = APIRouter(tags=["monedas"])
Code = Literal["USD", "EUR", "BRL"]


class RateOut(BaseModel):
    code: str
    rate: Decimal | None  # pesos chilenos por una unidad (la vigente)
    source: Literal["auto", "manual", "none"]
    updated_at: datetime | None


class RatesOut(BaseModel):
    base: str = "CLP"
    currencies: list[RateOut]
    attribution: dict[str, str] = service.ATTRIBUTION


class AdminRateOut(RateOut):
    auto_rate: Decimal | None
    auto_updated_at: datetime | None
    manual_rate: Decimal | None
    manual_updated_at: datetime | None


class ManualIn(BaseModel):
    # None: volver a la tasa automática.
    manual_rate: Annotated[Decimal, Field(gt=0, le=100_000, max_digits=14, decimal_places=4)] | None


def _public(r: ExchangeRate) -> RateOut:
    manual = r.manual_rate is not None
    return RateOut(
        code=r.currency,
        rate=r.rate,
        source="manual" if manual else "auto" if r.auto_rate is not None else "none",
        updated_at=r.manual_updated_at if manual else r.auto_updated_at,
    )


def _admin(r: ExchangeRate) -> AdminRateOut:
    return AdminRateOut(
        **_public(r).model_dump(),
        auto_rate=r.auto_rate,
        auto_updated_at=r.auto_updated_at,
        manual_rate=r.manual_rate,
        manual_updated_at=r.manual_updated_at,
    )


@router.get("/currencies", response_model=RatesOut)
async def public_rates(db: DB) -> RatesOut:
    rows = await service.all_rates(db)
    await db.commit()
    return RatesOut(currencies=[_public(r) for r in rows])


@router.get("/admin/currencies", response_model=list[AdminRateOut])
async def admin_rates(
    _: Annotated[User, Depends(require("settings:write"))], db: DB
) -> list[AdminRateOut]:
    rows = await service.all_rates(db)
    await db.commit()
    return [_admin(r) for r in rows]


@router.put("/admin/currencies/{code}", response_model=list[AdminRateOut])
async def set_manual(
    code: Code,
    data: ManualIn,
    actor: Annotated[User, Depends(require("settings:write"))],
    db: DB,
    meta: Meta,
) -> list[AdminRateOut]:
    if data.manual_rate is not None:
        low, high = service.BOUNDS[code]
        if not low <= data.manual_rate <= high:
            # Un error de tipeo ("1.234" por "1234") no debe mostrar precios absurdos.
            raise AppError(
                "La tasa está fuera del rango razonable para esta moneda. Revise el número.",
                code="RATE_OUT_OF_RANGE",
                fields={"manual_rate": "Fuera de rango."},
            )
    rows = {r.currency: r for r in await service.all_rates(db)}
    row = rows[code]
    before = {"manual_rate": str(row.manual_rate) if row.manual_rate else None}
    row.manual_rate = data.manual_rate
    row.manual_updated_at = datetime.now().astimezone() if data.manual_rate else None
    row.manual_by = actor.id if data.manual_rate else None
    record(
        db,
        actor_id=actor.id,
        action="EXCHANGE_RATE_MANUAL",
        entity_type="currency",
        entity_id=code,
        meta=meta,
        before=before,
        after={"manual_rate": str(data.manual_rate) if data.manual_rate else None},
    )
    await db.commit()
    return [_admin(r) for r in rows.values()]


@router.post("/admin/currencies/refresh", response_model=list[AdminRateOut])
async def refresh(
    _: Annotated[User, Depends(require("settings:write"))], db: DB
) -> list[AdminRateOut]:
    try:
        await service.refresh(db)
    except service.RatesUnavailable as exc:
        raise AppError(
            "No se pudieron obtener las tasas de cambio. Se mantienen las anteriores.",
            code="RATES_UNAVAILABLE",
            status_code=502,
        ) from exc
    return [_admin(r) for r in await service.all_rates(db)]
