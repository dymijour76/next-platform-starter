"""Tasas de cambio para mostrar precios de referencia en otras monedas.

Los precios se cobran siempre en pesos chilenos (CLP); estas tasas sólo sirven para mostrar
un valor aproximado. Cada moneda tiene una tasa automática (actualizada a diario) y,
opcionalmente, una tasa manual que fija el administrador y que tiene prioridad.
"""

import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Numeric, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin


class ExchangeRate(TimestampMixin, Base):
    __tablename__ = "exchange_rates"
    __table_args__ = (
        CheckConstraint("auto_rate IS NULL OR auto_rate > 0", name="auto_rate_positive"),
        CheckConstraint("manual_rate IS NULL OR manual_rate > 0", name="manual_rate_positive"),
    )

    currency: Mapped[str] = mapped_column(String(3), primary_key=True)  # USD, EUR, BRL
    # Pesos chilenos por una unidad de la moneda (por ejemplo, 945.32 por 1 USD).
    auto_rate: Mapped[Decimal | None] = mapped_column(Numeric(14, 4))
    auto_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    manual_rate: Mapped[Decimal | None] = mapped_column(Numeric(14, 4))
    manual_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    manual_by: Mapped[uuid.UUID | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"))

    @property
    def rate(self) -> Decimal | None:
        """La tasa vigente: la manual, si el administrador fijó una; si no, la automática."""
        return self.manual_rate or self.auto_rate
