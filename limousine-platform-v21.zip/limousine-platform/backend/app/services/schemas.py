import uuid
from datetime import datetime
from decimal import Decimal
from typing import Annotated, Any, Self

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, model_validator

from app.core.money import Amount, AmountIn
from app.core.translations import ServiceTranslations
from app.core.validators import clean_text
from app.media.schemas import ImageOut

Slug = Annotated[str, Field(pattern=r"^[a-z0-9]+(?:-[a-z0-9]+)*$", min_length=2, max_length=80)]
Name = Annotated[str, Field(min_length=1, max_length=100), AfterValidator(clean_text)]
Hours = Annotated[Decimal, Field(gt=0, le=24, decimal_places=2)]
Feature = Annotated[str, Field(min_length=1, max_length=80), AfterValidator(clean_text)]


class RatingOut(BaseModel):
    average: float | None = None
    count: int = 0


class ServiceOut(BaseModel):
    """Vista pública de un servicio."""

    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    slug: str
    name: str
    tagline: str | None
    description: str | None
    passenger_capacity: int
    luggage_capacity: int | None
    features: list[str]
    base_fare: Amount
    hourly_rate: Amount
    min_hours: Amount
    max_hours: Amount | None
    minimum_fare: Amount
    currency: str = "CLP"
    # Precio "desde": el mínimo que puede costar una reserva de este servicio.
    price_from: Amount = Decimal(0)
    # Fotografías: la primera es la portada.
    gallery: list[ImageOut] = []
    # Promedio de los clientes: cuentan todas, también las de comentarios ocultos.
    rating: RatingOut | None = None


class ServiceAdminOut(ServiceOut):
    # En el panel: el texto base (español) y todas sus traducciones, para editarlas.
    translations: dict[str, dict[str, Any]] = {}
    # Vehículos activos del servicio: definen cuántas reservas pueden coincidir.
    vehicle_count: int = 0
    is_active: bool
    sort_order: int
    created_at: datetime
    updated_at: datetime


class _ServiceFields(BaseModel):
    tagline: str | None = Field(default=None, max_length=200)
    description: str | None = Field(default=None, max_length=5000)
    luggage_capacity: int | None = Field(default=None, ge=0, le=50)
    features: list[Feature] = Field(default_factory=list, max_length=20)
    translations: ServiceTranslations = Field(default_factory=dict)
    max_hours: Hours | None = None
    sort_order: int = Field(default=100, ge=0, le=10000)


class ServiceIn(_ServiceFields):
    slug: Slug
    name: Name
    passenger_capacity: int = Field(ge=1, le=60)
    base_fare: AmountIn = Decimal(0)
    hourly_rate: AmountIn
    min_hours: Hours
    minimum_fare: AmountIn = Decimal(0)
    is_active: bool = True

    @model_validator(mode="after")
    def _hours(self) -> Self:
        if self.max_hours is not None and self.max_hours < self.min_hours:
            raise ValueError("El máximo de horas no puede ser menor que el mínimo.")
        return self


class ServiceUpdate(BaseModel):
    """Todos opcionales: sólo se modifica lo que se envía."""

    slug: Slug | None = None
    name: Name | None = None
    tagline: str | None = Field(default=None, max_length=200)
    description: str | None = Field(default=None, max_length=5000)
    passenger_capacity: int | None = Field(default=None, ge=1, le=60)
    luggage_capacity: int | None = Field(default=None, ge=0, le=50)
    features: list[Feature] | None = Field(default=None, max_length=20)
    translations: ServiceTranslations | None = None
    base_fare: AmountIn | None = None
    hourly_rate: AmountIn | None = None
    min_hours: Hours | None = None
    max_hours: Hours | None = None
    minimum_fare: AmountIn | None = None
    is_active: bool | None = None
    sort_order: int | None = Field(default=None, ge=0, le=10000)


class GalleryIn(BaseModel):
    """Imágenes del servicio en orden; la primera es la portada. Lista vacía: sin fotos."""

    image_ids: list[uuid.UUID] = Field(max_length=12)
