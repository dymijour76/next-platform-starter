"""Catálogo de servicios: público (/services) y administración (/admin/services)."""

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, status

from app.auth.deps import DB, require
from app.auth.router import Meta
from app.reviews.service import service_ratings
from app.services import crud
from app.services.schemas import (
    GalleryIn,
    RatingOut,
    ServiceAdminOut,
    ServiceIn,
    ServiceOut,
    ServiceUpdate,
)
from app.settings.service import get_pricing_settings
from app.users.models import User

router = APIRouter(tags=["services"])


@router.get("/services", response_model=list[ServiceOut])
async def list_public(db: DB) -> list[ServiceOut]:
    settings, ratings = await get_pricing_settings(db), await service_ratings(db)
    out = []
    for s in await crud.list_services(db, include_inactive=False):
        item = crud.to_public(s, settings)
        item.rating = RatingOut(**ratings[s.id].model_dump()) if s.id in ratings else None
        out.append(item)
    return out


@router.get("/services/{slug}", response_model=ServiceOut)
async def get_public(slug: str, db: DB) -> ServiceOut:
    settings = await get_pricing_settings(db)
    s = await crud.get_active_by_slug(db, slug)
    item = crud.to_public(s, settings)
    rating = (await service_ratings(db)).get(s.id)
    item.rating = RatingOut(**rating.model_dump()) if rating else None
    return item


@router.get("/admin/services", response_model=list[ServiceAdminOut])
async def list_admin(
    _: Annotated[User, Depends(require("services:read"))], db: DB
) -> list[ServiceAdminOut]:
    settings = await get_pricing_settings(db)
    counts = await crud.vehicle_counts(db)
    services = await crud.list_services(db, include_inactive=True)
    return [crud.to_admin(s, settings, counts.get(s.id, 0)) for s in services]


@router.post("/admin/services", response_model=ServiceAdminOut, status_code=status.HTTP_201_CREATED)
async def create(
    data: ServiceIn, actor: Annotated[User, Depends(require("services:write"))], db: DB, meta: Meta
) -> ServiceAdminOut:
    service = await crud.create_service(db, actor, data, meta)
    return crud.to_admin(service, await get_pricing_settings(db))


@router.get("/admin/services/{service_id}", response_model=ServiceAdminOut)
async def get_admin(
    service_id: uuid.UUID, _: Annotated[User, Depends(require("services:read"))], db: DB
) -> ServiceAdminOut:
    counts = await crud.vehicle_counts(db)
    return crud.to_admin(
        await crud.get_service(db, service_id),
        await get_pricing_settings(db),
        counts.get(service_id, 0),
    )


@router.patch("/admin/services/{service_id}", response_model=ServiceAdminOut)
async def update(
    service_id: uuid.UUID,
    data: ServiceUpdate,
    actor: Annotated[User, Depends(require("services:write"))],
    db: DB,
    meta: Meta,
) -> ServiceAdminOut:
    service = await crud.update_service(db, actor, service_id, data, meta)
    counts = await crud.vehicle_counts(db)
    return crud.to_admin(service, await get_pricing_settings(db), counts.get(service.id, 0))


@router.put("/admin/services/{service_id}/images", response_model=ServiceAdminOut)
async def set_gallery(
    service_id: uuid.UUID,
    data: GalleryIn,
    actor: Annotated[User, Depends(require("content:write"))],
    db: DB,
    meta: Meta,
) -> ServiceAdminOut:
    """Fotografías del servicio (permiso de contenido, no de precios)."""
    service = await crud.set_gallery(db, actor, service_id, data.image_ids, meta)
    counts = await crud.vehicle_counts(db)
    return crud.to_admin(service, await get_pricing_settings(db), counts.get(service.id, 0))
