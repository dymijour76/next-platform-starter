"""Gestión del catálogo de servicios."""

import uuid
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.audit.service import record
from app.core.errors import Conflict, NotFound, PermissionDenied
from app.core.request_context import RequestMeta
from app.core.translations import localized
from app.media.schemas import ImageOut
from app.media.service import image_out
from app.media.storage import get_storage
from app.pricing.engine import money
from app.services.models import Service, ServiceImage
from app.services.schemas import ServiceAdminOut, ServiceIn, ServiceOut, ServiceUpdate
from app.settings.schemas import PricingSettings
from app.users.models import User

# La tarifa vive en el servicio, pero cambiarla exige además el permiso de precios.
TARIFF_FIELDS = frozenset({"base_fare", "hourly_rate", "min_hours", "max_hours", "minimum_fare"})


def _ensure_can_price(actor: User) -> None:
    if "pricing:write" not in actor.permission_codes:
        raise PermissionDenied(
            "Modificar la tarifa requiere el permiso de precios.", code="PRICING_PERMISSION"
        )


def price_from(service: Service, currency: str) -> Decimal:
    """Lo mínimo que cuesta una reserva, antes de recargos y descuentos."""
    base = service.base_fare + service.hourly_rate * service.min_hours
    return money(max(base, service.minimum_fare), currency)


def _gallery(service: Service) -> list[ImageOut]:
    storage = get_storage()
    return [image_out(si.image, storage) for si in service.images]


def to_public(service: Service, settings: PricingSettings) -> ServiceOut:
    out = ServiceOut.model_validate(service)
    # Textos en el idioma de la persona (o español si no están traducidos).
    tr = service.translations
    out.name = localized(tr, "name", service.name)
    out.tagline = localized(tr, "tagline", service.tagline)
    out.description = localized(tr, "description", service.description)
    out.features = localized(tr, "features", service.features)
    out.currency = settings.currency
    out.price_from = price_from(service, settings.currency)
    out.gallery = _gallery(service)
    return out


def to_admin(service: Service, settings: PricingSettings, vehicles: int = 0) -> ServiceAdminOut:
    out = ServiceAdminOut.model_validate(service)
    out.currency = settings.currency
    out.price_from = price_from(service, settings.currency)
    out.vehicle_count = vehicles
    out.translations = service.translations or {}
    out.gallery = _gallery(service)
    return out


async def vehicle_counts(db: AsyncSession) -> dict[uuid.UUID, int]:
    """Vehículos activos por servicio."""
    from app.vehicles.models import Vehicle, VehicleStatus

    rows = await db.execute(
        select(Vehicle.service_id, func.count())
        .where(Vehicle.status == VehicleStatus.ACTIVE)
        .group_by(Vehicle.service_id)
    )
    return {sid: n for sid, n in rows.all()}


async def list_services(db: AsyncSession, *, include_inactive: bool) -> list[Service]:
    query = select(Service).order_by(Service.sort_order, Service.name)
    if not include_inactive:
        query = query.where(Service.is_active.is_(True))
    return list(await db.scalars(query))


async def get_active_by_slug(db: AsyncSession, slug: str) -> Service:
    service = await db.scalar(
        select(Service).where(Service.slug == slug, Service.is_active.is_(True))
    )
    if service is None:
        raise NotFound("El servicio no existe o no está disponible.")
    return service


async def get_service(db: AsyncSession, service_id: uuid.UUID) -> Service:
    service = await db.get(Service, service_id, populate_existing=True)
    if service is None:
        raise NotFound("El servicio no existe.")
    return service


async def _ensure_slug_free(db: AsyncSession, slug: str, exclude: uuid.UUID | None = None) -> None:
    query = select(Service.id).where(Service.slug == slug)
    if exclude:
        query = query.where(Service.id != exclude)
    if await db.scalar(query):
        raise Conflict(
            code="SLUG_TAKEN", fields={"slug": "Ya existe un servicio con esta dirección."}
        )


async def create_service(
    db: AsyncSession, actor: User, data: ServiceIn, meta: RequestMeta
) -> Service:
    _ensure_can_price(actor)
    await _ensure_slug_free(db, data.slug)
    service = Service(**data.model_dump())
    db.add(service)
    await db.flush()
    record(
        db,
        actor_id=actor.id,
        action="SERVICE_CREATE",
        entity_type="service",
        entity_id=service.id,
        meta=meta,
        after=service.audit_snapshot(),
    )
    await db.commit()
    await db.refresh(service)
    return service


async def update_service(
    db: AsyncSession, actor: User, service_id: uuid.UUID, data: ServiceUpdate, meta: RequestMeta
) -> Service:
    service = await get_service(db, service_id)
    changes = data.model_dump(exclude_unset=True)
    # Campos obligatorios: null no los borra.
    required = {
        "slug",
        "name",
        "passenger_capacity",
        "base_fare",
        "hourly_rate",
        "min_hours",
        "minimum_fare",
        "is_active",
        "sort_order",
        "features",
        "translations",
    }
    changes = {k: v for k, v in changes.items() if v is not None or k not in required}
    tariff_changes = {
        k for k in TARIFF_FIELDS & changes.keys() if changes[k] != getattr(service, k)
    }
    if tariff_changes:
        _ensure_can_price(actor)
    if "slug" in changes:
        await _ensure_slug_free(db, changes["slug"], exclude=service.id)

    min_hours = changes.get("min_hours", service.min_hours)
    max_hours = changes.get("max_hours", service.max_hours)
    if max_hours is not None and max_hours < min_hours:
        raise Conflict(
            "El máximo de horas no puede ser menor que el mínimo.",
            code="VALIDATION_ERROR",
            fields={"max_hours": "Debe ser mayor o igual al mínimo de horas."},
        )

    before = service.audit_snapshot()
    for key, value in changes.items():
        setattr(service, key, value)
    after = service.audit_snapshot()
    if before != after:
        record(
            db,
            actor_id=actor.id,
            action="SERVICE_UPDATE",
            entity_type="service",
            entity_id=service.id,
            meta=meta,
            before=before,
            after=after,
        )
    await db.commit()
    await db.refresh(service)
    return service


async def set_gallery(
    db: AsyncSession,
    actor: User,
    service_id: uuid.UUID,
    image_ids: list[uuid.UUID],
    meta: RequestMeta,
) -> Service:
    from app.media.models import MediaAsset

    service = await get_service(db, service_id)
    unique = list(dict.fromkeys(image_ids))
    found = (
        set(await db.scalars(select(MediaAsset.id).where(MediaAsset.id.in_(unique))))
        if unique
        else set()
    )
    if found != set(unique):
        raise NotFound("Alguna de las imágenes no existe.")
    before = [str(si.image_id) for si in service.images]
    service.images.clear()
    await db.flush()
    for position, image_id in enumerate(unique):
        service.images.append(ServiceImage(image_id=image_id, sort_order=position))
    record(
        db,
        actor_id=actor.id,
        action="SERVICE_GALLERY_UPDATE",
        entity_type="service",
        entity_id=service.id,
        meta=meta,
        before={"images": before},
        after={"images": [str(i) for i in unique]},
    )
    await db.commit()
    return await get_service(db, service.id)
