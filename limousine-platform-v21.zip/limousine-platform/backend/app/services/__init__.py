"""Módulo services (se implementa en fases posteriores)."""
