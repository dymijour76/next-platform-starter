"""Catálogo de servicios (Standard, Professional, Premium u otros que cree la empresa)."""

import uuid
from decimal import Decimal
from typing import TYPE_CHECKING, Any

from sqlalchemy import Boolean, CheckConstraint, ForeignKey, Integer, Numeric, String, Text, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.money import num
from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin

if TYPE_CHECKING:
    from app.media.models import MediaAsset

Money = Numeric(14, 2)


class Service(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "services"
    __table_args__ = (
        CheckConstraint("base_fare >= 0", name="base_fare_non_negative"),
        CheckConstraint("hourly_rate >= 0", name="hourly_rate_non_negative"),
        CheckConstraint("minimum_fare >= 0", name="minimum_fare_non_negative"),
        CheckConstraint("min_hours > 0", name="min_hours_positive"),
        CheckConstraint("max_hours IS NULL OR max_hours >= min_hours", name="max_hours_valid"),
        CheckConstraint("passenger_capacity > 0", name="passenger_capacity_positive"),
    )

    slug: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    tagline: Mapped[str | None] = mapped_column(String(200))
    description: Mapped[str | None] = mapped_column(Text)
    passenger_capacity: Mapped[int] = mapped_column(Integer, nullable=False)
    luggage_capacity: Mapped[int | None] = mapped_column(Integer)
    # Lista de textos: ["Agua mineral", "Wi-Fi", ...]
    features: Mapped[list[str]] = mapped_column(
        JSONB, nullable=False, server_default=text("'[]'::jsonb")
    )

    # Tarifa
    base_fare: Mapped[Decimal] = mapped_column(Money, nullable=False, server_default="0")
    hourly_rate: Mapped[Decimal] = mapped_column(Money, nullable=False)
    min_hours: Mapped[Decimal] = mapped_column(Numeric(5, 2), nullable=False)
    max_hours: Mapped[Decimal | None] = mapped_column(Numeric(5, 2))
    minimum_fare: Mapped[Decimal] = mapped_column(Money, nullable=False, server_default="0")

    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False, server_default="100")

    # Galería: la primera es la portada.
    # Traducciones: {"en": {"name": "...", ...}, "fr": {...}}. El español son las columnas.
    translations: Mapped[dict[str, Any]] = mapped_column(
        JSONB, nullable=False, server_default=text("'{}'::jsonb")
    )

    images: Mapped[list["ServiceImage"]] = relationship(
        lazy="selectin", order_by="ServiceImage.sort_order", cascade="all, delete-orphan"
    )

    def audit_snapshot(self) -> dict[str, Any]:
        return {
            "slug": self.slug,
            "name": self.name,
            "passenger_capacity": self.passenger_capacity,
            "base_fare": num(self.base_fare),
            "hourly_rate": num(self.hourly_rate),
            "min_hours": num(self.min_hours),
            "max_hours": num(self.max_hours) if self.max_hours is not None else None,
            "minimum_fare": num(self.minimum_fare),
            "is_active": self.is_active,
            "translations": self.translations,
        }


class ServiceImage(Base):
    __tablename__ = "service_images"

    service_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("services.id", ondelete="CASCADE"), primary_key=True
    )
    image_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("media_assets.id", ondelete="RESTRICT"), primary_key=True, index=True
    )
    sort_order: Mapped[int] = mapped_column(Integer, nullable=False)

    image: Mapped["MediaAsset"] = relationship(lazy="joined", innerjoin=True)
