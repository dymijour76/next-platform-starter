"""Comandos de administración.

    python -m app.cli create-admin --email admin@empresa.cl --first-name Ana --last-name Pérez

La contraseña se pide por teclado (no queda en el historial de la terminal).
Para automatizar, puede pasarse en la variable ADMIN_PASSWORD.
"""

import argparse
import asyncio
import getpass
import os
import sys
from datetime import UTC, datetime, time
from decimal import Decimal

from pydantic import TypeAdapter, ValidationError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth import service as auth_service
from app.auth.passwords import validate_password
from app.auth.schemas import Email
from app.auth.security import hash_password
from app.db import (
    models as _all_models,  # noqa: F401  registra todos los modelos (relaciones por nombre)
)
from app.db.session import SessionLocal, engine
from app.demo_translations import RULE_TRANSLATIONS, SERVICE_TRANSLATIONS
from app.pricing.models import PricingRule
from app.services.models import Service
from app.users.models import CustomerProfile, User, UserRole
from app.users.rbac import ROLE_SUPER_ADMIN
from app.vehicles.models import Vehicle


def _read_password(email: str) -> str:
    password = os.environ.get("ADMIN_PASSWORD")
    if password is None:
        password = getpass.getpass("Contraseña: ")
        if password != getpass.getpass("Repita la contraseña: "):
            sys.exit("Las contraseñas no coinciden.")
    try:
        return validate_password(password, email=email)
    except ValueError as exc:
        sys.exit(str(exc))


async def create_admin(email: str, first_name: str, last_name: str) -> None:
    try:
        email = TypeAdapter(Email).validate_python(email)
    except ValidationError:
        sys.exit("El email no es válido.")
    password = _read_password(email)

    async with SessionLocal() as db:
        user = await auth_service.get_user_by_email(db, email)
        role = await auth_service.get_role(db, ROLE_SUPER_ADMIN)
        if user is None:
            user = User(
                email=email,
                password_hash=hash_password(password),
                first_name=first_name,
                last_name=last_name,
                email_verified_at=datetime.now(UTC),
            )
            db.add(user)
            await db.flush()
            db.add(CustomerProfile(user_id=user.id))
            action = "creado"
        else:
            user.password_hash = hash_password(password)
            action = "actualizado"
        has_role = await db.scalar(
            select(UserRole).where(UserRole.user_id == user.id, UserRole.role_id == role.id)
        )
        if has_role is None:
            db.add(UserRole(user_id=user.id, role_id=role.id))
        await db.commit()
    await engine.dispose()
    print(f"Administrador general {action}: {email}")


DEMO_SERVICES = [
    {
        "slug": "standard",
        "name": "Standard",
        "tagline": "Traslados ejecutivos con chófer profesional",
        "description": "Sedán o SUV de lujo para traslados al aeropuerto, reuniones y cenas.",
        "passenger_capacity": 4,
        "luggage_capacity": 3,
        "features": ["Chófer profesional", "Agua mineral", "Cargadores de teléfono"],
        "base_fare": Decimal(15000),
        "hourly_rate": Decimal(35000),
        "min_hours": Decimal(2),
        "max_hours": Decimal(12),
        "sort_order": 10,
    },
    {
        "slug": "professional",
        "name": "Professional",
        "tagline": "Limusina para grupos y eventos corporativos",
        "description": "Limusina de 8 pasajeros para eventos, giras de clientes y celebraciones.",
        "passenger_capacity": 8,
        "luggage_capacity": 4,
        "features": [
            "Limusina de 8 pasajeros",
            "Bebidas sin alcohol",
            "Wi-Fi",
            "Música a elección",
        ],
        "base_fare": Decimal(25000),
        "hourly_rate": Decimal(55000),
        "min_hours": Decimal(3),
        "max_hours": Decimal(12),
        "sort_order": 20,
    },
    {
        "slug": "premium",
        "name": "Premium",
        "tagline": "Para las ocasiones que no se repiten",
        "description": "Limusina de gran lujo para matrimonios, aniversarios y gala.",
        "passenger_capacity": 10,
        "luggage_capacity": 4,
        "features": [
            "Limusina de gran lujo",
            "Champaña de cortesía",
            "Alfombra roja",
            "Decoración a pedido",
        ],
        "base_fare": Decimal(40000),
        "hourly_rate": Decimal(85000),
        "min_hours": Decimal(3),
        "max_hours": Decimal(10),
        "minimum_fare": Decimal(250000),
        "sort_order": 30,
    },
]

DEMO_RULES = [
    {
        "name": "Recargo nocturno",
        "description": "Recogidas entre las 22:00 y las 06:00.",
        "kind": "SURCHARGE",
        "adjustment_type": "PERCENT",
        "value": Decimal(20),
        "time_from": time(22),
        "time_until": time(6),
        "priority": 10,
    },
    {
        "name": "Recargo fin de semana",
        "description": "Recogidas el sábado o el domingo.",
        "kind": "SURCHARGE",
        "adjustment_type": "PERCENT",
        "value": Decimal(10),
        "days_of_week": [5, 6],
        "priority": 20,
    },
]


# (servicio, patente, marca, modelo, año, color, pasajeros)
DEMO_VEHICLES = [
    ("standard", "RTKL21", "Mercedes-Benz", "Clase E", 2023, "Negro", 4),
    ("standard", "RTKL22", "BMW", "Serie 5", 2023, "Gris", 4),
    ("professional", "SGHP35", "Lincoln", "Navigator L", 2022, "Negro", 8),
    ("premium", "TBWX48", "Cadillac", "Escalade ESV limusina", 2024, "Blanco", 10),
]


async def complete_demo_translations(db: AsyncSession) -> tuple[int, int]:
    """Agrega las traducciones de ejemplo que falten, sin pisar nada.

    Sólo si el texto en español sigue siendo el de ejemplo (si el equipo lo cambió, una
    traducción del texto original ya no corresponde) y sólo en los idiomas vacíos
    (lo que el equipo ya tradujo se respeta).
    """
    demo = {d["slug"]: d for d in DEMO_SERVICES}
    services = rules = 0
    for service in (await db.scalars(select(Service).where(Service.slug.in_(demo)))).all():
        base = demo[service.slug]
        unchanged = (service.tagline, service.description, service.features) == (
            base["tagline"],
            base["description"],
            base["features"],
        )
        if not unchanged:
            continue
        current = dict(service.translations or {})
        added = {k: v for k, v in SERVICE_TRANSLATIONS[service.slug].items() if not current.get(k)}
        if added:
            service.translations = {**current, **added}
            services += 1
    for rule in (
        await db.scalars(select(PricingRule).where(PricingRule.name.in_(RULE_TRANSLATIONS)))
    ).all():
        existing = dict(rule.translations or {})
        missing = {k: v for k, v in RULE_TRANSLATIONS[rule.name].items() if not existing.get(k)}
        if missing:
            rule.translations = {**existing, **missing}
            rules += 1
    return services, rules


async def seed_demo() -> None:
    """Carga servicios y reglas de ejemplo si todavía no hay ninguno; si ya existen,
    completa las traducciones de ejemplo que falten."""
    async with SessionLocal() as db:
        if await db.scalar(select(Service.id).limit(1)):
            completed_services, completed_rules = await complete_demo_translations(db)
            await db.commit()
            print(
                "Ya existen servicios: no se cargan datos de ejemplo. Traducciones completadas: "
                f"{completed_services} servicios y {completed_rules} reglas."
            )
        else:
            services = {
                data["slug"]: Service(**data, translations=SERVICE_TRANSLATIONS[str(data["slug"])])
                for data in DEMO_SERVICES
            }
            db.add_all(services.values())
            db.add_all(
                PricingRule(**data, translations=RULE_TRANSLATIONS[str(data["name"])])
                for data in DEMO_RULES
            )
            await db.flush()
            db.add_all(
                Vehicle(
                    service_id=services[slug].id, plate=plate, brand=brand, model=model,
                    year=year, color=color, passenger_capacity=capacity,
                )
                for slug, plate, brand, model, year, color, capacity in DEMO_VEHICLES
            )  # fmt: skip
            await db.commit()
            print(
                f"Cargados {len(DEMO_SERVICES)} servicios, {len(DEMO_VEHICLES)} vehículos y "
                f"{len(DEMO_RULES)} reglas de ejemplo. Revise precios y flota en Administración."
            )
    await engine.dispose()


def main() -> None:
    parser = argparse.ArgumentParser(prog="python -m app.cli")
    sub = parser.add_subparsers(dest="command", required=True)
    admin = sub.add_parser("create-admin", help="Crea (o promueve) un administrador general")
    admin.add_argument("--email", required=True)
    admin.add_argument("--first-name", default="Administrador")
    admin.add_argument("--last-name", default="General")
    sub.add_parser("seed-demo", help="Carga servicios y reglas de precio de ejemplo")
    args = parser.parse_args()

    if args.command == "create-admin":
        asyncio.run(create_admin(args.email, args.first_name, args.last_name))
    elif args.command == "seed-demo":
        asyncio.run(seed_demo())


if __name__ == "__main__":
    main()
