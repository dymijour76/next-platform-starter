"""Módulo reports (se implementa en fases posteriores)."""
