from datetime import date
from typing import Literal, Self

from pydantic import BaseModel, Field, model_validator

from app.core.money import Amount

Group = Literal["day", "week", "month"]
MAX_DAYS = {"day": 92, "week": 366, "month": 1100}


class RangeIn(BaseModel):
    date_from: date
    date_to: date
    group: Group = "day"

    @model_validator(mode="after")
    def _range(self) -> Self:
        if self.date_to < self.date_from:
            raise ValueError("La fecha final debe ser igual o posterior a la inicial.")
        days = (self.date_to - self.date_from).days + 1
        if days > MAX_DAYS[self.group]:
            unit = {"day": "por día", "week": "por semana", "month": "por mes"}[self.group]
            raise ValueError(
                f"Rango demasiado amplio para agrupar {unit}: máximo {MAX_DAYS[self.group]} días."
            )
        return self


class ReservationsRangeIn(RangeIn):
    # pickup: viajes realizados en el periodo; created: reservas hechas en el periodo.
    basis: Literal["pickup", "created"] = "pickup"


# ---- Reservas


class ReservationPoint(BaseModel):
    period: date
    label: str
    total: int
    confirmed: int  # confirmadas o en curso
    completed: int
    cancelled: int
    no_show: int
    expired: int
    pending: int


class ServiceBreakdown(BaseModel):
    service: str
    reservations: int
    completed: int
    cancelled: int
    amount: Amount  # suma de reservas no canceladas ni vencidas


class ReservationsReport(BaseModel):
    series: list[ReservationPoint]
    by_service: list[ServiceBreakdown]
    total: int
    completed: int
    cancelled: int
    cancellation_rate: float = Field(description="Canceladas / (total - pendientes - vencidas)")
    currency: str


# ---- Ingresos


class RevenuePoint(BaseModel):
    period: date
    label: str
    collected: Amount
    refunded: Amount
    net: Amount
    payments: int


class RevenueByService(BaseModel):
    service: str
    collected: Amount
    refunded: Amount
    net: Amount


class RevenueReport(BaseModel):
    series: list[RevenuePoint]
    by_service: list[RevenueByService]
    collected: Amount
    refunded: Amount
    net: Amount
    payments: int
    average_ticket: Amount
    currency: str


# ---- Panel


class TodayTrip(BaseModel):
    id: str
    code: str
    status: str
    pickup_at: str
    pickup_local: str
    service: str
    contact_name: str
    driver: str | None
    vehicle: str | None


class OperationsKpis(BaseModel):
    trips_today: int
    in_progress: int
    next_7_days: int
    pending_payment: int
    unassigned_upcoming: int
    today: list[TodayTrip]


class FinanceKpis(BaseModel):
    month_net: Amount
    month_collected: Amount
    month_refunded: Amount
    month_payments: int
    average_ticket: Amount
    previous_net: Amount
    change: float | None  # variación del neto vs. el mismo tramo del mes anterior
    failed_refunds: int


class FleetKpis(BaseModel):
    active_vehicles: int
    in_maintenance: int


class DriverKpis(BaseModel):
    active: int


class Alert(BaseModel):
    kind: Literal["unassigned", "failed_refunds", "no_vehicles", "license"]
    count: int
    text: str
    href: str


class Dashboard(BaseModel):
    currency: str
    today: str
    alerts: list[Alert]
    operations: OperationsKpis | None = None
    finance: FinanceKpis | None = None
    fleet: FleetKpis | None = None
    drivers: DriverKpis | None = None
