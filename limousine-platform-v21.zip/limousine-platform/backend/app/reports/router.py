"""Panel (/admin/dashboard) y reportes (/admin/reports/*), con exportación CSV."""

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi.responses import Response

from app.auth.deps import DB, require
from app.reports import service
from app.reports.schemas import (
    Dashboard,
    RangeIn,
    ReservationsRangeIn,
    ReservationsReport,
    RevenueReport,
)
from app.users.models import User

router = APIRouter(tags=["reports"])


@router.get("/admin/dashboard", response_model=Dashboard)
async def dashboard(user: Annotated[User, Depends(require("dashboard:view"))], db: DB) -> Dashboard:
    """Cada sección aparece sólo si el perfil tiene permiso sobre esa área."""
    return Dashboard.model_validate(await service.dashboard(db, user))


@router.get("/admin/reports/reservations", response_model=ReservationsReport)
async def reservations(
    _: Annotated[User, Depends(require("reports:read"))],
    db: DB,
    q: Annotated[ReservationsRangeIn, Query()],
) -> ReservationsReport:
    return await service.reservations_report(db, q)


@router.get("/admin/reports/revenue", response_model=RevenueReport)
async def revenue(
    _: Annotated[User, Depends(require("reports:financial"))],
    db: DB,
    q: Annotated[RangeIn, Query()],
) -> RevenueReport:
    return await service.revenue_report(db, q)


def _csv(content: str, name: str, q: RangeIn) -> Response:
    filename = f"{name}_{q.date_from:%Y%m%d}-{q.date_to:%Y%m%d}.csv"
    return Response(
        content.encode("utf-8"),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.get("/admin/reports/reservations.csv")
async def reservations_csv(
    _: Annotated[User, Depends(require("reports:read"))],
    db: DB,
    q: Annotated[ReservationsRangeIn, Query()],
) -> Response:
    return _csv(service.reservations_csv(await service.reservations_report(db, q)), "reservas", q)


@router.get("/admin/reports/revenue.csv")
async def revenue_csv(
    _: Annotated[User, Depends(require("reports:financial"))],
    db: DB,
    q: Annotated[RangeIn, Query()],
) -> Response:
    return _csv(service.revenue_csv(await service.revenue_report(db, q)), "ingresos", q)
