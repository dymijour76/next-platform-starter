"""Periodos del calendario en la zona horaria del negocio."""

from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

from app.core.i18n import get_locale

_MONTHS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]


def bounds(date_from: date, date_to: date, tz: str) -> tuple[datetime, datetime]:
    """[medianoche local del primer día, medianoche local del día siguiente al último)."""
    zone = ZoneInfo(tz)
    return (
        datetime.combine(date_from, time(0), tzinfo=zone),
        datetime.combine(date_to + timedelta(days=1), time(0), tzinfo=zone),
    )


def start_of(day: date, group: str) -> date:
    if group == "week":
        return day - timedelta(days=day.weekday())  # lunes, como date_trunc('week')
    if group == "month":
        return day.replace(day=1)
    return day


def periods(date_from: date, date_to: date, group: str) -> list[date]:
    """Todos los periodos del rango, también los que no tienen datos."""
    out, current = [], start_of(date_from, group)
    while current <= date_to:
        out.append(current)
        if group == "day":
            current += timedelta(days=1)
        elif group == "week":
            current += timedelta(weeks=1)
        else:
            current = (current.replace(day=28) + timedelta(days=4)).replace(day=1)
    return out


# Meses abreviados por idioma (los informes no dependen de librerías de idiomas).
_MONTHS_BY_LOCALE = {
    "es": ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"],
    "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    "fr": [
        "janv.",
        "févr.",
        "mars",
        "avr.",
        "mai",
        "juin",
        "juil.",
        "août",
        "sept.",
        "oct.",
        "nov.",
        "déc.",
    ],
    "ht": ["jan", "fev", "mas", "avr", "me", "jen", "jiy", "out", "sep", "okt", "nov", "des"],
}
_WEEK_PREFIX = {"es": "sem.", "en": "wk.", "fr": "sem.", "ht": "sem."}


def label(period: date, group: str, locale: str | None = None) -> str:
    """Etiqueta del periodo en el idioma pedido: "7 oct", "sem. 5 oct", "oct 2026"."""
    loc = locale or get_locale()
    if loc == "zh":  # 10月7日 · 10月5日当周 · 2026年10月
        if group == "month":
            return f"{period.year}年{period.month}月"
        if group == "week":
            return f"{period.month}月{period.day}日当周"
        return f"{period.month}月{period.day}日"
    months = _MONTHS_BY_LOCALE.get(loc, _MONTHS)
    month = months[period.month - 1]
    if group == "month":
        return f"{month} {period.year}"
    if loc == "en":  # "Oct 7", "wk. Oct 5"
        day = f"{month} {period.day}"
        return f"{_WEEK_PREFIX['en']} {day}" if group == "week" else day
    day = f"{period.day} {month}"
    return f"{_WEEK_PREFIX.get(loc, 'sem.')} {day}" if group == "week" else day
