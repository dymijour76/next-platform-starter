"""Indicadores del panel y reportes de reservas e ingresos.

Todas las agrupaciones por día, semana o mes se hacen en la zona horaria del
negocio (configuración de precios), nunca en UTC.
"""

import csv
import io
from collections import defaultdict
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import Date, and_, cast, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.i18n import get_locale, t
from app.core.translations import localized
from app.drivers.models import Driver, DriverStatus
from app.payments.models import Payment, PaymentStatus, Refund, RefundStatus
from app.reports import periods as P
from app.reports.schemas import (
    RangeIn,
    ReservationPoint,
    ReservationsRangeIn,
    ReservationsReport,
    RevenueByService,
    RevenuePoint,
    RevenueReport,
    ServiceBreakdown,
)
from app.reservations.models import ACTIVE_TRIP, Reservation, ReservationStatus
from app.services.models import Service
from app.settings.service import get_pricing_settings
from app.users.models import User
from app.vehicles.models import Vehicle, VehicleBlock, VehicleStatus

S = ReservationStatus
PAID = (PaymentStatus.AUTHORIZED, PaymentStatus.PARTIALLY_REFUNDED, PaymentStatus.REFUNDED)


def _bucket(column: Any, group: str, tz: str) -> Any:
    """Inicio del periodo (fecha local) de una marca de tiempo."""
    return cast(func.date_trunc(group, func.timezone(tz, column)), Date)


def _category(status: str) -> str:
    if status in ACTIVE_TRIP:
        return "confirmed"
    return {
        S.COMPLETED: "completed",
        S.CANCELLED: "cancelled",
        S.NO_SHOW: "no_show",
        S.EXPIRED: "expired",
        S.PENDING_PAYMENT: "pending",
    }[S(status)]


# ------------------------------------------------------------------ reservas


async def reservations_report(db: AsyncSession, q: ReservationsRangeIn) -> ReservationsReport:
    settings = await get_pricing_settings(db)
    tz = settings.timezone
    start, end = P.bounds(q.date_from, q.date_to, tz)
    column = Reservation.pickup_at if q.basis == "pickup" else Reservation.created_at
    bucket = _bucket(column, q.group, tz)

    rows = await db.execute(
        select(bucket, Reservation.status, func.count())
        .where(column >= start, column < end)
        .group_by(bucket, Reservation.status)
    )
    grid: dict[date, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for period, status, n in rows.all():
        grid[period][_category(status)] += n

    series = []
    for period in P.periods(q.date_from, q.date_to, q.group):
        counts = grid.get(period, {})
        series.append(
            ReservationPoint(
                period=period,
                label=P.label(period, q.group),
                total=sum(counts.values()),
                **{
                    k: counts.get(k, 0)
                    for k in (
                        "confirmed",
                        "completed",
                        "cancelled",
                        "no_show",
                        "expired",
                        "pending",
                    )
                },
            )
        )

    counted = Reservation.status.notin_([S.CANCELLED, S.EXPIRED])
    service_rows = await db.execute(
        select(
            Service.name,
            func.count(),
            func.count().filter(Reservation.status == S.COMPLETED),
            func.count().filter(Reservation.status == S.CANCELLED),
            func.coalesce(func.sum(Reservation.total_amount).filter(counted), 0),
        )
        .join(Service, Service.id == Reservation.service_id)
        .where(column >= start, column < end)
        .group_by(Service.name)
        .order_by(func.count().desc())
    )
    by_service = [
        ServiceBreakdown(service=name, reservations=n, completed=c, cancelled=x, amount=Decimal(a))
        for name, n, c, x, a in service_rows.all()
    ]

    total = sum(p.total for p in series)
    cancelled = sum(p.cancelled for p in series)
    base = total - sum(p.pending for p in series) - sum(p.expired for p in series)
    return ReservationsReport(
        series=series,
        by_service=by_service,
        total=total,
        completed=sum(p.completed for p in series),
        cancelled=cancelled,
        cancellation_rate=round(cancelled / base, 4) if base else 0.0,
        currency=settings.currency,
    )


# ------------------------------------------------------------------ ingresos


async def revenue_report(db: AsyncSession, q: RangeIn) -> RevenueReport:
    """Criterio de caja: cobros por fecha de autorización, reembolsos por fecha de reembolso."""
    settings = await get_pricing_settings(db)
    tz = settings.timezone
    start, end = P.bounds(q.date_from, q.date_to, tz)

    pay_bucket = _bucket(Payment.authorized_at, q.group, tz)
    pay_rows = await db.execute(
        select(pay_bucket, func.sum(Payment.amount), func.count())
        .where(
            Payment.status.in_(PAID),
            Payment.authorized_at >= start,
            Payment.authorized_at < end,
            # Ventas: pagos de reservas (con tarjeta o con saldo). Las recargas de billetera no
            # son ventas: es saldo que la empresa le debe al cliente hasta que lo use.
            Payment.reservation_id.is_not(None),
        )
        .group_by(pay_bucket)
    )
    collected = {p: (Decimal(a), n) for p, a, n in pay_rows.all()}

    ref_bucket = _bucket(Refund.created_at, q.group, tz)
    ref_rows = await db.execute(
        select(ref_bucket, func.sum(Refund.amount))
        .join(Payment, Payment.id == Refund.payment_id)
        .where(
            Payment.reservation_id.is_not(None),  # sin devoluciones de recargas
            Refund.status == RefundStatus.SUCCEEDED,
            Refund.created_at >= start,
            Refund.created_at < end,
        )
        .group_by(ref_bucket)
    )
    refunded = {p: Decimal(a) for p, a in ref_rows.all()}

    series = []
    for period in P.periods(q.date_from, q.date_to, q.group):
        c, n = collected.get(period, (Decimal(0), 0))
        r = refunded.get(period, Decimal(0))
        series.append(
            RevenuePoint(
                period=period,
                label=P.label(period, q.group),
                collected=c,
                refunded=r,
                net=c - r,
                payments=n,
            )
        )

    # Por servicio
    svc_paid = await db.execute(
        select(Service.name, func.sum(Payment.amount))
        .join(Reservation, Reservation.id == Payment.reservation_id)
        .join(Service, Service.id == Reservation.service_id)
        .where(
            Payment.status.in_(PAID), Payment.authorized_at >= start, Payment.authorized_at < end
        )
        .group_by(Service.name)
    )
    svc_ref = await db.execute(
        select(Service.name, func.sum(Refund.amount))
        .join(Payment, Payment.id == Refund.payment_id)
        .join(Reservation, Reservation.id == Payment.reservation_id)
        .join(Service, Service.id == Reservation.service_id)
        .where(
            Refund.status == RefundStatus.SUCCEEDED,
            Refund.created_at >= start,
            Refund.created_at < end,
        )
        .group_by(Service.name)
    )
    paid_by = {n: Decimal(a) for n, a in svc_paid.all()}
    ref_by = {n: Decimal(a) for n, a in svc_ref.all()}
    by_service = sorted(
        (
            RevenueByService(
                service=n,
                collected=paid_by.get(n, Decimal(0)),
                refunded=ref_by.get(n, Decimal(0)),
                net=paid_by.get(n, Decimal(0)) - ref_by.get(n, Decimal(0)),
            )
            for n in set(paid_by) | set(ref_by)
        ),
        key=lambda x: x.net,
        reverse=True,
    )

    total_c = sum((p.collected for p in series), Decimal(0))
    total_r = sum((p.refunded for p in series), Decimal(0))
    count = sum(p.payments for p in series)
    return RevenueReport(
        series=series,
        by_service=by_service,
        collected=total_c,
        refunded=total_r,
        net=total_c - total_r,
        payments=count,
        average_ticket=(total_c / count).quantize(Decimal(1)) if count else Decimal(0),
        currency=settings.currency,
    )


# ------------------------------------------------------------------ CSV


# Excel en inglés y en chino espera «,» como separador y punto decimal; en español,
# francés y creole, «;» y coma decimal. Si no coincide, todo queda en una columna.
_DOT_DECIMAL = {"en", "zh"}


def _cell(value: Any, decimal: str = ",") -> Any:
    """Decimales sin ceros sobrantes: 50000.00 → 50000; 0.25 → 0,25 (o 0.25)."""
    if isinstance(value, Decimal):
        return format(value.normalize(), "f").replace(".", decimal)
    if isinstance(value, float):
        return str(value).replace(".", decimal)
    return value


def to_csv(header: list[str], rows: list[list[Any]], locale: str | None = None) -> str:
    """CSV para Excel en el idioma de la persona: BOM UTF-8, montos sin separador de miles,
    encabezados traducidos y separador y decimales que ese Excel entiende."""
    loc = locale or get_locale()
    dot = loc in _DOT_DECIMAL
    buf = io.StringIO()
    writer = csv.writer(buf, delimiter="," if dot else ";", lineterminator="\r\n")
    writer.writerow([t(h, loc) for h in header])
    for row in rows:
        writer.writerow([_cell(v, "." if dot else ",") for v in row])
    return "\ufeff" + buf.getvalue()


def reservations_csv(r: ReservationsReport) -> str:
    return to_csv(
        [
            "Periodo",
            "Total",
            "Confirmadas o en curso",
            "Completadas",
            "Canceladas",
            "No se presentó",
            "Vencidas",
            "Pendientes de pago",
        ],
        [
            [
                p.period.isoformat(),
                p.total,
                p.confirmed,
                p.completed,
                p.cancelled,
                p.no_show,
                p.expired,
                p.pending,
            ]
            for p in r.series
        ],
    )


def revenue_csv(r: RevenueReport) -> str:
    return to_csv(
        ["Periodo", "Cobrado", "Reembolsado", "Neto", "Pagos"],
        [[p.period.isoformat(), p.collected, p.refunded, p.net, p.payments] for p in r.series],
    )


# ------------------------------------------------------------------ panel


async def dashboard(db: AsyncSession, user: User) -> dict[str, Any]:
    """Indicadores según los permisos de quien consulta."""
    perms = user.permission_codes
    settings = await get_pricing_settings(db)
    tz = ZoneInfo(settings.timezone)
    now = datetime.now(UTC)
    today = now.astimezone(tz).date()
    day_start, day_end = P.bounds(today, today, settings.timezone)
    out: dict[str, Any] = {"currency": settings.currency, "today": today.isoformat(), "alerts": []}
    alerts: list[dict[str, Any]] = out["alerts"]

    if "reservations:read" in perms:

        async def count(*conds: Any) -> int:
            return await db.scalar(select(func.count()).select_from(Reservation).where(*conds)) or 0

        active = Reservation.status.in_(ACTIVE_TRIP)
        unassigned = and_(
            Reservation.status == S.CONFIRMED,
            (Reservation.vehicle_id.is_(None)) | (Reservation.driver_id.is_(None)),
        )
        today_rows = await db.scalars(
            select(Reservation)
            .where(
                Reservation.pickup_at >= day_start,
                Reservation.pickup_at < day_end,
                Reservation.status.in_([*ACTIVE_TRIP, S.COMPLETED, S.NO_SHOW]),
            )
            .order_by(Reservation.pickup_at)
        )
        out["operations"] = {
            "trips_today": await count(
                Reservation.pickup_at >= day_start, Reservation.pickup_at < day_end, active
            ),
            "in_progress": await count(
                Reservation.status.in_([S.EN_ROUTE, S.ARRIVED, S.IN_PROGRESS])
            ),
            "next_7_days": await count(
                Reservation.pickup_at >= now,
                Reservation.pickup_at < now + timedelta(days=7),
                active,
            ),
            "pending_payment": await count(
                Reservation.status == S.PENDING_PAYMENT, Reservation.hold_expires_at > now
            ),
            "unassigned_upcoming": await count(unassigned, Reservation.pickup_at >= now),
            "today": [
                {
                    "id": str(r.id),
                    "code": r.code,
                    "status": r.status,
                    "pickup_at": r.pickup_at.isoformat(),
                    "pickup_local": str(r.pricing_snapshot.get("pickup_local", "")),
                    "service": localized(r.service.translations, "name", r.service.name),
                    "contact_name": r.contact_name,
                    "driver": r.driver.name if r.driver else None,
                    "vehicle": r.vehicle.plate if r.vehicle else None,
                }
                for r in today_rows.unique()
            ],
        }
        urgent = await count(
            unassigned,
            Reservation.pickup_at >= now,
            Reservation.pickup_at < now + timedelta(hours=48),
        )
        if urgent:
            alerts.append(
                {
                    "kind": "unassigned",
                    "count": urgent,
                    "href": "/admin/reservations?unassigned=true",
                    "text": t(
                        "1 viaje de las próximas 48 horas sin vehículo o conductor"
                        if urgent == 1
                        else "{count} viajes de las próximas 48 horas sin vehículo o conductor",
                        count=urgent,
                    ),
                }
            )

    if "payments:read" in perms:
        month_start = today.replace(day=1)
        prev_start = (month_start - timedelta(days=1)).replace(day=1)
        current = await revenue_report(
            db, RangeIn(date_from=month_start, date_to=today, group="month")
        )
        # Mismo tramo del mes anterior (del 1 al mismo día), para comparar parejo.
        prev_end = min(prev_start + timedelta(days=today.day - 1), month_start - timedelta(days=1))
        previous = await revenue_report(
            db, RangeIn(date_from=prev_start, date_to=prev_end, group="month")
        )
        failed = (
            await db.scalar(
                select(func.count()).select_from(Refund).where(Refund.status == RefundStatus.FAILED)
            )
            or 0
        )
        out["finance"] = {
            "month_net": current.net,
            "month_collected": current.collected,
            "month_refunded": current.refunded,
            "month_payments": current.payments,
            "average_ticket": current.average_ticket,
            "previous_net": previous.net,
            "change": float(round((current.net - previous.net) / previous.net, 4))
            if previous.net
            else None,
            "failed_refunds": failed,
        }
        if failed:
            alerts.append(
                {
                    "kind": "failed_refunds",
                    "count": failed,
                    "href": "/admin/payments?status=AUTHORIZED",
                    "text": t(
                        "1 reembolso fallido por reintentar"
                        if failed == 1
                        else "{count} reembolsos fallidos por reintentar",
                        count=failed,
                    ),
                }
            )

    if "vehicles:read" in perms:
        vehicles = (
            await db.scalar(select(func.count()).where(Vehicle.status == VehicleStatus.ACTIVE)) or 0
        )
        in_maintenance = (
            await db.scalar(
                select(func.count(func.distinct(VehicleBlock.vehicle_id))).where(
                    VehicleBlock.starts_at < now, VehicleBlock.ends_at > now
                )
            )
            or 0
        )
        no_vehicles = list(
            await db.scalars(
                select(Service.name).where(
                    Service.is_active.is_(True),
                    ~select(Vehicle.id)
                    .where(Vehicle.service_id == Service.id, Vehicle.status == VehicleStatus.ACTIVE)
                    .exists(),
                )
            )
        )
        out["fleet"] = {"active_vehicles": vehicles, "in_maintenance": in_maintenance}
        for name in no_vehicles:
            alerts.append(
                {
                    "kind": "no_vehicles",
                    "count": 1,
                    "href": "/admin/vehicles/new",
                    "text": t(
                        "El servicio {name} no tiene vehículos: no se puede reservar", name=name
                    ),
                }
            )

    if "drivers:read" in perms:
        soon = today + timedelta(days=30)
        expiring = list(
            (
                await db.scalars(
                    select(Driver)
                    .where(Driver.status == DriverStatus.ACTIVE, Driver.license_expires_on <= soon)
                    .order_by(Driver.license_expires_on)
                )
            ).unique()
        )
        out["drivers"] = {
            "active": await db.scalar(
                select(func.count()).where(Driver.status == DriverStatus.ACTIVE)
            )
            or 0
        }
        for d in expiring:
            alerts.append(
                {
                    "kind": "license",
                    "count": 1,
                    "href": f"/admin/drivers/{d.id}",
                    "text": t(
                        "La licencia de {name} venció el {date}"
                        if d.license_expires_on < today
                        else "La licencia de {name} vence el {date}",
                        name=d.name,
                        date=f"{d.license_expires_on:%d-%m-%Y}",
                    ),
                }
            )
    return out
