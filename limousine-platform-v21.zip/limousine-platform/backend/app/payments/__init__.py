"""Módulo payments (se implementa en fases posteriores)."""
