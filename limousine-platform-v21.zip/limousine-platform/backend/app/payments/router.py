"""Pagos: inicio (/reservations/{code}/pay), retorno de la pasarela y administración."""

import uuid
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Annotated, Literal
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select

from app.audit.service import record
from app.auth.deps import DB, CurrentUser, RedisDep, require
from app.auth.router import Mailer, Meta
from app.core.config import get_settings
from app.core.errors import NotFound
from app.core.money import Amount
from app.core.pagination import Page, PageParams, page_params
from app.core.rate_limit import client_ip, hit
from app.payments import service
from app.payments.models import Payment, PaymentStatus
from app.payments.providers.simulated import SimulatedProvider
from app.reservations import service as reservations
from app.reservations.models import Reservation
from app.reservations.schemas import RefundOut
from app.settings.service import get_pricing_settings
from app.users.models import User
from app.wallet.models import Wallet

router = APIRouter(tags=["payments"])


class RedirectOut(BaseModel):
    """El frontend envía al cliente con un formulario POST a `url` con estos campos."""

    url: str
    fields: dict[str, str]


@router.post("/reservations/{code}/pay", response_model=RedirectOut)
async def pay(code: str, user: CurrentUser, db: DB, redis: RedisDep) -> RedirectOut:
    await hit(redis, "pay", str(user.id), limit=10, window_seconds=600)
    redirect = await service.start(db, service.get_provider(redis), user, code)
    return RedirectOut(url=redirect.url, fields=redirect.fields)


class ReturnIn(BaseModel):
    """Parámetros con que vuelve el cliente desde la pasarela (nombres de Webpay)."""

    token_ws: str | None = Field(default=None, max_length=100)
    TBK_TOKEN: str | None = Field(default=None, max_length=100)
    TBK_ORDEN_COMPRA: str | None = Field(default=None, max_length=26)
    TBK_ID_SESION: str | None = Field(default=None, max_length=61)


class ReturnOut(BaseModel):
    reservation_code: str | None
    outcome: Literal["paid", "rejected", "aborted", "error", "refunded_unavailable"]
    topup: bool = False  # recarga de saldo: el sitio vuelve a la billetera


@router.post("/payments/return", response_model=ReturnOut)
async def payment_return(
    data: ReturnIn, request: Request, db: DB, redis: RedisDep, mailer: Mailer
) -> ReturnOut:
    """Sin sesión: el token de la pasarela es la credencial y se verifica con el proveedor."""
    await hit(redis, "payment-return", client_ip(request), limit=60, window_seconds=600)
    result = await service.handle_return(
        db,
        service.get_provider(redis),
        service.ReturnParams(
            token_ws=data.token_ws, tbk_token=data.TBK_TOKEN, tbk_buy_order=data.TBK_ORDEN_COMPRA
        ),
        mailer,
    )
    if result.outcome == "refunded_unavailable" and result.reservation_code:
        r = await db.scalar(select(Reservation).where(Reservation.code == result.reservation_code))
        if r is not None:
            await reservations.notify(db, r, "unavailable_refunded", mailer)
    return ReturnOut(
        reservation_code=result.reservation_code, outcome=result.outcome, topup=result.topup
    )


# ------------------------------------------------------------------ simulador (sólo desarrollo)


class SimulatorOut(BaseModel):
    amount: Amount
    buy_order: str


class DecisionIn(BaseModel):
    decision: Literal["approve", "reject", "abort"]


def _simulator(redis: RedisDep) -> SimulatedProvider:
    if get_settings().payment_provider != "simulated":
        raise NotFound()
    provider = service.get_provider(redis)
    assert isinstance(provider, SimulatedProvider)
    return provider


@router.get("/payments/simulator/{token}", response_model=SimulatorOut)
async def simulator_details(token: str, redis: RedisDep) -> SimulatorOut:
    data = await _simulator(redis).details(token)
    if data is None:
        raise NotFound("El pago simulado no existe o venció.")
    return SimulatorOut(amount=Decimal(data["amount"]), buy_order=data["buy_order"])


@router.post("/payments/simulator/{token}", response_model=RedirectOut)
async def simulator_decide(token: str, data: DecisionIn, redis: RedisDep) -> RedirectOut:
    """Registra la decisión y devuelve el formulario de retorno, igual que haría Webpay."""
    info = await _simulator(redis).decide(token, data.decision)
    if info is None:
        raise NotFound("El pago simulado no existe o venció.")
    fields = (
        {"TBK_TOKEN": token, "TBK_ORDEN_COMPRA": info["buy_order"]}
        if data.decision == "abort"
        else {"token_ws": token}
    )
    return RedirectOut(url=info["return_url"], fields=fields)


# ------------------------------------------------------------------ administración


class AdminPaymentOut(BaseModel):
    id: uuid.UUID
    reservation_id: uuid.UUID | None  # None: recarga de billetera
    reservation_code: str | None
    customer_name: str
    is_topup: bool = False
    provider: str
    status: PaymentStatus
    amount: Amount
    refunded_amount: Amount
    currency: str
    buy_order: str
    card_last4: str | None
    authorization_code: str | None
    response_code: str | None
    authorized_at: datetime | None
    created_at: datetime
    refunds: list[RefundOut]


class PaymentTotals(BaseModel):
    collected: Amount
    refunded: Amount
    net: Amount
    count: int


class PaymentPage(Page[AdminPaymentOut]):
    totals: PaymentTotals


class PaymentFilters(BaseModel):
    status: PaymentStatus | None = None
    date_from: date | None = None
    date_to: date | None = None
    q: str | None = Field(default=None, max_length=50)


def _refund_out(f: object) -> RefundOut:
    return RefundOut.model_validate(f, from_attributes=True)


@router.get("/admin/payments", response_model=PaymentPage)
async def list_payments(
    _: Annotated[User, Depends(require("payments:read"))],
    db: DB,
    params: Annotated[PageParams, Depends(page_params)],
    f: Annotated[PaymentFilters, Query()],
) -> PaymentPage:
    tz = ZoneInfo((await get_pricing_settings(db)).timezone)
    # Pagos de reservas y recargas de billetera (sin reserva: se muestra el titular).
    # Sólo las columnas necesarias de la reserva y del titular: la reserva completa trae sus
    # relaciones con JOIN obligatorio (servicio), que descartaría las recargas (sin reserva).
    query = (
        select(
            Payment,
            Reservation.id.label("res_id"),
            Reservation.code,
            Reservation.contact_name,
            User.first_name,
            User.last_name,
        )
        .outerjoin(Reservation, Reservation.id == Payment.reservation_id)
        .outerjoin(Wallet, Wallet.id == Payment.wallet_id)
        .outerjoin(User, User.id == Wallet.user_id)
    )
    # Por defecto no se listan los intentos abandonados: no mueven dinero.
    if f.status:
        query = query.where(Payment.status == f.status)
    else:
        hidden = [PaymentStatus.CREATED, PaymentStatus.ABORTED, PaymentStatus.EXPIRED]
        query = query.where(Payment.status.notin_(hidden))
    if f.date_from:
        query = query.where(Payment.created_at >= datetime.combine(f.date_from, time(0), tzinfo=tz))
    if f.date_to:
        end = datetime.combine(f.date_to + timedelta(days=1), time(0), tzinfo=tz)
        query = query.where(Payment.created_at < end)
    if f.q:
        pattern = f"%{f.q.strip()}%"
        query = query.where(
            Reservation.code.ilike(pattern)
            | Payment.buy_order.ilike(pattern)
            | Payment.authorization_code.ilike(pattern)
        )

    sub = query.subquery()
    count = await db.scalar(select(func.count()).select_from(sub)) or 0
    paid_states = [
        PaymentStatus.AUTHORIZED,
        PaymentStatus.PARTIALLY_REFUNDED,
        PaymentStatus.REFUNDED,
    ]
    # Cobrado y reembolsado: dinero que pasó por la pasarela. Un pago con saldo no suma: ese
    # dinero ya entró al recargarse (o nunca entró, si fue un crédito de la empresa).
    gateway = sub.c.provider != service.WALLET
    collected = await db.scalar(
        select(func.coalesce(func.sum(sub.c.amount), 0)).where(
            sub.c.status.in_(paid_states), gateway
        )
    ) or Decimal(0)
    refunded = await db.scalar(
        select(func.coalesce(func.sum(sub.c.refunded_amount), 0)).where(gateway)
    ) or Decimal(0)

    rows = (
        await db.execute(
            query.order_by(Payment.created_at.desc()).offset(params.offset).limit(params.page_size)
        )
    ).all()
    items = [
        AdminPaymentOut(
            id=p.id,
            reservation_id=rid,
            reservation_code=code,
            customer_name=contact or (f"{first} {last}" if first else "—"),
            is_topup=p.wallet_id is not None,
            provider=p.provider,
            status=PaymentStatus(p.status),
            amount=p.amount,
            refunded_amount=p.refunded_amount,
            currency=p.currency,
            buy_order=p.buy_order,
            card_last4=p.card_last4,
            authorization_code=p.authorization_code,
            response_code=p.response_code,
            authorized_at=p.authorized_at,
            created_at=p.created_at,
            refunds=[_refund_out(x) for x in p.refunds],
        )
        for p, rid, code, contact, first, last in rows
    ]
    return PaymentPage(
        items=items,
        total=count,
        page=params.page,
        page_size=params.page_size,
        totals=PaymentTotals(
            collected=collected, refunded=refunded, net=collected - refunded, count=count
        ),
    )


class RefundIn(BaseModel):
    amount: Decimal = Field(gt=0, decimal_places=2)
    reason: str = Field(min_length=3, max_length=500)


@router.post("/admin/payments/{payment_id}/refund", response_model=RefundOut)
async def refund_payment(
    payment_id: uuid.UUID,
    data: RefundIn,
    actor: Annotated[User, Depends(require("payments:refund"))],
    db: DB,
    redis: RedisDep,
    meta: Meta,
) -> RefundOut:
    """Reembolso manual, total o parcial (p. ej. compensación por un inconveniente)."""
    refund = await service.manual_refund(
        db, service.get_provider(redis), payment_id, data.amount, data.reason, actor
    )
    record(
        db, actor_id=actor.id, action="REFUND_CREATE", entity_type="payment", entity_id=payment_id,
        meta=meta,
        after={"amount": str(data.amount), "reason": data.reason, "status": refund.status},
    )  # fmt: skip
    await db.commit()
    return _refund_out(refund)


@router.post("/admin/refunds/{refund_id}/retry", response_model=RefundOut)
async def retry_refund(
    refund_id: uuid.UUID,
    actor: Annotated[User, Depends(require("payments:refund"))],
    db: DB,
    redis: RedisDep,
    meta: Meta,
) -> RefundOut:
    refund = await service.retry_refund(db, service.get_provider(redis), refund_id)
    record(
        db, actor_id=actor.id, action="REFUND_RETRY", entity_type="refund", entity_id=refund_id,
        meta=meta, after={"status": refund.status},
    )  # fmt: skip
    await db.commit()
    return _refund_out(refund)
