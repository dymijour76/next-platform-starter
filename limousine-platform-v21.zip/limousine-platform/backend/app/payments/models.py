"""Pagos y reembolsos.

Nunca se guardan datos de tarjeta: sólo los últimos 4 dígitos que informa el
proveedor, el código de autorización y la respuesta (sin datos sensibles).
"""

import enum
import uuid
from datetime import datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import CheckConstraint, DateTime, ForeignKey, Index, Numeric, SmallInteger, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPrimaryKeyMixin


class PaymentStatus(enum.StrEnum):
    CREATED = "CREATED"  # el cliente fue enviado a la pasarela
    AUTHORIZED = "AUTHORIZED"  # pago aprobado y confirmado con el proveedor
    REJECTED = "REJECTED"  # rechazado por el banco o el proveedor
    ABORTED = "ABORTED"  # el cliente abandonó la pasarela
    EXPIRED = "EXPIRED"  # nunca volvió de la pasarela
    ERROR = "ERROR"  # respuesta inválida o inconsistente
    REFUNDED = "REFUNDED"
    PARTIALLY_REFUNDED = "PARTIALLY_REFUNDED"


class RefundStatus(enum.StrEnum):
    PENDING = "PENDING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


def _values(e: type[enum.StrEnum]) -> str:
    return ", ".join(f"'{v.value}'" for v in e)


class Payment(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "payments"
    __table_args__ = (
        CheckConstraint(f"status IN ({_values(PaymentStatus)})", name="status_valid"),
        CheckConstraint("amount > 0", name="amount_positive"),
        CheckConstraint("refunded_amount >= 0 AND refunded_amount <= amount", name="refund_valid"),
        # Un pago es de una reserva o una recarga de billetera: exactamente uno de los dos.
        CheckConstraint("(reservation_id IS NULL) <> (wallet_id IS NULL)", name="one_target"),
        Index("ix_payments_status_created", "status", "created_at"),
    )

    reservation_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("reservations.id", ondelete="RESTRICT"), index=True
    )
    wallet_id: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("wallets.id", ondelete="RESTRICT"), index=True
    )
    provider: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[str] = mapped_column(String(24), nullable=False)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False)
    refunded_amount: Mapped[Decimal] = mapped_column(
        Numeric(14, 2), nullable=False, server_default="0"
    )
    # Orden de compra única que se envía al proveedor (Webpay: máx. 26 caracteres).
    buy_order: Mapped[str] = mapped_column(String(26), unique=True, nullable=False)
    session_id: Mapped[str] = mapped_column(String(61), nullable=False)
    # Token del proveedor: con él vuelve el cliente desde la pasarela.
    provider_token: Mapped[str | None] = mapped_column(String(100), unique=True)
    authorization_code: Mapped[str | None] = mapped_column(String(20))
    card_last4: Mapped[str | None] = mapped_column(String(4))
    payment_type: Mapped[str | None] = mapped_column(String(10))
    installments: Mapped[int | None] = mapped_column(SmallInteger)
    response_code: Mapped[str | None] = mapped_column(String(10))
    provider_response: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    authorized_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

    refunds: Mapped[list["Refund"]] = relationship(
        back_populates="payment", lazy="selectin", order_by="Refund.created_at"
    )


class Refund(UUIDPrimaryKeyMixin, TimestampMixin, Base):
    __tablename__ = "refunds"
    __table_args__ = (
        CheckConstraint(f"status IN ({_values(RefundStatus)})", name="status_valid"),
        CheckConstraint("amount > 0", name="amount_positive"),
    )

    payment_id: Mapped[uuid.UUID] = mapped_column(
        ForeignKey("payments.id", ondelete="RESTRICT"), nullable=False, index=True
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2), nullable=False)
    status: Mapped[str] = mapped_column(String(16), nullable=False)
    reason: Mapped[str | None] = mapped_column(String(500))
    provider_reference: Mapped[str | None] = mapped_column(String(50))
    provider_response: Mapped[dict[str, Any] | None] = mapped_column(JSONB)
    error_message: Mapped[str | None] = mapped_column(String(500))
    requested_by: Mapped[uuid.UUID | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL")
    )

    payment: Mapped[Payment] = relationship(back_populates="refunds")
