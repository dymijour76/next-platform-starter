"""Pagos: inicio, retorno desde la pasarela, confirmación de la reserva y reembolsos."""

import logging
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Literal

from fastapi import status
from redis.asyncio import Redis
from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import get_settings
from app.core.errors import AppError, Conflict, NotFound
from app.payments.models import Payment, PaymentStatus, Refund, RefundStatus
from app.payments.providers.base import PaymentProvider, ProviderError, Redirect
from app.payments.providers.simulated import SimulatedProvider
from app.payments.providers.webpay import WebpayProvider
from app.reservations import service as reservations
from app.reservations.models import Reservation, ReservationEvent, ReservationStatus
from app.users.models import User
from app.wallet import models as WE
from app.wallet import service as wallet
from app.wallet.models import Wallet

logger = logging.getLogger("app.payments")

P = PaymentStatus
R = ReservationStatus
Outcome = Literal["paid", "rejected", "aborted", "error", "refunded_unavailable"]


class PaymentUnavailable(AppError):
    status_code = status.HTTP_502_BAD_GATEWAY
    code = "PAYMENT_PROVIDER_ERROR"
    message = "No pudimos conectar con la pasarela de pago. Inténtelo de nuevo en unos minutos."


WALLET = "wallet"  # medio de pago: saldo de la billetera


def get_provider(redis: Redis) -> PaymentProvider:
    s = get_settings()
    if s.payment_provider == "webpay":
        return WebpayProvider(s.webpay_commerce_code, s.webpay_api_key, s.webpay_environment)
    return SimulatedProvider(redis, s.frontend_url)


def return_url() -> str:
    return f"{get_settings().frontend_url.rstrip('/')}/payments/return"


def _now() -> datetime:
    return datetime.now(UTC)


# ------------------------------------------------------------------ inicio


async def _payable(db: AsyncSession, user: User, code: str) -> Reservation:
    """La reserva propia, bloqueada, pendiente de pago y con cupo (aunque el retenido venciera)."""
    r = await reservations.get_own(db, user, code)
    r = await reservations._get_locked(db, r.id)
    if r.status != R.PENDING_PAYMENT:
        raise Conflict("Esta reserva no tiene un pago pendiente.", code="NOT_PAYABLE")
    now = _now()
    # Si el cupo retenido venció pero el horario sigue libre, se puede pagar igual.
    if r.hold_expires_at is None or r.hold_expires_at <= now:
        await reservations._lock_service(db, r.service_id)
        if not await reservations.has_capacity(
            db, r.service_id, r.pickup_at, r.blocks_until, exclude=r.id
        ):
            raise reservations.SlotUnavailable(
                "El cupo retenido venció y el horario ya no está disponible. "
                "Haga una nueva reserva."
            )
    return r


async def _next_buy_order(db: AsyncSession, r: Reservation) -> str:
    """Sólo el último intento cuenta: los anteriores sin terminar se dan por abandonados."""
    await db.execute(
        update(Payment)
        .where(Payment.reservation_id == r.id, Payment.status == P.CREATED)
        .values(status=P.ABORTED)
    )
    attempt = (await db.scalar(select(func.count()).where(Payment.reservation_id == r.id)) or 0) + 1
    return f"{r.code}-{attempt}"


async def start(db: AsyncSession, provider: PaymentProvider, user: User, code: str) -> Redirect:
    r = await _payable(db, user, code)
    now = _now()
    buy_order = await _next_buy_order(db, r)
    try:
        started = await provider.start(
            buy_order=buy_order,
            session_id=str(user.id),
            amount=r.total_amount,
            return_url=return_url(),
        )
    except ProviderError as exc:
        logger.error("No se pudo iniciar el pago de %s: %s", r.code, exc)
        raise PaymentUnavailable() from exc

    window = timedelta(minutes=get_settings().payment_window_minutes)
    db.add(
        Payment(
            reservation_id=r.id,
            provider=provider.name,
            status=P.CREATED,
            amount=r.total_amount,
            currency=r.currency,
            buy_order=buy_order,
            session_id=str(user.id),
            provider_token=started.token,
            expires_at=now + window,
        )
    )
    # El cupo se mantiene mientras el cliente está en la pasarela.
    r.hold_expires_at = max(r.hold_expires_at or now, now + window)
    await db.commit()
    return started.redirect


async def pay_with_wallet(db: AsyncSession, user: User, code: str) -> Reservation:
    """Paga la reserva completa con el saldo: descuento y confirmación en una sola transacción."""
    r = await _payable(db, user, code)
    now = _now()
    payment = Payment(
        reservation_id=r.id,
        provider=WALLET,
        status=P.AUTHORIZED,
        amount=r.total_amount,
        currency=r.currency,
        buy_order=await _next_buy_order(db, r),
        session_id=str(user.id),
        provider_token=f"wallet-{uuid.uuid4().hex}",
        authorization_code="SALDO",
        authorized_at=now,
        expires_at=now,
    )
    db.add(payment)
    await db.flush()
    await wallet.post(
        db,
        user.id,
        -r.total_amount,
        WE.PAYMENT,
        f"Pago de la reserva {r.code}",
        reservation_id=r.id,
        payment_id=payment.id,
    )
    if not await _confirm_reservation(db, payment):
        raise reservations.SlotUnavailable()  # nada se guarda: la transacción no se confirma
    await db.commit()
    await db.refresh(r)
    return r


async def start_topup(
    db: AsyncSession, provider: PaymentProvider, user: User, amount: Decimal
) -> Redirect:
    """Recarga de saldo por la pasarela (sólo si está habilitada)."""
    settings = get_settings()
    if not settings.wallet_topup_enabled:
        raise wallet.TopupDisabled()
    if not (settings.wallet_topup_min <= amount <= settings.wallet_topup_max):
        raise Conflict(
            "El monto de la recarga está fuera del rango permitido.",
            code="INVALID_AMOUNT",
            fields={"amount": "Monto fuera de rango."},
        )
    w = await wallet.get_or_create(db, user.id)
    await db.execute(
        update(Payment)
        .where(Payment.wallet_id == w.id, Payment.status == P.CREATED)
        .values(status=P.ABORTED)
    )
    buy_order = f"REC-{uuid.uuid4().hex[:20]}"
    try:
        started = await provider.start(
            buy_order=buy_order, session_id=str(user.id), amount=amount, return_url=return_url()
        )
    except ProviderError as exc:
        logger.error("No se pudo iniciar la recarga de %s: %s", user.id, exc)
        raise PaymentUnavailable() from exc
    now = _now()
    db.add(
        Payment(
            wallet_id=w.id,
            provider=provider.name,
            status=P.CREATED,
            amount=amount,
            currency=w.currency,
            buy_order=buy_order,
            session_id=str(user.id),
            provider_token=started.token,
            expires_at=now + timedelta(minutes=settings.payment_window_minutes),
        )
    )
    await db.commit()
    return started.redirect


# ------------------------------------------------------------------ retorno


@dataclass(frozen=True)
class ReturnParams:
    token_ws: str | None = None
    tbk_token: str | None = None
    tbk_buy_order: str | None = None


@dataclass(frozen=True)
class ReturnResult:
    reservation_code: str | None
    outcome: Outcome
    topup: bool = False  # recarga de saldo: el sitio vuelve a la billetera


_FINAL_OUTCOME: dict[str, Outcome] = {
    P.AUTHORIZED: "paid",
    P.REJECTED: "rejected",
    P.ABORTED: "aborted",
    P.EXPIRED: "aborted",
    P.ERROR: "error",
    P.REFUNDED: "refunded_unavailable",
    P.PARTIALLY_REFUNDED: "paid",
}


async def _code_of(db: AsyncSession, payment: Payment) -> str | None:
    if payment.reservation_id is None:
        return None
    return await db.scalar(select(Reservation.code).where(Reservation.id == payment.reservation_id))


async def handle_return(
    db: AsyncSession, provider: PaymentProvider, params: ReturnParams, mailer: object
) -> ReturnResult:
    """Procesa la vuelta del cliente desde la pasarela. Es idempotente."""
    # Abandono: el cliente anuló en la pasarela (TBK_TOKEN) o se agotó el tiempo (sólo orden).
    if params.tbk_token or (params.tbk_buy_order and not params.token_ws):
        query = select(Payment).with_for_update()
        query = (
            query.where(Payment.provider_token == params.tbk_token)
            if params.tbk_token
            else query.where(Payment.buy_order == params.tbk_buy_order)
        )
        payment = await db.scalar(query)
        if payment is None:
            return ReturnResult(None, "error")
        if payment.status == P.CREATED:
            payment.status = P.ABORTED
            await db.commit()
        return ReturnResult(
            await _code_of(db, payment),
            _FINAL_OUTCOME[payment.status],
            payment.wallet_id is not None,
        )

    if not params.token_ws:
        return ReturnResult(None, "error")

    payment = await db.scalar(
        select(Payment).where(Payment.provider_token == params.token_ws).with_for_update()
    )
    if payment is None:
        return ReturnResult(None, "error")
    code = await _code_of(db, payment)
    topup = payment.wallet_id is not None
    if payment.status != P.CREATED:
        # Segundo retorno (recarga, doble envío): se informa el resultado ya registrado.
        return ReturnResult(code, _FINAL_OUTCOME[payment.status], topup)

    try:
        result = await provider.commit(params.token_ws)
    except ProviderError as exc:
        logger.error("Error al confirmar el pago %s: %s", payment.buy_order, exc)
        payment.status = P.ERROR
        payment.provider_response = {"error": str(exc)}
        await db.commit()
        return ReturnResult(code, "error", topup)

    payment.provider_response = _safe(result.raw)
    payment.response_code = result.response_code
    consistent = result.buy_order == payment.buy_order and result.amount == payment.amount

    if not result.approved:
        payment.status = P.REJECTED
        await db.commit()
        return ReturnResult(code, "rejected", topup)

    payment.authorization_code = result.authorization_code
    payment.card_last4 = result.card_last4
    payment.payment_type = result.payment_type
    payment.installments = result.installments
    payment.authorized_at = _now()
    payment.status = P.AUTHORIZED

    if not consistent:
        # Monto u orden distintos a lo esperado: no se confirma y se devuelve el cargo.
        logger.error("Pago %s inconsistente con el proveedor: %s", payment.buy_order, result.raw)
        payment.status = P.ERROR
        await db.flush()
        await _refund(db, provider, payment, result.amount, "Pago inconsistente", None, force=True)
        await db.commit()
        return ReturnResult(code, "error", topup)

    if payment.wallet_id is not None:
        # Recarga aprobada: se abona a la billetera.
        owner = await db.scalar(select(Wallet.user_id).where(Wallet.id == payment.wallet_id))
        assert owner is not None
        description = (
            f"Recarga con tarjeta terminada en {payment.card_last4}"
            if payment.card_last4
            else "Recarga de saldo"
        )
        await wallet.post(db, owner, payment.amount, WE.TOPUP, description, payment_id=payment.id)
        await db.commit()
        return ReturnResult(None, "paid", topup=True)

    confirmed = await _confirm_reservation(db, payment)
    if not confirmed:
        await db.flush()
        await _refund(
            db,
            provider,
            payment,
            payment.amount,
            "El horario dejó de estar disponible mientras se pagaba",
            None,
        )
        await db.commit()
        return ReturnResult(code, "refunded_unavailable")

    await db.commit()
    r = await db.get(Reservation, payment.reservation_id)
    if r is not None:
        await db.refresh(r)
        await reservations.notify(db, r, "confirmed", mailer)
    return ReturnResult(code, "paid")


async def _confirm_reservation(db: AsyncSession, payment: Payment) -> bool:
    """Confirma la reserva pagada. False si ya no hay cupo (hay que devolver el pago)."""
    assert payment.reservation_id is not None
    r = await reservations._get_locked(db, payment.reservation_id)
    if r.status == R.CONFIRMED:
        return True
    if r.status not in (R.PENDING_PAYMENT, R.EXPIRED):
        return False  # cancelada mientras pagaba
    now = _now()
    if r.status == R.EXPIRED or r.hold_expires_at is None or r.hold_expires_at <= now:
        await reservations._lock_service(db, r.service_id)
        if not await reservations.has_capacity(
            db, r.service_id, r.pickup_at, r.blocks_until, exclude=r.id
        ):
            return False
    provider = {
        "webpay": "Webpay",
        "simulated": "pasarela de prueba",
        WALLET: "saldo de la billetera",
    }.get(payment.provider, payment.provider)
    note = f"{provider}, autorización {payment.authorization_code}"
    r.events.append(
        ReservationEvent(
            from_status=r.status, to_status=R.CONFIRMED, actor_label="Pago en línea", note=note
        )
    )
    r.status = R.CONFIRMED
    r.confirmed_at = now
    r.hold_expires_at = None
    return True


def _safe(raw: dict[str, object]) -> dict[str, object]:
    """Respuesta del proveedor sin datos de tarjeta más allá de los últimos 4 dígitos."""
    clean = dict(raw)
    card = clean.get("card_detail")
    if isinstance(card, dict) and card.get("card_number"):
        clean["card_detail"] = {"card_number": str(card["card_number"])[-4:]}
    return clean


# ------------------------------------------------------------------ reembolsos


async def _refund(
    db: AsyncSession,
    provider: PaymentProvider,
    payment: Payment,
    amount: Decimal,
    reason: str | None,
    actor: User | None,
    *,
    force: bool = False,
) -> Refund:
    available = payment.amount - payment.refunded_amount
    if not force and payment.status not in (P.AUTHORIZED, P.PARTIALLY_REFUNDED):
        raise Conflict("Este pago no admite reembolsos.", code="NOT_REFUNDABLE")
    if amount <= 0 or amount > available:
        raise Conflict(
            "El monto supera lo que queda por devolver.",
            code="REFUND_TOO_LARGE",
            fields={"amount": "Supera lo que queda por devolver."},
        )
    refund = Refund(
        payment_id=payment.id,
        amount=amount,
        status=RefundStatus.PENDING,
        reason=reason,
        requested_by=actor.id if actor else None,
    )
    db.add(refund)
    await db.flush()
    if payment.provider == WALLET:
        await _refund_to_wallet(db, payment, refund)
    elif payment.wallet_id is not None:
        await _refund_topup(db, provider, payment, refund)
    else:
        await _execute_refund(provider, payment, refund)
    return refund


def _mark_refunded(payment: Payment, refund: Refund) -> None:
    refund.status = RefundStatus.SUCCEEDED
    refund.error_message = None
    payment.refunded_amount += refund.amount
    if payment.status != P.ERROR:
        payment.status = (
            P.REFUNDED if payment.refunded_amount >= payment.amount else P.PARTIALLY_REFUNDED
        )


async def _refund_to_wallet(db: AsyncSession, payment: Payment, refund: Refund) -> None:
    """Reserva pagada con saldo: el reembolso vuelve al saldo, en la misma transacción."""
    r = await db.get(Reservation, payment.reservation_id)
    if r is None or r.user_id is None:
        refund.status = RefundStatus.FAILED
        refund.error_message = (
            "La reserva ya no tiene una cuenta asociada: gestione el reembolso manualmente."
        )
        return
    await wallet.post(
        db,
        r.user_id,
        refund.amount,
        WE.REFUND,
        f"Reembolso de la reserva {r.code}",
        reservation_id=r.id,
        payment_id=payment.id,
    )
    _mark_refunded(payment, refund)


async def _refund_topup(
    db: AsyncSession, provider: PaymentProvider, payment: Payment, refund: Refund
) -> None:
    """Devolución de una recarga: primero se verifica que el saldo alcance, después la pasarela."""
    locked = await db.scalar(select(Wallet).where(Wallet.id == payment.wallet_id).with_for_update())
    assert locked is not None
    if locked.balance < refund.amount:
        raise wallet.InsufficientBalance(
            "El cliente ya usó parte de esa recarga: el saldo no alcanza para devolverla."
        )
    await _execute_refund(provider, payment, refund)
    if refund.status == RefundStatus.SUCCEEDED:
        await wallet.post(
            db,
            locked.user_id,
            -refund.amount,
            WE.TOPUP_REFUND,
            "Devolución de una recarga",
            payment_id=payment.id,
        )


async def _execute_refund(provider: PaymentProvider, payment: Payment, refund: Refund) -> None:
    if payment.provider != provider.name or not payment.provider_token:
        refund.status = RefundStatus.FAILED
        refund.error_message = (
            "El pago se hizo con otra pasarela: gestione el reembolso manualmente."
        )
        return
    result = await provider.refund(payment.provider_token, refund.amount)
    refund.provider_response = result.raw
    refund.provider_reference = result.reference
    if not result.succeeded:
        refund.status = RefundStatus.FAILED
        refund.error_message = (result.message or "Reembolso rechazado")[:500]
        logger.error("Reembolso fallido del pago %s: %s", payment.buy_order, refund.error_message)
        return
    _mark_refunded(payment, refund)


async def paid_payment(db: AsyncSession, reservation_id: uuid.UUID) -> Payment | None:
    return await db.scalar(
        select(Payment)
        .where(
            Payment.reservation_id == reservation_id,
            Payment.status.in_([P.AUTHORIZED, P.PARTIALLY_REFUNDED]),
        )
        .with_for_update()
    )


async def refund_after_cancellation(
    db: AsyncSession, provider: PaymentProvider, r: Reservation, actor: User | None
) -> Refund | None:
    """Tras cancelar, devuelve por la pasarela lo que corresponda según la reserva."""
    if not r.refund_amount:
        return None
    payment = await paid_payment(db, r.id)
    if payment is None:
        return None  # pagada por otro medio: reembolso manual
    amount = min(r.refund_amount, payment.amount - payment.refunded_amount)
    if amount <= 0:
        return None
    refund = await _refund(db, provider, payment, amount, "Cancelación de la reserva", actor)
    await db.commit()
    return refund


async def manual_refund(
    db: AsyncSession,
    provider: PaymentProvider,
    payment_id: uuid.UUID,
    amount: Decimal,
    reason: str,
    actor: User,
) -> Refund:
    payment = await db.scalar(select(Payment).where(Payment.id == payment_id).with_for_update())
    if payment is None:
        raise NotFound("El pago no existe.")
    refund = await _refund(db, provider, payment, amount, reason, actor)
    await db.commit()
    return refund


async def retry_refund(db: AsyncSession, provider: PaymentProvider, refund_id: uuid.UUID) -> Refund:
    refund = await db.scalar(select(Refund).where(Refund.id == refund_id).with_for_update())
    if refund is None:
        raise NotFound("El reembolso no existe.")
    if refund.status != RefundStatus.FAILED:
        raise Conflict("Sólo se reintentan reembolsos fallidos.", code="NOT_RETRYABLE")
    payment = await db.scalar(
        select(Payment).where(Payment.id == refund.payment_id).with_for_update()
    )
    assert payment is not None
    if payment.wallet_id is not None:
        await _refund_topup(db, provider, payment, refund)
    else:
        await _execute_refund(provider, payment, refund)
    await db.commit()
    return refund


# ------------------------------------------------------------------ mantenimiento


async def expire_abandoned(db: AsyncSession) -> int:
    """Intentos que nunca volvieron de la pasarela. Webpay no cobra sin confirmación."""
    result = await db.execute(
        update(Payment)
        .where(Payment.status == P.CREATED, Payment.expires_at < _now())
        .values(status=P.EXPIRED)
    )
    await db.commit()
    return int(result.rowcount or 0)  # type: ignore[attr-defined]
