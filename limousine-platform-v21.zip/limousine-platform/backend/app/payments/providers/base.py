"""Interfaz común de las pasarelas de pago.

Cada proveedor (Webpay, simulado y, si se agrega, Mercado Pago o Flow)
implementa estas operaciones. El resto del sistema no sabe con cuál trabaja.
"""

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Literal, Protocol


class ProviderError(Exception):
    """El proveedor no respondió o respondió algo inesperado."""


@dataclass(frozen=True)
class Redirect:
    """Hacia dónde enviar al cliente: un formulario POST con estos campos."""

    url: str
    fields: dict[str, str]


@dataclass(frozen=True)
class Started:
    token: str
    redirect: Redirect


@dataclass(frozen=True)
class CommitResult:
    approved: bool
    amount: Decimal
    buy_order: str
    response_code: str
    authorization_code: str | None = None
    card_last4: str | None = None
    payment_type: str | None = None
    installments: int | None = None
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RefundResult:
    succeeded: bool
    reference: str | None
    raw: dict[str, Any] = field(default_factory=dict)
    message: str | None = None


ReturnKind = Literal["token", "aborted", "timeout"]


class PaymentProvider(Protocol):
    name: str

    async def start(
        self, *, buy_order: str, session_id: str, amount: Decimal, return_url: str
    ) -> Started: ...

    async def commit(self, token: str) -> CommitResult: ...

    async def refund(self, token: str, amount: Decimal) -> RefundResult: ...
