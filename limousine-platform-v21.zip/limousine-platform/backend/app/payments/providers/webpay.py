"""Webpay Plus (Transbank), API REST v1.2.

Flujo:
1. `start`: POST /transactions → token y URL. El cliente se envía a esa URL con
   un formulario POST que lleva `token_ws`.
2. El cliente paga en Transbank y vuelve a nuestra URL de retorno con
   `token_ws` (o con `TBK_TOKEN` si abandonó).
3. `commit`: PUT /transactions/{token}. Es lo que confirma el pago; si no se
   llama, Transbank no captura el cargo. Webpay Plus no envía webhooks: la
   confirmación ocurre siempre en el retorno.
4. `refund`: POST /transactions/{token}/refunds. El mismo día es una reversa;
   después, una anulación (total o parcial).

VERIFICACIÓN PENDIENTE: este adaptador sigue la documentación pública de
Transbank y está probado contra un servidor que imita sus respuestas, pero no
contra el ambiente de integración real (sin acceso desde el entorno de
desarrollo). Antes de producción, ejecute una compra de prueba completa en
integración con las tarjetas de prueba de Transbank.
"""

from decimal import Decimal
from typing import Any

import httpx

from app.payments.providers.base import CommitResult, ProviderError, Redirect, RefundResult, Started

HOSTS = {
    "integration": "https://webpay3gint.transbank.cl",
    "production": "https://webpay3g.transbank.cl",
}
PATH = "/rswebpaytransaction/api/webpay/v1.2/transactions"


class WebpayProvider:
    name = "webpay"

    def __init__(
        self,
        commerce_code: str,
        api_key: str,
        environment: str = "integration",
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._headers = {
            "Tbk-Api-Key-Id": commerce_code,
            "Tbk-Api-Key-Secret": api_key,
            "Content-Type": "application/json",
        }
        self._base = HOSTS[environment] + PATH
        self._transport = transport

    async def _request(
        self, method: str, url: str, body: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=20, transport=self._transport) as client:
                res = await client.request(method, url, headers=self._headers, json=body)
        except httpx.HTTPError as exc:
            raise ProviderError(f"Webpay no respondió: {exc.__class__.__name__}") from exc
        try:
            data: dict[str, Any] = res.json()
        except ValueError as exc:
            raise ProviderError(f"Webpay respondió {res.status_code} sin JSON") from exc
        if res.status_code >= 400:
            raise ProviderError(
                f"Webpay respondió {res.status_code}: {data.get('error_message', '')}"
            )
        return data

    async def start(
        self, *, buy_order: str, session_id: str, amount: Decimal, return_url: str
    ) -> Started:
        data = await self._request(
            "POST",
            self._base,
            {
                "buy_order": buy_order,
                "session_id": session_id,
                "amount": _amount(amount),
                "return_url": return_url,
            },
        )
        try:
            token, url = str(data["token"]), str(data["url"])
        except KeyError as exc:
            raise ProviderError("Webpay no devolvió token y URL") from exc
        return Started(token=token, redirect=Redirect(url=url, fields={"token_ws": token}))

    async def commit(self, token: str) -> CommitResult:
        data = await self._request("PUT", f"{self._base}/{token}")
        card = data.get("card_detail") or {}
        try:
            response_code = int(data["response_code"])
            return CommitResult(
                # Aprobado sólo si Transbank dice AUTHORIZED y código 0.
                approved=data.get("status") == "AUTHORIZED" and response_code == 0,
                amount=Decimal(str(data["amount"])),
                buy_order=str(data["buy_order"]),
                response_code=str(response_code),
                authorization_code=data.get("authorization_code"),
                card_last4=(str(card.get("card_number") or "")[-4:] or None),
                payment_type=data.get("payment_type_code"),
                installments=data.get("installments_number"),
                raw=data,
            )
        except (KeyError, ValueError, TypeError) as exc:
            raise ProviderError("Respuesta de confirmación de Webpay incompleta") from exc

    async def refund(self, token: str, amount: Decimal) -> RefundResult:
        try:
            data = await self._request(
                "POST", f"{self._base}/{token}/refunds", {"amount": _amount(amount)}
            )
        except ProviderError as exc:
            return RefundResult(succeeded=False, reference=None, message=str(exc))
        kind = data.get("type")
        ok = kind == "REVERSED" or (kind == "NULLIFIED" and int(data.get("response_code", -1)) == 0)
        return RefundResult(
            succeeded=ok,
            reference=data.get("authorization_code") or kind,
            raw=data,
            message=None if ok else f"Webpay rechazó el reembolso ({data.get('response_code')})",
        )


def _amount(value: Decimal) -> int | float:
    # CLP se envía como entero.
    return int(value) if value == value.to_integral_value() else float(value)
