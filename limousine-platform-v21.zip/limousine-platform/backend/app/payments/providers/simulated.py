"""Pasarela simulada para desarrollo y pruebas.

`start` devuelve la URL de una pantalla del propio sitio donde se elige
aprobar, rechazar o abandonar. La decisión se guarda en Redis y `commit` la lee,
igual que Webpay confirmaría el resultado. La API no arranca en producción con
este proveedor.
"""

import json
import secrets
from decimal import Decimal
from typing import Any

from redis.asyncio import Redis

from app.payments.providers.base import CommitResult, Redirect, RefundResult, Started

TTL_SECONDS = 3600


class SimulatedProvider:
    name = "simulated"

    def __init__(self, redis: Redis, frontend_url: str) -> None:
        self._redis = redis
        self._frontend = frontend_url.rstrip("/")

    async def _load(self, token: str) -> dict[str, Any] | None:
        raw = await self._redis.get(f"sim:{token}")
        return json.loads(raw) if raw else None

    async def _save(self, token: str, data: dict[str, Any]) -> None:
        await self._redis.set(f"sim:{token}", json.dumps(data), ex=TTL_SECONDS)

    async def start(
        self, *, buy_order: str, session_id: str, amount: Decimal, return_url: str
    ) -> Started:
        token = "sim_" + secrets.token_hex(16)
        await self._save(
            token, {"amount": str(amount), "buy_order": buy_order, "return_url": return_url}
        )
        url = f"{self._frontend}/payments/simulator"
        return Started(token=token, redirect=Redirect(url=url, fields={"token_ws": token}))

    async def details(self, token: str) -> dict[str, Any] | None:
        return await self._load(token)

    async def decide(self, token: str, decision: str) -> dict[str, Any] | None:
        data = await self._load(token)
        if data is None:
            return None
        data["decision"] = decision
        await self._save(token, data)
        return data

    async def commit(self, token: str) -> CommitResult:
        data = await self._load(token) or {}
        approved = data.get("decision") == "approve"
        return CommitResult(
            approved=approved,
            amount=Decimal(data.get("amount", "0")),
            buy_order=data.get("buy_order", ""),
            response_code="0" if approved else "-1",
            authorization_code="SIM" + token[-6:].upper() if approved else None,
            card_last4="6623" if approved else None,
            payment_type="VN" if approved else None,
            installments=0 if approved else None,
            raw={"simulated": True, "decision": data.get("decision")},
        )

    async def refund(self, token: str, amount: Decimal) -> RefundResult:
        return RefundResult(succeeded=True, reference="SIM-REFUND", raw={"simulated": True})
