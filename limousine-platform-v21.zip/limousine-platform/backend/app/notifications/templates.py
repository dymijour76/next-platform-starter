"""Plantillas de email de la cuenta de usuario, en el idioma del destinatario.

Cada email tiene versión de texto plano y HTML simple con estilos en línea, que es lo
que mejor se ve en todos los clientes de correo. Los textos están en español y se
traducen con el catálogo (app/locales); `locale` es el idioma de quien lo recibe.
"""

from html import escape

from app.core.config import get_settings
from app.core.i18n import LOCALES, t, translate_message
from app.notifications.email import Email

INK = "#1b2433"
CHAMPAGNE = "#b8a374"
SLATE = "#6b7483"
_HTML_LANG = {"es": "es", "en": "en", "fr": "fr", "ht": "ht", "zh": "zh-Hans"}


def _company() -> str:
    return "Limousine Platform"


def _loc(locale: str | None) -> str:
    return locale if locale in LOCALES else "es"


def _layout(
    title: str,
    paragraphs: list[str],
    button: tuple[str, str] | None,
    footnote: str,
    locale: str | None = None,
) -> str:
    loc = _loc(locale)
    body = "".join(
        f'<p style="margin:0 0 16px;line-height:1.6;color:{INK}">{escape(p)}</p>'
        for p in paragraphs
        if p
    )
    cta = ""
    if button:
        label, url = button
        fallback = t("Si el botón no funciona, copie este enlace en su navegador:", loc)
        cta = (
            f'<p style="margin:28px 0"><a href="{escape(url)}" '
            f'style="background:{INK};color:#ffffff;padding:12px 22px;text-decoration:none;'
            f'border-radius:4px;display:inline-block">{escape(label)}</a></p>'
            f'<p style="margin:0 0 16px;font-size:13px;color:{SLATE}">{escape(fallback)}'
            f"<br>{escape(url)}</p>"
        )
    return (
        f'<!doctype html><html lang="{_HTML_LANG[loc]}"><body style="margin:0;background:#e9ebee;'
        'font-family:Helvetica,Arial,sans-serif">'
        '<table role="presentation" width="100%" cellpadding="0" cellspacing="0">'
        '<tr><td align="center" style="padding:32px 16px">'
        '<table role="presentation" width="100%" style="max-width:560px;background:#ffffff">'
        f'<tr><td style="padding:24px 32px;background:{INK};color:#e9ebee;'
        f'font-family:Georgia,serif;font-size:18px;border-bottom:2px solid {CHAMPAGNE}">'
        f"{escape(_company())}</td></tr>"
        f'<tr><td style="padding:32px"><h1 style="margin:0 0 20px;font-family:Georgia,serif;'
        f'font-weight:normal;font-size:24px;color:{INK}">{escape(title)}</h1>{body}{cta}'
        f'<p style="margin:24px 0 0;font-size:13px;color:{SLATE}">{escape(footnote)}</p>'
        "</td></tr></table></td></tr></table></body></html>"
    )


def _text(title: str, paragraphs: list[str], button: tuple[str, str] | None, footnote: str) -> str:
    parts = [title, "", *[p for p in paragraphs if p]]
    if button:
        parts += ["", f"{button[0]}: {button[1]}"]
    parts += ["", footnote, "", f"— {_company()}"]
    return "\n".join(parts)


def _build(
    to: str,
    subject: str,
    title: str,
    paragraphs: list[str],
    button: tuple[str, str] | None,
    footnote: str,
    locale: str | None = None,
) -> Email:
    return Email(
        to=to,
        subject=subject,
        text=_text(title, paragraphs, button, footnote),
        html=_layout(title, paragraphs, button, footnote, locale),
    )


def _link(path: str, token: str) -> str:
    return f"{get_settings().frontend_url.rstrip('/')}{path}?token={token}"


def _hello(first_name: str, loc: str) -> str:
    return t("Hola, {name}", loc, name=first_name)


def verification_email(to: str, first_name: str, token: str, locale: str | None = None) -> Email:
    loc, hours = _loc(locale), get_settings().email_verification_hours
    return _build(
        to,
        t("Confirme su email", loc),
        _hello(first_name, loc),
        [t("Gracias por crear su cuenta. Confirme su dirección de email para continuar.", loc)],
        (t("Confirmar email", loc), _link("/verify-email", token)),
        t(
            "El enlace vence en {hours} horas. Si usted no creó esta cuenta, ignore este mensaje.",
            loc,
            hours=hours,
        ),
        loc,
    )


def password_reset_email(to: str, first_name: str, token: str, locale: str | None = None) -> Email:
    loc, minutes = _loc(locale), get_settings().password_reset_minutes
    return _build(
        to,
        t("Restablezca su contraseña", loc),
        _hello(first_name, loc),
        [t("Recibimos una solicitud para restablecer la contraseña de su cuenta.", loc)],
        (t("Crear nueva contraseña", loc), _link("/reset-password", token)),
        t(
            "El enlace vence en {minutes} minutos y sólo se puede usar una vez. Si usted no lo "
            "solicitó, ignore este mensaje: su contraseña actual sigue siendo válida.",
            loc,
            minutes=minutes,
        ),
        loc,
    )


def invitation_email(
    to: str, first_name: str, role_names: list[str], token: str, locale: str | None = None
) -> Email:
    loc = _loc(locale)
    roles = ", ".join(translate_message(name, loc) for name in role_names)
    return _build(
        to,
        t("Le han creado una cuenta de acceso", loc),
        _hello(first_name, loc),
        [
            t("Se le ha dado acceso a la plataforma con el perfil: {roles}.", loc, roles=roles),
            t("Para comenzar, cree su contraseña.", loc),
        ],
        (t("Crear contraseña", loc), _link("/reset-password", token)),
        t(
            "El enlace vence en 72 horas. Si no esperaba este mensaje, contacte al administrador.",
            loc,
        ),
        loc,
    )


def password_changed_email(to: str, first_name: str, locale: str | None = None) -> Email:
    loc = _loc(locale)
    return _build(
        to,
        t("Su contraseña fue cambiada", loc),
        _hello(first_name, loc),
        [
            t(
                "La contraseña de su cuenta se cambió correctamente. Por seguridad, cerramos "
                "la sesión en todos los demás dispositivos.",
                loc,
            )
        ],
        None,
        t(
            "Si usted no hizo este cambio, restablezca su contraseña de inmediato y contáctenos.",
            loc,
        ),
        loc,
    )


def failed_logins_email(to: str, first_name: str, locale: str | None = None) -> Email:
    loc = _loc(locale)
    return _build(
        to,
        t("Intentos de acceso fallidos a su cuenta", loc),
        _hello(first_name, loc),
        [
            t(
                "Detectamos varios intentos fallidos de iniciar sesión en su cuenta y la "
                "bloqueamos por unos minutos como precaución.",
                loc,
            ),
            t(
                "Si fue usted, espere y vuelva a intentarlo. Si no, le recomendamos cambiar su "
                "contraseña ahora.",
                loc,
            ),
        ],
        (
            t("Cambiar mi contraseña", loc),
            f"{get_settings().frontend_url.rstrip('/')}/forgot-password",
        ),
        t("Nadie de nuestro equipo le pedirá nunca su contraseña.", loc),
        loc,
    )


def mfa_changed_email(
    to: str, first_name: str, *, enabled: bool, locale: str | None = None
) -> Email:
    loc = _loc(locale)
    if enabled:
        title = t("Verificación en dos pasos activada", loc)
        lines = [
            t(
                "Desde ahora, al iniciar sesión le pediremos también un código de su aplicación "
                "de autenticación.",
                loc,
            ),
            t(
                "Guarde sus códigos de respaldo en un lugar seguro: le permiten entrar si "
                "pierde el teléfono.",
                loc,
            ),
        ]
    else:
        title = t("Verificación en dos pasos desactivada", loc)
        lines = [
            t("La verificación en dos pasos de su cuenta fue desactivada o restablecida.", loc)
        ]
    return _build(
        to,
        title,
        _hello(first_name, loc),
        lines,
        None,
        t("Si usted no hizo este cambio, cambie su contraseña y contáctenos de inmediato.", loc),
        loc,
    )


def account_deleted_email(to: str, first_name: str, locale: str | None = None) -> Email:
    loc = _loc(locale)
    return _build(
        to,
        t("Su cuenta fue eliminada", loc),
        _hello(first_name, loc),
        [
            t("Eliminamos su cuenta y sus datos personales, como lo solicitó.", loc),
            t(
                "Conservamos sin datos personales los registros de reservas y pagos que la ley "
                "tributaria nos obliga a guardar.",
                loc,
            ),
        ],
        None,
        t("Si usted no solicitó esto, contáctenos de inmediato.", loc),
        loc,
    )


def email_changed_notice(
    to: str, first_name: str, new_email: str, locale: str | None = None
) -> Email:
    loc = _loc(locale)
    return _build(
        to,
        t("El email de su cuenta fue cambiado", loc),
        _hello(first_name, loc),
        [t("El email de acceso de su cuenta se cambió a {email}.", loc, email=new_email)],
        None,
        t("Si usted no hizo este cambio, contáctenos de inmediato.", loc),
        loc,
    )


def site_url(path: str) -> str:
    return f"{get_settings().frontend_url.rstrip('/')}{path}"


# API pública para otros módulos (reservas, pagos).
build_email = _build
