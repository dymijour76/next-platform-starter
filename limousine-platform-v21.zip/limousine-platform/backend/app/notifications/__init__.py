"""Módulo notifications (se implementa en fases posteriores)."""
