"""Envío de emails.

La API nunca envía correos directamente: encola un trabajo que procesa el
worker. Así, si el servidor SMTP está lento o caído, el registro o la
recuperación de contraseña responden igual de rápido.
"""

import logging
from dataclasses import asdict, dataclass
from email.message import EmailMessage as MimeMessage
from typing import Any, Protocol

import aiosmtplib
from arq import ArqRedis, create_pool
from arq.connections import RedisSettings

from app.core.config import get_settings

logger = logging.getLogger("app.email")


@dataclass(frozen=True)
class Email:
    to: str
    subject: str
    text: str
    html: str


class EmailDispatcher(Protocol):
    async def send(self, email: Email) -> None: ...


class QueueEmailDispatcher:
    """Encola el email en arq (Redis). Implementación usada por la API."""

    _pool: ArqRedis | None = None

    async def _get_pool(self) -> ArqRedis:
        if QueueEmailDispatcher._pool is None:
            QueueEmailDispatcher._pool = await create_pool(
                RedisSettings.from_dsn(get_settings().redis_url)
            )
        return QueueEmailDispatcher._pool

    async def send(self, email: Email) -> None:
        try:
            pool = await self._get_pool()
            await pool.enqueue_job("send_email", asdict(email))
        except Exception:
            # No se interrumpe la operación del usuario, pero queda registrado
            # para reintentarlo o investigarlo.
            logger.exception("No se pudo encolar el email '%s'", email.subject)

    @classmethod
    async def close(cls) -> None:
        if cls._pool is not None:
            await cls._pool.aclose()
            cls._pool = None


_dispatcher = QueueEmailDispatcher()


def get_email_dispatcher() -> EmailDispatcher:
    """Dependencia de FastAPI; los tests la sustituyen por una bandeja en memoria."""
    return _dispatcher


async def deliver(data: dict[str, Any]) -> None:
    """Entrega efectiva del email. La ejecuta el worker."""
    settings = get_settings()
    email = Email(**data)
    if settings.email_backend == "console":
        logger.info("EMAIL para %s | %s\n%s", email.to, email.subject, email.text)
        return

    message = MimeMessage()
    message["From"] = settings.email_from
    message["To"] = email.to
    message["Subject"] = email.subject
    message.set_content(email.text)
    message.add_alternative(email.html, subtype="html")
    await aiosmtplib.send(
        message,
        hostname=settings.email_host,
        port=settings.email_port,
        username=settings.email_user or None,
        password=settings.email_password or None,
        start_tls=settings.email_use_tls,
    )
    logger.info("Email enviado a %s: %s", email.to, email.subject)
