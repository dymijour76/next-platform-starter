"""Vigilancia del worker: /health/worker según la antigüedad del último latido."""

from datetime import UTC, datetime, timedelta

from httpx import AsyncClient

from app.api.v1.health import HEARTBEAT_KEY
from app.core.redis import redis_client
from app.worker import heartbeat


async def test_worker_without_heartbeat_is_stale(client: AsyncClient) -> None:
    await redis_client.delete(HEARTBEAT_KEY)
    res = await client.get("/api/v1/health/worker")
    assert res.status_code == 503 and res.json()["status"] == "stale"


async def test_recent_heartbeat_is_ok(client: AsyncClient) -> None:
    await heartbeat({"redis": redis_client})
    res = await client.get("/api/v1/health/worker")
    assert res.status_code == 200 and res.json()["status"] == "ok"
    assert res.json()["age_seconds"] < 5


async def test_old_heartbeat_is_stale(client: AsyncClient) -> None:
    old = datetime.now(UTC) - timedelta(minutes=5)
    await redis_client.set(HEARTBEAT_KEY, old.isoformat())
    res = await client.get("/api/v1/health/worker")
    assert res.status_code == 503 and res.json()["age_seconds"] >= 300
