"""Traducciones de ejemplo: se completan sin pisar cambios ni traducciones del equipo."""

from sqlalchemy import select

from app.cli import DEMO_RULES, DEMO_SERVICES, complete_demo_translations
from app.db.session import SessionLocal
from app.demo_translations import SERVICE_TRANSLATIONS
from app.pricing.models import PricingRule
from app.services.models import Service


async def test_completes_only_untouched_demo_content(client) -> None:  # type: ignore[no-untyped-def]
    async with SessionLocal() as db:
        for data in DEMO_SERVICES:
            db.add(Service(**data))
        db.add_all(PricingRule(**data) for data in DEMO_RULES)
        await db.flush()
        services = {s.slug: s for s in (await db.scalars(select(Service))).all()}
        # El equipo cambió la descripción de "professional": la traducción de ejemplo no aplica.
        services["professional"].description = "Limusina para 8 con bar."
        # Y ya tradujo "premium" al inglés a su manera: no se pisa.
        services["premium"].translations = {"en": {"tagline": "Our own English tagline"}}
        await db.commit()

        completed = await complete_demo_translations(db)
        await db.commit()
        assert completed == (2, 2)

        services = {s.slug: s for s in (await db.scalars(select(Service))).all()}
        assert services["standard"].translations == SERVICE_TRANSLATIONS["standard"]
        assert services["professional"].translations == {}
        assert services["premium"].translations["en"] == {"tagline": "Our own English tagline"}
        assert services["premium"].translations["ht"] == SERVICE_TRANSLATIONS["premium"]["ht"]

        # Una segunda ejecución no cambia nada.
        assert await complete_demo_translations(db) == (0, 0)
