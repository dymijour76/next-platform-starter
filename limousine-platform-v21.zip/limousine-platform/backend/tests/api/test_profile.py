"""Perfil propio: datos, contraseña y email."""

from httpx import AsyncClient

from .conftest import PASSWORD, Outbox, bearer, create_user, login

API = "/api/v1"
NEW = "nueva-clave-segura-2026"


async def test_update_profile(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    headers = bearer(await login(client, "ana@example.com"))
    res = await client.patch(
        f"{API}/users/me",
        headers=headers,
        json={
            "first_name": "  Ana   María ",
            "phone": "+56 2 2345 6789",
            "company": "Eventos del Sur",
            "billing_tax_id": "76.543.210-3",
            "preferences": {"agua": "sin gas"},
        },
    )
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["first_name"] == "Ana María"
    assert body["phone"] == "+56223456789"
    assert body["profile"]["billing_tax_id"] == "76543210-3"
    assert body["profile"]["preferences"] == {"agua": "sin gas"}
    # Campos no enviados no se tocan.
    assert body["last_name"] == "Apellido"


async def test_invalid_rut_is_rejected(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    headers = bearer(await login(client, "ana@example.com"))
    res = await client.patch(
        f"{API}/users/me", headers=headers, json={"billing_tax_id": "76.543.210-9"}
    )
    assert res.status_code == 422
    assert "dígito verificador" in res.json()["error"]["fields"]["billing_tax_id"]


async def test_profile_cannot_change_status_or_roles(client: AsyncClient) -> None:
    """Campos no permitidos en el perfil propio se ignoran: no hay autoascenso."""
    await create_user("ana@example.com")
    headers = bearer(await login(client, "ana@example.com"))
    res = await client.patch(
        f"{API}/users/me", headers=headers, json={"roles": ["super_admin"], "status": "ACTIVE"}
    )
    assert res.status_code == 200
    assert [r["code"] for r in res.json()["roles"]] == ["customer"]
    assert res.json()["permissions"] == []


async def test_change_password(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    other_device = await login(client, "ana@example.com")
    tokens = await login(client, "ana@example.com")

    wrong = await client.post(
        f"{API}/users/me/password",
        headers=bearer(tokens),
        json={"current_password": "no-es-esta", "password": NEW, "password_confirmation": NEW},
    )
    assert wrong.status_code == 400
    assert "current_password" in wrong.json()["error"]["fields"]

    res = await client.post(
        f"{API}/users/me/password",
        headers=bearer(tokens),
        json={"current_password": PASSWORD, "password": NEW, "password_confirmation": NEW},
    )
    assert res.status_code == 200
    fresh = res.json()
    # Quien cambió la contraseña sigue conectado con los tokens nuevos...
    assert (await client.get(f"{API}/users/me", headers=bearer(fresh))).status_code == 200
    # ...y todas las demás sesiones se cerraron.
    assert (await client.get(f"{API}/users/me", headers=bearer(other_device))).status_code == 401
    assert (await client.get(f"{API}/users/me", headers=bearer(tokens))).status_code == 401
    assert outbox.messages[-1].subject == "Su contraseña fue cambiada"


async def test_change_email(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    await create_user("ocupado@example.com")
    headers = bearer(await login(client, "ana@example.com"))

    taken = await client.post(
        f"{API}/users/me/email",
        headers=headers,
        json={"email": "ocupado@example.com", "current_password": PASSWORD},
    )
    assert taken.status_code == 409

    res = await client.post(
        f"{API}/users/me/email",
        headers=headers,
        json={"email": "Nueva@Example.com", "current_password": PASSWORD},
    )
    assert res.status_code == 200
    assert res.json()["email"] == "nueva@example.com"
    assert res.json()["email_verified"] is False
    # Verificación al email nuevo y aviso al anterior.
    assert {m.to for m in outbox.messages} == {"nueva@example.com", "ana@example.com"}
