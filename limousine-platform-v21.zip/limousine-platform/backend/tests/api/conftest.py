"""Fixtures para tests contra PostgreSQL y Redis reales."""

import asyncio
import os
import subprocess
import sys
from collections.abc import AsyncIterator, Iterator
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import asyncpg
import pytest
from httpx import AsyncClient
from sqlalchemy import select, text

from app.auth.security import hash_password
from app.core.config import get_settings
from app.core.redis import redis_client
from app.db.session import SessionLocal
from app.main import app
from app.notifications.email import Email, get_email_dispatcher
from app.users.models import CustomerProfile, Permission, Role, User, UserRole, UserStatus

BACKEND_DIR = Path(__file__).resolve().parents[2]
PASSWORD = "clave-de-prueba-segura"

# Tablas con datos de referencia creados por las migraciones: no se vacían.
KEEP_TABLES = {"permissions", "roles", "role_permissions", "alembic_version"}
SYSTEM_ROLES = ("super_admin", "reservations_admin", "finance_admin", "driver", "customer")


def _plain_dsn(url: str) -> str:
    return url.replace("postgresql+asyncpg://", "postgresql://")


async def _ensure_database(url: str) -> None:
    base, name = _plain_dsn(url).rsplit("/", 1)
    conn = await asyncpg.connect(f"{base}/postgres")
    try:
        exists = await conn.fetchval("SELECT 1 FROM pg_database WHERE datname = $1", name)
        if not exists:
            await conn.execute(f'CREATE DATABASE "{name}"')
    finally:
        await conn.close()


@pytest.fixture(scope="session", autouse=True)
def _database() -> Iterator[None]:
    url = os.environ["DATABASE_URL"]
    assert url.rsplit("/", 1)[1].endswith("_test"), "Los tests sólo corren en una base *_test"
    asyncio.run(_ensure_database(url))
    subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=BACKEND_DIR,
        check=True,
        env={**os.environ},
        capture_output=True,
    )
    yield


@pytest.fixture(autouse=True)
async def _clean() -> AsyncIterator[None]:
    yield
    async with SessionLocal() as db:
        tables = (
            await db.execute(text("SELECT tablename FROM pg_tables WHERE schemaname = 'public'"))
        ).scalars()
        to_clear = [t for t in tables if t not in KEEP_TABLES]
        if to_clear:
            await db.execute(text(f"TRUNCATE {', '.join(to_clear)} CASCADE"))
        # Los roles personalizados creados en un test se eliminan.
        await db.execute(
            text("DELETE FROM roles WHERE NOT (code = ANY(:codes))"),
            {"codes": list(SYSTEM_ROLES)},
        )
        await db.commit()
    await redis_client.flushdb()


class Outbox:
    def __init__(self) -> None:
        self.messages: list[Email] = []

    async def send(self, email: Email) -> None:
        self.messages.append(email)

    def last_token(self, to: str | None = None) -> str:
        """Extrae el token del último enlace enviado (opcionalmente a un destinatario)."""
        msgs = [m for m in self.messages if to is None or m.to == to]
        assert msgs, "No se envió ningún email"
        return msgs[-1].text.split("?token=", 1)[1].split()[0]


@pytest.fixture
def outbox() -> Outbox:
    box = Outbox()
    app.dependency_overrides[get_email_dispatcher] = lambda: box
    return box


@pytest.fixture
def settings():  # type: ignore[no-untyped-def]
    """Permite cambiar la configuración en un test y la restaura al terminar."""
    s = get_settings()
    original = s.model_copy()
    yield s
    for field in type(s).model_fields:
        setattr(s, field, getattr(original, field))


@dataclass
class Account:
    id: str
    email: str
    password: str


async def create_user(
    email: str,
    roles: tuple[str, ...] = ("customer",),
    *,
    status: UserStatus = UserStatus.ACTIVE,
    verified: bool = True,
    password: str = PASSWORD,
) -> Account:
    async with SessionLocal() as db:
        user = User(
            email=email,
            password_hash=hash_password(password),
            first_name="Nombre",
            last_name="Apellido",
            status=status,
            email_verified_at=datetime.now(UTC) if verified else None,
        )
        db.add(user)
        await db.flush()
        db.add(CustomerProfile(user_id=user.id))
        for code in roles:
            role_id = (
                await db.execute(text("SELECT id FROM roles WHERE code = :c"), {"c": code})
            ).scalar_one()
            db.add(UserRole(user_id=user.id, role_id=role_id))
        await db.commit()
        return Account(str(user.id), email, password)


async def create_role(code: str, permissions: list[str]) -> None:
    async with SessionLocal() as db:
        perms = list(await db.scalars(select(Permission).where(Permission.code.in_(permissions))))
        db.add(Role(code=code, name=code, permissions=perms))
        await db.commit()


async def login(client: AsyncClient, email: str, password: str = PASSWORD) -> dict[str, str]:
    res = await client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert res.status_code == 200, res.text
    return res.json()


def bearer(tokens: dict[str, str]) -> dict[str, str]:
    return {"Authorization": f"Bearer {tokens['access_token']}"}


async def auth_headers(client: AsyncClient, email: str, roles: tuple[str, ...]) -> dict[str, str]:
    await create_user(email, roles)
    return bearer(await login(client, email))
