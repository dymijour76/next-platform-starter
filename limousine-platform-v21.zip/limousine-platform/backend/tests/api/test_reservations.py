"""Reservas: creación, disponibilidad, concurrencia, aislamiento, estados y cancelación."""

import asyncio
import re
import uuid
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from httpx import AsyncClient
from sqlalchemy import select, update

from app.db.session import SessionLocal
from app.reservations import service as reservations
from app.reservations.models import Reservation

from .conftest import Outbox, auth_headers

API = "/api/v1"
SCL = ZoneInfo("America/Santiago")

SERVICE = {
    "slug": "premium",
    "name": "Premium",
    "passenger_capacity": 8,
    "base_fare": "20000",
    "hourly_rate": "60000",
    "min_hours": "2",
}


def weekday_noon(days_ahead: int = 8) -> datetime:
    """Un miércoles a mediodía, sin recargos, varios días adelante."""
    day = datetime.now(SCL).date() + timedelta(days=days_ahead)
    day += timedelta(days=(2 - day.weekday()) % 7)
    return datetime(day.year, day.month, day.day, 12, 0, tzinfo=SCL)


async def setup(
    client: AsyncClient, fleet_size: int = 1, **service: Any
) -> tuple[dict[str, str], dict[str, str], str]:
    """Servicio con `fleet_size` vehículos activos, un administrador y una clienta."""
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    res = await client.post(f"{API}/admin/services", headers=admin, json={**SERVICE, **service})
    assert res.status_code == 201, res.text
    for i in range(fleet_size):
        vehicle = await client.post(
            f"{API}/admin/vehicles",
            headers=admin,
            json={"plate": f"BCDF{10 + i}", "service_id": res.json()["id"], "brand": "Lincoln",
                  "model": "Continental", "year": 2024, "color": "Negro", "passenger_capacity": 8},
        )  # fmt: skip
        assert vehicle.status_code == 201, vehicle.text
    customer = await auth_headers(client, "ana@example.com", ("customer",))
    return admin, customer, res.json()["id"]


def booking(service_id: str, pickup: datetime, **over: Any) -> dict[str, Any]:
    data = {
        "service_id": service_id,
        "pickup_at": pickup.isoformat(),
        "duration_minutes": 120,
        "pickup_address": "Av. Apoquindo 3000, Las Condes",
        "dropoff_address": "Aeropuerto de Santiago",
        "passenger_count": 3,
        "contact_name": "Ana Pérez",
        "contact_email": "ana@example.com",
        "contact_phone": "+56 9 1234 5678",
        "expected_total": "140000",
        "accept_policy": True,
        "idempotency_key": str(uuid.uuid4()),
    }
    return {**data, **over}


async def book(client: AsyncClient, headers: dict[str, str], **kw: Any) -> dict[str, Any]:
    res = await client.post(f"{API}/reservations", headers=headers, json=booking(**kw))
    assert res.status_code == 201, res.text
    return res.json()


# ------------------------------------------------------------------ creación


async def test_create_reservation(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon(),
                   contact_email="pasajero@example.com")  # fmt: skip

    year = datetime.now(SCL).year
    assert re.fullmatch(rf"RES-{year}-\d{{6}}", r["code"])
    assert r["status"] == "PENDING_PAYMENT"
    assert r["total_amount"] == "140000"
    assert r["contact_phone"] == "+56912345678"
    assert [line["label"] for line in r["pricing"]["lines"]] == [
        "Tarifa de salida",
        "2 horas × $60.000",
    ]
    assert "24 horas" in r["cancellation_policy"]
    hold = datetime.fromisoformat(r["hold_expires_at"]) - datetime.now(UTC)
    assert timedelta(minutes=29) < hold <= timedelta(minutes=30)
    assert r["can_cancel"] is True
    # Aviso al pasajero y al titular de la cuenta.
    assert {m.to for m in outbox.messages if r["code"] in m.subject} == {
        "pasajero@example.com",
        "ana@example.com",
    }


async def test_codes_are_sequential(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client, fleet_size=5)
    codes = [
        (await book(client, customer, service_id=sid, pickup=weekday_noon()))["code"]
        for _ in range(3)
    ]
    numbers = [int(c.rsplit("-", 1)[1]) for c in codes]
    assert numbers == [numbers[0], numbers[0] + 1, numbers[0] + 2]


async def test_price_is_recomputed_on_server(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    res = await client.post(
        f"{API}/reservations",
        headers=customer,
        json=booking(sid, weekday_noon(), expected_total="1000", total_amount="1000"),
    )
    assert res.status_code == 409
    assert res.json()["error"]["code"] == "PRICE_CHANGED"
    assert "$140.000" in res.json()["error"]["message"]


async def test_validation(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    res = await client.post(
        f"{API}/reservations",
        headers=customer,
        json=booking(sid, weekday_noon(), passenger_count=9),
    )
    assert res.json()["error"]["code"] == "TOO_MANY_PASSENGERS"
    res = await client.post(
        f"{API}/reservations",
        headers=customer,
        json=booking(sid, weekday_noon(), accept_policy=False, pickup_address="", contact_phone=""),
    )
    assert {"accept_policy", "pickup_address", "contact_phone"} <= set(
        res.json()["error"]["fields"]
    )
    soon = datetime.now(UTC) + timedelta(minutes=30)
    res = await client.post(f"{API}/reservations", headers=customer, json=booking(sid, soon))
    assert res.json()["error"]["code"] == "PICKUP_TOO_SOON"


async def test_requires_login(client: AsyncClient) -> None:
    res = await client.post(f"{API}/reservations", json=booking(str(uuid.uuid4()), weekday_noon()))
    assert res.status_code == 401


async def test_idempotency(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client, fleet_size=3)
    body = booking(sid, weekday_noon())
    first = await client.post(f"{API}/reservations", headers=customer, json=body)
    again = await client.post(f"{API}/reservations", headers=customer, json=body)
    assert (first.status_code, again.status_code) == (201, 200)
    assert first.json()["code"] == again.json()["code"]
    # Un solo email por reserva, aunque llegue dos veces.
    assert len([m for m in outbox.messages if first.json()["code"] in m.subject]) == 1

    other = await auth_headers(client, "otro@example.com", ("customer",))
    res = await client.post(f"{API}/reservations", headers=other, json=body)
    assert res.json()["error"]["code"] == "IDEMPOTENCY_CONFLICT"


# ------------------------------------------------------------------ disponibilidad


async def test_no_double_booking_including_turnaround(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)  # 1 unidad, 60 min de preparación
    noon = weekday_noon()
    await book(client, customer, service_id=sid, pickup=noon)  # ocupa 12:00-14:00 (+1 h)

    trip = {"service_id": sid, "duration_minutes": 120}
    for pickup, available in [
        (noon + timedelta(hours=1), False),  # se solapa con el viaje
        (noon + timedelta(hours=2, minutes=30), False),  # cae en la preparación
        (noon - timedelta(hours=1, minutes=30), False),  # su propia preparación choca
        (noon + timedelta(hours=3), True),
        (noon - timedelta(hours=3), True),
    ]:
        res = await client.post(
            f"{API}/reservations/preview", headers=customer,
            json={**trip, "pickup_at": pickup.isoformat()},
        )  # fmt: skip
        assert res.json()["available"] is available, pickup

    res = await client.post(
        f"{API}/reservations", headers=customer, json=booking(sid, noon + timedelta(hours=1))
    )
    assert res.status_code == 409
    assert res.json()["error"]["code"] == "SLOT_UNAVAILABLE"
    await book(client, customer, service_id=sid, pickup=noon + timedelta(hours=3))


async def test_concurrent_bookings_never_exceed_fleet(client: AsyncClient, outbox: Outbox) -> None:
    """Ocho clientes reservan el mismo horario a la vez: sólo caben dos."""
    _, _, sid = await setup(client, fleet_size=2)
    headers = [await auth_headers(client, f"c{i}@example.com", ("customer",)) for i in range(8)]
    body = booking(sid, weekday_noon())
    results = await asyncio.gather(
        *(
            client.post(
                f"{API}/reservations",
                headers=h,
                json={**body, "idempotency_key": str(uuid.uuid4())},
            )
            for h in headers
        )
    )
    codes = sorted(r.status_code for r in results)
    assert codes == [201, 201, 409, 409, 409, 409, 409, 409]


async def test_expired_hold_frees_the_slot(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    noon = weekday_noon()
    first = await book(client, customer, service_id=sid, pickup=noon)
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(hold_expires_at=datetime.now(UTC) - timedelta(seconds=1))
        )
        await db.commit()

    # Aunque el worker aún no la haya vencido, ya no bloquea el horario.
    await book(client, customer, service_id=sid, pickup=noon)

    async with SessionLocal() as db:
        expired = await reservations.expire_holds(db)
    assert [r.code for r in expired] == [first["code"]]
    detail = (await client.get(f"{API}/reservations/{first['code']}", headers=customer)).json()
    assert detail["status"] == "EXPIRED"
    assert detail["can_cancel"] is False


# ------------------------------------------------------------------ aislamiento entre clientes


async def test_customers_only_see_their_own(client: AsyncClient, outbox: Outbox) -> None:
    _, ana, sid = await setup(client, fleet_size=5)
    r = await book(client, ana, service_id=sid, pickup=weekday_noon())
    luis = await auth_headers(client, "luis@example.com", ("customer",))

    assert (await client.get(f"{API}/reservations/{r['code']}", headers=luis)).status_code == 404
    res = await client.post(f"{API}/reservations/{r['code']}/cancel", headers=luis, json={})
    assert res.status_code == 404
    assert (await client.get(f"{API}/reservations", headers=luis)).json() == []
    assert (await client.get(f"{API}/admin/reservations", headers=luis)).status_code == 403
    # Ana sí, y el código no distingue mayúsculas.
    own = await client.get(f"{API}/reservations/{r['code'].lower()}", headers=ana)
    assert own.status_code == 200


# ------------------------------------------------------------------ estados y cancelación


async def test_admin_workflow(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    rid = r["id"]

    res = await client.post(
        f"{API}/admin/reservations/{rid}/confirm", headers=admin, json={"note": "Transferencia"}
    )
    assert res.status_code == 200
    detail = res.json()
    assert detail["status"] == "CONFIRMED" and detail["hold_expires_at"] is None
    assert [(e["from_status"], e["to_status"]) for e in detail["events"]] == [
        (None, "PENDING_PAYMENT"),
        ("PENDING_PAYMENT", "CONFIRMED"),
    ]
    assert detail["events"][1]["note"] == "Transferencia"
    assert detail["customer"]["email"] == "ana@example.com"
    assert any("confirmada" in m.subject for m in outbox.messages)

    again = await client.post(f"{API}/admin/reservations/{rid}/confirm", headers=admin, json={})
    assert again.json()["error"]["code"] == "INVALID_TRANSITION"
    early = await client.post(f"{API}/admin/reservations/{rid}/complete", headers=admin, json={})
    assert early.status_code == 409  # todavía no llega la hora

    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(
                pickup_at=datetime.now(UTC) - timedelta(hours=3),
                end_at=datetime.now(UTC) - timedelta(hours=1),
                blocks_until=datetime.now(UTC),
            )
        )
        await db.commit()
    done = await client.post(f"{API}/admin/reservations/{rid}/complete", headers=admin, json={})
    assert done.json()["status"] == "COMPLETED"
    cancel = await client.post(
        f"{API}/admin/reservations/{rid}/cancel", headers=admin, json={"reason": "Prueba"}
    )
    assert cancel.status_code == 409


async def test_staff_permissions(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    finance = await auth_headers(client, "fin@example.com", ("finance_admin",))
    ops = await auth_headers(client, "ops@example.com", ("reservations_admin",))

    assert (await client.get(f"{API}/admin/reservations", headers=finance)).status_code == 403
    listing = await client.get(f"{API}/admin/reservations", headers=ops)
    assert listing.json()["total"] == 1
    res = await client.post(
        f"{API}/admin/reservations/{r['id']}/cancel",
        headers=ops,
        json={"reason": "Pedido del cliente"},
    )
    assert res.json()["status"] == "CANCELLED"
    # Cambiar la política de cancelación es configuración general.
    res = await client.put(
        f"{API}/admin/booking/settings", headers=ops,
        json={"hold_minutes": 30, "turnaround_minutes": 0, "free_cancellation_hours": 1,
              "late_cancellation_refund_percent": 100},
    )  # fmt: skip
    assert res.status_code == 403


async def test_customer_cancellation_and_policy(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=5)

    # Pendiente de pago: se cancela sin reembolso porque no se cobró nada.
    pending = await book(client, customer, service_id=sid, pickup=weekday_noon())
    res = await client.post(
        f"{API}/reservations/{pending['code']}/cancel",
        headers=customer,
        json={"reason": "Cambio de planes"},
    )
    assert res.json()["status"] == "CANCELLED" and res.json()["refund_amount"] is None
    assert "No se había realizado ningún cobro" in outbox.messages[-1].text

    # Confirmada con más de 24 h de anticipación: reembolso total.
    early = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await client.post(f"{API}/admin/reservations/{early['id']}/confirm", headers=admin, json={})
    detail = (await client.get(f"{API}/reservations/{early['code']}", headers=customer)).json()
    assert detail["refund_if_cancelled_now"] == "140000"
    res = await client.post(f"{API}/reservations/{early['code']}/cancel", headers=customer, json={})
    assert res.json()["refund_amount"] == "140000"

    # Confirmada para dentro de 3 horas: fuera de plazo, rige la política vigente AL RESERVAR.
    await client.put(
        f"{API}/admin/booking/settings", headers=admin,
        json={"hold_minutes": 30, "turnaround_minutes": 60, "free_cancellation_hours": 24,
              "late_cancellation_refund_percent": 50},
    )  # fmt: skip
    pickup = (datetime.now(UTC) + timedelta(hours=3)).replace(second=0, microsecond=0)
    late = await book(client, customer, service_id=sid, pickup=pickup)
    await client.put(
        f"{API}/admin/booking/settings", headers=admin,
        json={"hold_minutes": 30, "turnaround_minutes": 60, "free_cancellation_hours": 24,
              "late_cancellation_refund_percent": 0},
    )  # fmt: skip
    await client.post(f"{API}/admin/reservations/{late['id']}/confirm", headers=admin, json={})
    res = await client.post(f"{API}/reservations/{late['code']}/cancel", headers=customer, json={})
    assert res.json()["refund_amount"] == "70000"  # 50 % según la política que aceptó


async def test_cannot_cancel_after_pickup(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await client.post(f"{API}/admin/reservations/{r['id']}/confirm", headers=admin, json={})
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(pickup_at=datetime.now(UTC) - timedelta(minutes=5))
        )
        await db.commit()
    res = await client.post(f"{API}/reservations/{r['code']}/cancel", headers=customer, json={})
    assert res.json()["error"]["code"] == "INVALID_TRANSITION"


async def test_confirming_expired_hold_rechecks_availability(
    client: AsyncClient, outbox: Outbox
) -> None:
    admin, customer, sid = await setup(client)
    noon = weekday_noon()
    stale = await book(client, customer, service_id=sid, pickup=noon)
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(hold_expires_at=datetime.now(UTC) - timedelta(minutes=1))
        )
        await db.commit()
    await book(client, customer, service_id=sid, pickup=noon)  # otro toma el cupo liberado
    res = await client.post(
        f"{API}/admin/reservations/{stale['id']}/confirm", headers=admin, json={}
    )
    assert res.json()["error"]["code"] == "SLOT_UNAVAILABLE"


async def test_lists_and_filters(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=5)
    a = await book(
        client, customer, service_id=sid, pickup=weekday_noon(8), contact_name="Ana Pérez"
    )
    b = await book(
        client, customer, service_id=sid, pickup=weekday_noon(15), contact_name="Bruno Díaz"
    )
    await client.post(f"{API}/reservations/{b['code']}/cancel", headers=customer, json={})

    upcoming = (await client.get(f"{API}/reservations", headers=customer)).json()
    past = (await client.get(f"{API}/reservations?scope=past", headers=customer)).json()
    assert [r["code"] for r in upcoming] == [a["code"]]
    assert [r["code"] for r in past] == [b["code"]]  # las canceladas pasan al historial

    async def codes(**params: str) -> list[str]:
        res = await client.get(f"{API}/admin/reservations", headers=admin, params=params)
        return [r["code"] for r in res.json()["items"]]

    assert await codes(status="CANCELLED") == [b["code"]]
    assert await codes(q="bruno") == [b["code"]]
    assert await codes(q=a["code"]) == [a["code"]]
    day = datetime.fromisoformat(a["pickup_local"]).date().isoformat()
    assert await codes(date_from=day, date_to=day) == [a["code"]]


async def test_snapshot_survives_price_changes(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await client.patch(f"{API}/admin/services/{sid}", headers=admin, json={"hourly_rate": "99000"})
    again = (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()
    assert again["total_amount"] == "140000"
    assert again["pricing"]["lines"][1]["label"] == "2 horas × $60.000"
    async with SessionLocal() as db:
        stored = await db.scalar(select(Reservation.pricing_snapshot))
    assert stored is not None and stored["tariff"]["hourly_rate"] == "60000.00"


async def test_public_policy(client: AsyncClient) -> None:
    res = await client.get(f"{API}/booking/policy")
    assert res.json() == {
        "text": (
            "Cancelación sin costo hasta 24 horas antes de la recogida; después no hay reembolso."
        ),
        "hold_minutes": 30,
        "free_cancellation_hours": 24,
        "late_cancellation_refund_percent": 0,
    }
