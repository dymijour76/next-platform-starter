"""Código de verificación del chófer: el mismo para pasajero y chófer, y cambia con el chófer."""

from httpx import AsyncClient
from sqlalchemy import update

from app.db.session import SessionLocal
from app.reservations.models import Reservation

from .conftest import Outbox
from .test_fleet import _trip_ready, assign, confirmed, new_driver, vehicle_ids
from .test_reservations import setup, weekday_noon

API = "/api/v1"


async def test_same_code_for_passenger_and_driver(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, driver, r = await _trip_ready(client, outbox)
    seen_by_customer = (
        await client.get(f"{API}/reservations/{r['code']}", headers=customer)
    ).json()["driver_code"]
    seen_by_driver = (await client.get(f"{API}/driver/trips/{r['id']}", headers=driver)).json()[
        "driver_code"
    ]
    assert seen_by_customer == seen_by_driver
    assert len(seen_by_customer) == 4 and seen_by_customer.isdigit()

    # Si cambia el chófer, cambia el código: el anterior ya no tiene el correcto.
    other = await new_driver(client, admin, "otro-chofer@example.com")
    detail = (await client.get(f"{API}/admin/reservations/{r['id']}", headers=admin)).json()
    res = await assign(
        client, admin, r["id"], vehicle_id=detail["vehicle"]["id"], driver_id=other["id"]
    )
    assert res.status_code == 200, res.text
    assert res.json()["driver"]["id"] == other["id"]
    new_code = (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()[
        "driver_code"
    ]
    assert new_code != seen_by_customer

    # Una vez a bordo ya no se muestra.
    async with SessionLocal() as db:
        await db.execute(update(Reservation).values(status="IN_PROGRESS"))
        await db.commit()
    assert (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()[
        "driver_code"
    ] is None


async def test_no_code_without_driver(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    r = await confirmed(client, admin, customer, sid, weekday_noon(days_ahead=12))
    assert (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()[
        "driver_code"
    ] is None
    driver = await new_driver(client, admin, "jorge@example.com")
    vid = (await vehicle_ids(client, admin, sid))[0]
    await assign(client, admin, r["id"], vehicle_id=vid, driver_id=driver["id"])
    assert (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()[
        "driver_code"
    ] is not None
