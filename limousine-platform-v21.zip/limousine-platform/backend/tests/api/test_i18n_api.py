"""La API responde los errores en el idioma de la petición (Accept-Language)."""

from httpx import AsyncClient

API = "/api/v1"


async def test_errors_follow_accept_language(client: AsyncClient) -> None:
    for lang, expected in [
        (None, "El email o la contraseña no son correctos."),
        ("en", "The email or password is incorrect."),
        ("fr-FR", "L'e-mail ou le mot de passe est incorrect."),
        ("ht", "Imèl la oswa modpas la pa kòrèk."),
        ("zh-CN", "邮箱或密码不正确。"),
    ]:
        headers = {"Accept-Language": lang} if lang else {}
        # Un email por idioma: cinco fallos con el mismo activarían el bloqueo de la cuenta.
        body = {"email": f"nadie-{lang}@example.com", "password": "incorrecta-123"}
        res = await client.post(f"{API}/auth/login", json=body, headers=headers)
        assert res.json()["error"]["message"] == expected


async def test_field_errors_are_translated(client: AsyncClient) -> None:
    res = await client.post(
        f"{API}/auth/register",
        json={
            "email": "",
            "password": "x",
            "password_confirmation": "x",
            "first_name": "",
            "last_name": "A",
            "accept_terms": True,
        },
        headers={"Accept-Language": "en"},
    )
    error = res.json()["error"]
    assert error["message"] == "Please check the information you entered."
    assert error["fields"]["first_name"] == "This field is required."


async def test_account_keeps_its_language(client: AsyncClient, outbox) -> None:  # type: ignore[no-untyped-def]
    """Se registra con el idioma en que navega y puede cambiarlo después."""
    from .conftest import PASSWORD, bearer, login

    res = await client.post(
        f"{API}/auth/register",
        json={
            "email": "marie@example.com",
            "password": PASSWORD,
            "password_confirmation": PASSWORD,
            "first_name": "Marie",
            "last_name": "Joseph",
            "accept_terms": True,
        },
        headers={"Accept-Language": "ht"},
    )
    assert res.status_code == 201
    headers = bearer(await login(client, "marie@example.com"))
    assert (await client.get(f"{API}/auth/me", headers=headers)).json()["locale"] == "ht"

    res = await client.patch(f"{API}/users/me", headers=headers, json={"locale": "fr"})
    assert res.json()["locale"] == "fr"
    bad = await client.patch(f"{API}/users/me", headers=headers, json={"locale": "de"})
    assert bad.status_code == 422
