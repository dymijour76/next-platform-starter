"""Pagos con la pasarela simulada: el mismo flujo que Webpay (inicio, retorno, confirmación)."""

import uuid
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

import pytest
from httpx import AsyncClient
from sqlalchemy import select, update

from app.db.session import SessionLocal
from app.payments import service as payments
from app.payments.models import Payment, Refund
from app.payments.providers.base import CommitResult, RefundResult
from app.payments.providers.simulated import SimulatedProvider
from app.reservations.models import Reservation

from .conftest import Outbox, auth_headers
from .test_reservations import book, setup, weekday_noon

API = "/api/v1"


async def pay(
    client: AsyncClient, headers: dict[str, str], code: str, decision: str
) -> dict[str, Any]:
    """Recorre la pasarela simulada y vuelve al sitio como lo haría el navegador."""
    start = await client.post(f"{API}/reservations/{code}/pay", headers=headers)
    assert start.status_code == 200, start.text
    token = start.json()["fields"]["token_ws"]
    back = await client.post(f"{API}/payments/simulator/{token}", json={"decision": decision})
    assert back.status_code == 200
    assert back.json()["url"].endswith("/payments/return")
    res = await client.post(f"{API}/payments/return", json=back.json()["fields"])
    assert res.status_code == 200
    return {"token": token, **res.json()}


async def detail(client: AsyncClient, headers: dict[str, str], code: str) -> dict[str, Any]:
    return (await client.get(f"{API}/reservations/{code}", headers=headers)).json()


async def test_successful_payment_confirms_reservation(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    assert r["can_pay"] is True

    result = await pay(client, customer, r["code"], "approve")
    assert result == {**result, "outcome": "paid", "reservation_code": r["code"]}

    d = await detail(client, customer, r["code"])
    assert d["status"] == "CONFIRMED" and d["can_pay"] is False and d["hold_expires_at"] is None
    [p] = d["payments"]
    assert (p["status"], p["amount"], p["card_last4"]) == ("AUTHORIZED", "140000", "6623")
    confirmation = [m for m in outbox.messages if "confirmada" in m.subject]
    assert confirmation and "terminada en 6623" in confirmation[0].text

    # Segundo retorno (recarga del navegador): mismo resultado, sin volver a confirmar.
    again = await client.post(f"{API}/payments/return", json={"token_ws": result["token"]})
    assert again.json()["outcome"] == "paid"
    assert len([m for m in outbox.messages if "confirmada" in m.subject]) == len(confirmation)
    async with SessionLocal() as db:
        res = await db.scalar(select(Reservation).where(Reservation.code == r["code"]))
        assert res is not None
        assert [e.to_status for e in res.events].count("CONFIRMED") == 1


async def test_rejected_then_retry(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    assert (await pay(client, customer, r["code"], "reject"))["outcome"] == "rejected"
    d = await detail(client, customer, r["code"])
    assert d["status"] == "PENDING_PAYMENT" and d["can_pay"] is True
    assert [p["status"] for p in d["payments"]] == ["REJECTED"]

    assert (await pay(client, customer, r["code"], "approve"))["outcome"] == "paid"
    async with SessionLocal() as db:
        orders = list(await db.scalars(select(Payment.buy_order).order_by(Payment.created_at)))
    assert orders == [f"{r['code']}-1", f"{r['code']}-2"]


async def test_abandoned_and_timeout(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client, fleet_size=3)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    assert (await pay(client, customer, r["code"], "abort"))["outcome"] == "aborted"

    # Tiempo agotado en la pasarela: sólo vuelve la orden de compra.
    start = await client.post(f"{API}/reservations/{r['code']}/pay", headers=customer)
    token = start.json()["fields"]["token_ws"]
    async with SessionLocal() as db:
        order = await db.scalar(select(Payment.buy_order).where(Payment.provider_token == token))
    res = await client.post(
        f"{API}/payments/return", json={"TBK_ORDEN_COMPRA": order, "TBK_ID_SESION": "x"}
    )
    assert res.json()["outcome"] == "aborted"
    assert (await detail(client, customer, r["code"]))["status"] == "PENDING_PAYMENT"

    unknown = await client.post(f"{API}/payments/return", json={"token_ws": "inventado"})
    assert unknown.json() == {"reservation_code": None, "outcome": "error", "topup": False}


async def test_starting_payment_extends_hold(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(hold_expires_at=datetime.now(UTC) + timedelta(minutes=2))
        )
        await db.commit()
    await client.post(f"{API}/reservations/{r['code']}/pay", headers=customer)
    hold = datetime.fromisoformat((await detail(client, customer, r["code"]))["hold_expires_at"])
    assert hold - datetime.now(UTC) > timedelta(minutes=14)


async def test_only_owner_can_pay_pending(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    other = await auth_headers(client, "otro@example.com", ("customer",))
    assert (
        await client.post(f"{API}/reservations/{r['code']}/pay", headers=other)
    ).status_code == 404
    await pay(client, customer, r["code"], "approve")
    res = await client.post(f"{API}/reservations/{r['code']}/pay", headers=customer)
    assert res.json()["error"]["code"] == "NOT_PAYABLE"


async def test_paid_after_slot_was_taken_is_refunded(client: AsyncClient, outbox: Outbox) -> None:
    """El cupo venció mientras pagaba y otro cliente tomó el horario: se devuelve el cargo."""
    _, ana, sid = await setup(client)
    noon = weekday_noon()
    r = await book(client, ana, service_id=sid, pickup=noon)
    start = await client.post(f"{API}/reservations/{r['code']}/pay", headers=ana)
    token = start.json()["fields"]["token_ws"]
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(hold_expires_at=datetime.now(UTC) - timedelta(seconds=1))
        )
        await db.commit()
    luis = await auth_headers(client, "luis@example.com", ("customer",))
    await book(client, luis, service_id=sid, pickup=noon)

    back = await client.post(f"{API}/payments/simulator/{token}", json={"decision": "approve"})
    res = await client.post(f"{API}/payments/return", json=back.json()["fields"])
    assert res.json()["outcome"] == "refunded_unavailable"
    d = await detail(client, ana, r["code"])
    assert d["status"] == "PENDING_PAYMENT"
    assert d["payments"][0]["status"] == "REFUNDED"
    assert d["payments"][0]["refunds"][0]["status"] == "SUCCEEDED"
    assert any("No pudimos confirmar" in m.subject for m in outbox.messages)


async def test_expired_reservation_is_confirmed_if_slot_still_free(
    client: AsyncClient, outbox: Outbox
) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    start = await client.post(f"{API}/reservations/{r['code']}/pay", headers=customer)
    token = start.json()["fields"]["token_ws"]
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation).values(status="EXPIRED", hold_expires_at=datetime.now(UTC))
        )
        await db.commit()
    back = await client.post(f"{API}/payments/simulator/{token}", json={"decision": "approve"})
    res = await client.post(f"{API}/payments/return", json=back.json()["fields"])
    assert res.json()["outcome"] == "paid"
    assert (await detail(client, customer, r["code"]))["status"] == "CONFIRMED"


async def test_inconsistent_amount_is_not_confirmed(
    client: AsyncClient, outbox: Outbox, monkeypatch: pytest.MonkeyPatch
) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    original = SimulatedProvider.commit

    async def tampered(self: SimulatedProvider, token: str) -> CommitResult:
        result = await original(self, token)
        return CommitResult(**{**result.__dict__, "amount": Decimal(1000)})

    monkeypatch.setattr(SimulatedProvider, "commit", tampered)
    assert (await pay(client, customer, r["code"], "approve"))["outcome"] == "error"
    d = await detail(client, customer, r["code"])
    assert d["status"] == "PENDING_PAYMENT"
    assert d["payments"][0]["status"] == "ERROR"
    assert d["payments"][0]["refunds"][0]["amount"] == "1000"


async def test_customer_cancellation_refunds_automatically(
    client: AsyncClient, outbox: Outbox
) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await pay(client, customer, r["code"], "approve")
    res = await client.post(f"{API}/reservations/{r['code']}/cancel", headers=customer, json={})
    d = res.json()
    assert d["refund_amount"] == "140000"
    [p] = d["payments"]
    assert p["status"] == "REFUNDED" and p["refunded_amount"] == "140000"
    assert "por el mismo medio de pago" in outbox.messages[-1].text


async def test_admin_cancel_with_policy_refunds_partially(
    client: AsyncClient, outbox: Outbox
) -> None:
    admin, customer, sid = await setup(client)
    await client.put(
        f"{API}/admin/booking/settings", headers=admin,
        json={"hold_minutes": 30, "turnaround_minutes": 60, "free_cancellation_hours": 24,
              "late_cancellation_refund_percent": 50},
    )  # fmt: skip
    pickup = (datetime.now(UTC) + timedelta(hours=3)).replace(second=0, microsecond=0)
    r = await book(client, customer, service_id=sid, pickup=pickup)
    await pay(client, customer, r["code"], "approve")
    res = await client.post(
        f"{API}/admin/reservations/{r['id']}/cancel", headers=admin,
        json={"reason": "Solicitud tardía", "apply_policy": True},
    )  # fmt: skip
    [p] = res.json()["payments"]
    assert (p["status"], p["refunded_amount"]) == ("PARTIALLY_REFUNDED", "70000")


async def test_manual_refunds_and_permissions(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await pay(client, customer, r["code"], "approve")
    pid = (await detail(client, customer, r["code"]))["payments"][0]["id"]

    finance = await auth_headers(client, "fin@example.com", ("finance_admin",))
    body = {"amount": "20000", "reason": "Compensación por demora"}
    assert (
        await client.post(f"{API}/admin/payments/{pid}/refund", headers=finance, json=body)
    ).status_code == 403
    res = await client.post(f"{API}/admin/payments/{pid}/refund", headers=admin, json=body)
    assert res.json()["status"] == "SUCCEEDED"
    too_much = await client.post(
        f"{API}/admin/payments/{pid}/refund", headers=admin, json={**body, "amount": "130000"}
    )
    assert too_much.json()["error"]["code"] == "REFUND_TOO_LARGE"

    # Finanzas ve los pagos y los totales.
    listing = (await client.get(f"{API}/admin/payments", headers=finance)).json()
    assert listing["totals"] == {
        "collected": "140000",
        "refunded": "20000",
        "net": "120000",
        "count": 1,
    }
    assert listing["items"][0]["status"] == "PARTIALLY_REFUNDED"
    assert (await client.get(f"{API}/admin/payments", headers=customer)).status_code == 403


async def test_failed_refund_can_be_retried(
    client: AsyncClient, outbox: Outbox, monkeypatch: pytest.MonkeyPatch
) -> None:
    admin, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await pay(client, customer, r["code"], "approve")

    async def failing(self: SimulatedProvider, token: str, amount: Decimal) -> RefundResult:
        return RefundResult(succeeded=False, reference=None, message="Webpay no respondió")

    monkeypatch.setattr(SimulatedProvider, "refund", failing)
    d = (
        await client.post(f"{API}/reservations/{r['code']}/cancel", headers=customer, json={})
    ).json()
    refund = d["payments"][0]["refunds"][0]
    assert refund["status"] == "FAILED" and d["payments"][0]["status"] == "AUTHORIZED"

    monkeypatch.undo()
    res = await client.post(f"{API}/admin/refunds/{refund['id']}/retry", headers=admin)
    assert res.json()["status"] == "SUCCEEDED"
    assert (await detail(client, customer, r["code"]))["payments"][0]["status"] == "REFUNDED"
    again = await client.post(f"{API}/admin/refunds/{refund['id']}/retry", headers=admin)
    assert again.json()["error"]["code"] == "NOT_RETRYABLE"


async def test_abandoned_attempts_expire(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await client.post(f"{API}/reservations/{r['code']}/pay", headers=customer)
    async with SessionLocal() as db:
        await db.execute(
            update(Payment).values(expires_at=datetime.now(UTC) - timedelta(minutes=1))
        )
        await db.commit()
        assert await payments.expire_abandoned(db) == 1
        assert await db.scalar(select(Payment.status)) == "EXPIRED"


async def test_simulator_disabled_with_real_provider(client: AsyncClient, settings) -> None:
    settings.payment_provider = "webpay"
    res = await client.get(f"{API}/payments/simulator/sim_{uuid.uuid4().hex}")
    assert res.status_code == 404


async def test_no_card_data_stored(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    await pay(client, customer, r["code"], "approve")
    async with SessionLocal() as db:
        p = await db.scalar(select(Payment))
        refunds = list(await db.scalars(select(Refund)))
    assert p is not None and p.card_last4 == "6623"
    assert "card_number" not in str(p.provider_response) or len(str(p.provider_response)) < 200
    assert refunds == []
