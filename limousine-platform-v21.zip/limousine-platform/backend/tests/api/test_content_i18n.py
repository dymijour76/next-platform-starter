"""Contenido administrable en cinco idiomas: servicios, reglas, carrusel, desglose y política."""

import uuid
from datetime import UTC, datetime, timedelta
from typing import Any

from httpx import AsyncClient

from .conftest import auth_headers

API = "/api/v1"
EN = {"Accept-Language": "en"}
HT = {"Accept-Language": "ht"}

TRANSLATIONS = {
    "en": {
        "name": "Premium",
        "tagline": "For unforgettable occasions",
        "features": ["Red carpet", "  "],
    },  # el espacio vacío se descarta
    "ht": {
        "tagline": "Pou okazyon espesyal",
        "description": "",
    },  # descripción vacía: queda el español
    "zh": {},
}


async def premium(client: AsyncClient, admin: dict[str, str]) -> dict[str, Any]:
    res = await client.post(
        f"{API}/admin/services",
        headers=admin,
        json={
            "slug": "premium",
            "name": "Premium",
            "tagline": "Para las ocasiones que no se repiten",
            "description": "Limusina de gran lujo.",
            "features": ["Alfombra roja"],
            "passenger_capacity": 8,
            "base_fare": "40000",
            "hourly_rate": "85000",
            "min_hours": "3",
            "translations": TRANSLATIONS,
        },
    )
    assert res.status_code == 201, res.text
    vehicle = await client.post(
        f"{API}/admin/vehicles",
        headers=admin,
        json={
            "plate": "TBWX48",
            "service_id": res.json()["id"],
            "brand": "Cadillac",
            "model": "Escalade",
            "year": 2024,
            "color": "Negro",
            "passenger_capacity": 8,
        },
    )
    assert vehicle.status_code == 201, vehicle.text
    return res.json()


async def test_service_translations(client: AsyncClient) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    created = await premium(client, admin)
    # Se guardan limpias: sin campos vacíos ni idiomas sin contenido.
    assert created["translations"] == {
        "en": {
            "name": "Premium",
            "tagline": "For unforgettable occasions",
            "features": ["Red carpet"],
        },
        "ht": {"tagline": "Pou okazyon espesyal"},
    }

    en = (await client.get(f"{API}/services/premium", headers=EN)).json()
    assert (en["tagline"], en["features"]) == ("For unforgettable occasions", ["Red carpet"])
    ht = (await client.get(f"{API}/services/premium", headers=HT)).json()
    assert ht["tagline"] == "Pou okazyon espesyal"
    assert ht["description"] == "Limusina de gran lujo."  # sin traducción: español
    zh = (await client.get(f"{API}/services/premium", headers={"Accept-Language": "zh"})).json()
    assert zh["tagline"] == "Para las ocasiones que no se repiten"

    # El panel recibe siempre el texto base y las traducciones, aunque navegue en inglés.
    panel = (
        await client.get(f"{API}/admin/services/{created['id']}", headers={**admin, **EN})
    ).json()
    assert panel["tagline"] == "Para las ocasiones que no se repiten"
    assert panel["translations"]["en"]["tagline"] == "For unforgettable occasions"


async def test_quote_and_reservation_in_the_visitor_language(client: AsyncClient, outbox) -> None:  # type: ignore[no-untyped-def]
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    service = await premium(client, admin)
    res = await client.post(
        f"{API}/admin/pricing/rules",
        headers=admin,
        json={
            "name": "Recargo nocturno",
            "kind": "SURCHARGE",
            "adjustment_type": "PERCENT",
            "value": "20",
            "time_from": "22:00",
            "time_until": "06:00",
            "translations": {"en": {"name": "Night surcharge"}, "zh": {"name": "夜间附加费"}},
        },
    )
    assert res.status_code == 201, res.text
    assert res.json()["translations"]["en"]["name"] == "Night surcharge"

    night = (datetime.now(UTC) + timedelta(days=5)).replace(
        hour=3, minute=0, second=0, microsecond=0
    )
    body = {"service_id": service["id"], "pickup_at": night.isoformat(), "duration_minutes": 180}
    quote = (await client.post(f"{API}/pricing/quote", json=body, headers=EN)).json()
    labels = [ln["label"] for ln in quote["lines"]]
    assert labels == ["Base fare", "3 hours × $85.000", "Night surcharge (20 %)"]
    assert quote["tax_name"] == "VAT"

    # La reserva guarda el nombre de la regla en cada idioma: se ve igual aunque la regla cambie.
    customer = await auth_headers(client, "ana@example.com", ("customer",))
    trip = {
        **body,
        "pickup_address": "Av. Apoquindo 3000",
        "passenger_count": 2,
        "contact_name": "Ana Pérez",
        "contact_email": "ana@example.com",
        "contact_phone": "+56912345678",
        "accept_policy": True,
        "idempotency_key": str(uuid.uuid4()),
        "expected_total": quote["total"],
    }
    booked = await client.post(f"{API}/reservations", json=trip, headers=customer)
    assert booked.status_code == 201, booked.text
    code = booked.json()["code"]
    rule_id = res.json()["id"]
    await client.delete(f"{API}/admin/pricing/rules/{rule_id}", headers=admin)

    zh = (
        await client.get(
            f"{API}/reservations/{code}", headers={**customer, "Accept-Language": "zh"}
        )
    ).json()
    assert [ln["label"] for ln in zh["pricing"]["lines"]][-1] == "夜间附加费 (20 %)"
    assert zh["cancellation_policy"].startswith("接载前 24 小时之前可免费取消")
    ht = (await client.get(f"{API}/reservations/{code}", headers={**customer, **HT})).json()
    # Sin traducción al creole de la regla: español. El resto del desglose, en creole.
    assert [ln["label"] for ln in ht["pricing"]["lines"]] == [
        "Frè depa",
        "3 èdtan × $85.000",
        "Recargo nocturno (20 %)",
    ]
    assert ht["service"]["name"] == "Premium"


async def test_carousel_translations(client: AsyncClient, tmp_path, settings) -> None:  # type: ignore[no-untyped-def]
    import io

    from PIL import Image

    from app.media.storage import get_storage

    settings.media_root = str(tmp_path)
    get_storage.cache_clear()
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    buf = io.BytesIO()
    Image.new("RGB", (1200, 800)).save(buf, "JPEG")
    image = await client.post(
        f"{API}/admin/media",
        headers=admin,
        files={"file": ("a.jpg", buf.getvalue(), "image/jpeg")},
        data={"alt_text": "Limusina blanca"},
    )
    slide = await client.post(
        f"{API}/admin/carousel",
        headers=admin,
        json={
            "image_id": image.json()["id"],
            "title": "Su boda, sin preocupaciones",
            "cta_label": "Reservar",
            "cta_url": "/book",
            "translations": {"fr": {"title": "Votre mariage, sans souci", "cta_label": "Réserver"}},
        },
    )
    assert slide.status_code == 201, slide.text
    fr = (await client.get(f"{API}/content/carousel", headers={"Accept-Language": "fr"})).json()[0]
    assert (fr["title"], fr["cta_label"]) == ("Votre mariage, sans souci", "Réserver")
    panel = (
        await client.get(f"{API}/admin/carousel", headers={**admin, "Accept-Language": "fr"})
    ).json()[0]
    assert (
        panel["title"] == "Su boda, sin preocupaciones"
        and panel["translations"]["fr"]["cta_label"] == "Réserver"
    )
    get_storage.cache_clear()


async def test_invalid_translation_language_is_rejected(client: AsyncClient) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    res = await client.post(
        f"{API}/admin/services",
        headers=admin,
        json={
            "slug": "x",
            "name": "X",
            "passenger_capacity": 4,
            "hourly_rate": "1000",
            "min_hours": "1",
            "translations": {"de": {"name": "Deutsch"}},
        },
    )
    assert res.status_code == 422
