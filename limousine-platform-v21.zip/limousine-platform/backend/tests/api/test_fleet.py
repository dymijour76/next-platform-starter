"""Vehículos, conductores, asignación, panel del conductor y abordaje con QR."""

import uuid
from datetime import UTC, date, datetime, timedelta
from typing import Any

import pytest
from httpx import AsyncClient
from sqlalchemy import text, update
from sqlalchemy.exc import IntegrityError

from app.db.session import SessionLocal
from app.reservations.models import Reservation

from .conftest import PASSWORD, Outbox, auth_headers, bearer, create_user, login
from .test_reservations import book, setup, weekday_noon

API = "/api/v1"


def vehicle_body(service_id: str, plate: str, **over: Any) -> dict[str, Any]:
    return {
        "plate": plate,
        "service_id": service_id,
        "brand": "Mercedes-Benz",
        "model": "Clase S",
        "year": 2023,
        "color": "Negro",
        "passenger_capacity": 8,
        **over,
    }


def driver_body(email: str, **over: Any) -> dict[str, Any]:
    return {
        "email": email,
        "first_name": "Jorge",
        "last_name": "Vidal",
        "phone": "+56 9 5555 1234",
        "license_number": "12345678",
        "license_class": "A2",
        "license_expires_on": (date.today() + timedelta(days=365)).isoformat(),
        **over,
    }


async def confirmed(
    client: AsyncClient,
    admin: dict[str, str],
    customer: dict[str, str],
    sid: str,
    pickup: datetime,
    **kw: Any,
) -> dict[str, Any]:
    r = await book(client, customer, service_id=sid, pickup=pickup, **kw)
    res = await client.post(f"{API}/admin/reservations/{r['id']}/confirm", headers=admin, json={})
    assert res.status_code == 200, res.text
    return res.json()


async def new_driver(
    client: AsyncClient, admin: dict[str, str], email: str, **over: Any
) -> dict[str, Any]:
    res = await client.post(f"{API}/admin/drivers", headers=admin, json=driver_body(email, **over))
    assert res.status_code == 201, res.text
    return res.json()


async def assign(client: AsyncClient, admin: dict[str, str], rid: str, **ids: str | None):  # type: ignore[no-untyped-def]
    return await client.put(f"{API}/admin/reservations/{rid}/assignment", headers=admin, json=ids)


async def vehicle_ids(client: AsyncClient, admin: dict[str, str], sid: str) -> list[str]:
    res = await client.get(f"{API}/admin/vehicles", headers=admin, params={"service_id": sid})
    return [v["id"] for v in res.json()]


# ------------------------------------------------------------------ vehículos y capacidad


async def test_capacity_comes_from_active_vehicles(client: AsyncClient) -> None:
    admin, customer, sid = await setup(client, fleet_size=0)
    trip = {"service_id": sid, "pickup_at": weekday_noon().isoformat(), "duration_minutes": 120}
    preview = lambda: client.post(f"{API}/reservations/preview", headers=customer, json=trip)  # noqa: E731
    assert (await preview()).json()["available"] is False  # sin vehículos, no se reserva

    res = await client.post(
        f"{API}/admin/vehicles", headers=admin, json=vehicle_body(sid, "bc-df 12")
    )
    assert res.status_code == 201
    v = res.json()
    assert v["plate"] == "BCDF12" and v["label"] == "Mercedes-Benz Clase S negro, patente BCDF12"
    assert (await preview()).json()["available"] is True

    services = (await client.get(f"{API}/admin/services", headers=admin)).json()
    assert services[0]["vehicle_count"] == 1

    await client.put(
        f"{API}/admin/vehicles/{v['id']}",
        headers=admin,
        json=vehicle_body(sid, "BCDF12", status="INACTIVE"),
    )
    assert (await preview()).json()["available"] is False


async def test_vehicle_validation(client: AsyncClient) -> None:
    admin, _, sid = await setup(client, fleet_size=1)  # crea BCDF10
    bad = await client.post(f"{API}/admin/vehicles", headers=admin, json=vehicle_body(sid, "12345"))
    assert "patente" in bad.json()["error"]["fields"]["plate"]
    dup = await client.post(
        f"{API}/admin/vehicles", headers=admin, json=vehicle_body(sid, "bcdf10")
    )
    assert dup.json()["error"]["code"] == "PLATE_TAKEN"
    old = await client.post(
        f"{API}/admin/vehicles", headers=admin, json=vehicle_body(sid, "AB1234")
    )
    assert old.status_code == 201  # formato antiguo de patente


async def test_maintenance_block_reduces_capacity_only_in_that_period(client: AsyncClient) -> None:
    admin, customer, sid = await setup(client, fleet_size=1)
    [vid] = await vehicle_ids(client, admin, sid)
    noon = weekday_noon()
    res = await client.post(
        f"{API}/admin/vehicles/{vid}/blocks",
        headers=admin,
        json={
            "starts_at": (noon - timedelta(hours=1)).isoformat(),
            "ends_at": (noon + timedelta(hours=3)).isoformat(),
            "reason": "Mantención de frenos",
        },
    )
    assert res.status_code == 201 and len(res.json()["blocks"]) == 1

    def trip(at: datetime) -> dict[str, Any]:
        return {"service_id": sid, "pickup_at": at.isoformat(), "duration_minutes": 120}

    blocked = await client.post(f"{API}/reservations/preview", headers=customer, json=trip(noon))
    later = await client.post(
        f"{API}/reservations/preview", headers=customer, json=trip(noon + timedelta(days=1))
    )
    assert blocked.json()["available"] is False and later.json()["available"] is True

    block_id = res.json()["blocks"][0]["id"]
    res = await client.delete(f"{API}/admin/vehicles/{vid}/blocks/{block_id}", headers=admin)
    assert res.json()["blocks"] == []


async def test_cannot_block_or_retire_vehicle_with_assigned_trips(
    client: AsyncClient, outbox: Outbox
) -> None:
    admin, customer, sid = await setup(client, fleet_size=1)
    [vid] = await vehicle_ids(client, admin, sid)
    r = await confirmed(client, admin, customer, sid, weekday_noon())
    assert (await assign(client, admin, r["id"], vehicle_id=vid)).status_code == 200

    res = await client.post(
        f"{API}/admin/vehicles/{vid}/blocks",
        headers=admin,
        json={
            "starts_at": weekday_noon().isoformat(),
            "ends_at": (weekday_noon() + timedelta(hours=1)).isoformat(),
            "reason": "Revisión técnica",
        },
    )
    assert res.json()["error"]["code"] == "VEHICLE_IN_USE"
    assert r["code"] in res.json()["error"]["message"]
    res = await client.put(
        f"{API}/admin/vehicles/{vid}",
        headers=admin,
        json=vehicle_body(sid, "BCDF10", status="RETIRED"),
    )
    assert res.json()["error"]["code"] == "VEHICLE_IN_USE"


async def test_fleet_permissions(client: AsyncClient) -> None:
    _, _, sid = await setup(client, fleet_size=1)
    ops = await auth_headers(client, "ops@example.com", ("reservations_admin",))
    finance = await auth_headers(client, "fin@example.com", ("finance_admin",))
    assert (await client.get(f"{API}/admin/vehicles", headers=ops)).status_code == 200
    assert (await client.get(f"{API}/admin/drivers", headers=ops)).status_code == 200
    res = await client.post(f"{API}/admin/vehicles", headers=ops, json=vehicle_body(sid, "ZZZZ99"))
    assert res.status_code == 403
    assert (await client.get(f"{API}/admin/vehicles", headers=finance)).status_code == 403


# ------------------------------------------------------------------ conductores


async def test_create_driver_invites_new_person(client: AsyncClient, outbox: Outbox) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    d = await new_driver(client, admin, "jorge@example.com")
    assert d["name"] == "Jorge Vidal" and d["license_expired"] is False
    assert "Conductor" in outbox.messages[-1].text  # invitación para crear su contraseña

    # Una persona que ya tiene cuenta de cliente recibe además el rol de conductor.
    await create_user("ana@example.com")
    d2 = await new_driver(client, admin, "ana@example.com", first_name="Ana", last_name="Pérez")
    me = (
        await client.get(f"{API}/auth/me", headers=bearer(await login(client, "ana@example.com")))
    ).json()
    assert {r["code"] for r in me["roles"]} == {"customer", "driver"}
    assert d2["phone"] == "+56955551234"

    dup = await client.post(
        f"{API}/admin/drivers", headers=admin, json=driver_body("ana@example.com")
    )
    assert dup.json()["error"]["code"] == "DRIVER_EXISTS"


# ------------------------------------------------------------------ asignación


async def test_assignment_notifies_and_is_visible(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=1)
    [vid] = await vehicle_ids(client, admin, sid)
    driver = await new_driver(client, admin, "jorge@example.com")
    r = await confirmed(client, admin, customer, sid, weekday_noon())

    res = await assign(client, admin, r["id"], vehicle_id=vid, driver_id=driver["id"])
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["vehicle"]["label"].endswith("BCDF10") and body["driver"]["phone"] == "+56955551234"
    assert body["events"][-1]["note"].startswith("Asignación: vehículo Lincoln")

    detail = (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()
    assert detail["driver_name"] == "Jorge" and "BCDF10" in detail["vehicle_label"]
    assert detail["qr_token"]  # la clienta ve su QR
    subjects = [m.subject for m in outbox.messages]
    assert f"Su chófer para la reserva {r['code']}" in subjects
    assert f"Nuevo viaje asignado: {r['code']}" in subjects
    driver_mail = next(
        m for m in outbox.messages if m.to == "jorge@example.com" and r["code"] in m.subject
    )
    assert "$" not in driver_mail.text  # el conductor no ve precios


async def test_assignment_rules(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=2)
    v1, v2 = await vehicle_ids(client, admin, sid)
    await client.put(
        f"{API}/admin/vehicles/{v2}",
        headers=admin,
        json=vehicle_body(
            sid, "BCDF11", passenger_capacity=3, brand="Lincoln", model="Continental"
        ),
    )
    expired = await new_driver(
        client,
        admin,
        "vencido@example.com",
        license_expires_on=(date.today() - timedelta(days=1)).isoformat(),
    )

    pending = await book(client, customer, service_id=sid, pickup=weekday_noon())
    res = await assign(client, admin, pending["id"], vehicle_id=v1)
    assert res.json()["error"]["code"] == "NOT_ASSIGNABLE"  # aún no se paga

    r = await confirmed(
        client, admin, customer, sid, weekday_noon() + timedelta(days=1), passenger_count=5
    )
    options = (
        await client.get(f"{API}/admin/reservations/{r['id']}/assignment", headers=admin)
    ).json()
    reasons = {o["id"]: o["reason"] for o in options["vehicles"] + options["drivers"]}
    assert reasons[v1] is None
    assert reasons[v2] == "Capacidad 3 pasajeros"
    assert reasons[expired["id"]].startswith("Licencia vencida")

    assert (await assign(client, admin, r["id"], vehicle_id=v2)).json()["error"][
        "code"
    ] == "VEHICLE_UNAVAILABLE"
    res = await assign(client, admin, r["id"], driver_id=expired["id"])
    assert res.json()["error"]["code"] == "DRIVER_UNAVAILABLE"

    # Un vehículo de otro servicio no se puede asignar.
    other = await client.post(
        f"{API}/admin/services",
        headers=admin,
        json={
            "slug": "standard",
            "name": "Standard",
            "passenger_capacity": 4,
            "hourly_rate": "30000",
            "min_hours": "1",
        },
    )
    foreign = await client.post(
        f"{API}/admin/vehicles", headers=admin, json=vehicle_body(other.json()["id"], "XYZW12")
    )
    res = await assign(client, admin, r["id"], vehicle_id=foreign.json()["id"])
    assert res.json()["error"]["code"] == "INVALID_VEHICLE"


async def test_no_double_assignment(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=2)
    v1, _ = await vehicle_ids(client, admin, sid)
    driver = await new_driver(client, admin, "jorge@example.com")
    noon = weekday_noon()
    a = await confirmed(client, admin, customer, sid, noon)
    b = await confirmed(
        client, admin, customer, sid, noon + timedelta(hours=2, minutes=30)
    )  # cae en la preparación

    assert (
        await assign(client, admin, a["id"], vehicle_id=v1, driver_id=driver["id"])
    ).status_code == 200
    res = await assign(client, admin, b["id"], vehicle_id=v1)
    assert res.json()["error"]["code"] == "VEHICLE_UNAVAILABLE"
    assert a["code"] in res.json()["error"]["message"]
    res = await assign(client, admin, b["id"], driver_id=driver["id"])
    assert res.json()["error"]["code"] == "DRIVER_UNAVAILABLE"

    # Cancelada la primera, el vehículo y el conductor quedan libres.
    await client.post(
        f"{API}/admin/reservations/{a['id']}/cancel", headers=admin, json={"reason": "Prueba"}
    )
    res = await assign(client, admin, b["id"], vehicle_id=v1, driver_id=driver["id"])
    assert res.status_code == 200


async def test_database_rejects_overlapping_assignment(client: AsyncClient, outbox: Outbox) -> None:
    """Aunque la aplicación fallara, PostgreSQL no permite asignar el mismo vehículo dos veces."""
    admin, customer, sid = await setup(client, fleet_size=2)
    v1, _ = await vehicle_ids(client, admin, sid)
    a = await confirmed(client, admin, customer, sid, weekday_noon())
    b = await confirmed(client, admin, customer, sid, weekday_noon() + timedelta(hours=1))
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation)
            .where(Reservation.id == uuid.UUID(a["id"]))
            .values(vehicle_id=uuid.UUID(v1))
        )
        await db.commit()
        with pytest.raises(IntegrityError, match="ex_reservations_vehicle_no_overlap"):
            await db.execute(
                update(Reservation)
                .where(Reservation.id == uuid.UUID(b["id"]))
                .values(vehicle_id=uuid.UUID(v1))
            )
            await db.commit()


# ------------------------------------------------------------------ panel del conductor


async def _trip_ready(
    client: AsyncClient, outbox: Outbox
) -> tuple[dict[str, str], dict[str, str], dict[str, str], dict[str, Any]]:
    """Viaje confirmado y asignado, con la recogida dentro de una hora."""
    admin, customer, sid = await setup(client, fleet_size=1)
    [vid] = await vehicle_ids(client, admin, sid)
    driver = await new_driver(client, admin, "jorge@example.com")
    r = await confirmed(client, admin, customer, sid, weekday_noon())
    await assign(client, admin, r["id"], vehicle_id=vid, driver_id=driver["id"])
    async with SessionLocal() as db:
        await db.execute(
            text("UPDATE users SET password_hash = :h WHERE email = 'jorge@example.com'"),
            {"h": (await _hash())},
        )
        now = datetime.now(UTC)
        await db.execute(
            update(Reservation).values(
                pickup_at=now + timedelta(hours=1),
                end_at=now + timedelta(hours=3),
                blocks_until=now + timedelta(hours=4),
            )
        )
        await db.commit()
    driver_headers = bearer(await login(client, "jorge@example.com"))
    return admin, customer, driver_headers, r


async def _hash() -> str:
    from app.auth.security import hash_password

    return hash_password(PASSWORD)


async def test_driver_trip_lifecycle_with_qr(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, driver, r = await _trip_ready(client, outbox)
    trips = (await client.get(f"{API}/driver/trips", headers=driver)).json()
    [trip] = trips
    assert trip["code"] == r["code"] and trip["actions"] == ["EN_ROUTE"]
    assert trip["contact_phone"] == "+56912345678"
    assert "total_amount" not in trip and "payments" not in trip

    async def step(status: str) -> Any:
        return await client.post(
            f"{API}/driver/trips/{trip['id']}/status", headers=driver, json={"status": status}
        )

    assert (await step("ARRIVED")).json()["error"][
        "code"
    ] == "INVALID_TRANSITION"  # aún no va en camino
    assert (await step("EN_ROUTE")).json()["actions"] == ["ARRIVED"]
    assert any("va en camino" in m.subject for m in outbox.messages)
    assert (await step("ARRIVED")).json()["actions"] == [
        "BOARD"
    ]  # antes de la hora, sin "no se presentó"

    wrong = await client.post(
        f"{API}/driver/trips/{trip['id']}/board", headers=driver, json={"qr_token": "falso"}
    )
    assert wrong.json()["error"]["code"] == "QR_MISMATCH"
    qr = (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()["qr_token"]
    boarded = await client.post(
        f"{API}/driver/trips/{trip['id']}/board", headers=driver, json={"qr_token": qr}
    )
    assert boarded.json()["status"] == "IN_PROGRESS" and boarded.json()["boarded_at"]

    assert (await step("COMPLETED")).json()["status"] == "COMPLETED"
    detail = (await client.get(f"{API}/admin/reservations/{r['id']}", headers=admin)).json()
    notes = [(e["to_status"], e["note"]) for e in detail["events"]]
    assert ("IN_PROGRESS", "Abordaje validado con QR") in notes
    assert [e["actor_label"] for e in detail["events"]][-1] == "Conductor Jorge Vidal"
    # Terminado el viaje, el cliente ya no recibe el QR.
    assert (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()[
        "qr_token"
    ] is None


async def test_boarding_without_qr_and_no_show(client: AsyncClient, outbox: Outbox) -> None:
    _, _, driver, _ = await _trip_ready(client, outbox)
    [trip] = (await client.get(f"{API}/driver/trips", headers=driver)).json()
    for status in ("EN_ROUTE", "ARRIVED"):
        await client.post(
            f"{API}/driver/trips/{trip['id']}/status", headers=driver, json={"status": status}
        )
    res = await client.post(f"{API}/driver/trips/{trip['id']}/board", headers=driver, json={})
    assert res.json()["error"]["code"] == "QR_REQUIRED"
    no_show = await client.post(
        f"{API}/driver/trips/{trip['id']}/status", headers=driver, json={"status": "NO_SHOW"}
    )
    assert no_show.status_code == 409  # todavía no es la hora de recogida
    res = await client.post(
        f"{API}/driver/trips/{trip['id']}/board", headers=driver, json={"without_qr": True}
    )
    assert res.json()["status"] == "IN_PROGRESS"


async def test_driver_only_sees_own_trips(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, _driver, r = await _trip_ready(client, outbox)
    await new_driver(client, admin, "otro@example.com", first_name="Luis")
    async with SessionLocal() as db:
        await db.execute(
            text("UPDATE users SET password_hash = :h WHERE email = 'otro@example.com'"),
            {"h": await _hash()},
        )
        await db.commit()
    other = bearer(await login(client, "otro@example.com"))
    assert (await client.get(f"{API}/driver/trips", headers=other)).json() == []
    assert (await client.get(f"{API}/driver/trips/{r['id']}", headers=other)).status_code == 404
    # Un cliente no entra al panel del conductor.
    assert (await client.get(f"{API}/driver/trips", headers=customer)).status_code == 403


async def test_trip_too_far_ahead_cannot_start(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=1)
    [vid] = await vehicle_ids(client, admin, sid)
    d = await new_driver(client, admin, "jorge@example.com")
    r = await confirmed(client, admin, customer, sid, weekday_noon())
    await assign(client, admin, r["id"], vehicle_id=vid, driver_id=d["id"])
    await create_user("jorge2@example.com", ("driver",))
    async with SessionLocal() as db:
        await db.execute(
            text("UPDATE users SET password_hash = :h WHERE email = 'jorge@example.com'"),
            {"h": await _hash()},
        )
        await db.commit()
    headers = bearer(await login(client, "jorge@example.com"))
    [trip] = (await client.get(f"{API}/driver/trips", headers=headers)).json()
    assert trip["actions"] == []  # faltan más de 12 horas

    # Rol de conductor sin ficha: no entra al panel.
    no_profile = bearer(await login(client, "jorge2@example.com"))
    assert (await client.get(f"{API}/driver/trips", headers=no_profile)).json()["error"][
        "code"
    ] == "DRIVER_INACTIVE"


async def test_cannot_deactivate_driver_with_trips(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=1)
    d = await new_driver(client, admin, "jorge@example.com")
    r = await confirmed(client, admin, customer, sid, weekday_noon())
    await assign(client, admin, r["id"], driver_id=d["id"])
    res = await client.put(
        f"{API}/admin/drivers/{d['id']}",
        headers=admin,
        json=driver_body("jorge@example.com", status="INACTIVE"),
    )
    assert res.json()["error"]["code"] == "DRIVER_IN_USE"


async def test_unassigned_filter(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client, fleet_size=2)
    v1, _ = await vehicle_ids(client, admin, sid)
    d = await new_driver(client, admin, "jorge@example.com")
    a = await confirmed(client, admin, customer, sid, weekday_noon())
    b = await confirmed(client, admin, customer, sid, weekday_noon() + timedelta(days=1))
    await assign(client, admin, a["id"], vehicle_id=v1, driver_id=d["id"])
    res = await client.get(
        f"{API}/admin/reservations", headers=admin, params={"unassigned": "true"}
    )
    assert [r["code"] for r in res.json()["items"]] == [b["code"]]
    listing = await client.get(f"{API}/admin/reservations", headers=admin)
    assigned = next(r for r in listing.json()["items"] if r["code"] == a["code"])
    assert assigned["driver_name"] == "Jorge" and assigned["vehicle_label"].endswith("BCDF10")
