"""IP del cliente: sólo se acepta la reenviada por el sitio si trae el secreto compartido."""

import pytest
from httpx import AsyncClient
from sqlalchemy import select

from app.auth.models import RefreshToken
from app.db.session import SessionLocal

from .conftest import PASSWORD, create_user

SECRET = "s" * 40


async def last_ip() -> str | None:
    async with SessionLocal() as db:
        return await db.scalar(
            select(RefreshToken.ip_address).order_by(RefreshToken.created_at.desc()).limit(1)
        )


async def login(client: AsyncClient, **headers: str) -> None:
    res = await client.post(
        "/api/v1/auth/login",
        json={"email": "ana@example.com", "password": PASSWORD},
        headers=headers,
    )
    assert res.status_code == 200


@pytest.fixture
async def ana() -> None:
    await create_user("ana@example.com")


async def test_forwarded_ip_accepted_with_secret(client: AsyncClient, settings, ana) -> None:  # type: ignore[no-untyped-def]
    settings.internal_proxy_secret = SECRET
    await login(client, **{"X-Proxy-Secret": SECRET, "X-Client-IP": "200.1.2.3"})
    assert str(await last_ip()) == "200.1.2.3"


@pytest.mark.parametrize(
    "headers",
    [
        {"X-Client-IP": "200.1.2.3"},  # sin secreto: alguien intentando falsificar su IP
        {"X-Proxy-Secret": "otro", "X-Client-IP": "200.1.2.3"},
        {"X-Proxy-Secret": SECRET, "X-Client-IP": "no-es-una-ip"},
    ],
)
async def test_forwarded_ip_ignored_otherwise(client: AsyncClient, settings, ana, headers) -> None:  # type: ignore[no-untyped-def]
    settings.internal_proxy_secret = SECRET
    await login(client, **headers)
    assert str(await last_ip()) != "200.1.2.3"


async def test_rate_limit_is_per_real_client(client: AsyncClient, settings) -> None:  # type: ignore[no-untyped-def]
    """Con la IP real, el límite por IP no castiga a todos los usuarios juntos."""
    settings.internal_proxy_secret = SECRET
    for i in range(50):
        await client.post(
            "/api/v1/auth/login",
            json={"email": f"x{i}@example.com", "password": "mala"},
            headers={"X-Proxy-Secret": SECRET, "X-Client-IP": "200.1.2.3"},
        )
    blocked = await client.post(
        "/api/v1/auth/login",
        json={"email": "y@example.com", "password": "mala"},
        headers={"X-Proxy-Secret": SECRET, "X-Client-IP": "200.1.2.3"},
    )
    other = await client.post(
        "/api/v1/auth/login",
        json={"email": "y@example.com", "password": "mala"},
        headers={"X-Proxy-Secret": SECRET, "X-Client-IP": "190.5.6.7"},
    )
    assert blocked.status_code == 429 and other.status_code == 401
