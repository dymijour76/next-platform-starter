"""Verificación en dos pasos: activación, inicio de sesión, respaldo y exigencia al personal."""

from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
import pyotp
from httpx import AsyncClient
from sqlalchemy import select

from app.db.session import SessionLocal
from app.users.models import User

from .conftest import PASSWORD, Outbox, auth_headers, bearer, create_user, login

API = "/api/v1"


async def enable_mfa(client: AsyncClient, headers: dict[str, str]) -> tuple[pyotp.TOTP, list[str]]:
    totp, backup, _ = await enable_mfa_with_code(client, headers)
    return totp, backup


async def enable_mfa_with_code(
    client: AsyncClient, headers: dict[str, str]
) -> tuple[pyotp.TOTP, list[str], str]:
    """Activa la verificación y devuelve también el código usado para activarla."""
    setup = await client.post(
        f"{API}/users/me/mfa/setup", headers=headers, json={"current_password": PASSWORD}
    )
    assert setup.status_code == 200, setup.text
    assert setup.json()["otpauth_uri"].startswith("otpauth://totp/")
    totp = pyotp.TOTP(setup.json()["secret"])
    code = totp.now()
    res = await client.post(f"{API}/users/me/mfa/enable", headers=headers, json={"code": code})
    assert res.status_code == 200, res.text
    return totp, res.json()["backup_codes"], code


def next_code(totp: pyotp.TOTP) -> str:
    """Código del intervalo siguiente: aceptado por el desfase de relojes y aún no usado."""
    return totp.at(datetime.now(UTC) + timedelta(seconds=30))


async def start_login(client: AsyncClient, email: str) -> dict[str, Any]:
    res = await client.post(f"{API}/auth/login", json={"email": email, "password": PASSWORD})
    assert res.status_code == 200
    return res.json()


async def test_enable_and_login_with_code(client: AsyncClient, outbox: Outbox) -> None:
    headers = await auth_headers(client, "ana@example.com", ("customer",))
    totp, backup = await enable_mfa(client, headers)
    assert len(backup) == 10 and all(len(c) == 9 and c[4] == "-" for c in backup)
    assert outbox.messages[-1].subject == "Verificación en dos pasos activada"
    me = (await client.get(f"{API}/auth/me", headers=headers)).json()
    assert me["mfa_enabled"] is True and me["mfa_backup_codes_left"] == 10

    # La contraseña ya no basta: se pide el código.
    challenge = await start_login(client, "ana@example.com")
    assert challenge["mfa_required"] is True and "access_token" not in challenge
    # El permiso temporal no sirve como sesión.
    assert (
        await client.get(
            f"{API}/auth/me", headers={"Authorization": f"Bearer {challenge['mfa_token']}"}
        )
    ).status_code == 401

    res = await client.post(
        f"{API}/auth/mfa", json={"mfa_token": challenge["mfa_token"], "code": "000000"}
    )
    assert res.json()["error"]["code"] == "INVALID_MFA_CODE"
    res = await client.post(
        f"{API}/auth/mfa", json={"mfa_token": challenge["mfa_token"], "code": next_code(totp)}
    )
    assert res.status_code == 200 and res.json()["access_token"]


async def test_code_cannot_be_reused(client: AsyncClient, outbox: Outbox) -> None:
    """El código usado al activar no vale otra vez, ni uno más antiguo."""
    headers = await auth_headers(client, "ana@example.com", ("customer",))
    _, _, used = await enable_mfa_with_code(client, headers)
    challenge = await start_login(client, "ana@example.com")
    res = await client.post(
        f"{API}/auth/mfa", json={"mfa_token": challenge["mfa_token"], "code": used}
    )
    assert res.json()["error"]["code"] == "INVALID_MFA_CODE"


async def test_backup_code_works_once(client: AsyncClient, outbox: Outbox) -> None:
    headers = await auth_headers(client, "ana@example.com", ("customer",))
    _, backup = await enable_mfa(client, headers)
    for expected in (200, 400):
        challenge = await start_login(client, "ana@example.com")
        res = await client.post(
            f"{API}/auth/mfa", json={"mfa_token": challenge["mfa_token"], "code": backup[0].upper()}
        )
        assert res.status_code == expected
    me = (await client.get(f"{API}/auth/me", headers=headers)).json()
    assert me["mfa_backup_codes_left"] == 9


async def test_mfa_token_expires_and_is_bound_to_version(
    client: AsyncClient, outbox: Outbox, settings
) -> None:  # type: ignore[no-untyped-def]
    user = await create_user("ana@example.com")
    headers = bearer(await login(client, user.email))
    totp, _ = await enable_mfa(client, headers)
    now = datetime.now(UTC)
    expired = jwt.encode(
        {
            "sub": user.id,
            "ver": 0,
            "type": "mfa",
            "iss": settings.jwt_issuer,
            "iat": now - timedelta(minutes=10),
            "exp": now - timedelta(minutes=5),
        },
        settings.jwt_secret,
        algorithm="HS256",
    )
    res = await client.post(f"{API}/auth/mfa", json={"mfa_token": expired, "code": totp.now()})
    assert res.json()["error"]["code"] == "MFA_TOKEN_INVALID"
    # Un token de acceso no sirve como permiso de MFA.
    res = await client.post(
        f"{API}/auth/mfa", json={"mfa_token": headers["Authorization"][7:], "code": totp.now()}
    )
    assert res.json()["error"]["code"] == "MFA_TOKEN_INVALID"


async def test_secret_is_encrypted_at_rest(client: AsyncClient, outbox: Outbox) -> None:
    headers = await auth_headers(client, "ana@example.com", ("customer",))
    setup = await client.post(
        f"{API}/users/me/mfa/setup", headers=headers, json={"current_password": PASSWORD}
    )
    secret = setup.json()["secret"]
    await client.post(
        f"{API}/users/me/mfa/enable", headers=headers, json={"code": pyotp.TOTP(secret).now()}
    )
    async with SessionLocal() as db:
        user = await db.scalar(select(User).where(User.email == "ana@example.com"))
    assert user is not None and user.mfa_secret and secret not in user.mfa_secret


async def test_disable_requires_password_and_code(client: AsyncClient, outbox: Outbox) -> None:
    headers = await auth_headers(client, "ana@example.com", ("customer",))
    _, backup = await enable_mfa(client, headers)
    wrong = await client.post(
        f"{API}/users/me/mfa/disable",
        headers=headers,
        json={"current_password": "otra", "code": backup[0]},
    )
    assert wrong.status_code == 400
    ok = await client.post(
        f"{API}/users/me/mfa/disable",
        headers=headers,
        json={"current_password": PASSWORD, "code": backup[0]},
    )
    assert ok.status_code == 204
    assert "access_token" in await start_login(client, "ana@example.com")


async def test_staff_must_enable_when_required(
    client: AsyncClient, outbox: Outbox, settings
) -> None:  # type: ignore[no-untyped-def]
    settings.require_staff_mfa = True
    staff = await auth_headers(client, "ops@example.com", ("reservations_admin",))
    customer = await auth_headers(client, "c@example.com", ("customer",))

    res = await client.get(f"{API}/admin/reservations", headers=staff)
    assert res.json()["error"]["code"] == "MFA_REQUIRED"
    assert (await client.get(f"{API}/auth/me", headers=staff)).json()["mfa_setup_required"] is True
    assert (await client.get(f"{API}/auth/me", headers=customer)).json()[
        "mfa_setup_required"
    ] is False
    assert (await client.get(f"{API}/reservations", headers=customer)).status_code == 200

    _, backup = await enable_mfa(client, staff)
    assert (await client.get(f"{API}/admin/reservations", headers=staff)).status_code == 200
    res = await client.post(
        f"{API}/users/me/mfa/disable",
        headers=staff,
        json={"current_password": PASSWORD, "code": backup[0]},
    )
    assert res.json()["error"]["code"] == "MFA_REQUIRED_FOR_STAFF"


async def test_admin_can_reset_lost_device(client: AsyncClient, outbox: Outbox) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    user = await create_user("ana@example.com")
    ana = bearer(await login(client, user.email))
    await enable_mfa(client, ana)
    assert (await client.post(f"{API}/users/{user.id}/mfa/reset", headers=admin)).status_code == 204
    assert (await client.get(f"{API}/auth/me", headers=ana)).status_code == 401  # sesiones cerradas
    assert "access_token" in await start_login(client, "ana@example.com")
    customer = await auth_headers(client, "c@example.com", ("customer",))
    assert (
        await client.post(f"{API}/users/{user.id}/mfa/reset", headers=customer)
    ).status_code == 403
