"""Registro, login, sesiones y recuperación de contraseña."""

from datetime import UTC, datetime, timedelta
from typing import Any

import jwt
from httpx import AsyncClient
from sqlalchemy import select, update

from app.auth.models import OneTimeToken, RefreshToken
from app.db.session import SessionLocal
from app.users.models import User, UserStatus

from .conftest import PASSWORD, Outbox, bearer, create_user, login

API = "/api/v1"
NEW_PASSWORD = "otra-clave-muy-segura"


def registration(**overrides: object) -> dict[str, object]:
    data: dict[str, object] = {
        "email": "Cliente@Example.com",
        "password": PASSWORD,
        "password_confirmation": PASSWORD,
        "first_name": "Ana",
        "last_name": "Pérez",
        "phone": "+56 9 1234 5678",
        "accept_terms": True,
    }
    return {**data, **overrides}


# ---------------------------------------------------------------- registro


async def test_register_creates_customer_and_sends_verification(
    client: AsyncClient, outbox: Outbox
) -> None:
    res = await client.post(f"{API}/auth/register", json=registration())
    assert res.status_code == 201, res.text
    body = res.json()
    assert body["email"] == "cliente@example.com"
    assert body["phone"] == "+56912345678"
    assert [r["code"] for r in body["roles"]] == ["customer"]
    assert body["permissions"] == []
    assert body["email_verified"] is False
    assert "password" not in res.text and "hash" not in res.text

    assert len(outbox.messages) == 1
    assert outbox.messages[0].to == "cliente@example.com"
    assert "/verify-email?token=" in outbox.messages[0].text


async def test_register_rejects_duplicate_email_case_insensitive(
    client: AsyncClient, outbox: Outbox
) -> None:
    await create_user("cliente@example.com")
    res = await client.post(f"{API}/auth/register", json=registration(email="CLIENTE@example.com"))
    assert res.status_code == 409
    assert res.json()["error"]["code"] == "EMAIL_TAKEN"


async def test_register_validation_messages(client: AsyncClient, outbox: Outbox) -> None:
    res = await client.post(
        f"{API}/auth/register",
        json=registration(password="corta", password_confirmation="corta", accept_terms=False),
    )
    assert res.status_code == 422
    error = res.json()["error"]
    assert error["code"] == "VALIDATION_ERROR"
    empty = await client.post(f"{API}/auth/register", json=registration(first_name="", email=""))
    assert empty.json()["error"]["fields"]["first_name"] == "Este campo es obligatorio."
    assert empty.json()["error"]["fields"]["email"] == "Este campo es obligatorio."

    # Todos los errores se informan a la vez, cada uno en su campo.
    assert "accept_terms" in error["fields"]
    assert "10 caracteres" in error["fields"]["password"]

    res = await client.post(
        f"{API}/auth/register", json=registration(password_confirmation="distinta-clave-123")
    )
    assert res.json()["error"]["fields"] == {
        "password_confirmation": "Las contraseñas no coinciden."
    }

    res = await client.post(
        f"{API}/auth/register",
        json=registration(password="cliente-12345", password_confirmation="cliente-12345"),
    )
    assert "email" in res.json()["error"]["fields"]["password"]


# ---------------------------------------------------------------- login


async def test_login_and_me(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    tokens = await login(client, "ANA@example.com")
    assert tokens["token_type"] == "bearer"
    assert tokens["expires_in"] == 15 * 60

    res = await client.get(f"{API}/auth/me", headers=bearer(tokens))
    assert res.status_code == 200
    assert res.json()["email"] == "ana@example.com"


async def test_login_does_not_reveal_whether_email_exists(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    wrong_pw = await client.post(
        f"{API}/auth/login", json={"email": "ana@example.com", "password": "incorrecta"}
    )
    no_user = await client.post(
        f"{API}/auth/login", json={"email": "nadie@example.com", "password": "incorrecta"}
    )
    assert wrong_pw.status_code == no_user.status_code == 401
    assert wrong_pw.json() == no_user.json()


async def test_suspended_account_cannot_login(client: AsyncClient) -> None:
    await create_user("ana@example.com", status=UserStatus.SUSPENDED)
    res = await client.post(
        f"{API}/auth/login", json={"email": "ana@example.com", "password": PASSWORD}
    )
    assert res.status_code == 403
    assert res.json()["error"]["code"] == "ACCOUNT_DISABLED"


async def test_email_verification_required_when_configured(
    client: AsyncClient, outbox: Outbox, settings
) -> None:
    settings.require_email_verification = True
    await client.post(f"{API}/auth/register", json=registration())
    res = await client.post(
        f"{API}/auth/login", json={"email": "cliente@example.com", "password": PASSWORD}
    )
    assert res.json()["error"]["code"] == "EMAIL_NOT_VERIFIED"

    res = await client.post(f"{API}/auth/verify-email", json={"token": outbox.last_token()})
    assert res.status_code == 204
    tokens = await login(client, "cliente@example.com")
    me = await client.get(f"{API}/auth/me", headers=bearer(tokens))
    assert me.json()["email_verified"] is True


async def test_ip_rate_limit_across_accounts(client: AsyncClient) -> None:
    """Muchas cuentas distintas desde la misma IP: salta el límite por IP."""
    for i in range(50):
        payload = {"email": f"nadie{i}@example.com", "password": "incorrecta"}
        assert (await client.post(f"{API}/auth/login", json=payload)).status_code == 401
    res = await client.post(f"{API}/auth/login", json={"email": "x@example.com", "password": "x"})
    assert res.status_code == 429
    assert res.json()["error"]["code"] == "RATE_LIMITED"
    assert int(res.headers["Retry-After"]) > 0


async def fail(client: AsyncClient, email: str, times: int) -> Any:
    res = None
    for _ in range(times):
        res = await client.post(
            f"{API}/auth/login", json={"email": email, "password": "incorrecta"}
        )
    return res


async def test_account_lockout_is_progressive(client: AsyncClient, outbox: Outbox) -> None:
    from app.auth import lockout
    from app.core.redis import redis_client

    await create_user("ana@example.com")
    assert (await fail(client, "ana@example.com", 4)).status_code == 401
    fifth = await fail(client, "ana@example.com", 1)
    assert fifth.status_code == 429 and fifth.json()["error"]["code"] == "ACCOUNT_LOCKED"
    assert 50 <= int(fifth.headers["Retry-After"]) <= 60
    # Bloqueada, ni la contraseña correcta entra.
    res = await client.post(
        f"{API}/auth/login", json={"email": "ana@example.com", "password": PASSWORD}
    )
    assert res.json()["error"]["code"] == "ACCOUNT_LOCKED"
    # Aviso al titular.
    assert [m.subject for m in outbox.messages] == ["Intentos de acceso fallidos a su cuenta"]

    # Pasado el primer bloqueo, cinco fallos más: 15 minutos, y ya sin repetir el email.
    await redis_client.delete(lockout._key("until", "ana@example.com"))
    tenth = await fail(client, "ana@example.com", 5)
    assert 800 < int(tenth.headers["Retry-After"]) <= 900
    assert len(outbox.messages) == 1


async def test_lockout_does_not_reveal_accounts(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    real = await fail(client, "ana@example.com", 5)
    ghost = await fail(client, "fantasma@example.com", 5)
    assert real.status_code == ghost.status_code == 429
    assert real.json() == ghost.json()


async def test_success_resets_the_count(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    await fail(client, "ana@example.com", 4)
    await login(client, "ana@example.com")
    assert (await fail(client, "ana@example.com", 4)).status_code == 401


async def test_password_reset_unlocks(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    await fail(client, "ana@example.com", 5)
    await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    body = {
        "token": outbox.last_token(),
        "password": NEW_PASSWORD,
        "password_confirmation": NEW_PASSWORD,
    }
    assert (await client.post(f"{API}/auth/reset-password", json=body)).status_code == 204
    await login(client, "ana@example.com", NEW_PASSWORD)


# ---------------------------------------------------------------- tokens


async def test_invalid_tokens_are_rejected(client: AsyncClient, settings) -> None:
    user = await create_user("ana@example.com")
    now = datetime.now(UTC)
    claims = {"sub": user.id, "ver": 0, "type": "access", "iss": settings.jwt_issuer,
              "iat": now, "exp": now + timedelta(minutes=5)}  # fmt: skip
    forged = {
        "sin token": {},
        "basura": {"Authorization": "Bearer abc.def.ghi"},
        "firma ajena": {"Authorization": f"Bearer {jwt.encode(claims, 'x' * 40, 'HS256')}"},
        "alg none": {"Authorization": f"Bearer {jwt.encode(claims, None, 'none')}"},
        "expirado": {
            "Authorization": "Bearer "
            + jwt.encode({**claims, "exp": now - timedelta(seconds=1)}, settings.jwt_secret)
        },
    }
    for case, headers in forged.items():
        res = await client.get(f"{API}/auth/me", headers=headers)
        assert res.status_code == 401, case
        assert res.headers["WWW-Authenticate"] == "Bearer", case


async def test_refresh_rotates_tokens(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    first = await login(client, "ana@example.com")
    res = await client.post(f"{API}/auth/refresh", json={"refresh_token": first["refresh_token"]})
    assert res.status_code == 200
    second = res.json()
    assert second["refresh_token"] != first["refresh_token"]
    assert (await client.get(f"{API}/auth/me", headers=bearer(second))).status_code == 200


async def test_parallel_refresh_within_grace_window_is_allowed(client: AsyncClient) -> None:
    """Dos pestañas refrescan a la vez con el mismo token: ambas deben seguir conectadas."""
    await create_user("ana@example.com")
    tokens = await login(client, "ana@example.com")
    body = {"refresh_token": tokens["refresh_token"]}
    a = await client.post(f"{API}/auth/refresh", json=body)
    b = await client.post(f"{API}/auth/refresh", json=body)
    assert a.status_code == b.status_code == 200


async def test_refresh_token_reuse_revokes_whole_family(client: AsyncClient, settings) -> None:
    settings.refresh_reuse_grace_seconds = 0
    await create_user("ana@example.com")
    stolen = await login(client, "ana@example.com")
    legit = (
        await client.post(f"{API}/auth/refresh", json={"refresh_token": stolen["refresh_token"]})
    ).json()

    # El atacante reutiliza el token viejo: se rechaza...
    res = await client.post(f"{API}/auth/refresh", json={"refresh_token": stolen["refresh_token"]})
    assert res.status_code == 401
    # ...y como precaución también deja de servir el token nuevo del usuario legítimo.
    res = await client.post(f"{API}/auth/refresh", json={"refresh_token": legit["refresh_token"]})
    assert res.status_code == 401
    assert res.json()["error"]["code"] == "INVALID_REFRESH_TOKEN"


async def test_expired_refresh_token(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    tokens = await login(client, "ana@example.com")
    async with SessionLocal() as db:
        await db.execute(
            update(RefreshToken).values(expires_at=datetime.now(UTC) - timedelta(seconds=1))
        )
        await db.commit()
    res = await client.post(f"{API}/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert res.status_code == 401


async def test_logout_revokes_refresh_token(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    tokens = await login(client, "ana@example.com")
    body = {"refresh_token": tokens["refresh_token"]}
    assert (await client.post(f"{API}/auth/logout", json=body)).status_code == 204
    assert (await client.post(f"{API}/auth/refresh", json=body)).status_code == 401


async def test_logout_all_invalidates_access_tokens(client: AsyncClient) -> None:
    await create_user("ana@example.com")
    phone = await login(client, "ana@example.com")
    laptop = await login(client, "ana@example.com")
    assert (await client.post(f"{API}/auth/logout-all", headers=bearer(laptop))).status_code == 204
    res = await client.get(f"{API}/auth/me", headers=bearer(phone))
    assert res.status_code == 401
    assert res.json()["error"]["code"] == "TOKEN_REVOKED"
    res = await client.post(f"{API}/auth/refresh", json={"refresh_token": phone["refresh_token"]})
    assert res.status_code == 401


# ---------------------------------------------------------------- recuperación de contraseña


async def test_forgot_password_same_response_for_unknown_email(
    client: AsyncClient, outbox: Outbox
) -> None:
    await create_user("ana@example.com")
    known = await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    unknown = await client.post(f"{API}/auth/forgot-password", json={"email": "x@example.com"})
    assert known.status_code == unknown.status_code == 202
    assert known.json() == unknown.json()
    assert [m.to for m in outbox.messages] == ["ana@example.com"]


async def test_password_reset_flow(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    old_session = await login(client, "ana@example.com")
    await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    token = outbox.last_token()

    reset = {"token": token, "password": NEW_PASSWORD, "password_confirmation": NEW_PASSWORD}
    assert (await client.post(f"{API}/auth/reset-password", json=reset)).status_code == 204

    # La contraseña vieja ya no sirve y la nueva sí.
    res = await client.post(
        f"{API}/auth/login", json={"email": "ana@example.com", "password": PASSWORD}
    )
    assert res.status_code == 401
    await login(client, "ana@example.com", NEW_PASSWORD)
    # Las sesiones previas quedaron cerradas.
    assert (await client.get(f"{API}/auth/me", headers=bearer(old_session))).status_code == 401
    # Se avisó del cambio por email.
    assert "contraseña fue cambiada" in outbox.messages[-1].subject
    # El enlace no se puede reutilizar.
    res = await client.post(f"{API}/auth/reset-password", json=reset)
    assert res.status_code == 400
    assert res.json()["error"]["code"] == "INVALID_TOKEN"


async def test_only_latest_reset_link_is_valid(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    first = outbox.last_token()
    await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    body = {"token": first, "password": NEW_PASSWORD, "password_confirmation": NEW_PASSWORD}
    assert (await client.post(f"{API}/auth/reset-password", json=body)).status_code == 400


async def test_expired_reset_link(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    async with SessionLocal() as db:
        await db.execute(
            update(OneTimeToken).values(expires_at=datetime.now(UTC) - timedelta(seconds=1))
        )
        await db.commit()
    body = {
        "token": outbox.last_token(),
        "password": NEW_PASSWORD,
        "password_confirmation": NEW_PASSWORD,
    }
    assert (await client.post(f"{API}/auth/reset-password", json=body)).status_code == 400


async def test_tokens_are_stored_hashed(client: AsyncClient, outbox: Outbox) -> None:
    await create_user("ana@example.com")
    tokens = await login(client, "ana@example.com")
    await client.post(f"{API}/auth/forgot-password", json={"email": "ana@example.com"})
    async with SessionLocal() as db:
        stored_refresh = list(await db.scalars(select(RefreshToken.token_hash)))
        stored_reset = list(await db.scalars(select(OneTimeToken.token_hash)))
        user = await db.scalar(select(User))
    assert tokens["refresh_token"] not in stored_refresh
    assert outbox.last_token() not in stored_reset
    assert user is not None and user.password_hash.startswith("$argon2id$")
