"""Chat entre cliente y chófer: participantes, apertura, avisos, lectura y privacidad."""

from datetime import UTC, datetime, timedelta

from httpx import AsyncClient
from sqlalchemy import update

from app.db.session import SessionLocal
from app.reservations.models import Reservation

from .conftest import PASSWORD, Outbox, auth_headers
from .test_fleet import _trip_ready, confirmed
from .test_reservations import setup, weekday_noon

API = "/api/v1"


def _past() -> dict[str, datetime]:
    """Un viaje que terminó hace 3 horas (inicio, término y bloqueo coherentes)."""
    now = datetime.now(UTC)
    return {
        "pickup_at": now - timedelta(hours=5),
        "end_at": now - timedelta(hours=3),
        "blocks_until": now - timedelta(hours=2),
    }


async def test_no_chat_before_a_driver_is_assigned(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    r = await confirmed(client, admin, customer, sid, weekday_noon(days_ahead=12))
    chat = (await client.get(f"{API}/reservations/{r['code']}/messages", headers=customer)).json()
    assert chat == {"open": False, "closes_at": None, "counterpart": None, "messages": []}
    res = await client.post(
        f"{API}/reservations/{r['code']}/messages", headers=customer, json={"body": "Hola"}
    )
    assert res.json()["error"]["code"] == "CHAT_CLOSED"


async def test_conversation_notifications_and_read_receipts(
    client: AsyncClient, outbox: Outbox
) -> None:
    admin, customer, driver, r = await _trip_ready(client, outbox)
    code, trip = r["code"], f"{API}/driver/trips/{r['id']}/messages"
    outbox.messages.clear()

    # El cliente escribe dos veces: el chófer recibe un solo email (racha sin leer).
    for body in ("Hola, estoy en la puerta 3.\nLlevo maleta grande.", "¿Cuánto falta?"):
        res = await client.post(
            f"{API}/reservations/{code}/messages", headers=customer, json={"body": body}
        )
        assert res.status_code == 201, res.text
    to_driver = [m for m in outbox.messages if "Mensaje del pasajero" in m.subject]
    assert len(to_driver) == 1 and "puerta 3" not in to_driver[0].text  # sin el texto del mensaje

    # El chófer lee (se marcan como leídos) y responde: el cliente recibe un email.
    chat = (await client.get(trip, headers=driver)).json()
    assert chat["open"] is True and [m["mine"] for m in chat["messages"]] == [False, False]
    assert (
        chat["messages"][0]["body"] == "Hola, estoy en la puerta 3.\nLlevo maleta grande."
    )  # saltos de línea
    await client.post(trip, headers=driver, json={"body": "Llego en 5 minutos."})
    assert any("Tiene un mensaje de su chófer" in m.subject for m in outbox.messages)
    mine = (await client.get(f"{API}/reservations/{code}/messages", headers=customer)).json()[
        "messages"
    ]
    # Lo que importa al cliente: sus dos mensajes ya los leyó el chófer.
    assert [(m["mine"], m["read"]) for m in mine if m["mine"]] == [(True, True), (True, True)]

    # El panel lee sin marcar nada como leído.
    await client.post(trip, headers=driver, json={"body": "Ya llegué."})
    staff = (await client.get(f"{API}/admin/reservations/{r['id']}/messages", headers=admin)).json()
    assert len(staff["messages"]) == 4 and not any(m["mine"] for m in staff["messages"])
    trips = (await client.get(f"{API}/driver/trips", headers=driver)).json()
    assert trips[0]["unread_messages"] == 0
    assert (await client.get(f"{API}/reservations/{code}/messages", headers=customer)).json()[
        "messages"
    ][-1]["read"] is True


async def test_only_participants(client: AsyncClient, outbox: Outbox) -> None:
    _, _, _, r = await _trip_ready(client, outbox)
    other = await auth_headers(client, "otro@example.com", ("customer",))
    assert (
        await client.get(f"{API}/reservations/{r['code']}/messages", headers=other)
    ).status_code == 404
    other_driver = await auth_headers(client, "otro-chofer@example.com", ("driver",))
    assert (
        await client.get(f"{API}/driver/trips/{r['id']}/messages", headers=other_driver)
    ).status_code in (403, 404)


async def test_validation_and_rate_limit(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, _, r = await _trip_ready(client, outbox)
    url = f"{API}/reservations/{r['code']}/messages"
    for bad in ("   \n  ", "hola\x07", "x" * 1001):
        assert (await client.post(url, headers=customer, json={"body": bad})).status_code == 422, (
            bad
        )
    codes = [
        (await client.post(url, headers=customer, json={"body": f"m{i}"})).status_code
        for i in range(21)
    ]
    assert codes[:20] == [201] * 20 and codes[20] == 429


async def test_closes_two_hours_after_the_trip(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, _, r = await _trip_ready(client, outbox)
    async with SessionLocal() as db:
        await db.execute(update(Reservation).values(status="COMPLETED", **_past()))
        await db.commit()
    url = f"{API}/reservations/{r['code']}/messages"
    chat = (await client.get(url, headers=customer)).json()
    assert chat["open"] is False  # se puede leer, no escribir
    assert (await client.post(url, headers=customer, json={"body": "Hola"})).json()["error"][
        "code"
    ] == "CHAT_CLOSED"


async def test_deleted_account_removes_message_text(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, _, r = await _trip_ready(client, outbox)
    await client.post(
        f"{API}/reservations/{r['code']}/messages",
        headers=customer,
        json={"body": "Mi dirección es …"},
    )
    async with SessionLocal() as db:  # el viaje terminó: se puede eliminar la cuenta
        await db.execute(update(Reservation).values(status="COMPLETED", **_past()))
        await db.commit()
    res = await client.post(
        f"{API}/users/me/delete",
        headers=customer,
        json={"current_password": PASSWORD, "confirmation": "ELIMINAR"},
    )
    assert res.status_code in (200, 204), res.text
    staff = (await client.get(f"{API}/admin/reservations/{r['id']}/messages", headers=admin)).json()
    assert staff["messages"][0]["body"] is None
