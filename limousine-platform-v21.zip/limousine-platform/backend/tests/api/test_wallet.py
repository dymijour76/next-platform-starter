"""Billetera: créditos, pago con saldo, reembolsos al saldo, recargas, integridad y privacidad."""

import asyncio
from datetime import date
from decimal import Decimal

import pytest
from httpx import AsyncClient
from sqlalchemy import func, select, text
from sqlalchemy.exc import DBAPIError

from app.core.config import get_settings
from app.db.session import SessionLocal
from app.wallet.models import Wallet, WalletEntry

from .conftest import PASSWORD, Outbox, auth_headers
from .test_reservations import book, setup, weekday_noon

API = "/api/v1"


async def me(client: AsyncClient, headers: dict[str, str]) -> str:
    return (await client.get(f"{API}/auth/me", headers=headers)).json()["id"]


async def credit(client: AsyncClient, finance: dict[str, str], user_id: str, amount: int) -> None:
    res = await client.post(
        f"{API}/admin/users/{user_id}/wallet/credits",
        headers=finance,
        json={"amount": amount, "reason": "Compensación por demora"},
    )
    assert res.status_code == 201, res.text


async def balance(client: AsyncClient, headers: dict[str, str]) -> Decimal:
    return Decimal((await client.get(f"{API}/wallet", headers=headers)).json()["balance"])


async def test_credit_permissions_and_translation(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, _ = await setup(client)
    uid = await me(client, customer)
    admin = await auth_headers(client, "general@example.com", ("super_admin",))
    finance = await auth_headers(client, "finanzas@example.com", ("finance_admin",))
    bookings = await auth_headers(client, "reservas@example.com", ("reservations_admin",))
    body = {"amount": 20000, "reason": "Compensación por demora"}
    # Finanzas consulta la billetera, pero no mueve dinero (no tiene payments:refund).
    assert (await client.get(f"{API}/admin/users/{uid}/wallet", headers=finance)).status_code == 200
    res = await client.post(f"{API}/admin/users/{uid}/wallet/credits", headers=finance, json=body)
    assert res.status_code == 403
    assert (
        await client.post(f"{API}/admin/users/{uid}/wallet/credits", headers=bookings, json=body)
    ).status_code == 403
    assert (
        await client.post(f"{API}/admin/users/{uid}/wallet/credits", headers=customer, json=body)
    ).status_code == 403
    too_big = {**body, "amount": get_settings().wallet_credit_max + 1}
    finance = admin  # desde aquí, quien otorga es el administrador general
    assert (
        await client.post(f"{API}/admin/users/{uid}/wallet/credits", headers=finance, json=too_big)
    ).status_code == 400
    await credit(client, finance, uid, 20000)
    w = (await client.get(f"{API}/wallet", headers={**customer, "Accept-Language": "en"})).json()
    assert Decimal(w["balance"]) == 20000 and w["topup_enabled"] is False
    assert w["entries"][0]["description"] == "Credit granted"
    assert (
        w["entries"][0]["reason"] == "Compensación por demora"
    )  # lo escrito por el personal, tal cual


async def test_pay_with_wallet_and_refund_to_wallet(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    uid = await me(client, customer)
    finance = await auth_headers(client, "general@example.com", ("super_admin",))
    r = await book(client, customer, service_id=sid, pickup=weekday_noon(days_ahead=10))
    total = Decimal(r["total_amount"])

    # Sin saldo suficiente: nada cambia.
    await credit(client, finance, uid, int(total) - 1000)
    res = await client.post(f"{API}/reservations/{r['code']}/pay-with-wallet", headers=customer)
    assert res.status_code == 409 and res.json()["error"]["code"] == "INSUFFICIENT_BALANCE"
    assert (await client.get(f"{API}/reservations/{r['code']}", headers=customer)).json()[
        "status"
    ] == "PENDING_PAYMENT"
    assert await balance(client, customer) == total - 1000

    # Con saldo: se confirma, con su email y sin cobrar por la pasarela.
    await credit(client, finance, uid, 1000)
    outbox.messages.clear()
    res = await client.post(f"{API}/reservations/{r['code']}/pay-with-wallet", headers=customer)
    assert res.status_code == 200, res.text
    out = res.json()
    assert out["status"] == "CONFIRMED" and out["payments"][0]["provider"] == "wallet"
    assert await balance(client, customer) == 0
    assert any("confirmada" in m.subject for m in outbox.messages)

    # Cancelación con más de 24 h: el reembolso total vuelve al saldo.
    res = await client.post(f"{API}/reservations/{r['code']}/cancel", headers=customer, json={})
    assert res.status_code == 200, res.text
    assert await balance(client, customer) == total
    kinds = [
        e["kind"] for e in (await client.get(f"{API}/wallet", headers=customer)).json()["entries"]
    ]
    assert kinds[:2] == ["REFUND", "PAYMENT"]


async def test_no_double_spending(client: AsyncClient, outbox: Outbox) -> None:
    """Dos pagos simultáneos con un saldo que alcanza para uno: sólo uno pasa."""
    _, customer, sid = await setup(client, fleet_size=2)
    uid = await me(client, customer)
    finance = await auth_headers(client, "general@example.com", ("super_admin",))
    a = await book(client, customer, service_id=sid, pickup=weekday_noon(days_ahead=10))
    b = await book(client, customer, service_id=sid, pickup=weekday_noon(days_ahead=11))
    await credit(client, finance, uid, int(Decimal(a["total_amount"])))
    results = await asyncio.gather(
        client.post(f"{API}/reservations/{a['code']}/pay-with-wallet", headers=customer),
        client.post(f"{API}/reservations/{b['code']}/pay-with-wallet", headers=customer),
    )
    assert sorted(r.status_code for r in results) == [200, 409]
    assert await balance(client, customer) == 0


async def test_topup(client: AsyncClient, outbox: Outbox, monkeypatch: pytest.MonkeyPatch) -> None:
    admin, customer, sid = await setup(client)
    assert (
        await client.post(f"{API}/wallet/topups", headers=customer, json={"amount": 50000})
    ).json()["error"]["code"] == "TOPUP_DISABLED"

    monkeypatch.setattr(get_settings(), "wallet_topup_enabled", True)
    assert (
        await client.post(f"{API}/wallet/topups", headers=customer, json={"amount": 500})
    ).status_code == 409
    start = await client.post(f"{API}/wallet/topups", headers=customer, json={"amount": 500000})
    assert start.status_code == 200, start.text
    token = start.json()["fields"]["token_ws"]
    back = await client.post(f"{API}/payments/simulator/{token}", json={"decision": "approve"})
    res = (await client.post(f"{API}/payments/return", json=back.json()["fields"])).json()
    assert res == {"reservation_code": None, "outcome": "paid", "topup": True}
    assert await balance(client, customer) == 500000

    # En el panel: la recarga aparece y cuenta como cobrada; no es una venta en los reportes.
    payments = (await client.get(f"{API}/admin/payments", headers=admin)).json()
    assert (
        payments["items"][0]["is_topup"] is True
        and Decimal(payments["totals"]["collected"]) == 500000
    )
    today = date.today().isoformat()
    res = await client.get(
        f"{API}/admin/reports/revenue?date_from={today}&date_to={today}", headers=admin
    )
    assert res.status_code == 200, res.text
    assert Decimal(res.json()["collected"]) == 0  # la recarga no es una venta

    # Pagar una reserva con ese saldo: no se vuelve a sumar como cobrado.
    r = await book(client, customer, service_id=sid, pickup=weekday_noon(days_ahead=10))
    assert (
        await client.post(f"{API}/reservations/{r['code']}/pay-with-wallet", headers=customer)
    ).status_code == 200
    payments = (await client.get(f"{API}/admin/payments", headers=admin)).json()
    assert Decimal(payments["totals"]["collected"]) == 500000

    # Devolver la recarga ya no es posible: el saldo se usó (y la pasarela no se llama).
    topup_id = next(p["id"] for p in payments["items"] if p["is_topup"])
    res = await client.post(
        f"{API}/admin/payments/{topup_id}/refund",
        headers=admin,
        json={"amount": 500000, "reason": "Solicitud del cliente"},
    )
    assert res.json()["error"]["code"] == "INSUFFICIENT_BALANCE"


async def test_ledger_integrity(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, sid = await setup(client)
    uid = await me(client, customer)
    finance = await auth_headers(client, "general@example.com", ("super_admin",))
    await credit(client, finance, uid, 300000)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon(days_ahead=10))
    await client.post(f"{API}/reservations/{r['code']}/pay-with-wallet", headers=customer)
    async with SessionLocal() as db:
        wallet = await db.scalar(select(Wallet))
        assert wallet is not None
        total = await db.scalar(
            select(func.sum(WalletEntry.amount)).where(WalletEntry.wallet_id == wallet.id)
        )
        assert total == wallet.balance  # el saldo es la suma de los movimientos
        with pytest.raises(DBAPIError, match="no se modifican ni se borran"):
            await db.execute(text("UPDATE wallet_entries SET amount = 999999"))
        await db.rollback()
        with pytest.raises(DBAPIError, match="no se modifican ni se borran"):
            await db.execute(text("DELETE FROM wallet_entries"))
        await db.rollback()
        with pytest.raises(DBAPIError):  # saldo negativo: lo impide la base de datos
            await db.execute(text("UPDATE wallets SET balance = -1"))
        await db.rollback()


async def test_privacy(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, _ = await setup(client)
    uid = await me(client, customer)
    finance = await auth_headers(client, "general@example.com", ("super_admin",))
    await credit(client, finance, uid, 10000)
    export = (await client.get(f"{API}/users/me/export", headers=customer)).json()
    assert export["billetera"]["saldo"] == "10000.00"
    res = await client.post(
        f"{API}/users/me/delete",
        headers=customer,
        json={"current_password": PASSWORD, "confirmation": "ELIMINAR"},
    )
    assert res.status_code == 409 and "saldo" in res.json()["error"]["message"]


async def test_stale_balance_is_never_used(client: AsyncClient, outbox: Outbox) -> None:
    """La sesión A leyó la billetera antes de que B gastara el saldo: al bloquearla, A debe ver
    el saldo nuevo (no el que tenía en memoria). Secuencia forzada, sin depender de tiempos."""
    from app.wallet import service as wallet
    from app.wallet.models import PAYMENT

    _, customer, _ = await setup(client)
    uid = await me(client, customer)
    admin = await auth_headers(client, "general@example.com", ("super_admin",))
    await credit(client, admin, uid, 1000)
    async with SessionLocal() as a, SessionLocal() as b:
        await wallet.get_or_create(a, uid)  # A lee: saldo 1000
        await wallet.post(b, uid, Decimal(-1000), PAYMENT, "Pago de la reserva X")  # B gasta todo
        await b.commit()
        with pytest.raises(wallet.InsufficientBalance):
            await wallet.post(a, uid, Decimal(-1000), PAYMENT, "Pago de la reserva Y")
        await a.rollback()
    assert await balance(client, customer) == 0


async def test_wallet_number(client: AsyncClient, outbox: Outbox) -> None:
    """Número único "LP-4821-7730": estable, válido y útil para encontrar al cliente."""
    from app.wallet import numbers

    _, customer, _ = await setup(client)
    admin = await auth_headers(client, "general@example.com", ("super_admin",))
    first = (await client.get(f"{API}/wallet", headers=customer)).json()
    again = (await client.get(f"{API}/wallet", headers=customer)).json()
    number = first["number"]
    assert numbers.normalize(number) == number and again["number"] == number
    assert first["holder"].strip()

    async def found(q: str) -> list[str]:
        res = await client.get(f"{API}/users", headers=admin, params={"q": q})
        return [u["email"] for u in res.json()["items"]]

    email = (await client.get(f"{API}/auth/me", headers=customer)).json()["email"]
    assert await found(number) == [email]
    assert await found(number.replace("-", "").lower()) == [email]  # sin guiones
    wrong = number[:-1] + str((int(number[-1]) + 1) % 10)  # dígito de verificación equivocado
    assert email not in await found(wrong)


def test_wallet_number_detects_typos() -> None:
    from app.wallet import numbers

    for _ in range(200):
        n = numbers.generate()
        digits = n.replace("LP-", "").replace("-", "")
        assert numbers.normalize(n) == n
        for i in range(8):  # cualquier dígito cambiado
            changed = digits[:i] + str((int(digits[i]) + 3) % 10) + digits[i + 1 :]
            assert numbers.normalize(f"LP-{changed[:4]}-{changed[4:]}") is None
        for i in range(7):  # dos dígitos vecinos invertidos (si son distintos)
            if digits[i] != digits[i + 1] and {digits[i], digits[i + 1]} != {"0", "9"}:
                swapped = digits[:i] + digits[i + 1] + digits[i] + digits[i + 2 :]
                assert numbers.normalize(f"LP-{swapped[:4]}-{swapped[4:]}") is None
