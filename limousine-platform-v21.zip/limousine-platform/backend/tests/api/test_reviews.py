"""Reseñas: sólo de viajes completados, una por reserva, moderación honesta y privacidad."""

from datetime import UTC, datetime, timedelta

from httpx import AsyncClient
from sqlalchemy import update

from app.db.session import SessionLocal
from app.reservations.models import Reservation, ReservationEvent

from .conftest import PASSWORD, Outbox, auth_headers
from .test_fleet import assign, confirmed, new_driver, vehicle_ids
from .test_reservations import setup, weekday_noon

API = "/api/v1"


async def completed_trip(client: AsyncClient, outbox: Outbox):  # type: ignore[no-untyped-def]
    """Reserva confirmada, asignada a un conductor y completada (con la recogida en el pasado)."""
    admin, customer, sid = await setup(client)
    r = await confirmed(client, admin, customer, sid, weekday_noon())
    driver = await new_driver(client, admin, "jorge@example.com")
    vid = (await vehicle_ids(client, admin, sid))[0]
    assert (
        await assign(client, admin, r["id"], vehicle_id=vid, driver_id=driver["id"])
    ).status_code == 200
    async with SessionLocal() as db:
        await db.execute(
            update(Reservation)
            .where(Reservation.id == r["id"])
            .values(pickup_at=datetime.now(UTC) - timedelta(hours=5))
        )
        await db.commit()
    outbox.messages.clear()
    res = await client.post(f"{API}/admin/reservations/{r['id']}/complete", headers=admin, json={})
    assert res.status_code == 200, res.text
    return admin, customer, r, driver, sid


async def test_invitation_and_eligibility(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, sid = await setup(client)
    pending = await confirmed(client, admin, customer, sid, weekday_noon(days_ahead=15))
    state = (
        await client.get(f"{API}/reservations/{pending['code']}/review", headers=customer)
    ).json()
    assert state["eligible"] is False  # aún no se completa
    res = await client.post(
        f"{API}/reservations/{pending['code']}/review", headers=customer, json={"service_rating": 5}
    )
    assert res.json()["error"]["code"] == "NOT_REVIEWABLE"


async def test_review_lifecycle(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, r, driver, _ = await completed_trip(client, outbox)
    assert any(
        "¿Cómo estuvo su viaje?" in m.subject for m in outbox.messages
    )  # invitación por email
    code = r["code"]
    state = (await client.get(f"{API}/reservations/{code}/review", headers=customer)).json()
    assert state["eligible"] is True and state["has_driver"] is True

    body = {
        "service_rating": 4,
        "driver_rating": 5,
        "comment": "Muy puntual y amable.",
        "consent_publish": True,
    }
    res = await client.post(f"{API}/reservations/{code}/review", headers=customer, json=body)
    assert res.status_code == 201 and res.json()["status"] == "PENDING"
    again = await client.post(f"{API}/reservations/{code}/review", headers=customer, json=body)
    assert again.json()["error"]["code"] == "ALREADY_REVIEWED"

    # Las estrellas cuentan de inmediato; el comentario espera revisión.
    service = (await client.get(f"{API}/services")).json()[0]
    assert service["rating"] == {"average": 4.0, "count": 1}
    assert (await client.get(f"{API}/reviews")).json() == []

    page = (await client.get(f"{API}/admin/reviews", headers=admin)).json()
    assert page["pending"] == 1 and page["items"][0]["driver_name"] == "Jorge Vidal"
    rid = page["items"][0]["id"]
    await client.post(
        f"{API}/admin/reviews/{rid}/moderate", headers=admin, json={"action": "publish"}
    )
    public = (await client.get(f"{API}/reviews")).json()
    assert [(p["comment"], p["service_rating"]) for p in public] == [("Muy puntual y amable.", 4)]
    assert public[0]["display_name"].endswith(".")  # "Nombre I."

    # Ocultar el comentario lo saca del sitio, pero sus estrellas siguen en el promedio.
    await client.post(f"{API}/admin/reviews/{rid}/moderate", headers=admin, json={"action": "hide"})
    assert (await client.get(f"{API}/reviews")).json() == []
    assert (await client.get(f"{API}/services")).json()[0]["rating"]["count"] == 1

    # La calificación del conductor la ve el personal.
    d = (await client.get(f"{API}/admin/drivers/{driver['id']}", headers=admin)).json()
    assert (d["rating_average"], d["rating_count"]) == (5.0, 1)

    # Otro cliente no puede ver ni calificar esa reserva.
    other = await auth_headers(client, "otro@example.com", ("customer",))
    assert (await client.get(f"{API}/reservations/{code}/review", headers=other)).status_code == 404


async def test_without_consent_never_public(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, r, _, _ = await completed_trip(client, outbox)
    body = {"service_rating": 2, "comment": "Llegó tarde.", "consent_publish": False}
    res = await client.post(f"{API}/reservations/{r['code']}/review", headers=customer, json=body)
    assert res.json()["status"] == "PUBLISHED"  # suma sus estrellas, sin texto público
    assert (await client.get(f"{API}/reviews")).json() == []
    rid = (await client.get(f"{API}/admin/reviews?status=all", headers=admin)).json()["items"][0][
        "id"
    ]
    res = await client.post(
        f"{API}/admin/reviews/{rid}/moderate", headers=admin, json={"action": "publish"}
    )
    assert res.json()["error"]["code"] == "NOT_PUBLISHABLE"


async def test_thirty_day_window(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, r, _, _ = await completed_trip(client, outbox)
    async with SessionLocal() as db:
        await db.execute(
            update(ReservationEvent)
            .where(ReservationEvent.reservation_id == r["id"])
            .values(created_at=datetime.now(UTC) - timedelta(days=31))
        )
        await db.commit()
    res = await client.post(
        f"{API}/reservations/{r['code']}/review", headers=customer, json={"service_rating": 5}
    )
    assert res.json()["error"]["code"] == "NOT_REVIEWABLE"


async def test_account_deletion_anonymizes_review(client: AsyncClient, outbox: Outbox) -> None:
    admin, customer, r, _, _ = await completed_trip(client, outbox)
    body = {"service_rating": 5, "comment": "Excelente.", "consent_publish": True}
    await client.post(f"{API}/reservations/{r['code']}/review", headers=customer, json=body)
    res = await client.post(
        f"{API}/users/me/delete",
        headers=customer,
        json={"current_password": PASSWORD, "confirmation": "ELIMINAR"},
    )
    assert res.status_code in (200, 204), res.text
    item = (await client.get(f"{API}/admin/reviews?status=all", headers=admin)).json()["items"][0]
    assert (item["comment"], item["display_name"]) == (None, "Cliente")
    assert (await client.get(f"{API}/services")).json()[0]["rating"]["count"] == 1
