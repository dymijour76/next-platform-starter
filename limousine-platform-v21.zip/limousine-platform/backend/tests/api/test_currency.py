"""Tasas de cambio: automáticas (validadas), manuales con prioridad y permisos."""

from decimal import Decimal
from typing import Any

import httpx
import pytest
from httpx import AsyncClient

from app.currency import service

from .conftest import auth_headers

API = "/api/v1"


def source(rates: dict[str, float]) -> Any:
    async def fake(url: str) -> dict[str, Any]:
        return {"result": "success", "base_code": "CLP", "rates": {"CLP": 1, **rates}}

    return fake


def rate(payload: dict[str, Any], code: str) -> tuple[Decimal | None, str]:
    item = next(c for c in payload["currencies"] if c["code"] == code)
    return (Decimal(item["rate"]) if item["rate"] else None, item["source"])


async def test_automatic_rates_are_validated(
    client: AsyncClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    # 1 CLP = 0.00106 USD → 943.3962 CLP por dólar
    monkeypatch.setattr(
        service, "_get_json", source({"USD": 0.00106, "EUR": 0.00098, "BRL": 0.0058})
    )
    assert (await client.post(f"{API}/admin/currencies/refresh", headers=admin)).status_code == 200
    public = (await client.get(f"{API}/currencies")).json()
    assert rate(public, "USD") == (Decimal("943.3962"), "auto")
    assert public["attribution"]["name"] == "ExchangeRate-API"

    # Un dólar a 5 pesos es un error de la fuente: se descarta y queda la tasa anterior.
    monkeypatch.setattr(service, "_get_json", source({"USD": 0.2, "EUR": 0.00098, "BRL": 0.0058}))
    await client.post(f"{API}/admin/currencies/refresh", headers=admin)
    assert rate((await client.get(f"{API}/currencies")).json(), "USD")[0] == Decimal("943.3962")

    # La fuente no responde: error claro y se mantienen las tasas.
    async def down(url: str) -> dict[str, Any]:
        raise httpx.ConnectError("sin conexión")

    monkeypatch.setattr(service, "_get_json", down)
    res = await client.post(f"{API}/admin/currencies/refresh", headers=admin)
    assert res.status_code == 502 and res.json()["error"]["code"] == "RATES_UNAVAILABLE"
    assert rate((await client.get(f"{API}/currencies")).json(), "USD")[0] == Decimal("943.3962")


async def test_manual_rate_takes_priority(
    client: AsyncClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    monkeypatch.setattr(
        service, "_get_json", source({"USD": 0.00106, "EUR": 0.00098, "BRL": 0.0058})
    )
    await client.post(f"{API}/admin/currencies/refresh", headers=admin)
    res = await client.put(
        f"{API}/admin/currencies/USD", headers=admin, json={"manual_rate": "950"}
    )
    assert res.status_code == 200
    assert rate((await client.get(f"{API}/currencies")).json(), "USD") == (Decimal("950"), "manual")
    await client.put(f"{API}/admin/currencies/USD", headers=admin, json={"manual_rate": None})
    assert rate((await client.get(f"{API}/currencies")).json(), "USD") == (
        Decimal("943.3962"),
        "auto",
    )
    assert (
        await client.put(f"{API}/admin/currencies/USD", headers=admin, json={"manual_rate": "-5"})
    ).status_code == 422

    customer = await auth_headers(client, "ana@example.com", ("customer",))
    res = await client.put(
        f"{API}/admin/currencies/USD", headers=customer, json={"manual_rate": "1"}
    )
    assert res.status_code == 403
