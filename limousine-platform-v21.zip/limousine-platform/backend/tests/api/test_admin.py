"""Administración de usuarios y roles: permisos y protección contra escaladas."""

from httpx import AsyncClient
from sqlalchemy import select

from app.audit.models import AuditLog
from app.db.session import SessionLocal

from .conftest import Outbox, auth_headers, bearer, create_role, create_user, login

API = "/api/v1"
NEW = "clave-del-nuevo-usuario"


async def test_customer_cannot_access_admin_endpoints(client: AsyncClient) -> None:
    headers = await auth_headers(client, "cliente@example.com", ("customer",))
    for method, path in [
        ("GET", "/users"),
        ("POST", "/users"),
        ("GET", "/roles"),
        ("GET", "/permissions"),
    ]:
        res = await client.request(method, f"{API}{path}", headers=headers, json={})
        assert res.status_code == 403, path
        assert res.json()["error"]["code"] == "PERMISSION_DENIED"


async def test_list_users_with_filters(client: AsyncClient) -> None:
    headers = await auth_headers(client, "admin@example.com", ("super_admin",))
    for i in range(3):
        await create_user(f"cliente{i}@example.com")
    await create_user("chofer@example.com", ("driver",))

    res = await client.get(f"{API}/users", headers=headers, params={"page_size": 2})
    body = res.json()
    assert body["total"] == 5 and len(body["items"]) == 2

    res = await client.get(f"{API}/users", headers=headers, params={"role": "driver"})
    assert [u["email"] for u in res.json()["items"]] == ["chofer@example.com"]

    res = await client.get(f"{API}/users", headers=headers, params={"q": "cliente1"})
    assert [u["email"] for u in res.json()["items"]] == ["cliente1@example.com"]


async def test_invite_staff_member(client: AsyncClient, outbox: Outbox) -> None:
    headers = await auth_headers(client, "admin@example.com", ("super_admin",))
    res = await client.post(
        f"{API}/users",
        headers=headers,
        json={
            "email": "reservas@example.com",
            "first_name": "Luis",
            "last_name": "Soto",
            "roles": ["reservations_admin"],
        },
    )
    assert res.status_code == 201, res.text
    assert "Administrador de reservas" in outbox.messages[-1].text

    # La persona invitada crea su contraseña con el enlace y entra con sus permisos.
    token = outbox.last_token("reservas@example.com")
    body = {"token": token, "password": NEW, "password_confirmation": NEW}
    assert (await client.post(f"{API}/auth/reset-password", json=body)).status_code == 204
    me = (
        await client.get(
            f"{API}/auth/me", headers=bearer(await login(client, "reservas@example.com", NEW))
        )
    ).json()
    assert me["email_verified"] is True
    assert "reservations:assign" in me["permissions"]
    assert "payments:read" not in me["permissions"]


async def test_role_without_users_write_cannot_create_users(client: AsyncClient) -> None:
    headers = await auth_headers(client, "reservas@example.com", ("reservations_admin",))
    res = await client.post(
        f"{API}/users",
        headers=headers,
        json={"email": "x@example.com", "first_name": "X", "last_name": "Y", "roles": ["driver"]},
    )
    assert res.status_code == 403


async def test_cannot_grant_permissions_you_do_not_have(client: AsyncClient) -> None:
    await create_role("jefe_personal", ["users:read", "users:write", "driver_portal:access"])
    headers = await auth_headers(client, "jefe@example.com", ("jefe_personal",))

    # Puede dar roles cuyos permisos ya tiene...
    res = await client.post(
        f"{API}/users",
        headers=headers,
        json={"email": "c@example.com", "first_name": "C", "last_name": "D", "roles": ["driver"]},
    )
    assert res.status_code == 201
    # ...pero no ascender a nadie a administrador general.
    res = await client.patch(
        f"{API}/users/{res.json()['id']}", headers=headers, json={"roles": ["super_admin"]}
    )
    assert res.status_code == 403
    assert res.json()["error"]["code"] == "PRIVILEGE_ESCALATION"
    # Ni modificar a alguien con más permisos que él.
    boss = await create_user("jefa@example.com", ("super_admin",))
    res = await client.patch(
        f"{API}/users/{boss.id}", headers=headers, json={"status": "SUSPENDED"}
    )
    assert res.status_code == 403


async def test_cannot_modify_own_roles_or_status(client: AsyncClient) -> None:
    admin = await create_user("admin@example.com", ("super_admin",))
    headers = bearer(await login(client, admin.email))
    res = await client.patch(
        f"{API}/users/{admin.id}", headers=headers, json={"status": "SUSPENDED"}
    )
    assert res.status_code == 403
    assert res.json()["error"]["code"] == "SELF_MODIFICATION"


async def test_last_super_admin_cannot_be_removed(client: AsyncClient) -> None:
    """Aun con todos los permisos, no se puede dejar el sistema sin administrador general."""
    from app.users.rbac import PERMISSIONS

    only_admin = await create_user("unica@example.com", ("super_admin",))
    await create_role("casi_admin", list(PERMISSIONS))
    headers = await auth_headers(client, "casi@example.com", ("casi_admin",))

    for change in ({"status": "SUSPENDED"}, {"roles": ["customer"]}):
        res = await client.patch(f"{API}/users/{only_admin.id}", headers=headers, json=change)
        assert res.status_code == 409, change
        assert res.json()["error"]["code"] == "LAST_SUPER_ADMIN"


async def test_suspension_ends_sessions_immediately(client: AsyncClient) -> None:
    headers = await auth_headers(client, "admin@example.com", ("super_admin",))
    target = await create_user("cliente@example.com")
    target_tokens = await login(client, target.email)

    res = await client.patch(
        f"{API}/users/{target.id}", headers=headers, json={"status": "SUSPENDED"}
    )
    assert res.status_code == 200
    assert (await client.get(f"{API}/auth/me", headers=bearer(target_tokens))).status_code == 401
    res = await client.post(
        f"{API}/auth/refresh", json={"refresh_token": target_tokens["refresh_token"]}
    )
    assert res.status_code == 401


async def test_role_changes_apply_without_new_login(client: AsyncClient) -> None:
    headers = await auth_headers(client, "admin@example.com", ("super_admin",))
    staff = await create_user("staff@example.com", ("finance_admin",))
    staff_headers = bearer(await login(client, staff.email))
    assert (await client.get(f"{API}/users", headers=staff_headers)).status_code == 403

    await client.patch(f"{API}/users/{staff.id}", headers=headers, json={"roles": ["super_admin"]})
    assert (await client.get(f"{API}/users", headers=staff_headers)).status_code == 200


async def test_roles_management(client: AsyncClient) -> None:
    headers = await auth_headers(client, "admin@example.com", ("super_admin",))

    roles = {r["code"]: r for r in (await client.get(f"{API}/roles", headers=headers)).json()}
    assert roles["super_admin"]["user_count"] == 1
    assert roles["finance_admin"]["is_system"] is True

    res = await client.post(
        f"{API}/roles",
        headers=headers,
        json={"code": "despacho", "name": "Despacho", "permissions": ["reservations:read"]},
    )
    assert res.status_code == 201
    role_id = res.json()["id"]

    res = await client.put(
        f"{API}/roles/{role_id}",
        headers=headers,
        json={"permissions": ["reservations:read", "reservations:assign"]},
    )
    assert res.json()["permissions"] == ["reservations:assign", "reservations:read"]

    unknown = await client.post(
        f"{API}/roles",
        headers=headers,
        json={"code": "raro", "name": "Raro", "permissions": ["no:existe"]},
    )
    assert unknown.json()["error"]["code"] == "UNKNOWN_PERMISSION"

    protected = await client.put(
        f"{API}/roles/{roles['super_admin']['id']}", headers=headers, json={"permissions": []}
    )
    assert protected.status_code == 409
    system = await client.delete(f"{API}/roles/{roles['driver']['id']}", headers=headers)
    assert system.status_code == 409
    in_use = await client.delete(f"{API}/roles/{roles['super_admin']['id']}", headers=headers)
    assert in_use.status_code == 409
    assert (await client.delete(f"{API}/roles/{role_id}", headers=headers)).status_code == 204


async def test_admin_actions_are_audited(client: AsyncClient, outbox: Outbox) -> None:
    admin = await create_user("admin@example.com", ("super_admin",))
    headers = bearer(await login(client, admin.email))
    target = await create_user("cliente@example.com")
    await client.patch(f"{API}/users/{target.id}", headers=headers, json={"status": "SUSPENDED"})
    await client.post(
        f"{API}/roles", headers=headers, json={"code": "nuevo", "name": "Nuevo", "permissions": []}
    )

    async with SessionLocal() as db:
        logs = list(await db.scalars(select(AuditLog).order_by(AuditLog.created_at)))
    assert [log.action for log in logs] == ["USER_UPDATE", "ROLE_CREATE"]
    update = logs[0]
    assert str(update.actor_user_id) == admin.id
    assert update.entity_id == target.id
    assert update.before is not None and update.before["status"] == "ACTIVE"
    assert update.after is not None and update.after["status"] == "SUSPENDED"
    assert update.request_id is not None


async def test_unknown_user_returns_404(client: AsyncClient) -> None:
    headers = await auth_headers(client, "admin@example.com", ("super_admin",))
    res = await client.get(f"{API}/users/00000000-0000-0000-0000-000000000000", headers=headers)
    assert res.status_code == 404
    res = await client.get(f"{API}/users/no-es-uuid", headers=headers)
    assert res.status_code == 422
