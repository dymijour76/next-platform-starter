"""Ley 21.719: exportación de datos y eliminación (anonimización) de la cuenta."""

import json

from httpx import AsyncClient
from sqlalchemy import select, update

from app.audit.models import AuditLog
from app.db.session import SessionLocal
from app.payments.models import Payment
from app.reservations.models import Reservation

from .conftest import PASSWORD, Outbox
from .test_payments import pay
from .test_reservations import book, setup, weekday_noon

API = "/api/v1"
DELETE = {"current_password": PASSWORD, "confirmation": "eliminar"}


async def paid_and_completed(client: AsyncClient) -> tuple[dict[str, str], dict[str, str], dict]:
    admin, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon(), notes="Aniversario")
    await pay(client, customer, r["code"], "approve")
    async with SessionLocal() as db:
        await db.execute(update(Reservation).values(status="COMPLETED"))
        await db.commit()
    return admin, customer, r


async def test_export_contains_my_data(client: AsyncClient, outbox: Outbox) -> None:
    _, customer, r = await paid_and_completed(client)
    res = await client.get(f"{API}/users/me/export", headers=customer)
    assert res.headers["content-disposition"] == 'attachment; filename="mis-datos.json"'
    data = json.loads(res.content)
    assert data["cuenta"]["email"] == "ana@example.com"
    [reservation] = data["reservas"]
    assert reservation["codigo"] == r["code"] and reservation["indicaciones"] == "Aniversario"
    assert reservation["pagos"][0]["tarjeta_terminada_en"] == "6623"


async def test_delete_account_anonymizes_and_keeps_records(
    client: AsyncClient, outbox: Outbox
) -> None:
    _, customer, r = await paid_and_completed(client)
    res = await client.post(f"{API}/users/me/delete", headers=customer, json=DELETE)
    assert res.status_code == 204, res.text

    # Aviso al email original, y la sesión quedó cerrada.
    assert outbox.messages[-1].to == "ana@example.com"
    assert outbox.messages[-1].subject == "Su cuenta fue eliminada"
    assert (await client.get(f"{API}/auth/me", headers=customer)).status_code == 401
    res = await client.post(
        f"{API}/auth/login", json={"email": "ana@example.com", "password": PASSWORD}
    )
    assert res.status_code == 401

    async with SessionLocal() as db:
        reservation = await db.scalar(select(Reservation).where(Reservation.code == r["code"]))
        payment = await db.scalar(select(Payment))
        logs = list(await db.scalars(select(AuditLog).where(AuditLog.entity_type == "user")))
    assert reservation is not None and payment is not None
    # Se conserva el registro contable...
    assert str(reservation.total_amount) == "140000.00" and payment.authorization_code
    # ...sin datos personales.
    assert reservation.contact_name == "Cliente eliminado"
    assert "ana" not in reservation.contact_email and reservation.contact_phone == ""
    assert reservation.pickup_address == "[eliminado]" and reservation.notes is None
    assert payment.card_last4 is None
    assert all(
        log.before is None and log.after is None for log in logs if log.action != "ACCOUNT_DELETED"
    )

    # El email queda libre: la persona puede volver a registrarse.
    again = await client.post(
        f"{API}/auth/register",
        json={
            "email": "ana@example.com",
            "password": PASSWORD,
            "password_confirmation": PASSWORD,
            "first_name": "Ana",
            "last_name": "Pérez",
            "accept_terms": True,
        },
    )
    assert again.status_code == 201


async def test_delete_is_blocked_with_active_reservations(
    client: AsyncClient, outbox: Outbox
) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon())
    res = await client.post(f"{API}/users/me/delete", headers=customer, json=DELETE)
    assert res.json()["error"]["code"] == "ACTIVE_RESERVATIONS"
    assert r["code"] in res.json()["error"]["message"]


async def test_delete_requires_password_and_confirmation(
    client: AsyncClient, outbox: Outbox
) -> None:
    _, customer, _ = await setup(client)
    res = await client.post(
        f"{API}/users/me/delete", headers=customer, json={**DELETE, "current_password": "otra"}
    )
    assert res.json()["error"]["code"] == "INVALID_CURRENT_PASSWORD"
    res = await client.post(
        f"{API}/users/me/delete", headers=customer, json={**DELETE, "confirmation": "sí"}
    )
    assert res.json()["error"]["code"] == "CONFIRMATION_REQUIRED"
    assert (await client.get(f"{API}/auth/me", headers=customer)).status_code == 200


async def test_staff_cannot_self_delete(client: AsyncClient, outbox: Outbox) -> None:
    admin, _, _ = await setup(client)
    res = await client.post(f"{API}/users/me/delete", headers=admin, json=DELETE)
    assert res.json()["error"]["code"] == "ACCOUNT_DELETE_NOT_ALLOWED"
