"""Panel de indicadores y reportes: zona horaria, periodos, permisos y CSV."""

import secrets
import uuid
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from typing import Any
from zoneinfo import ZoneInfo

from httpx import AsyncClient

from app.db.session import SessionLocal
from app.payments.models import Payment, Refund
from app.reservations.models import Reservation
from app.services.models import Service

from .conftest import auth_headers

API = "/api/v1"
SCL = ZoneInfo("America/Santiago")


async def service(name: str = "Premium") -> uuid.UUID:
    async with SessionLocal() as db:
        s = Service(
            slug=name.lower(),
            name=name,
            passenger_capacity=8,
            hourly_rate=Decimal(60000),
            min_hours=Decimal(2),
        )
        db.add(s)
        await db.commit()
        return s.id


async def reservation(
    service_id: uuid.UUID,
    pickup: datetime,
    status: str = "COMPLETED",
    total: int = 100000,
    created: datetime | None = None,
    **extra: Any,
) -> uuid.UUID:
    async with SessionLocal() as db:
        code = f"RES-2026-{secrets.randbelow(10**6):06d}"
        r = Reservation(
            code=code,
            service_id=service_id,
            status=status,
            pickup_at=pickup,
            duration_minutes=120,
            end_at=pickup + timedelta(hours=2),
            blocks_until=pickup + timedelta(hours=3),
            pickup_address="Av. Apoquindo 3000",
            passenger_count=2,
            contact_name="Ana Pérez",
            contact_email="ana@example.com",
            contact_phone="+56912345678",
            currency="CLP",
            total_amount=Decimal(total),
            pricing_snapshot={"pickup_local": pickup.isoformat()},
            cancellation_policy_snapshot={"text": "x"},
            qr_token=secrets.token_urlsafe(8),
            **extra,
        )
        db.add(r)
        await db.flush()
        if created:
            r.created_at = created
        await db.commit()
        return r.id


async def payment(
    reservation_id: uuid.UUID,
    amount: int,
    authorized: datetime,
    refunds: list[tuple[int, datetime, str]] = (),
) -> None:  # type: ignore[assignment]
    async with SessionLocal() as db:
        refunded = sum(a for a, _, st in refunds if st == "SUCCEEDED")
        status = (
            "AUTHORIZED"
            if not refunded
            else ("REFUNDED" if refunded >= amount else "PARTIALLY_REFUNDED")
        )
        p = Payment(
            reservation_id=reservation_id,
            provider="simulated",
            status=status,
            amount=Decimal(amount),
            currency="CLP",
            refunded_amount=Decimal(refunded),
            buy_order=f"B{secrets.token_hex(6)}",
            session_id="s",
            authorized_at=authorized,
            expires_at=authorized,
        )
        db.add(p)
        await db.flush()
        for amt, when, st in refunds:
            f = Refund(payment_id=p.id, amount=Decimal(amt), status=st)
            db.add(f)
            await db.flush()
            f.created_at = when
        await db.commit()


def local(*args: int) -> datetime:
    return datetime(*args, tzinfo=SCL)  # type: ignore[misc]


async def admin(client: AsyncClient) -> dict[str, str]:
    return await auth_headers(client, "admin@example.com", ("super_admin",))


# ------------------------------------------------------------------ ingresos


async def test_revenue_groups_by_local_month(client: AsyncClient) -> None:
    """Un pago del 31 de mayo a las 23:30 en Santiago es de mayo, aunque en UTC ya sea junio."""
    headers = await admin(client)
    sid = await service()
    late_may = local(2026, 5, 31, 23, 30)
    assert late_may.astimezone(UTC).month == 6
    r1 = await reservation(sid, late_may)
    r2 = await reservation(sid, local(2026, 6, 10, 12, 0))
    await payment(
        r1,
        120000,
        late_may,
        refunds=[
            (20000, local(2026, 6, 2, 10, 0), "SUCCEEDED"),
            (5000, local(2026, 6, 3, 10, 0), "FAILED"),
        ],
    )
    await payment(r2, 80000, local(2026, 6, 10, 9, 0))

    res = await client.get(
        f"{API}/admin/reports/revenue",
        headers=headers,
        params={"date_from": "2026-05-01", "date_to": "2026-06-30", "group": "month"},
    )
    body = res.json()
    assert [(p["label"], p["collected"], p["refunded"], p["net"]) for p in body["series"]] == [
        ("may 2026", "120000", "0", "120000"),
        ("jun 2026", "80000", "20000", "60000"),  # el reembolso fallido no cuenta
    ]
    assert (body["collected"], body["refunded"], body["net"]) == ("200000", "20000", "180000")
    assert body["payments"] == 2 and body["average_ticket"] == "100000"
    assert body["by_service"] == [
        {"service": "Premium", "collected": "200000", "refunded": "20000", "net": "180000"}
    ]


async def test_empty_days_are_filled_with_zero(client: AsyncClient) -> None:
    headers = await admin(client)
    sid = await service()
    r = await reservation(sid, local(2026, 6, 2, 12, 0))
    await payment(r, 50000, local(2026, 6, 2, 12, 0))
    res = await client.get(
        f"{API}/admin/reports/revenue",
        headers=headers,
        params={"date_from": "2026-06-01", "date_to": "2026-06-03"},
    )
    assert [(p["period"], p["collected"]) for p in res.json()["series"]] == [
        ("2026-06-01", "0"),
        ("2026-06-02", "50000"),
        ("2026-06-03", "0"),
    ]


# ------------------------------------------------------------------ reservas


async def test_reservations_report(client: AsyncClient) -> None:
    headers = await admin(client)
    premium, standard = await service("Premium"), await service("Standard")
    day = local(2026, 6, 15, 12, 0)
    for status in (
        "COMPLETED",
        "COMPLETED",
        "CANCELLED",
        "NO_SHOW",
        "EXPIRED",
        "CONFIRMED",
        "EN_ROUTE",
    ):
        await reservation(premium, day, status, created=local(2026, 5, 20, 10, 0))
    await reservation(
        standard,
        day + timedelta(days=1),
        "PENDING_PAYMENT",
        total=50000,
        created=local(2026, 6, 15, 9, 0),
    )

    params = {"date_from": "2026-06-15", "date_to": "2026-06-16"}
    body = (
        await client.get(f"{API}/admin/reports/reservations", headers=headers, params=params)
    ).json()
    first = body["series"][0]
    assert (
        first["total"],
        first["completed"],
        first["cancelled"],
        first["no_show"],
        first["expired"],
        first["confirmed"],
    ) == (7, 2, 1, 1, 1, 2)
    assert body["series"][1]["pending"] == 1
    # Canceladas / (total - pendientes - vencidas) = 1 / (8 - 1 - 1)
    assert body["cancellation_rate"] == round(1 / 6, 4)
    premium_row = next(s for s in body["by_service"] if s["service"] == "Premium")
    # El monto excluye canceladas y vencidas: 5 reservas × 100.000
    assert (premium_row["reservations"], premium_row["amount"]) == (7, "500000")

    # Por fecha de creación, esas reservas son de mayo.
    created = await client.get(
        f"{API}/admin/reports/reservations", headers=headers, params={**params, "basis": "created"}
    )
    assert created.json()["total"] == 1  # sólo la pendiente se creó en el rango


async def test_week_starts_on_monday(client: AsyncClient) -> None:
    headers = await admin(client)
    sid = await service()
    await reservation(sid, local(2026, 6, 14, 12, 0))  # domingo
    await reservation(sid, local(2026, 6, 15, 12, 0))  # lunes
    res = await client.get(
        f"{API}/admin/reports/reservations",
        headers=headers,
        params={"date_from": "2026-06-10", "date_to": "2026-06-16", "group": "week"},
    )
    assert [(p["period"], p["total"]) for p in res.json()["series"]] == [
        ("2026-06-08", 1),
        ("2026-06-15", 1),
    ]


async def test_range_validation(client: AsyncClient) -> None:
    headers = await admin(client)
    backwards = await client.get(
        f"{API}/admin/reports/revenue",
        headers=headers,
        params={"date_from": "2026-06-10", "date_to": "2026-06-01"},
    )
    assert backwards.status_code == 422
    too_long = await client.get(
        f"{API}/admin/reports/revenue",
        headers=headers,
        params={"date_from": "2026-01-01", "date_to": "2026-12-31", "group": "day"},
    )
    assert "máximo 92 días" in str(too_long.json()["error"])
    ok = await client.get(
        f"{API}/admin/reports/revenue",
        headers=headers,
        params={"date_from": "2026-01-01", "date_to": "2026-12-31", "group": "month"},
    )
    assert len(ok.json()["series"]) == 12


async def test_csv_for_spanish_excel(client: AsyncClient) -> None:
    headers = await admin(client)
    sid = await service()
    r = await reservation(sid, local(2026, 6, 2, 12, 0))
    await payment(r, 50000, local(2026, 6, 2, 12, 0))
    res = await client.get(
        f"{API}/admin/reports/revenue.csv",
        headers=headers,
        params={"date_from": "2026-06-01", "date_to": "2026-06-02"},
    )
    assert res.headers["content-type"].startswith("text/csv")
    assert 'filename="ingresos_20260601-20260602.csv"' in res.headers["content-disposition"]
    text = res.content.decode("utf-8")
    assert text.startswith("\ufeff")  # BOM: Excel reconoce las tildes
    lines = text.lstrip("\ufeff").splitlines()
    assert lines[0] == "Periodo;Cobrado;Reembolsado;Neto;Pagos"
    assert lines[2] == "2026-06-02;50000;0;50000;1"
    res = await client.get(
        f"{API}/admin/reports/reservations.csv",
        headers=headers,
        params={"date_from": "2026-06-01", "date_to": "2026-06-02"},
    )
    assert "No se presentó" in res.content.decode("utf-8").splitlines()[0]


# ------------------------------------------------------------------ panel y permisos


async def test_dashboard_sections_follow_permissions(client: AsyncClient) -> None:
    ops = await auth_headers(client, "ops@example.com", ("reservations_admin",))
    finance = await auth_headers(client, "fin@example.com", ("finance_admin",))
    customer = await auth_headers(client, "c@example.com", ("customer",))

    ops_view = (await client.get(f"{API}/admin/dashboard", headers=ops)).json()
    assert ops_view["operations"] is not None and ops_view["fleet"] is not None
    assert ops_view["finance"] is None
    fin_view = (await client.get(f"{API}/admin/dashboard", headers=finance)).json()
    assert fin_view["finance"] is not None and fin_view["operations"] is None

    assert (await client.get(f"{API}/admin/dashboard", headers=customer)).status_code == 403
    params = {"date_from": "2026-06-01", "date_to": "2026-06-02"}
    assert (
        await client.get(f"{API}/admin/reports/revenue", headers=ops, params=params)
    ).status_code == 403
    assert (
        await client.get(f"{API}/admin/reports/revenue", headers=finance, params=params)
    ).status_code == 200
    # El rol de finanzas incluye también el reporte operativo (reports:read).
    assert (
        await client.get(f"{API}/admin/reports/reservations", headers=finance, params=params)
    ).status_code == 200


async def test_dashboard_numbers_and_alerts(client: AsyncClient) -> None:
    from app.drivers.models import Driver
    from app.users.models import User

    headers = await admin(client)
    sid = await service()
    now = datetime.now(UTC)
    await reservation(sid, now + timedelta(hours=5), "CONFIRMED")  # sin asignar, dentro de 48 h
    await reservation(sid, now + timedelta(days=4), "CONFIRMED")  # sin asignar, más adelante
    await reservation(sid, now - timedelta(minutes=10), "IN_PROGRESS")
    await reservation(
        sid, now + timedelta(days=2), "PENDING_PAYMENT", hold_expires_at=now + timedelta(minutes=20)
    )
    today_local = now.astimezone(SCL)
    r = await reservation(sid, now - timedelta(hours=30), "COMPLETED")
    await payment(
        r,
        300000,
        today_local.replace(day=1, hour=12, minute=0, second=0, microsecond=0),
        refunds=[(10000, now, "FAILED")],
    )

    async with SessionLocal() as db:
        u = User(email="d@example.com", password_hash="x", first_name="Jorge", last_name="Vidal")
        db.add(u)
        await db.flush()
        db.add(
            Driver(
                user_id=u.id,
                license_number="1",
                license_class="A2",
                license_expires_on=date.today() + timedelta(days=10),
            )
        )
        await db.commit()

    body = (await client.get(f"{API}/admin/dashboard", headers=headers)).json()
    ops = body["operations"]
    assert ops["in_progress"] == 1
    assert ops["pending_payment"] == 1
    assert ops["unassigned_upcoming"] == 2
    assert body["finance"]["month_collected"] == "300000"
    assert body["finance"]["failed_refunds"] == 1
    kinds = {a["kind"]: a for a in body["alerts"]}
    assert kinds["unassigned"]["count"] == 1  # sólo el de las próximas 48 horas
    assert kinds["unassigned"]["href"] == "/admin/reservations?unassigned=true"
    assert "failed_refunds" in kinds
    assert kinds["no_vehicles"]["text"].startswith("El servicio Premium no tiene vehículos")
    assert "Jorge Vidal" in kinds["license"]["text"]
