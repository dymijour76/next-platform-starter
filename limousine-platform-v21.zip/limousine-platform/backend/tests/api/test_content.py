"""Biblioteca de imágenes, carrusel y galería de servicios vía API."""

import io
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest
from httpx import AsyncClient
from PIL import Image

from app.media.storage import get_storage

from .conftest import auth_headers

API = "/api/v1"


@pytest.fixture
def media_dir(tmp_path: Path, settings) -> Path:  # type: ignore[no-untyped-def]
    settings.media_root = str(tmp_path)
    settings.media_base_url = "http://api.test"
    get_storage.cache_clear()
    yield tmp_path
    get_storage.cache_clear()


def jpeg(size: tuple[int, int] = (1800, 1200)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, (184, 163, 116)).save(buf, "JPEG")
    return buf.getvalue()


async def upload(
    client: AsyncClient,
    headers: dict[str, str],
    data: bytes | None = None,
    alt: str = "Limusina blanca frente a un hotel",
    name: str = "foto.jpg",
) -> Any:
    return await client.post(
        f"{API}/admin/media",
        headers=headers,
        files={"file": (name, data if data is not None else jpeg(), "image/jpeg")},
        data={"alt_text": alt},
    )


async def editor(client: AsyncClient) -> dict[str, str]:
    return await auth_headers(client, "admin@example.com", ("super_admin",))


async def test_upload_creates_variants(client: AsyncClient, media_dir: Path) -> None:
    headers = await editor(client)
    res = await upload(client, headers)
    assert res.status_code == 201, res.text
    img = res.json()
    assert img["alt"] == "Limusina blanca frente a un hotel"
    assert (img["width"], img["height"]) == (1800, 1200)
    assert img["src"] == f"http://api.test/media/{img['id']}/1600.webp"
    assert img["srcset"].count("webp") == 4
    stored = sorted(p.name for p in (media_dir / "media" / img["id"]).iterdir())
    assert stored == ["1600.webp", "1800.webp", "480.webp", "960.webp"]

    listing = (await client.get(f"{API}/admin/media", headers=headers)).json()
    assert [m["id"] for m in listing] == [img["id"]] and listing[0]["usage"] == 0


async def test_upload_validation(client: AsyncClient, media_dir: Path, settings) -> None:  # type: ignore[no-untyped-def]
    headers = await editor(client)
    no_alt = await upload(client, headers, alt="")
    assert "alt_text" in no_alt.json()["error"]["fields"]
    fake = await upload(client, headers, data=b"%PDF-1.7 no es una foto", name="foto.jpg")
    assert fake.json()["error"]["code"] == "INVALID_IMAGE"
    settings.upload_max_mb = 1
    big = await upload(client, headers, data=b"x" * (1024 * 1024 + 1))
    assert big.status_code == 413 and big.json()["error"]["code"] == "FILE_TOO_LARGE"
    assert not (media_dir / "media").exists() or not any((media_dir / "media").iterdir())


async def test_content_permission(client: AsyncClient, media_dir: Path) -> None:
    ops = await auth_headers(client, "ops@example.com", ("reservations_admin",))
    assert (await upload(client, ops)).status_code == 403
    assert (await client.get(f"{API}/admin/carousel", headers=ops)).status_code == 403


def slide(image_id: str, **over: Any) -> dict[str, Any]:
    return {
        "image_id": image_id,
        "title": "Su boda, sin preocupaciones",
        "subtitle": "Limusinas decoradas para el gran día",
        "cta_label": "Ver Premium",
        "cta_url": "/services/premium",
        **over,
    }


async def test_carousel_schedule_and_order(client: AsyncClient, media_dir: Path) -> None:
    headers = await editor(client)
    image_id = (await upload(client, headers)).json()["id"]
    now = datetime.now(UTC)
    ids = {}
    for name, extra in [
        ("visible", {}),
        ("inactiva", {"is_active": False}),
        ("futura", {"starts_at": (now + timedelta(days=2)).isoformat()}),
        (
            "terminada",
            {
                "ends_at": (now - timedelta(minutes=1)).isoformat(),
                "starts_at": (now - timedelta(days=3)).isoformat(),
            },
        ),
        (
            "campaña",
            {
                "starts_at": (now - timedelta(hours=1)).isoformat(),
                "ends_at": (now + timedelta(days=1)).isoformat(),
            },
        ),
    ]:
        res = await client.post(
            f"{API}/admin/carousel", headers=headers, json=slide(image_id, title=name, **extra)
        )
        assert res.status_code == 201, res.text
        ids[name] = res.json()["id"]

    public = (await client.get(f"{API}/content/carousel")).json()
    assert [s["title"] for s in public] == ["visible", "campaña"]
    assert public[0]["image"]["srcset"] and public[0]["cta_url"] == "/services/premium"
    admin = {
        s["title"]: s["live"]
        for s in (await client.get(f"{API}/admin/carousel", headers=headers)).json()
    }
    assert admin == {
        "visible": True,
        "inactiva": False,
        "futura": False,
        "terminada": False,
        "campaña": True,
    }

    order = [ids[n] for n in ("campaña", "futura", "terminada", "inactiva", "visible")]
    res = await client.put(f"{API}/admin/carousel-order", headers=headers, json={"ids": order})
    assert res.json()[0]["title"] == "campaña"
    assert [s["title"] for s in (await client.get(f"{API}/content/carousel")).json()] == [
        "campaña",
        "visible",
    ]
    bad = await client.put(f"{API}/admin/carousel-order", headers=headers, json={"ids": order[:2]})
    assert bad.json()["error"]["code"] == "INVALID_ORDER"


@pytest.mark.parametrize(
    "override",
    [
        {"cta_url": "javascript:alert(1)"},
        {"cta_url": "//sitio-malicioso.com"},
        {"cta_url": "http://sin-cifrar.com"},
        {"cta_label": None},
        {"starts_at": "2026-12-10T10:00:00Z", "ends_at": "2026-12-01T10:00:00Z"},
    ],
)
async def test_slide_validation(
    client: AsyncClient, media_dir: Path, override: dict[str, Any]
) -> None:
    headers = await editor(client)
    image_id = (await upload(client, headers)).json()["id"]
    res = await client.post(
        f"{API}/admin/carousel", headers=headers, json=slide(image_id, **override)
    )
    assert res.status_code == 422


async def test_service_gallery_and_in_use_protection(client: AsyncClient, media_dir: Path) -> None:
    headers = await editor(client)
    service = await client.post(
        f"{API}/admin/services",
        headers=headers,
        json={
            "slug": "premium",
            "name": "Premium",
            "passenger_capacity": 8,
            "hourly_rate": "60000",
            "min_hours": "2",
        },
    )
    sid = service.json()["id"]
    a = (await upload(client, headers, alt="Exterior de la limusina")).json()["id"]
    b = (await upload(client, headers, alt="Interior con champaña")).json()["id"]

    res = await client.put(
        f"{API}/admin/services/{sid}/images", headers=headers, json={"image_ids": [b, a]}
    )
    assert [g["id"] for g in res.json()["gallery"]] == [b, a]
    public = (await client.get(f"{API}/services/premium")).json()
    assert public["gallery"][0]["alt"] == "Interior con champaña"  # la primera es la portada

    in_use = await client.delete(f"{API}/admin/media/{a}", headers=headers)
    assert in_use.json()["error"]["code"] == "MEDIA_IN_USE"
    await client.put(f"{API}/admin/services/{sid}/images", headers=headers, json={"image_ids": [b]})
    assert (await client.delete(f"{API}/admin/media/{a}", headers=headers)).status_code == 204
    assert not (media_dir / "media" / a).exists() or not any((media_dir / "media" / a).iterdir())

    res = await client.patch(
        f"{API}/admin/media/{b}", headers=headers, json={"alt_text": "Interior iluminado"}
    )
    assert res.json()["alt"] == "Interior iluminado"
    unknown = await client.put(
        f"{API}/admin/services/{sid}/images",
        headers=headers,
        json={"image_ids": ["00000000-0000-0000-0000-000000000000"]},
    )
    assert unknown.status_code == 404


async def test_uploaded_file_is_served(client: AsyncClient, media_dir: Path) -> None:
    """En desarrollo la API sirve los archivos: la URL devuelta funciona."""
    from app.main import create_app

    headers = await editor(client)
    img = (await upload(client, headers)).json()
    # La app de los tests se creó antes de cambiar la carpeta: se monta una nueva para comprobar.
    from httpx import ASGITransport

    async with AsyncClient(
        transport=ASGITransport(app=create_app()), base_url="http://api.test"
    ) as fresh:
        res = await fresh.get(img["src"].removeprefix("http://api.test"))
    assert res.status_code == 200 and res.headers["content-type"] == "image/webp"
