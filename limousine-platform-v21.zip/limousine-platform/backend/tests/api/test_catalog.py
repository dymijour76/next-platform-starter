"""Servicios, reglas de precio, configuración y cotización vía API."""

from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

from httpx import AsyncClient
from sqlalchemy import select

from app.audit.models import AuditLog
from app.db.session import SessionLocal

from .conftest import auth_headers

API = "/api/v1"
SCL = ZoneInfo("America/Santiago")

PREMIUM = {
    "slug": "premium",
    "name": "Premium",
    "tagline": "Para ocasiones que no se repiten",
    "passenger_capacity": 8,
    "features": ["Champaña de cortesía", "Wi-Fi"],
    "base_fare": "20000",
    "hourly_rate": "60000",
    "min_hours": "2",
    "max_hours": "8",
    "minimum_fare": "0",
}


async def admin(client: AsyncClient) -> dict[str, str]:
    return await auth_headers(client, "admin@example.com", ("super_admin",))


async def create_service(client: AsyncClient, headers: dict[str, str], **over: object) -> dict:
    res = await client.post(f"{API}/admin/services", headers=headers, json={**PREMIUM, **over})
    assert res.status_code == 201, res.text
    return res.json()


def future_wednesday_noon() -> datetime:
    """Un miércoles a mediodía hora de Santiago, al menos una semana adelante."""
    day = datetime.now(SCL).date() + timedelta(days=7)
    day += timedelta(days=(2 - day.weekday()) % 7)
    return datetime(day.year, day.month, day.day, 12, 0, tzinfo=SCL)


async def test_public_catalog_shows_only_active(client: AsyncClient) -> None:
    headers = await admin(client)
    await create_service(client, headers)
    await create_service(client, headers, slug="standard", name="Standard", is_active=False)

    res = await client.get(f"{API}/services")
    assert [s["slug"] for s in res.json()] == ["premium"]
    service = res.json()[0]
    # Montos como texto exacto y precio "desde" = 20.000 + 2 h × 60.000.
    assert service["hourly_rate"] == "60000"
    assert service["price_from"] == "140000"
    assert service["currency"] == "CLP"
    assert "is_active" not in service

    assert (await client.get(f"{API}/services/standard")).status_code == 404
    assert (await client.get(f"{API}/services/premium")).json()["name"] == "Premium"
    admin_list = await client.get(f"{API}/admin/services", headers=headers)
    assert len(admin_list.json()) == 2


async def test_service_permissions(client: AsyncClient) -> None:
    customer = await auth_headers(client, "c@example.com", ("customer",))
    reservations = await auth_headers(client, "r@example.com", ("reservations_admin",))
    assert (await client.get(f"{API}/admin/services", headers=customer)).status_code == 403
    # El administrador de reservas ve los servicios pero no los modifica.
    assert (await client.get(f"{API}/admin/services", headers=reservations)).status_code == 200
    res = await client.post(f"{API}/admin/services", headers=reservations, json=PREMIUM)
    assert res.status_code == 403
    # Ni la tarifa ni las reglas.
    assert (await client.get(f"{API}/admin/pricing/rules", headers=reservations)).status_code == 403


async def test_service_validation_and_update(client: AsyncClient) -> None:
    headers = await admin(client)
    bad = await client.post(
        f"{API}/admin/services",
        headers=headers,
        json={**PREMIUM, "slug": "Con Espacios", "hourly_rate": "-5", "max_hours": "1"},
    )
    fields = bad.json()["error"]["fields"]
    assert {"slug", "hourly_rate"} <= set(fields)

    svc = await create_service(client, headers)
    dup = await client.post(f"{API}/admin/services", headers=headers, json=PREMIUM)
    assert dup.json()["error"]["code"] == "SLUG_TAKEN"

    res = await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=headers, json={"hourly_rate": "65000"}
    )
    assert res.json()["hourly_rate"] == "65000"
    assert res.json()["name"] == "Premium"  # lo no enviado no cambia
    res = await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=headers, json={"max_hours": "1"}
    )
    assert res.status_code == 409  # máximo menor que el mínimo


async def test_quote(client: AsyncClient) -> None:
    headers = await admin(client)
    svc = await create_service(client, headers)
    body = {
        "service_id": svc["id"],
        "pickup_at": future_wednesday_noon().isoformat(),
        "duration_minutes": 150,
    }
    res = await client.post(f"{API}/pricing/quote", json=body)
    assert res.status_code == 200, res.text
    quote = res.json()
    assert [(ln["label"], ln["amount"]) for ln in quote["lines"]] == [
        ("Tarifa de salida", "20000"),
        ("2,5 horas × $60.000", "150000"),
    ]
    assert quote["total"] == "170000"
    assert int(quote["net"]) + int(quote["tax"]) == 170000
    assert quote["pickup_local"].endswith(("-03:00", "-04:00"))


async def test_quote_rejections(client: AsyncClient) -> None:
    headers = await admin(client)
    svc = await create_service(client, headers)
    soon = datetime.now(UTC) + timedelta(minutes=30)
    far = datetime.now(UTC) + timedelta(days=400)

    cases = [
        ({"pickup_at": soon.isoformat()}, "PICKUP_TOO_SOON"),
        ({"pickup_at": far.isoformat()}, "PICKUP_TOO_FAR"),
        ({"duration_minutes": 9 * 60}, "DURATION_TOO_LONG"),
        ({"pickup_at": "2026-12-01T12:00:00"}, "VALIDATION_ERROR"),  # sin zona horaria
        ({"service_id": "00000000-0000-0000-0000-000000000000"}, "NOT_FOUND"),
    ]
    base = {
        "service_id": svc["id"],
        "pickup_at": future_wednesday_noon().isoformat(),
        "duration_minutes": 120,
    }
    for override, code in cases:
        res = await client.post(f"{API}/pricing/quote", json={**base, **override})
        assert res.json()["error"]["code"] == code, override

    # Un servicio desactivado no se cotiza públicamente, pero sí en el simulador.
    await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=headers, json={"is_active": False}
    )
    assert (await client.post(f"{API}/pricing/quote", json=base)).status_code == 404
    sim = await client.post(f"{API}/admin/pricing/simulate", headers=headers, json=base)
    assert sim.status_code == 200


async def test_price_cannot_be_injected(client: AsyncClient) -> None:
    """Campos de precio enviados por el cliente se ignoran."""
    headers = await admin(client)
    svc = await create_service(client, headers)
    res = await client.post(
        f"{API}/pricing/quote",
        json={
            "service_id": svc["id"],
            "pickup_at": future_wednesday_noon().isoformat(),
            "duration_minutes": 120,
            "total": "1",
            "hourly_rate": "1",
            "lines": [],
        },
    )
    assert res.json()["total"] == "140000"


async def test_rules_change_quotes(client: AsyncClient) -> None:
    headers = await admin(client)
    svc = await create_service(client, headers)
    pickup = future_wednesday_noon()
    body = {"service_id": svc["id"], "pickup_at": pickup.isoformat(), "duration_minutes": 120}

    res = await client.post(
        f"{API}/admin/pricing/rules",
        headers=headers,
        json={
            "name": "Recargo de mediodía",
            "kind": "SURCHARGE",
            "adjustment_type": "PERCENT",
            "value": "10",
            "days_of_week": [pickup.weekday()],
            "time_from": "11:00",
            "time_until": "13:00",
        },
    )
    assert res.status_code == 201, res.text
    rule = res.json()
    quote = (await client.post(f"{API}/pricing/quote", json=body)).json()
    assert quote["total"] == "154000"
    assert quote["lines"][-1]["label"] == "Recargo de mediodía (10 %)"

    # Desactivada, deja de aplicar.
    update = {**rule, "is_active": False}
    for key in ("id", "created_at", "updated_at"):
        update.pop(key)
    assert (
        await client.put(f"{API}/admin/pricing/rules/{rule['id']}", headers=headers, json=update)
    ).status_code == 200
    assert (await client.post(f"{API}/pricing/quote", json=body)).json()["total"] == "140000"

    assert (
        await client.delete(f"{API}/admin/pricing/rules/{rule['id']}", headers=headers)
    ).status_code == 204


async def test_rule_validation(client: AsyncClient) -> None:
    headers = await admin(client)
    base = {"name": "X", "kind": "SURCHARGE", "adjustment_type": "PERCENT", "value": "10"}
    cases = [
        {"value": "150"},
        {"time_from": "22:00"},
        {"time_from": "22:00", "time_until": "22:00"},
        {"valid_from": "2026-12-31", "valid_until": "2026-01-01"},
        {"days_of_week": [7]},
        {"service_ids": ["00000000-0000-0000-0000-000000000000"]},
    ]
    for override in cases:
        res = await client.post(
            f"{API}/admin/pricing/rules", headers=headers, json={**base, **override}
        )
        assert res.status_code in (400, 422), override


async def test_settings_update_affects_quotes(client: AsyncClient) -> None:
    headers = await admin(client)
    svc = await create_service(client, headers, base_fare="0", hourly_rate="50000")
    current = (await client.get(f"{API}/admin/pricing/settings", headers=headers)).json()
    assert current["tax_rate"] == "0.19" and current["currency"] == "CLP"

    res = await client.put(
        f"{API}/admin/pricing/settings",
        headers=headers,
        json={**current, "billing_increment_minutes": 60, "timezone": "Marte/Olympus"},
    )
    assert res.status_code == 422
    res = await client.put(
        f"{API}/admin/pricing/settings",
        headers=headers,
        json={**current, "billing_increment_minutes": 60},
    )
    assert res.json()["billing_increment_minutes"] == 60

    body = {
        "service_id": svc["id"],
        "pickup_at": future_wednesday_noon().isoformat(),
        "duration_minutes": 130,
    }
    # 2 h 10 min con tramos de 60 min se cobra como 3 horas.
    assert (await client.post(f"{API}/pricing/quote", json=body)).json()["total"] == "150000"


async def test_price_changes_are_audited(client: AsyncClient) -> None:
    headers = await admin(client)
    svc = await create_service(client, headers)
    await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=headers, json={"hourly_rate": "70000"}
    )
    async with SessionLocal() as db:
        logs = list(await db.scalars(select(AuditLog).order_by(AuditLog.created_at)))
    assert [log.action for log in logs] == ["SERVICE_CREATE", "SERVICE_UPDATE"]
    assert logs[1].before is not None and logs[1].before["hourly_rate"] == "60000"
    assert logs[1].after is not None and logs[1].after["hourly_rate"] == "70000"


async def test_tariff_changes_require_pricing_permission(client: AsyncClient) -> None:
    from .conftest import create_role

    headers = await admin(client)
    svc = await create_service(client, headers)
    await create_role("catalogo", ["services:read", "services:write"])
    editor = await auth_headers(client, "editor@example.com", ("catalogo",))

    # Puede cambiar textos...
    res = await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=editor, json={"tagline": "Nuevo texto"}
    )
    assert res.status_code == 200
    # ...y reenviar la tarifa sin cambios (formulario completo)...
    res = await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=editor, json={"hourly_rate": "60000"}
    )
    assert res.status_code == 200
    # ...pero no modificar precios ni crear servicios.
    res = await client.patch(
        f"{API}/admin/services/{svc['id']}", headers=editor, json={"hourly_rate": "1000"}
    )
    assert res.json()["error"]["code"] == "PRICING_PERMISSION"
    other = {**PREMIUM, "slug": "otro"}
    res = await client.post(f"{API}/admin/services", headers=editor, json=other)
    assert res.status_code == 403


async def test_public_pricing_config(client: AsyncClient) -> None:
    res = await client.get(f"{API}/pricing/config")
    assert res.json() == {
        "currency": "CLP",
        "timezone": "America/Santiago",
        "tax_name": "IVA",
        "prices_include_tax": True,
        "billing_increment_minutes": 30,
        "min_notice_minutes": 120,
        "max_advance_days": 365,
    }
