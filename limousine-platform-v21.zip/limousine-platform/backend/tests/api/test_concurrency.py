"""Operaciones simultáneas sobre la misma fila: el bloqueo debe ver siempre el valor vigente."""

import asyncio

from httpx import AsyncClient
from sqlalchemy import func, select

from app.db.session import SessionLocal
from app.payments.models import Refund

from .conftest import Outbox
from .test_payments import pay
from .test_reservations import book, setup, weekday_noon

API = "/api/v1"


async def test_two_simultaneous_cancellations_refund_once(
    client: AsyncClient, outbox: Outbox
) -> None:
    _, customer, sid = await setup(client)
    r = await book(client, customer, service_id=sid, pickup=weekday_noon(days_ahead=10))
    assert (await pay(client, customer, r["code"], "approve"))["outcome"] == "paid"
    results = await asyncio.gather(
        *(
            client.post(f"{API}/reservations/{r['code']}/cancel", headers=customer, json={})
            for _ in range(2)
        )
    )
    assert sorted(x.status_code for x in results) == [200, 409], [x.text for x in results]
    async with SessionLocal() as db:
        assert await db.scalar(select(func.count()).select_from(Refund)) == 1  # un solo reembolso
