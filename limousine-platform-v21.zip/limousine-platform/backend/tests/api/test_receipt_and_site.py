"""Comprobante en PDF y datos de la empresa (pie de página, redes, encabezado del PDF)."""

import io
import uuid
from datetime import UTC, datetime, timedelta

import pdfplumber
from httpx import AsyncClient

from app.core.i18n import catalog
from app.reservations.receipt import PAYMENT_STATUS, STATUS

from .conftest import auth_headers

API = "/api/v1"
COMPANY = {
    "name": "Limusinas del Pacífico",
    "legal_name": "Limusinas del Pacífico SpA",
    "tax_id": "12.345.678-5",
    "address": "Av. Apoquindo 3000, Las Condes",
    "phone": "+56 2 2345 6789",
    "whatsapp": "+56 9 8765 4321",
    "email": "contacto@limusinas.cl",
    "about": "Traslados con chófer desde 2010.",
    "hours": "Atención 24/7",
    "social": {"instagram": "https://instagram.com/limusinas", "facebook": ""},
    "translations": {"ht": {"hours": "Disponib 24/7"}},
}


def pdf_text(content: bytes) -> str:
    with pdfplumber.open(io.BytesIO(content)) as pdf:
        return "\n".join(page.extract_text() or "" for page in pdf.pages)


async def test_site_settings(client: AsyncClient) -> None:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    res = await client.put(f"{API}/admin/site", headers=admin, json=COMPANY)
    assert res.status_code == 200, res.text
    saved = res.json()
    assert saved["tax_id"] == "12345678-5"  # RUT normalizado
    assert saved["social"] == {"instagram": "https://instagram.com/limusinas"}  # vacíos fuera

    public = (await client.get(f"{API}/site", headers={"Accept-Language": "ht"})).json()
    assert public["hours"] == "Disponib 24/7"
    assert public["about"] == "Traslados con chófer desde 2010."  # sin traducción: español
    assert public["whatsapp_url"] == "https://wa.me/56987654321"

    bad = await client.put(
        f"{API}/admin/site",
        headers=admin,
        json={**COMPANY, "social": {"instagram": "http://x.com"}},
    )
    assert bad.status_code == 422
    customer = await auth_headers(client, "ana@example.com", ("customer",))
    assert (
        await client.put(f"{API}/admin/site", headers=customer, json=COMPANY)
    ).status_code == 403


async def booked(client: AsyncClient) -> tuple[dict[str, str], dict[str, str], str]:
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    await client.put(f"{API}/admin/site", headers=admin, json=COMPANY)
    service = (
        await client.post(
            f"{API}/admin/services",
            headers=admin,
            json={
                "slug": "premium",
                "name": "Premium",
                "passenger_capacity": 8,
                "base_fare": "40000",
                "hourly_rate": "85000",
                "min_hours": "3",
            },
        )
    ).json()
    await client.post(
        f"{API}/admin/vehicles",
        headers=admin,
        json={
            "plate": "TBWX48",
            "service_id": service["id"],
            "brand": "Cadillac",
            "model": "Escalade",
            "year": 2024,
            "color": "Negro",
            "passenger_capacity": 8,
        },
    )
    customer = await auth_headers(client, "marie@example.com", ("customer",))
    pickup = (datetime.now(UTC) + timedelta(days=5)).replace(
        hour=15, minute=0, second=0, microsecond=0
    )
    body = {"service_id": service["id"], "pickup_at": pickup.isoformat(), "duration_minutes": 180}
    quote = (await client.post(f"{API}/pricing/quote", json=body)).json()
    trip = {
        **body,
        "pickup_address": "Av. Apoquindo 3000",
        "passenger_count": 2,
        "contact_name": "Marie Joseph",
        "contact_email": "marie@example.com",
        "contact_phone": "+56912345678",
        "accept_policy": True,
        "idempotency_key": str(uuid.uuid4()),
        "expected_total": quote["total"],
    }
    res = await client.post(f"{API}/reservations", json=trip, headers=customer)
    assert res.status_code == 201, res.text
    return admin, customer, res.json()["code"]


async def test_receipt_pdf_in_each_language(client: AsyncClient, outbox) -> None:  # type: ignore[no-untyped-def]
    admin, customer, code = await booked(client)
    res = await client.get(f"{API}/reservations/{code}/receipt", headers=customer)
    assert res.status_code == 200
    assert res.headers["content-type"] == "application/pdf"
    assert f'filename="comprobante-{code}.pdf"' in res.headers["content-disposition"]
    text = pdf_text(res.content)
    for expected in [
        "Limusinas del Pacífico",
        "RUT 12345678-5",
        "Comprobante de reserva",
        code,
        "Pendiente de pago",
        "3 horas × $85.000",
        "$295.000",
        "Este comprobante no es una boleta ni factura electrónica.",
    ]:
        assert expected in text, (expected, text)

    for lang, expected in [
        ("en", ["Booking receipt", "CLP 295,000", "Pending payment"]),
        ("ht", ["Resi rezèvasyon", "Ap tann peman", "295"]),
        ("zh", ["预订凭证", "待付款", "本凭证不是发票"]),
    ]:
        content = (
            await client.get(
                f"{API}/reservations/{code}/receipt", headers={**customer, "Accept-Language": lang}
            )
        ).content
        got = pdf_text(content)
        for piece in expected:
            assert piece in got, (lang, piece, got)

    # Otro cliente no puede descargarlo; el personal sí, desde el panel.
    other = await auth_headers(client, "otro@example.com", ("customer",))
    assert (
        await client.get(f"{API}/reservations/{code}/receipt", headers=other)
    ).status_code == 404
    rid = (await client.get(f"{API}/admin/reservations?q={code}", headers=admin)).json()["items"][
        0
    ]["id"]
    assert (
        await client.get(f"{API}/admin/reservations/{rid}/receipt", headers=admin)
    ).status_code == 200


def test_receipt_status_labels_are_translated() -> None:
    for label in [*STATUS.values(), *PAYMENT_STATUS.values()]:
        assert label in catalog("en"), label


async def test_full_form_with_empty_fields_never_500(client: AsyncClient) -> None:
    """El formulario envía todos los campos, algunos vacíos: validación (422), nunca error 500."""
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    empty = {
        k: None
        for k in ("legal_name", "tax_id", "about", "hours", "address", "phone", "whatsapp", "email")
    }
    bad = await client.put(
        f"{API}/admin/site",
        headers=admin,
        json={"name": "X", **empty, "social": {"instagram": "http://x.com"}},
    )
    assert bad.status_code == 422
    assert bad.json()["error"]["fields"]["social"] == "Use una dirección https:// completa."
    good = await client.put(
        f"{API}/admin/site", headers=admin, json={"name": "X", **empty, "social": {}}
    )
    assert good.status_code == 200
    too_long = await client.put(
        f"{API}/admin/site", headers=admin, json={"name": "X", "hours": "x" * 121}
    )
    assert too_long.status_code == 422

    # Lo mismo en las traducciones del contenido: un campo nulo no rompe nada.
    res = await client.post(
        f"{API}/admin/services",
        headers=admin,
        json={
            "slug": "traslado",
            "name": "X",
            "passenger_capacity": 4,
            "hourly_rate": "1000",
            "min_hours": "1",
            "translations": {"en": {"name": None, "tagline": "  "}},
        },
    )
    assert res.status_code == 201, res.text
    assert res.json()["translations"] == {}
