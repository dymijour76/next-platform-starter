from datetime import UTC, datetime, timedelta

from httpx import AsyncClient

from app.cli import create_admin, seed_demo

from .conftest import auth_headers, bearer, login

PASSWORD = "Carrusel-Sedan-2026"


async def test_create_admin_is_idempotent(client: AsyncClient, monkeypatch) -> None:
    monkeypatch.setenv("ADMIN_PASSWORD", PASSWORD)
    await create_admin("Jefa@Empresa.cl", "Carla", "Rojas")
    await create_admin("jefa@empresa.cl", "Carla", "Rojas")  # segunda vez: no duplica

    me = await client.get(
        "/api/v1/auth/me", headers=bearer(await login(client, "jefa@empresa.cl", PASSWORD))
    )
    body = me.json()
    assert [r["code"] for r in body["roles"]] == ["super_admin"]
    assert body["email_verified"] is True
    assert len(body["permissions"]) == 28


async def test_seed_demo_is_idempotent(client: AsyncClient) -> None:
    await seed_demo()
    await seed_demo()  # segunda vez: no duplica
    services = (await client.get("/api/v1/services")).json()
    assert [s["slug"] for s in services] == ["standard", "professional", "premium"]
    # Premium: 40.000 + 3 h × 85.000 = 295.000, sobre la tarifa mínima de 250.000.
    assert services[2]["price_from"] == "295000"
    trip = {
        "service_id": services[0]["id"],
        "duration_minutes": 120,
        "pickup_at": (datetime.now(UTC) + timedelta(days=3)).isoformat(),
    }
    admin = await auth_headers(client, "admin@example.com", ("super_admin",))
    vehicles = (await client.get("/api/v1/admin/vehicles", headers=admin)).json()
    assert len(vehicles) == 4
    # Los servicios de ejemplo se pueden reservar.
    res = await client.post("/api/v1/reservations/preview", headers=admin, json=trip)
    assert res.json()["available"] is True
