"""Motor de precios: función pura, se prueba sin base de datos."""

import json
from datetime import UTC, date, datetime, time
from decimal import Decimal as D
from zoneinfo import ZoneInfo

import pytest

from app.pricing.engine import (
    AdjustmentType,
    PricingError,
    Rule,
    RuleKind,
    Settings,
    Tariff,
    billed_hours,
    calculate,
    format_amount,
)

SCL = ZoneInfo("America/Santiago")
TARIFF = Tariff("premium", "Premium", D(20000), D(60000), D(2), D(0))
SETTINGS = Settings()


def local(*args: int) -> datetime:
    return datetime(*args, tzinfo=SCL)  # type: ignore[misc]


def rule(name: str = "Regla", **kw: object) -> Rule:
    defaults: dict[str, object] = {
        "id": name,
        "name": name,
        "kind": RuleKind.SURCHARGE,
        "adjustment_type": AdjustmentType.PERCENT,
        "value": D(10),
    }
    return Rule(**{**defaults, **kw})  # type: ignore[arg-type]


def amounts(q) -> dict[str, D]:  # type: ignore[no-untyped-def]
    return {ln.label: ln.amount for ln in q.lines}


# Un miércoles cualquiera al mediodía, sin reglas especiales.
WEDNESDAY_NOON = local(2026, 10, 14, 12, 0)


def test_basic_breakdown_total_is_sum_of_lines() -> None:
    q = calculate(TARIFF, [], SETTINGS, WEDNESDAY_NOON, 180)
    assert amounts(q) == {"Tarifa de salida": D(20000), "3 horas × $60.000": D(180000)}
    assert q.total == D(200000) == sum(ln.amount for ln in q.lines)


@pytest.mark.parametrize(
    ("minutes", "increment", "expected"),
    [
        (60, 30, D(2)),  # bajo el mínimo de 2 horas
        (130, 30, D("2.5")),  # 2 h 10 min se cobra como 2,5 h
        (150, 30, D("2.5")),
        (130, 15, D("2.25")),
        (130, 60, D(3)),
    ],
)
def test_billed_hours(minutes: int, increment: int, expected: D) -> None:
    assert billed_hours(minutes, TARIFF, increment) == expected


@pytest.mark.parametrize(
    ("hour", "minute", "applies"),
    [(21, 59, False), (22, 0, True), (23, 30, True), (0, 0, True), (5, 59, True), (6, 0, False)],
)
def test_night_window_crossing_midnight(hour: int, minute: int, applies: bool) -> None:
    night = rule("Nocturno", time_from=time(22), time_until=time(6), value=D(20))
    q = calculate(TARIFF, [night], SETTINGS, local(2026, 10, 14, hour, minute), 120)
    assert (q.rules_applied == ["Nocturno"]) is applies


def test_rules_use_santiago_local_time_across_dst() -> None:
    """01:30 UTC es 21:30 en invierno (UTC-4) y 22:30 en verano (UTC-3)."""
    night = rule("Nocturno", time_from=time(22), time_until=time(6))
    winter = calculate(TARIFF, [night], SETTINGS, datetime(2026, 7, 15, 1, 30, tzinfo=UTC), 120)
    summer = calculate(TARIFF, [night], SETTINGS, datetime(2026, 10, 15, 1, 30, tzinfo=UTC), 120)
    assert winter.pickup_local.hour == 21 and winter.rules_applied == []
    assert summer.pickup_local.hour == 22 and summer.rules_applied == ["Nocturno"]


def test_day_of_week_and_date_range() -> None:
    weekend = rule("Fin de semana", days_of_week=frozenset({5, 6}))
    holidays = rule("Fiestas Patrias", valid_from=date(2026, 9, 18), valid_until=date(2026, 9, 19))
    saturday = local(2026, 10, 17, 12, 0)
    assert calculate(TARIFF, [weekend], SETTINGS, saturday, 120).rules_applied == ["Fin de semana"]
    assert calculate(TARIFF, [weekend], SETTINGS, WEDNESDAY_NOON, 120).rules_applied == []
    # El último día del rango está incluido.
    on_19 = calculate(TARIFF, [holidays], SETTINGS, local(2026, 9, 19, 23, 0), 120)
    on_20 = calculate(TARIFF, [holidays], SETTINGS, local(2026, 9, 20, 0, 0), 120)
    assert on_19.rules_applied == ["Fiestas Patrias"] and on_20.rules_applied == []


def test_rule_limited_to_service_and_min_hours() -> None:
    other = rule("Sólo Standard", service_ids=frozenset({"standard"}))
    long_trip = rule("Viaje largo", kind=RuleKind.DISCOUNT, min_hours=D(5))
    assert calculate(TARIFF, [other], SETTINGS, WEDNESDAY_NOON, 120).rules_applied == []
    assert calculate(TARIFF, [long_trip], SETTINGS, WEDNESDAY_NOON, 240).rules_applied == []
    assert calculate(TARIFF, [long_trip], SETTINGS, WEDNESDAY_NOON, 300).rules_applied == [
        "Viaje largo"
    ]


def test_percentages_do_not_compound() -> None:
    """Dos recargos de 10 % suman 20 % del subtotal, no 21 %."""
    t = Tariff("s", "S", D(0), D(50000), D(2), D(0))  # subtotal 100.000
    q = calculate(t, [rule("A"), rule("B")], SETTINGS, WEDNESDAY_NOON, 120)
    assert q.total == D(120000)


def test_rules_ordered_by_priority() -> None:
    q = calculate(
        TARIFF,
        [rule("Segunda", priority=20), rule("Primera", priority=10)],
        SETTINGS,
        WEDNESDAY_NOON,
        120,
    )
    assert q.rules_applied == ["Primera", "Segunda"]


def test_fixed_discount_and_minimum_fare() -> None:
    t = Tariff("s", "S", D(0), D(50000), D(2), D(90000))
    promo = rule("Promo", kind=RuleKind.DISCOUNT, adjustment_type=AdjustmentType.FIXED,
                 value=D(30000))  # fmt: skip
    q = calculate(t, [promo], SETTINGS, WEDNESDAY_NOON, 120)
    lines = amounts(q)
    assert lines["Promo"] == D(-30000)
    assert lines["Ajuste a tarifa mínima"] == D(20000)
    assert q.total == D(90000)


def test_total_never_negative() -> None:
    t = Tariff("s", "S", D(0), D(10000), D(1), D(0))
    big = rule("Gratis", kind=RuleKind.DISCOUNT, adjustment_type=AdjustmentType.FIXED,
               value=D(50000))  # fmt: skip
    q = calculate(t, [big], SETTINGS, WEDNESDAY_NOON, 60)
    assert q.total == 0 and q.tax == 0


def test_rounding_to_whole_pesos() -> None:
    t = Tariff("s", "S", D(0), D(33333), D(1), D(0))
    q = calculate(t, [rule("Raro", value=D("12.5"))], SETTINGS, WEDNESDAY_NOON, 90)
    for ln in q.lines:
        assert ln.amount == ln.amount.to_integral_value()
    assert q.total == sum(ln.amount for ln in q.lines)


@pytest.mark.parametrize("total", [1, 119, 119000, 204000, 999999, 1234567])
def test_tax_included_always_adds_up(total: int) -> None:
    t = Tariff("s", "S", D(total), D(0), D(1), D(0))
    q = calculate(t, [], SETTINGS, WEDNESDAY_NOON, 60)
    assert q.net + q.tax == q.total == D(total)


def test_tax_included_example() -> None:
    t = Tariff("s", "S", D(119000), D(0), D(1), D(0))
    q = calculate(t, [], SETTINGS, WEDNESDAY_NOON, 60)
    assert (q.net, q.tax) == (D(100000), D(19000))


def test_tax_added_when_prices_exclude_it() -> None:
    t = Tariff("s", "S", D(100000), D(0), D(1), D(0))
    q = calculate(t, [], Settings(prices_include_tax=False), WEDNESDAY_NOON, 60)
    assert amounts(q)["IVA (19 %)"] == D(19000)
    assert q.total == D(119000)


def test_invalid_inputs() -> None:
    with pytest.raises(PricingError):
        calculate(TARIFF, [], SETTINGS, datetime(2026, 10, 14, 12), 60)  # sin zona horaria
    with pytest.raises(PricingError):
        calculate(TARIFF, [], SETTINGS, WEDNESDAY_NOON, 0)


def test_snapshot_is_json_serializable() -> None:
    q = calculate(TARIFF, [rule("Nocturno")], SETTINGS, WEDNESDAY_NOON, 150)
    snap = json.loads(json.dumps(q.snapshot(TARIFF)))
    assert snap["total"] == str(q.total)
    assert snap["service"]["name"] == "Premium"
    assert [ln["label"] for ln in snap["lines"]][-1] == "Nocturno (10 %)"


def test_format_amount() -> None:
    assert format_amount(D(1234567), "CLP") == "$1.234.567"
    assert format_amount(D(-30000), "CLP") == "-$30.000"
    assert format_amount(D("19.5"), "USD") == "19,50 USD"
