"""Adaptador de Webpay Plus contra un servidor falso con las respuestas documentadas."""

import json
from decimal import Decimal

import httpx
import pytest

from app.payments.providers.base import ProviderError
from app.payments.providers.webpay import WebpayProvider

BASE = "https://webpay3gint.transbank.cl/rswebpaytransaction/api/webpay/v1.2/transactions"


def provider(handler) -> WebpayProvider:  # type: ignore[no-untyped-def]
    return WebpayProvider("597055555532", "secreto", "integration", httpx.MockTransport(handler))


COMMIT_OK = {
    "vci": "TSY",
    "amount": 295000,
    "status": "AUTHORIZED",
    "buy_order": "RES-2026-000001-1",
    "session_id": "u1",
    "card_detail": {"card_number": "6623"},
    "accounting_date": "1007",
    "transaction_date": "2026-10-07T15:00:00.000Z",
    "authorization_code": "1213",
    "payment_type_code": "VN",
    "response_code": 0,
    "installments_number": 0,
}


async def test_start_sends_credentials_and_returns_form() -> None:
    seen: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        seen["method"], seen["url"] = request.method, str(request.url)
        seen["headers"] = dict(request.headers)
        seen["body"] = json.loads(request.content)
        return httpx.Response(
            200,
            json={
                "token": "e9d5…tok",
                "url": "https://webpay3gint.transbank.cl/webpayserver/initTransaction",
            },
        )

    started = await provider(handler).start(
        buy_order="RES-2026-000001-1", session_id="u1", amount=Decimal("295000.00"),
        return_url="https://sitio.cl/payments/return",
    )  # fmt: skip
    assert seen["method"] == "POST" and seen["url"] == BASE
    headers = seen["headers"]
    assert isinstance(headers, dict)
    assert headers["tbk-api-key-id"] == "597055555532"
    assert headers["tbk-api-key-secret"] == "secreto"
    # CLP se envía como entero.
    assert seen["body"] == {
        "buy_order": "RES-2026-000001-1",
        "session_id": "u1",
        "amount": 295000,
        "return_url": "https://sitio.cl/payments/return",
    }
    assert started.redirect.fields == {"token_ws": "e9d5…tok"}
    assert started.redirect.url.endswith("/initTransaction")


async def test_commit_approved() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "PUT" and str(request.url) == f"{BASE}/tok123"
        return httpx.Response(200, json=COMMIT_OK)

    result = await provider(handler).commit("tok123")
    assert result.approved
    assert result.amount == Decimal(295000)
    assert result.buy_order == "RES-2026-000001-1"
    assert (result.authorization_code, result.card_last4, result.payment_type) == (
        "1213",
        "6623",
        "VN",
    )


@pytest.mark.parametrize(
    "changes",
    [{"status": "FAILED", "response_code": -1}, {"status": "AUTHORIZED", "response_code": -3}],
)
async def test_commit_rejected(changes: dict[str, object]) -> None:
    result = await provider(lambda r: httpx.Response(200, json={**COMMIT_OK, **changes})).commit(
        "t"
    )
    assert not result.approved


async def test_errors_become_provider_errors() -> None:
    def down(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("sin red")

    with pytest.raises(ProviderError):
        await provider(down).commit("t")
    with pytest.raises(ProviderError):
        await provider(
            lambda r: httpx.Response(422, json={"error_message": "Invalid status"})
        ).commit("t")
    with pytest.raises(ProviderError):
        await provider(lambda r: httpx.Response(200, json={"status": "AUTHORIZED"})).commit("t")
    with pytest.raises(ProviderError):
        await provider(lambda r: httpx.Response(502, text="<html>")).commit("t")


@pytest.mark.parametrize(
    ("response", "ok"),
    [
        ({"type": "REVERSED"}, True),
        (
            {"type": "NULLIFIED", "authorization_code": "123", "response_code": 0, "balance": 0},
            True,
        ),
        ({"type": "NULLIFIED", "response_code": -1}, False),
    ],
)
async def test_refund(response: dict[str, object], ok: bool) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url) == f"{BASE}/tok/refunds"
        assert json.loads(request.content) == {"amount": 150000}
        return httpx.Response(200, json=response)

    result = await provider(handler).refund("tok", Decimal(150000))
    assert result.succeeded is ok


async def test_refund_network_error_is_reported_not_raised() -> None:
    def down(request: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("lento")

    result = await provider(down).refund("tok", Decimal(1000))
    assert not result.succeeded and result.message
