"""Adaptador de S3 contra un S3 simulado (moto)."""

import boto3
from moto import mock_aws

from app.media.storage import S3Storage


async def test_put_url_and_delete() -> None:
    with mock_aws():
        await _scenario()


async def _scenario() -> None:
    client = boto3.client("s3", region_name="us-east-1")
    client.create_bucket(Bucket="medios")
    storage = S3Storage("medios", "https://cdn.empresa.cl/", "us-east-1", client=client)

    await storage.put("media/abc/960.webp", b"RIFF-webp", "image/webp")
    obj = client.get_object(Bucket="medios", Key="media/abc/960.webp")
    assert obj["Body"].read() == b"RIFF-webp"
    assert obj["ContentType"] == "image/webp"
    assert "immutable" in obj["CacheControl"]
    assert storage.url("media/abc/960.webp") == "https://cdn.empresa.cl/media/abc/960.webp"

    await storage.delete("media/abc/960.webp")
    assert client.list_objects_v2(Bucket="medios").get("KeyCount") == 0
