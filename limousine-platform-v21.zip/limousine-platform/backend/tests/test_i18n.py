"""Idiomas de la API: negociación, traducción de mensajes y cobertura de los catálogos."""

import json
import subprocess
import sys
from pathlib import Path

import pytest

from app.core.i18n import LOCALES, catalog, negotiate, t, translate_message
from app.locales.build import check

BACKEND = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize(
    ("header", "expected"),
    [
        (None, "es"),
        ("en-US,en;q=0.9", "en"),
        ("fr-CA", "fr"),
        ("ht", "ht"),
        ("zh-CN,zh;q=0.9,en;q=0.8", "zh"),
        ("de-DE,fr;q=0.5", "fr"),  # el primero soportado según su peso
        ("de-DE", "es"),  # ninguno soportado: español
        ("en;q=0.2,ht;q=0.9", "ht"),
    ],
)
def test_negotiate(header: str | None, expected: str) -> None:
    assert negotiate(header) == expected


def test_catalogs_are_consistent() -> None:
    assert check() == []  # sin vacíos, duplicados ni marcadores distintos
    keys = {lang: set(catalog(lang)) for lang in LOCALES if lang != "es"}
    assert len({frozenset(k) for k in keys.values()}) == 1  # mismos textos en todos los idiomas


def test_every_api_message_is_translated() -> None:
    """Un mensaje nuevo en el código sin traducción hace fallar este test."""
    result = subprocess.run(
        [sys.executable, "scripts/extract_messages.py"],
        cwd=BACKEND,
        capture_output=True,
        text=True,
        check=True,
    )
    missing = [m for m in json.loads(result.stdout) if m not in catalog("en")]
    assert missing == [], (
        f"Mensajes sin traducir (agréguelos a app/locales/source_api.py): {missing}"
    )


def test_translate_exact_and_template() -> None:
    assert translate_message("La reserva no existe.", "en") == "The booking does not exist."
    assert (
        translate_message("Este servicio admite hasta 8 pasajeros.", "fr")
        == "Ce service accepte jusqu'à 8 passagers."
    )
    # Partes variables que también son textos: se traducen por dentro.
    assert translate_message("Vehículo no disponible: Ocupado en RES-2026-000001.", "en") == (
        "Vehicle not available: Busy with RES-2026-000001."
    )
    assert translate_message(
        "Demasiados intentos fallidos. Espere 15 minutos o recupere su contraseña.", "ht"
    ) == ("Twòp tantativ ki echwe. Tann 15 minit oswa chanje modpas ou.")
    assert (
        translate_message("Texto que no está en el catálogo.", "en")
        == "Texto que no está en el catálogo."
    )
    assert translate_message("La reserva no existe.", "es") == "La reserva no existe."


def test_t_formats_in_the_target_language() -> None:
    assert (
        t("Máximo {passenger_capacity} pasajeros.", "zh", passenger_capacity=8) == "最多 8 名乘客。"
    )
    assert (
        t("Máximo {passenger_capacity} pasajeros.", "es", passenger_capacity=8)
        == "Máximo 8 pasajeros."
    )


def test_template_with_a_repeated_placeholder() -> None:
    """Un marcador repetido no rompe el reconocimiento de plantillas (se compilan todas juntas)."""
    text = "Incluye IVA: neto $247.899 + IVA $47.101"
    assert translate_message(text, "en") == "Includes VAT: net $247.899 + VAT $47.101"
    assert translate_message("La reserva no existe.", "fr") == "La réservation n'existe pas."
