"""Cada proceso (API, worker, consola) debe poder configurar todos los modelos por sí solo.

Las relaciones se declaran por nombre ("Vehicle", "Payment"); si un proceso no
importa el módulo del modelo, SQLAlchemy falla recién al primer uso. El worker
no importa las rutas de la API, así que se prueba en un proceso limpio.
"""

import subprocess
import sys
from pathlib import Path

import pytest

BACKEND = Path(__file__).resolve().parents[1]


# Cada entrada: el proceso y los módulos que ese proceso carga al trabajar
# (las tareas del worker importan reservas y pagos recién al ejecutarse).
PROCESSES = {
    "worker": "import app.worker, app.reservations.service, app.payments.service",
    "cli": "import app.cli",
    "api": "import app.main",
}


@pytest.mark.parametrize("imports", PROCESSES.values(), ids=PROCESSES.keys())
def test_mappers_configure_in_fresh_process(imports: str) -> None:
    code = f"{imports}; from sqlalchemy.orm import configure_mappers; configure_mappers()"
    result = subprocess.run(  # noqa: S603 - comando fijo
        [sys.executable, "-c", code], cwd=BACKEND, capture_output=True, text=True, check=False
    )
    assert result.returncode == 0, result.stderr[-2000:]
