import pytest
from pydantic import ValidationError

from app.core.config import Settings


def test_production_rejects_default_secret() -> None:
    with pytest.raises(ValidationError, match="JWT_SECRET"):
        Settings(environment="production", jwt_secret="change-me")


def test_production_rejects_debug() -> None:
    with pytest.raises(ValidationError, match="DEBUG"):
        Settings(environment="production", jwt_secret="x" * 40, debug=True)


def test_production_rejects_console_email() -> None:
    with pytest.raises(ValidationError, match="EMAIL_BACKEND"):
        Settings(environment="production", jwt_secret="x" * 40, email_backend="console")


PROD = {
    "environment": "production",
    "jwt_secret": "x" * 40,
    "email_backend": "smtp",
    "storage_backend": "s3",
    "field_encryption_key": "clave-de-prueba",
    "internal_proxy_secret": "p" * 40,
}


def test_production_requires_proxy_secret() -> None:
    with pytest.raises(ValidationError, match="INTERNAL_PROXY_SECRET"):
        Settings(**{**PROD, "internal_proxy_secret": "corta"}, payment_provider="webpay")


def test_production_requires_encryption_key() -> None:
    with pytest.raises(ValidationError, match="FIELD_ENCRYPTION_KEY"):
        Settings(**{**PROD, "field_encryption_key": ""}, payment_provider="webpay")


def test_production_rejects_local_storage() -> None:
    with pytest.raises(ValidationError, match="STORAGE_BACKEND"):
        Settings(**{**PROD, "storage_backend": "local"}, payment_provider="webpay")


def test_production_rejects_simulated_payments() -> None:
    with pytest.raises(ValidationError, match="PAYMENT_PROVIDER"):
        Settings(**PROD, payment_provider="simulated")


def test_production_rejects_webpay_test_credentials() -> None:
    with pytest.raises(ValidationError, match="credenciales propias"):
        Settings(**PROD, payment_provider="webpay", webpay_environment="production")


def test_production_accepts_valid_config() -> None:
    settings = Settings(
        **PROD,
        payment_provider="webpay",
        webpay_environment="production",
        webpay_commerce_code="597012345678",
        webpay_api_key="clave-real-del-comercio",
    )
    assert settings.is_production
