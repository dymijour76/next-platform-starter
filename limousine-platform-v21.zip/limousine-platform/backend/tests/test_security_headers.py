"""Cabeceras de seguridad de la API y saneamiento del X-Request-ID."""

import pytest
from httpx import AsyncClient

HEALTH = "/api/v1/health/live"


async def test_api_security_headers(client: AsyncClient) -> None:
    res = await client.get(HEALTH)
    assert res.headers["content-security-policy"] == "default-src 'none'; frame-ancestors 'none'"
    assert res.headers["x-frame-options"] == "DENY"
    assert res.headers["x-content-type-options"] == "nosniff"
    assert res.headers["cross-origin-resource-policy"] == "same-origin"
    assert "strict-transport-security" not in res.headers  # sólo en producción


async def test_valid_request_id_is_kept(client: AsyncClient) -> None:
    res = await client.get(HEALTH, headers={"X-Request-ID": "abc-123.def_4"})
    assert res.headers["x-request-id"] == "abc-123.def_4"


@pytest.mark.parametrize("bad", ["a" * 65, "id con espacios", "id\\r\\nX-Falso: 1", "<script>"])
async def test_suspicious_request_id_is_replaced(client: AsyncClient, bad: str) -> None:
    res = await client.get(HEALTH, headers={"X-Request-ID": bad})
    assert res.headers["x-request-id"] != bad
    assert len(res.headers["x-request-id"]) == 36  # un UUID nuevo
