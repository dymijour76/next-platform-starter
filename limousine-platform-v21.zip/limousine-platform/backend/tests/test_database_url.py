from app.core.config import normalize_database_url


def test_provider_urls_become_asyncpg():
    assert normalize_database_url("postgres://u:p@h/db") == "postgresql+asyncpg://u:p@h/db"
    assert (
        normalize_database_url("postgresql://u:p@h:5432/db") == "postgresql+asyncpg://u:p@h:5432/db"
    )


def test_sslmode_is_translated_for_asyncpg():
    url = "postgresql://u:p@h/db?sslmode=require&channel_binding=require"
    assert normalize_database_url(url) == "postgresql+asyncpg://u:p@h/db?ssl=require"
    assert (
        normalize_database_url("postgresql://u:p@h/db?sslmode=prefer")
        == "postgresql+asyncpg://u:p@h/db"
    )


def test_asyncpg_url_is_unchanged():
    url = "postgresql+asyncpg://limo:limo@postgres:5432/limo"
    assert normalize_database_url(url) == url
