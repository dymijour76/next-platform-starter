"""Emails en el idioma del destinatario: textos, fechas, montos, vehículo y política."""

from datetime import UTC, datetime
from decimal import Decimal
from types import SimpleNamespace as NS

from app.core.dates import format_local, format_money
from app.core.i18n import set_locale
from app.notifications import templates
from app.reservations import emails


def _reservation(**extra):  # type: ignore[no-untyped-def]
    vehicle = NS(
        label_for=lambda loc: {"ht": "Cadillac Escalade negro, plak TBWX48"}.get(
            loc, "Cadillac Escalade negro, patente TBWX48"
        )
    )
    driver = NS(user=NS(first_name="Jorge", email="jorge@example.com", locale="fr"))
    base = dict(
        code="RES-2026-000123",
        contact_name="Marie Joseph",
        pickup_address="Av. Apoquindo 3000",
        dropoff_address=None,
        passenger_count=2,
        total_amount=Decimal("255000"),
        currency="CLP",
        pickup_at=datetime(2026, 10, 10, 23, 0, tzinfo=UTC),
        hold_expires_at=None,
        refund_amount=None,
        service=NS(name="Premium", slug="premium", translations={"ht": {"name": "Premium"}}),
        cancellation_policy_snapshot={
            "text": "Cancelación sin costo hasta 24 horas antes de la recogida; "
            "después no hay reembolso."
        },
        payments=[NS(status="AUTHORIZED", card_last4="6623", authorization_code="A1B2")],
        driver=driver,
        vehicle=vehicle,
    )
    return NS(**{**base, **extra})


def test_dates_and_money_per_language() -> None:
    dt = datetime(2026, 10, 10, 23, 0, tzinfo=UTC)
    tz = "UTC"
    assert format_local(dt, tz, "es") == "sábado 10 de octubre de 2026, 23:00"
    assert format_local(dt, tz, "en") == "Saturday, October 10, 2026, 23:00"
    assert format_local(dt, tz, "ht") == "samdi 10 oktòb 2026, 23:00"
    assert format_local(dt, tz, "zh") == "2026年10月10日（星期六）23:00"  # noqa: RUF001
    assert format_money(Decimal("125000"), "CLP", "es") == "$125.000"
    assert format_money(Decimal("125000"), "CLP", "en") == "CLP 125,000"
    assert format_money(Decimal("125000"), "CLP", "fr") == "125\u202f000 CLP"


def test_reservation_email_in_the_recipient_language() -> None:
    # El idioma de quien hace la acción (aquí, inglés) no influye: manda el del destinatario.
    set_locale("en")
    mail = emails.build("confirmed", "marie@example.com", _reservation(), "UTC", "ht")
    assert mail.subject == "Rezèvasyon RES-2026-000123 konfime"
    assert 'lang="ht"' in mail.html
    assert "samdi 10 oktòb 2026, 23:00" in mail.text
    assert "255\u202f000 CLP" in mail.text
    assert (
        "Ou ka anile gratis jiska 24 èdtan" in mail.text
    )  # política guardada en español, traducida
    assert "Si bouton an pa mache" in mail.html
    assigned = emails.build("assigned", "marie@example.com", _reservation(), "UTC", "ht")
    assert "plak TBWX48" in assigned.text


def test_without_language_it_is_spanish() -> None:
    mail = emails.build("confirmed", "a@example.com", _reservation(), "UTC", None)
    assert mail.subject == "Reserva RES-2026-000123 confirmada"
    assert 'lang="es"' in mail.html


def test_driver_email_uses_the_driver_language() -> None:
    mail = emails.driver_email(_reservation(), "UTC")
    assert mail.subject == "Nouveau trajet attribué : RES-2026-000123"
    assert "2 passagers" in mail.text


def test_account_email_and_role_names() -> None:
    mail = templates.invitation_email(
        "a@example.com", "Wen", ["Administrador financiero"], "tok", "zh"
    )
    assert mail.subject == "已为您创建访问账户"
    assert "财务管理员" in mail.text
