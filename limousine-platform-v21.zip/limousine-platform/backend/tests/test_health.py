"""Tests de salud. Los checks se sustituyen para no depender de servicios externos."""

import pytest
from httpx import AsyncClient

from app.api.v1.health import get_checks
from app.main import app


async def _ok() -> None:
    return None


async def _fail() -> None:
    raise ConnectionError("down")


async def test_live(client: AsyncClient) -> None:
    response = await client.get("/api/v1/health/live")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


async def test_ready_all_ok(client: AsyncClient) -> None:
    app.dependency_overrides[get_checks] = lambda: {"database": _ok, "redis": _ok}
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "checks": {"database": "ok", "redis": "ok"}}


async def test_ready_degraded_returns_503(client: AsyncClient) -> None:
    app.dependency_overrides[get_checks] = lambda: {"database": _ok, "redis": _fail}
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 503
    assert response.json()["checks"]["redis"] == "error"


async def test_security_headers_and_request_id(client: AsyncClient) -> None:
    response = await client.get("/api/v1/health/live", headers={"X-Request-ID": "abc-123"})
    assert response.headers["X-Request-ID"] == "abc-123"
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert response.headers["X-Frame-Options"] == "DENY"


@pytest.mark.integration
async def test_ready_against_real_services(client: AsyncClient) -> None:
    """Se ejecuta en CI, donde PostgreSQL y Redis están disponibles."""
    response = await client.get("/api/v1/health/ready")
    assert response.status_code == 200
