"""Reportes por idioma: etiquetas de periodo y CSV que Excel entiende en cada idioma."""

from datetime import date
from decimal import Decimal

from app.reports.periods import label
from app.reports.service import to_csv


def test_period_labels() -> None:
    assert label(date(2026, 10, 7), "day", "es") == "7 oct"
    assert label(date(2026, 10, 5), "week", "en") == "wk. Oct 5"
    assert label(date(2026, 10, 1), "month", "ht") == "okt 2026"
    assert label(date(2026, 10, 7), "day", "zh") == "10月7日"


def test_csv_follows_excel_conventions() -> None:
    rows = [["2026-10-01", Decimal("1234.50")]]
    es = to_csv(["Periodo", "Cobrado"], rows, "es").removeprefix("\ufeff")
    en = to_csv(["Periodo", "Cobrado"], rows, "en").removeprefix("\ufeff")
    zh = to_csv(["Periodo", "Cobrado"], rows, "zh").removeprefix("\ufeff")
    assert es.splitlines() == ["Periodo;Cobrado", "2026-10-01;1234,5"]
    assert en.splitlines() == ["Period,Collected", "2026-10-01,1234.5"]
    assert zh.splitlines()[0] == "期间,已收款"
