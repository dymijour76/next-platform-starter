"""Sentry: desactivado sin DSN, y sin datos personales en los eventos."""

from app.core.monitoring import _scrub, init_monitoring


def test_disabled_without_dsn() -> None:
    import sentry_sdk

    init_monitoring("api")  # no debe fallar ni activar nada
    assert not sentry_sdk.get_client().is_active()


def test_sensitive_data_is_removed() -> None:
    event = {
        "request": {
            "headers": {
                "Authorization": "Bearer x",
                "Cookie": "lp_at=1",
                "X-Proxy-Secret": "s",
                "Accept": "json",
            },
            "data": {"password": "secreta"},
            "cookies": {"lp_at": "1"},
        },
        "user": {"ip_address": "200.1.2.3"},
    }
    clean = _scrub(event, {})
    headers = clean["request"]["headers"]
    assert (
        headers["Authorization"] == headers["Cookie"] == headers["X-Proxy-Secret"] == "[filtrado]"
    )
    assert headers["Accept"] == "json"
    assert "data" not in clean["request"] and "cookies" not in clean["request"]
    assert "ip_address" not in clean["user"]
