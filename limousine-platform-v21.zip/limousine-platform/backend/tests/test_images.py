"""Procesamiento de imágenes: formatos, metadatos, rotación y límites."""

import io

import pytest
from PIL import Image

from app.media.images import ImageRejected, process


def jpeg(size: tuple[int, int] = (3000, 2000), exif: Image.Exif | None = None) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, (27, 36, 51)).save(buf, "JPEG", exif=exif or Image.Exif())
    return buf.getvalue()


def gps_exif(orientation: int = 1) -> Image.Exif:
    exif = Image.Exif()
    exif[0x0112] = orientation  # Orientation
    exif[0x8825] = {
        1: "S",
        2: (33.0, 26.0, 0.0),
        3: "W",
        4: (70.0, 36.0, 0.0),
    }  # GPSInfo (Santiago)
    return exif


def test_variants_are_webp_and_sorted() -> None:
    result = process(jpeg())
    assert (result.width, result.height, result.source_format) == (3000, 2000, "JPEG")
    assert [v.width for v in result.variants] == [480, 960, 1600, 2400]
    for v in result.variants:
        img = Image.open(io.BytesIO(v.data))
        assert img.format == "WEBP" and img.size == (v.width, v.height)


def test_small_image_keeps_its_own_width() -> None:
    assert [v.width for v in process(jpeg((700, 500))).variants] == [480, 700]


def test_gps_and_exif_are_removed() -> None:
    data = jpeg(exif=gps_exif())
    assert Image.open(io.BytesIO(data)).getexif().get(0x8825)  # el original sí trae GPS
    for v in process(data).variants:
        assert not Image.open(io.BytesIO(v.data)).getexif()


def test_exif_rotation_is_applied() -> None:
    # Orientación 6: la cámara guardó la foto acostada; se debe ver vertical.
    result = process(jpeg((3000, 2000), gps_exif(orientation=6)))
    assert (result.width, result.height) == (2000, 3000)


def test_transparency_is_kept() -> None:
    buf = io.BytesIO()
    Image.new("RGBA", (800, 600), (0, 0, 0, 0)).save(buf, "PNG")
    variant = process(buf.getvalue()).variants[-1]
    assert Image.open(io.BytesIO(variant.data)).mode == "RGBA"


@pytest.mark.parametrize(
    ("data", "message"),
    [
        (b"<?php echo 'no soy una imagen'; ?>", "no es una imagen"),
        (b"\xff\xd8\xff\xe0" + b"0" * 100, "no es una imagen"),  # cabecera JPEG truncada
    ],
)
def test_fake_images_rejected(data: bytes, message: str) -> None:
    with pytest.raises(ImageRejected, match=message):
        process(data)


def test_unsupported_format_rejected() -> None:
    buf = io.BytesIO()
    Image.new("RGB", (800, 600)).save(buf, "GIF")
    with pytest.raises(ImageRejected, match="Formato no admitido"):
        process(buf.getvalue())


def test_too_small_rejected() -> None:
    with pytest.raises(ImageRejected, match="muy pequeña"):
        process(jpeg((300, 200)))


def test_decompression_bomb_rejected_before_decoding() -> None:
    # Un PNG de pocos KB que declara 45 megapíxeles: se rechaza mirando sólo la cabecera.
    buf = io.BytesIO()
    Image.new("1", (9000, 5000)).save(buf, "PNG")
    assert len(buf.getvalue()) < 100_000
    with pytest.raises(ImageRejected, match="demasiados píxeles"):
        process(buf.getvalue())
