"""Configuración común de tests.

Los tests de tests/api usan una base de datos propia (sufijo _test) que se crea
y migra automáticamente, y la base 15 de Redis. Nunca tocan los datos de
desarrollo.
"""

import os

os.environ["ENVIRONMENT"] = "test"
_base_db = os.environ.get("DATABASE_URL", "postgresql+asyncpg://limo:limo@localhost:5432/limo")
os.environ["DATABASE_URL"] = os.environ.get("TEST_DATABASE_URL") or (
    _base_db if _base_db.rsplit("/", 1)[1].endswith("_test") else f"{_base_db}_test"
)
_redis = os.environ.get("REDIS_URL", "redis://localhost:6379/0")
os.environ["REDIS_URL"] = os.environ.get("TEST_REDIS_URL") or f"{_redis.rsplit('/', 1)[0]}/15"
os.environ["EMAIL_BACKEND"] = "console"
os.environ["JWT_SECRET"] = "secreto-de-pruebas-" + "x" * 32

from collections.abc import AsyncIterator  # noqa: E402

import pytest  # noqa: E402
from httpx import ASGITransport, AsyncClient  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture
async def client() -> AsyncIterator[AsyncClient]:
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()
