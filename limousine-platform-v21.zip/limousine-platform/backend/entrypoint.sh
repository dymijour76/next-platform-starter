#!/bin/sh
set -e
# Las migraciones se aplican al arrancar sólo si se solicita explícitamente.
# En producción con varias réplicas conviene ejecutarlas como un paso de despliegue aparte.
if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
  echo "Aplicando migraciones..."
  alembic upgrade head
fi
exec "$@"
