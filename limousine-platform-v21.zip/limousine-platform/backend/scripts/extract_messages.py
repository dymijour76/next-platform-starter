"""Extrae los mensajes de la API que puede ver una persona, como plantillas.

  python scripts/extract_messages.py > /tmp/mensajes.json

Recorre el código con `ast` (no con búsquedas de texto) y toma:
- el mensaje de `raise Algo("...")` y el argumento `message=`,
- los textos de `fields={...}`,
- los `message = "..."` de las clases de error,
- los `ValueError("...")` de las validaciones,
- los textos de `t("…")` (emails, alertas, reportes).
Las partes variables de los f-strings se convierten en marcadores {nombre}.
"""

import ast
import json
import sys
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "app"
ERRORS = ("Error", "Denied", "NotFound", "Conflict", "Unavailable", "Locked", "Rejected",
          "Invalid", "Required", "Limited", "Mismatch", "Password", "Allowed", "Credentials")  # fmt: skip


def name_of(node: ast.expr) -> str:
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Call):
        return name_of(node.func)
    if isinstance(node, ast.Subscript):
        return name_of(node.value)
    return "valor"


def text(node: ast.expr | None) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.JoinedStr):
        out = ""
        for part in node.values:
            if isinstance(part, ast.Constant):
                out += str(part.value)
            elif isinstance(part, ast.FormattedValue):
                out += "{" + name_of(part.value) + "}"
        return out
    if isinstance(node, ast.BinOp) and isinstance(
        node.op, ast.Add
    ):  # "a " "b" ya viene unido; "a" + f"b"
        left, right = text(node.left), text(node.right)
        return left + right if left is not None and right is not None else None
    return None


def is_error_call(call: ast.Call) -> bool:
    name = name_of(call.func)
    return name == "ValueError" or name.endswith(ERRORS) or name in {"AppError", "_locked_error"}


def collect() -> set[str]:
    found: set[str] = set()
    explicit: set[str] = set()  # textos de t(): siempre se incluyen, aunque sean una palabra
    for path in APP.rglob("*.py"):
        if path.name in {
            "config.py",
            "cli.py",
        }:  # mensajes para quien opera el servidor, no para usuarios
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and is_error_call(node):
                if node.args and (msg := text(node.args[0])):
                    found.add(msg)
                for kw in node.keywords:
                    if kw.arg == "message" and (msg := text(kw.value)):
                        found.add(msg)
                    if kw.arg == "fields" and isinstance(kw.value, ast.Dict):
                        found.update(v for v in (text(x) for x in kw.value.values) if v)
            # Textos traducidos explícitamente: t("…", …) (emails, alertas, reportes).
            if isinstance(node, ast.Call) and name_of(node.func) == "t" and node.args:
                if msg := text(node.args[0]):
                    explicit.add(msg)
                elif isinstance(node.args[0], ast.IfExp):  # t("1 x" if n == 1 else "{n} x", …)
                    explicit.update(
                        m for m in (text(node.args[0].body), text(node.args[0].orelse)) if m
                    )
            if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "message" for t in node.targets
            ):
                if msg := text(node.value):
                    found.add(msg)
            # Diccionarios de mensajes (manejador de errores): {"clave": "Texto."}
            if isinstance(node, ast.Dict) and path.name == "errors.py":
                found.update(v for v in (text(x) for x in node.values) if v and " " in v)
    # Sólo textos para personas: con letras y al menos una palabra (no códigos como "NOT_FOUND").
    errors = {s for s in found if any(c.islower() for c in s) and " " in s.strip()}
    return errors | {s for s in explicit if s.strip()}


if __name__ == "__main__":
    messages = sorted(collect())
    json.dump(messages, sys.stdout, ensure_ascii=False, indent=1)
    print(f"\n{len(messages)} mensajes", file=sys.stderr)
