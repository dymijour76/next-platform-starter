"""Planilla de traducciones para revisores nativos, ida y vuelta.

  python tools/translations.py export traducciones.xlsx
  python tools/translations.py import traducciones.xlsx      (aplica la columna "Corrección")

Reúne los dos catálogos: el del sitio (frontend/messages/source.mjs) y el de la API y los
emails (backend/app/locales/source_api.py). Al importar, rechaza las correcciones que cambian
los marcadores ({name}, {count, plural, …}) y vuelve a generar los archivos de cada idioma.
"""

import ast
import json
import re
import subprocess
import sys
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation  # noqa: F401  (reservado)

ROOT = Path(__file__).resolve().parents[1]
FRONT = ROOT / "frontend" / "messages" / "source.mjs"
BACK = ROOT / "backend" / "app" / "locales" / "source_api.py"
LANGS = [
    ("en", "English"),
    ("fr", "Français"),
    ("ht", "Kreyòl ayisyen"),
    ("zh", "中文（简体）"),
]
INDEX = {
    code: i + 1 for i, (code, _) in enumerate(LANGS)
}  # posición en [es, en, fr, ht, zh]
HEAD = [
    "Área",
    "Clave",
    "Español (original)",
    "Traducción actual",
    "Corrección",
    "Comentario",
]
FONT = "Arial"
EDIT_FILL = PatternFill("solid", start_color="FFF2CC")
HEAD_FILL = PatternFill("solid", start_color="1B2433")


def _args(text: str) -> list[str]:
    return sorted(re.findall(r"\{(\w+)[,}]", text))


def load_front() -> dict[str, list[str]]:
    script = "import(process.argv[1]).then(m => console.log(JSON.stringify(m.default)))"
    out = subprocess.run(
        ["node", "-e", script, str(FRONT)], capture_output=True, text=True, check=True
    )
    return json.loads(out.stdout)


def load_back() -> list[tuple[str, ...]]:
    tree = ast.parse(BACK.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.AnnAssign)
            and getattr(node.target, "id", "") == "MESSAGES"
        ):
            return [tuple(ast.literal_eval(e)) for e in node.value.elts]  # type: ignore[union-attr]
    raise SystemExit("No se encontró MESSAGES en source_api.py")


def export(path: str) -> None:
    front, back = load_front(), load_back()
    wb = Workbook()
    info = wb.active
    info.title = "Instrucciones"
    lines = [
        ("Revisión de traducciones", True),
        ("", False),
        (
            "1. Abra la hoja de su idioma (English, Français, Kreyòl ayisyen o 中文).",
            False,
        ),
        ("2. Compare «Español (original)» con «Traducción actual».", False),
        (
            "3. Si hay que cambiarla, escriba la versión correcta en «Corrección» (celdas amarillas).",
            False,
        ),
        ("   Deje «Corrección» vacía si la traducción actual está bien.", False),
        ("4. Use «Comentario» para dudas o para explicar un cambio.", False),
        ("", False),
        ("Importante", True),
        (
            "• Mantenga los marcadores entre llaves tal cual: {name}, {code}, {count}…",
            False,
        ),
        (
            "• Los plurales tienen la forma {count, plural, one {# hora} other {# horas}}:",
            False,
        ),
        (
            "  traduzca sólo las palabras de cada rama, no «count», «plural», «one» ni «other».",
            False,
        ),
        (
            "• Trato formal: «usted» en español, «vous» en francés, «您» en chino.",
            False,
        ),
        (
            "• Área «Sitio»: pantallas. Área «API y emails»: mensajes del servidor y correos.",
            False,
        ),
        ("", False),
        ("Ejemplo (hoja English)", True),
    ]
    for row, (text, bold) in enumerate(lines, start=1):
        cell = info.cell(row=row, column=1, value=text)
        cell.font = Font(name=FONT, bold=bold, size=14 if row == 1 else 11)
    example = [
        "Sitio",
        "nav.book",
        "Reservar",
        "Book",
        "Book now",
        "Más claro como botón principal",
    ]
    for col, value in enumerate(HEAD, start=1):
        c = info.cell(row=len(lines) + 1, column=col, value=value)
        c.font = Font(name=FONT, bold=True, color="FFFFFF")
        c.fill = HEAD_FILL
    for col, value in enumerate(example, start=1):
        c = info.cell(row=len(lines) + 2, column=col, value=value)
        c.font = Font(name=FONT)
        if col == 5:
            c.fill = EDIT_FILL
    info.column_dimensions["A"].width = 110
    for col in "BCDEF":
        info.column_dimensions[col].width = 22

    for code, name in LANGS:
        ws = wb.create_sheet(name)
        ws.append(HEAD)
        for c in ws[1]:
            c.font = Font(name=FONT, bold=True, color="FFFFFF")
            c.fill = HEAD_FILL
        rows = [("Sitio", key, v[0], v[INDEX[code]]) for key, v in front.items()]
        rows += [
            ("API y emails", f"api:{i}", r[0], r[INDEX[code]])
            for i, r in enumerate(back)
        ]
        for area, key, es, current in rows:
            ws.append([area, key, es, current, None, None])
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.font = Font(name=FONT)
                c.alignment = Alignment(wrap_text=True, vertical="top")
            row[4].fill = EDIT_FILL
        for col, width in zip("ABCDEF", [14, 30, 50, 50, 50, 30], strict=True):
            ws.column_dimensions[col].width = width
        ws.freeze_panes = "C2"
        ws.auto_filter.ref = f"A1:F{ws.max_row}"
    wb.save(path)
    total = len(front) + len(back)
    print(f"{path}: {total} textos × {len(LANGS)} idiomas")


def _rewrite_front(updates: dict[str, dict[int, str]]) -> None:
    lines = FRONT.read_text(encoding="utf-8").split("\n")
    for i, line in enumerate(lines):
        m = re.match(r'^(\s*)("(?:[^"\\]|\\.)*"): (\[.*\]),\s*$', line)
        if not m:
            continue
        key = json.loads(m.group(2))
        if key in updates:
            values = json.loads(m.group(3))
            for idx, text in updates[key].items():
                values[idx] = text
            lines[i] = (
                f"{m.group(1)}{m.group(2)}: [{', '.join(json.dumps(v, ensure_ascii=False) for v in values)}],"
            )
    FRONT.write_text("\n".join(lines), encoding="utf-8")


def _rewrite_back(updates: dict[int, dict[int, str]]) -> None:
    src = BACK.read_text(encoding="utf-8")
    tree = ast.parse(src)
    elts = next(n.value.elts for n in ast.walk(tree)
                if isinstance(n, ast.AnnAssign) and getattr(n.target, "id", "") == "MESSAGES")  # type: ignore[union-attr]  # fmt: skip
    lines = src.split("\n")
    for i in sorted(
        updates, reverse=True
    ):  # de abajo hacia arriba: no cambian los números de línea
        node = elts[i]
        values = list(ast.literal_eval(node))
        for idx, text in updates[i].items():
            values[idx] = text
        indent = " " * node.col_offset
        new = (
            f"{indent}({', '.join(json.dumps(v, ensure_ascii=False) for v in values)}),"
        )
        lines[node.lineno - 1 : node.end_lineno] = [new]  # type: ignore[misc]
    BACK.write_text("\n".join(lines), encoding="utf-8")


def import_(path: str) -> None:
    front, back = load_front(), load_back()
    wb = load_workbook(path)
    front_up: dict[str, dict[int, str]] = {}
    back_up: dict[int, dict[int, str]] = {}
    applied, rejected = 0, []
    for code, name in LANGS:
        if name not in wb.sheetnames:
            continue
        for area, key, es, _current, fix, _note in wb[name].iter_rows(
            min_row=2, values_only=True
        ):
            if not fix or not str(fix).strip():
                continue
            fix = str(fix).strip()
            if _args(fix) != _args(str(es)):
                rejected.append(
                    f"[{name}] {key}: los marcadores no coinciden con el original"
                )
                continue
            if area == "Sitio" and key in front:
                front_up.setdefault(key, {})[INDEX[code]] = fix
            elif (
                area == "API y emails"
                and re.fullmatch(r"api:\d+", str(key))
                and int(str(key)[4:]) < len(back)
            ):
                back_up.setdefault(int(str(key)[4:]), {})[INDEX[code]] = fix
            else:
                rejected.append(f"[{name}] {key}: clave desconocida")
                continue
            applied += 1
    if front_up:
        _rewrite_front(front_up)
        subprocess.run(
            ["node", "scripts/build-messages.mjs"], cwd=ROOT / "frontend", check=True
        )
    if back_up:
        _rewrite_back(back_up)
        subprocess.run(
            [sys.executable, "-m", "app.locales.build"],
            cwd=ROOT / "backend",
            check=True,
        )
    print(f"{applied} correcciones aplicadas.")
    for r in rejected:
        print("Rechazada:", r)


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in {"export", "import"}:
        raise SystemExit(__doc__)
    (export if sys.argv[1] == "export" else import_)(sys.argv[2])
