"""Recorrido de la fase 9: CSP, verificación en dos pasos, bloqueo, Ley 21.719 y QR en iPhone.

Uso: python e2e9.py main   |   python e2e9.py staff   (este con REQUIRE_STAFF_MFA=true en la API)
"""
import json, re, subprocess, sys
from datetime import UTC, datetime, timedelta
import pyotp
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase9")
PW = "Faro-Costero-Nocturno"
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name, flush=True)


def login(page, email, password=PW, landing="/account"):
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(password)
    page.get_by_role("button", name="Ingresar").click()
    if landing:
        expect(page).to_have_url(f"{BASE}{landing}")

def logout(page):
    page.get_by_role("button", name=re.compile("^(Cerrar sesión|Salir)$")).click()
    expect(page).to_have_url(f"{BASE}/")

def enable_mfa(page, secret_holder):
    page.goto(f"{BASE}/account/security")
    page.locator("#mfa-setup-password").fill(PW)
    page.get_by_role("button", name="Configurar").click()
    expect(page.get_by_role("img", name="Código QR para su aplicación de autenticación")).to_be_visible()
    secret = page.get_by_text(re.compile("^Clave:")).inner_text().split(":", 1)[1].strip()
    secret_holder.append(secret)
    page.get_by_label("Código de 6 dígitos").fill(pyotp.TOTP(secret).now())
    page.get_by_role("button", name="Activar").click()
    expect(page.get_by_text("Guarde estos códigos de respaldo")).to_be_visible()
    return [li.inner_text() for li in page.locator("ul.font-mono li").all()]

def main_part(browser, page):
    # 1. CSP en las respuestas
    res = page.goto(BASE)
    csp = res.headers.get("content-security-policy", "")
    check("CSP con nonce y sin 'unsafe-inline' en scripts", "'nonce-" in csp and "script-src 'self' 'nonce-" in csp and "unsafe-inline' 'strict" not in csp)

    # Página no encontrada, en español y con código 404
    missing = page.goto(f"{BASE}/no-existe-esta-pagina")
    expect(page.get_by_role("heading", name="No encontramos esta página")).to_be_visible()
    check("página 404 en español", missing.status == 404)

    # 2. Bloqueo progresivo por cuenta
    for _ in range(5):
        page.goto(f"{BASE}/login")
        page.get_by_label("Email", exact=True).fill("valentina@example.com")
        page.get_by_label("Contraseña").fill("incorrecta")
        page.get_by_role("button", name="Ingresar").click()
        page.wait_for_load_state("networkidle")
    expect(page.get_by_text(re.compile("Demasiados intentos fallidos. Espere 1 minuto"))).to_be_visible()
    check("bloqueo tras 5 intentos fallidos")
    page.screenshot(path=f"{SHOTS}/01-bloqueo.png")
    # El bloqueo vive en Redis: se limpia para seguir.
    flush_redis()

    # 3. Verificación en dos pasos
    login(page, "valentina@example.com")
    secret = []
    codes = enable_mfa(page, secret)
    check("se muestran 10 códigos de respaldo", len(codes) == 10)
    page.screenshot(path=f"{SHOTS}/02-codigos-respaldo.png", full_page=True)
    logout(page)
    login(page, "valentina@example.com", landing=None)
    expect(page.get_by_label("Código de verificación")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/03-login-codigo.png")
    page.get_by_label("Código de verificación").fill("123456")
    page.get_by_role("button", name="Verificar").click()
    expect(page.get_by_text(re.compile("El código no es correcto")).first).to_be_visible()
    nxt = pyotp.TOTP(secret[0]).at(datetime.now(UTC) + timedelta(seconds=30))
    page.get_by_label("Código de verificación").fill(nxt)
    page.get_by_role("button", name="Verificar").click()
    expect(page).to_have_url(f"{BASE}/account")
    check("inicio de sesión con código de la aplicación")
    logout(page)
    login(page, "valentina@example.com", landing=None)
    page.get_by_label("Código de verificación").fill(codes[0])
    page.get_by_role("button", name="Verificar").click()
    expect(page).to_have_url(f"{BASE}/account")
    page.goto(f"{BASE}/account/security")
    check("código de respaldo consumido", page.get_by_text("Le quedan 9 códigos de respaldo.").count() == 1)
    logout(page)

    # 4. El administrador restablece la verificación (teléfono perdido)
    login(page, ADMIN_EMAIL, ADMIN_PASSWORD)
    page.goto(f"{BASE}/admin/users")
    page.get_by_role("link", name="Valentina Muñoz").click()
    page.get_by_role("button", name="Restablecer verificación en dos pasos").click()
    expect(page.get_by_text(re.compile("Verificación en dos pasos restablecida"))).to_be_visible()
    check("la ficha ya no ofrece restablecer", page.get_by_role("button", name="Restablecer verificación en dos pasos").count() == 0)
    check("administrador restablece la verificación")
    logout(page)
    login(page, "valentina@example.com")
    check("tras restablecer, entra sólo con contraseña")

    # 5. Mis datos: descarga y eliminación
    page.goto(f"{BASE}/account/privacy")
    with page.expect_download() as info:
        page.get_by_role("link", name="Descargar (JSON)").click()
    data = json.loads(open(info.value.path(), encoding="utf-8").read())
    check("descarga de mis datos", data["cuenta"]["email"] == "valentina@example.com")
    page.screenshot(path=f"{SHOTS}/04-mis-datos.png", full_page=True)
    page.get_by_role("button", name="Eliminar mi cuenta").click()
    page.get_by_label("Contraseña actual").fill(PW)
    page.get_by_label("Escriba ELIMINAR para confirmar").fill("ELIMINAR")
    page.get_by_role("button", name="Eliminar definitivamente").click()
    expect(page).to_have_url(f"{BASE}/login?deleted=1")
    expect(page.get_by_text("Su cuenta fue eliminada.")).to_be_visible()
    check("cuenta eliminada", sql("select count(*) from users where email = 'valentina@example.com'") == "0")

    # 6. QR en iPhone: sin BarcodeDetector, con la cámara falsa mostrando el QR real
    cam = browser_cam.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL", permissions=["camera"])
    cam.add_init_script("delete window.BarcodeDetector;")
    d = cam.new_page(); d.set_default_timeout(15000)
    login(d, "conductor@example.com", landing="/driver")
    d.get_by_role("link", name=re.compile("Av. Apoquindo")).click()
    check("sin BarcodeDetector, como en Safari", d.evaluate("typeof window.BarcodeDetector") == "undefined")
    d.get_by_role("button", name="Escanear QR del pasajero").click()
    expect(d.get_by_text("Pasajero a bordo. ¡Buen viaje!")).to_be_visible(timeout=20000)
    d.screenshot(path=f"{SHOTS}/05-qr-iphone.png", full_page=True)
    check("jsQR leyó el QR desde la cámara", sql("select count(*) from reservation_events where note = 'Abordaje validado con QR'") == "1")

def staff_part(browser, page):
    login(page, "reservas@empresa.cl")
    page.goto(f"{BASE}/admin")
    expect(page).to_have_url(f"{BASE}/account/security?mfa=required")
    expect(page.get_by_text("Para usar el panel de administración, active la verificación en dos pasos.")).to_be_visible()
    check("personal sin verificación es enviado a activarla")
    page.screenshot(path=f"{SHOTS}/06-personal-obligado.png", full_page=True)
    enable_mfa(page, [])
    page.goto(f"{BASE}/admin")
    expect(page.get_by_role("heading", name="Hola, Tomás")).to_be_visible()
    check("con la verificación activa, entra al panel")

part = sys.argv[1] if len(sys.argv) > 1 else "main"
with sync_playwright() as p:
    browser = p.chromium.launch()
    browser_cam = p.chromium.launch(args=["--use-fake-device-for-media-stream", "--use-fake-ui-for-media-stream",
                                          f"--use-file-for-fake-video-capture={TMP}/qr-camera.y4m"])
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL", accept_downloads=True)
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        (main_part if part == "main" else staff_part)(browser, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url)
        for c in browser_cam.contexts:
            for pg in c.pages: pg.screenshot(path=f"{SHOTS}/FALLO-movil.png", full_page=True); print("URL móvil:", pg.url)
        raise
    finally:
        browser.close(); browser_cam.close()
print(f"\n{len(ok)} comprobaciones superadas")
