# Recorridos en navegador

Pruebas de extremo a extremo con Playwright: un navegador real recorre el sitio
como lo harían clientes, operadores, finanzas y conductores. Hay un recorrido
por fase (`fase2.py` … `fase9.py`), cada uno desde un estado limpio.

Además de sus propias comprobaciones, todos los recorridos vigilan dos cosas en
cada página (`csp_watch/`):

- **Violaciones de la política de seguridad de contenido (CSP).** Una política
  mal armada rompe cosas concretas (el pago, las imágenes, la cámara).
- **Identificadores HTML duplicados**, que hacen que una etiqueta enfoque el
  campo equivocado y confunden a los lectores de pantalla.

`run_all.py` falla si alguna fase falla o si aparece cualquiera de las dos.

## Requisitos

- PostgreSQL y Redis corriendo, con las migraciones aplicadas, un administrador
  general y los datos de ejemplo (`make admin`, `make demo`).
- El sitio compilado: `cd frontend && npm run build`.
- Dependencias: `pip install -r backend/requirements.txt -r e2e/requirements.txt`
  y `python -m playwright install chromium`.
- `psql` disponible (los recorridos preparan datos con él).

## Uso

```bash
cd e2e
./start_stack.sh           # API, worker, receptor de emails y sitio
python run_all.py          # fases 2 a 9
python run_all.py fase5    # sólo una fase
./stop_stack.sh

# Exigencia de verificación en dos pasos al personal:
REQUIRE_STAFF_MFA=true ./start_stack.sh && python run_all.py --staff-mfa
```

**Los recorridos borran reservas, pagos, conductores y usuarios de prueba.**
Úselos sólo contra una base de desarrollo o de CI, nunca contra producción.

## Configuración

| Variable | Por defecto |
|---|---|
| `E2E_BASE_URL` | `http://127.0.0.1:3000` |
| `E2E_DATABASE_URL` | `postgresql://limo:limo@127.0.0.1:5432/limo` |
| `E2E_REDIS_URL` | `redis://127.0.0.1:6379/0` |
| `E2E_ADMIN_EMAIL`, `E2E_ADMIN_PASSWORD` | administrador general existente |
| `E2E_SHOTS` | carpeta de capturas (`e2e-shots`) |
| `E2E_SMTP_LOG` | emails recibidos por el receptor de prueba |
| `E2E_TMP` | imágenes de prueba y video de la cámara simulada |
| `PYTHON`, `E2E_LOGS` | para `start_stack.sh` |

## Idiomas (fase 11)

`fase11.py` recorre la plataforma en los cinco idiomas: detección por el navegador, selector,
errores de la API en chino, una reserva completa en creole (pago y cancelación), el panel del
conductor en creole desde un teléfono, el panel de administración en inglés y la traducción
de contenido desde el panel. Tiene dos partes (`fase11` y `fase11-panel`), porque usan datos de
partida distintos.

## Comprobante, pie de página y redes (fase 12)

`fase12.py` completa «Sitio y contacto» desde el panel (incluida una red sin `https://`, que
debe rechazarse), revisa el pie de página en español y creole, reserva y paga, descarga el
comprobante y lee su texto, comprueba que «Imprimir» lo abre en el navegador y que sin sesión
no se descarga.

## Calificaciones y reseñas (fase 13)

`fase13.py` reserva y paga, asigna vehículo y conductor, completa el viaje desde el panel
(llega la invitación por email), califica con el ratón y con el teclado, comprueba que el
comentario no aparece hasta que el equipo lo publica, que el testimonio conserva su idioma
(`lang`) y que el conductor tiene su calificación en el panel.

## Billetera (fase 14)

`fase14.py` otorga un crédito desde el panel, comprueba que el cliente ve su saldo y el motivo,
paga una reserva con saldo, la cancela y verifica que el reembolso vuelve al saldo, revisa los
movimientos en creole y que una cuenta con saldo no se puede eliminar.

## Chat (fase 15)

`fase15.py` asigna un chófer, comprueba que el chat no existe antes, que la clienta escribe con
Enter (y salto de línea con Mayúsculas + Enter), que el chófer ve el aviso en su lista desde un
teléfono y responde, que la respuesta llega sola, el «Leído», los avisos por email, la lectura
del panel y que un envío desde otro sitio se rechaza aun con sesión válida.

## Monedas (fase 16)

`fase16.py` comprueba que sin tasas no se ofrece cambiar de moneda, que una fuente caída se
informa, que una tasa mal escrita se rechaza y que «1.030,50» se interpreta bien, y que el
visitante ve la referencia en dólares en el catálogo, la ficha y el cotizador (y «approx.» en
inglés). El entorno de pruebas no tiene internet: las tasas se fijan a mano.

## Qué simula cada recorrido de forma especial

- **Pagos (fase 5):** la pasarela simulada, con los mismos retornos que Webpay.
- **QR del conductor (fases 6 y 9):** Chromium con una cámara simulada. La
  fase 9 quita `BarcodeDetector` (como en Safari de iPhone) y transmite un video
  con el QR real de la reserva: el sitio lo decodifica con jsQR.
- **Verificación en dos pasos (fase 9):** los códigos se calculan con `pyotp`
  a partir de la clave que muestra la pantalla.

En la integración continua corren en el trabajo *Recorridos en navegador*; si
algo falla, las capturas y los registros quedan como artefacto descargable.
