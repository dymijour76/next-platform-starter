"""Recorrido de la fase 15: chat entre el cliente y el chófer.

Uso: python fase15.py   (datos: fixtures.trip, que crea al conductor)
"""
import re
from datetime import date, timedelta

from playwright.sync_api import expect, sync_playwright

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, email_subjects, shots

SHOTS = shots("fase15")
PW = "Faro-Costero-Nocturno"
ok: list[str] = []


def check(name: str, cond: bool = True) -> None:
    assert cond, name
    ok.append(name)
    print("✓", name, flush=True)


def login(browser, email: str, password: str, mobile: bool = False):  # type: ignore[no-untyped-def]
    opts = {"locale": "es-CL"}
    if mobile:
        opts.update(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
    page = browser.new_context(**opts).new_page()
    page.set_default_timeout(10000)
    page.goto(BASE + "/login")
    page.locator("input[name=email]").fill(email)
    page.locator("input[name=password]").fill(password)
    page.locator("main form button[type=submit]").first.click()
    page.wait_for_url(re.compile(r"/(account|driver)$"))
    return page


def main() -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        # 1. Reserva pagada y chófer asignado
        client = login(b, "valentina@example.com", PW)
        client.goto(BASE + "/book")
        day = date.today() + timedelta(days=(2 - date.today().weekday()) % 7 + 7)
        client.get_by_label("Fecha").fill(day.isoformat())
        client.get_by_label("Hora de recogida").fill("10:00")
        client.get_by_role("button", name="Ver precio y disponibilidad").click()
        client.get_by_label("Dirección de recogida").fill("Av. Apoquindo 3000, Las Condes")
        client.get_by_label("Acepto la política de cancelación.").check()
        client.get_by_role("button", name="Reservar y pagar").click()
        client.get_by_role("button", name="Aprobar pago").click()
        expect(client.get_by_text("Pago recibido", exact=False)).to_be_visible()
        code = re.search(r"RES-\d{4}-\d{6}", client.url).group(0)  # type: ignore[union-attr]
        check("sin chófer asignado no hay chat", client.locator("#mensajes").count() == 0)

        admin = login(b, ADMIN_EMAIL, ADMIN_PASSWORD)
        admin.goto(BASE + f"/admin/reservations?q={code}")
        admin.locator("tbody tr a").first.click()
        admin.wait_for_url(re.compile(r"/admin/reservations/[0-9a-f-]{36}$"))
        rid = admin.url.rstrip("/").split("/")[-1]
        admin.locator("select[name=vehicle_id]").select_option(index=1)
        admin.locator("select[name=driver_id]").select_option(label="Jorge Vidal (licencia A2)")
        admin.get_by_role("button", name="Guardar asignación").click()
        expect(admin.get_by_text("Asignación guardada", exact=False)).to_be_visible()

        # 2. La clienta escribe (Mayúsculas + Enter: nueva línea; Enter: enviar)
        client.goto(BASE + f"/account/reservations/{code}#mensajes")
        chat = client.locator("#mensajes")
        expect(chat.get_by_role("heading", name="Mensajes con su chófer")).to_be_visible()
        check("el chat presenta al chófer por su nombre", chat.get_by_text("Puede escribirle a Jorge", exact=False).count() == 1)
        box = chat.get_by_label("Mensaje")
        box.fill("Hola Jorge, estaré en la puerta 3.")
        box.press("Shift+Enter")
        box.type("Llevo una maleta grande.")
        box.press("Enter")
        sent = chat.locator("ol li", has_text="Llevo una maleta grande.")  # en la lista, no en el cuadro
        expect(sent).to_be_visible()
        expect(box).to_have_value("")
        check("mensaje enviado con Enter, con su salto de línea", "puerta 3.\nLlevo" in sent.inner_text())

        # 3. El chófer ve el aviso, lee y responde (desde el teléfono)
        driver = login(b, "conductor@example.com", PW, mobile=True)
        driver.goto(BASE + "/driver")
        check("aviso de mensaje nuevo en la lista del chófer", driver.get_by_text("1 mensaje nuevo").count() == 1)
        driver.goto(BASE + f"/driver/trips/{rid}#mensajes")
        code_box = driver.locator("section[aria-labelledby=driver-code]")
        driver_code = re.search(r"\b\d{4}\b", code_box.inner_text()).group(0)  # type: ignore[union-attr]
        dchat = driver.locator("#mensajes")
        expect(dchat.locator("ol li", has_text="estaré en la puerta 3")).to_be_visible()
        dchat.get_by_label("Mensaje").fill("Perfecto, llego 10 minutos antes.")
        dchat.get_by_role("button", name="Enviar").click()
        expect(dchat.locator("ol li", has_text="Perfecto, llego 10 minutos antes.")).to_be_visible()
        check("el chófer responde")
        driver.screenshot(path=f"{SHOTS}/01-chofer.png", full_page=True)

        # En otra pestaña de la clienta (la página del chat no se recarga: se prueba que la
        # respuesta llega sola).
        tab = client.context.new_page()
        tab.goto(BASE + f"/account/reservations/{code}")
        check("la clienta ve el mismo código de verificación que el chófer",
              tab.get_by_text("Código de su chófer").count() == 1 and driver_code in tab.locator("main").inner_text())
        tab.close()
        # 4. La respuesta aparece sola en la pantalla de la clienta, y su mensaje figura leído
        expect(chat.locator("ol li", has_text="Perfecto, llego 10 minutos antes.")).to_be_visible(timeout=12000)
        check("la respuesta llega sin recargar la página")
        client.reload()
        # Junto a su último mensaje: "Leído" (el chófer ya lo abrió).
        expect(client.locator("#mensajes").get_by_text("Leído", exact=False)).to_be_visible()
        check("su mensaje figura como leído")

        client.screenshot(path=f"{SHOTS}/02-cliente.png", full_page=True)

        # 5. Avisos por email (uno por racha, sin el texto)
        admin.wait_for_timeout(1500)
        subjects = email_subjects()
        check("aviso al chófer", f"Mensaje del pasajero ({code})" in subjects)
        check("aviso a la clienta", f"Tiene un mensaje de su chófer ({code})" in subjects)

        # 6. El panel lee la conversación, sin poder escribir
        admin.goto(BASE + f"/admin/reservations/{rid}")
        expect(admin.get_by_role("heading", name="Mensajes entre el cliente y el chófer")).to_be_visible()
        check("el panel muestra la conversación en sólo lectura", admin.locator("textarea#chat-message").count() == 0)

        # 7. Un envío desde otro sitio se rechaza (CSRF)
        # Con la sesión válida de la clienta y un origen ajeno: el escenario de un ataque.
        # (Además, sus cookies son SameSite=Lax: un navegador real no las enviaría en un POST
        # desde otro sitio. La verificación de origen es una segunda barrera.)
        cookie = "; ".join(f"{c['name']}={c['value']}" for c in client.context.cookies())
        url = BASE + f"/account/reservations/{code}/messages"
        body, json_ct = '{"body":"x"}', {"Content-Type": "application/json", "Cookie": cookie}
        foreign = client.request.post(url, data=body, headers={**json_ct, "Origin": "https://otro-sitio.example"}, max_redirects=0)
        check("un envío desde otro sitio se rechaza, aun con sesión", foreign.status == 403)
        own = client.request.post(url, data='{"body":"Gracias"}', headers={**json_ct, "Origin": BASE}, max_redirects=0)
        check("el mismo envío desde el propio sitio se acepta", own.status == 201)
        b.close()
    print(f"\n{len(ok)} comprobaciones superadas")


if __name__ == "__main__":
    main()
