"""Recorrido de la fase 12: pie de página, redes sociales y comprobante en PDF.

Uso: python fase12.py
"""
import io
import re
from datetime import date, timedelta

import pdfplumber
from playwright.sync_api import expect, sync_playwright

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, shots

SHOTS = shots("fase12")
PW = "Faro-Costero-Nocturno"
ok: list[str] = []


def check(name: str, cond: bool = True) -> None:
    assert cond, name
    ok.append(name)
    print("✓", name, flush=True)


def login(page, email: str, password: str) -> None:  # type: ignore[no-untyped-def]
    page.goto(BASE + "/login")
    page.locator("input[name=email]").fill(email)
    page.locator("input[name=password]").fill(password)
    page.locator("main form button[type=submit]").first.click()
    page.wait_for_url(BASE + "/account")


# Las comprobaciones se hacen con fetch desde la página: usa la sesión del navegador igual que
# un clic. (page.request no envía siempre las cookies de la sesión y recibe una redirección.)
FETCH = """async (u) => {
  const r = await fetch(u);
  const bytes = Array.from(new Uint8Array(await r.arrayBuffer()));
  return [r.status, r.headers.get("content-type"), r.headers.get("content-disposition"), bytes];
}"""


def pdf_text(content: bytes) -> str:
    with pdfplumber.open(io.BytesIO(content)) as pdf:
        return "\n".join(p.extract_text() or "" for p in pdf.pages)


def main() -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        admin = b.new_context(locale="es-CL").new_page()
        admin.set_default_timeout(10000)
        login(admin, ADMIN_EMAIL, ADMIN_PASSWORD)

        # 1. Sitio y contacto desde el panel
        admin.goto(BASE + "/admin/site")
        admin.get_by_label("Nombre comercial").fill("Limusinas del Pacífico")
        admin.get_by_label("Razón social").fill("Limusinas del Pacífico SpA")
        admin.get_by_label("RUT de la empresa").fill("12.345.678-5")
        admin.get_by_label("Horario de atención (opcional)", exact=True).fill("Atención 24/7")
        admin.get_by_label("Dirección (opcional)", exact=True).fill("Av. Apoquindo 3000, Las Condes")
        admin.get_by_label("WhatsApp (opcional)", exact=True).fill("+56 9 8765 4321")
        admin.get_by_label("Instagram").fill("http://instagram.com/limusinas")  # sin https: error
        admin.get_by_role("button", name="Guardar").click()
        expect(admin.get_by_text("Use una dirección https:// completa.")).to_be_visible()
        check("una red sin https:// se rechaza con su mensaje")
        admin.get_by_label("Instagram").fill("https://instagram.com/limusinas")
        admin.get_by_label("Tripadvisor").fill("https://www.tripadvisor.cl/limusinas")
        admin.locator("details:has(#tr-ht-hours) > summary").click()
        admin.locator("#tr-ht-hours").fill("Disponib 24/7")
        admin.get_by_role("button", name="Guardar").click()
        expect(admin.get_by_text("Datos guardados. Ya se muestran en el sitio.")).to_be_visible()
        check("datos de la empresa guardados desde el panel")

        # 2. Pie de página
        home = b.new_context(locale="es-CL").new_page()
        home.goto(BASE)
        footer = home.locator("footer")
        expect(footer.get_by_text("Limusinas del Pacífico").first).to_be_visible()
        wa = footer.get_by_role("link", name=re.compile("Escríbanos por WhatsApp"))
        check("WhatsApp con enlace directo", wa.get_attribute("href") == "https://wa.me/56987654321")
        insta = footer.get_by_role("link", name=re.compile("^Instagram"))
        check("las redes nuevas aparecen en el pie", footer.get_by_role("link", name=re.compile("^Tripadvisor")).count() == 1)
        check("red social en pestaña nueva y segura", insta.get_attribute("target") == "_blank"
              and "noopener" in (insta.get_attribute("rel") or ""))
        home.screenshot(path=f"{SHOTS}/01-pie.png", full_page=True)
        ht = b.new_context(locale="ht").new_page()
        ht.goto(BASE + "/services")
        check("horario traducido al creole en el pie", ht.locator("footer").get_by_text("Disponib 24/7").count() == 1)

        # 3. Comprobante del cliente
        client = b.new_context(locale="es-CL", accept_downloads=True).new_page()
        client.set_default_timeout(10000)
        login(client, "valentina@example.com", PW)
        client.goto(BASE + "/book")
        day = date.today() + timedelta(days=(2 - date.today().weekday()) % 7 + 7)
        client.get_by_label("Fecha").fill(day.isoformat())
        client.get_by_label("Hora de recogida").fill("10:00")
        client.get_by_role("button", name="Ver precio y disponibilidad").click()
        client.get_by_label("Dirección de recogida").fill("Av. Apoquindo 3000, Las Condes")
        client.get_by_label("Acepto la política de cancelación.").check()
        client.get_by_role("button", name="Reservar y pagar").click()
        client.get_by_role("button", name="Aprobar pago").click()
        expect(client.get_by_text("Pago recibido", exact=False)).to_be_visible()
        code = re.search(r"RES-\d{4}-\d{6}", client.url).group(0)  # type: ignore[union-attr]
        with client.expect_download() as info:
            client.get_by_role("link", name="Descargar comprobante (PDF)").click()
        download = info.value
        check("descarga con nombre de archivo", download.suggested_filename == f"comprobante-{code}.pdf")
        text = pdf_text(open(download.path(), "rb").read())
        for piece in ["Limusinas del Pacífico SpA", "RUT 12345678-5", "Comprobante de reserva", code, "Confirmada",
                      "Pagado", "Este comprobante no es una boleta ni factura electrónica."]:
            assert piece in text, (piece, text)
        check("el PDF trae la empresa, la reserva, el pago y el aviso legal")
        print_link = client.get_by_role("link", name=re.compile("Imprimir comprobante"))
        check("imprimir abre en pestaña nueva", print_link.get_attribute("target") == "_blank")
        status, ctype, disposition, _ = client.evaluate(FETCH, print_link.get_attribute("href"))
        check("imprimir abre el PDF en el navegador", status == 200 and ctype == "application/pdf"
              and disposition.startswith("inline"))
        client.screenshot(path=f"{SHOTS}/02-reserva-con-comprobante.png", full_page=True)

        # 4. Comprobante desde el panel y para otra persona
        admin.goto(BASE + f"/admin/reservations?q={code}")
        admin.locator("tbody tr a").first.click()
        href = admin.get_by_role("link", name=re.compile("Imprimir comprobante")).get_attribute("href")
        status, _, _, data = admin.evaluate(FETCH, href)
        check("el personal descarga el comprobante desde el panel", status == 200 and code in pdf_text(bytes(data)))
        other = b.new_context().new_page()
        anon = other.request.get(BASE + f"/account/reservations/{code}/receipt", max_redirects=0)
        check("sin sesión no se descarga", anon.status in (302, 303, 307, 308))
        b.close()
    print(f"\n{len(ok)} comprobaciones superadas")


if __name__ == "__main__":
    main()
