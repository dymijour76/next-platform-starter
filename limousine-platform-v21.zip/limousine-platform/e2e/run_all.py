"""Corre los recorridos de todas las fases, cada uno desde un estado limpio.

  python run_all.py              fases 2 a 9 (el sistema debe estar corriendo: start_stack.sh)
  python run_all.py --staff-mfa  sólo la exigencia de verificación al personal
                                 (el sistema debe arrancar con REQUIRE_STAFF_MFA=true)
  python run_all.py fase5 fase7  sólo esas fases

Registra además cualquier violación de la política de seguridad de contenido (CSP)
y falla si hubo alguna.
"""

import argparse
import os
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CSP_LOG = os.environ.setdefault("E2E_CSP_LOG", "/tmp/e2e-csp-violations.log")

# fase → (opciones de reset, preparación adicional, argumentos del recorrido)
PLAN: dict[str, tuple[list[str], list[str], list[str]]] = {
    "fase2": (["--users", "admin"], [], []),
    "fase3": ([], [], []),
    "fase4": ([], [], []),
    "fase5": ([], [], []),
    "fase6": (["--no-vehicles"], [], []),
    "fase7": ([], ["fixtures.images"], []),
    "fase8": ([], ["fixtures.activity"], []),
    "fase9": ([], ["fixtures.trip"], ["main"]),
    "fase11": ([], ["fixtures.trip"], ["publico"]),
    "fase11-panel": ([], ["fixtures.activity"], ["panel"]),
    "fase12": ([], [], []),
    "fase13": ([], ["fixtures.trip"], []),
    "fase14": ([], [], []),
    "fase15": ([], ["fixtures.trip"], []),
    "fase16": ([], [], []),
}


def run(args: list[str]) -> int:
    env = {**os.environ, "PYTHONPATH": f"{HERE}{os.pathsep}{HERE / 'csp_watch'}"}
    return subprocess.run([sys.executable, *args], cwd=HERE, env=env, check=False).returncode


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("phases", nargs="*")
    parser.add_argument("--staff-mfa", action="store_true")
    opts = parser.parse_args()

    plan = {"fase9-personal": ([], [], ["staff"])} if opts.staff_mfa else {
        k: v for k, v in PLAN.items() if not opts.phases or k in opts.phases
    }
    Path(CSP_LOG).unlink(missing_ok=True)
    results = []
    for name, (reset_args, prepare, script_args) in plan.items():
        started = time.monotonic()
        ok = run(["-m", "fixtures.reset", *reset_args]) == 0
        for module in prepare:
            ok = ok and run(["-m", module]) == 0
        script = f"{name.split('-')[0]}.py"  # fase9-personal → fase9.py, fase11-panel → fase11.py
        ok = ok and run([script, *script_args]) == 0
        results.append((name, ok, time.monotonic() - started))
        print(f"{'✓' if ok else '✗'} {name} ({time.monotonic() - started:.0f} s)", flush=True)

    violations = Path(CSP_LOG).read_text().splitlines() if Path(CSP_LOG).exists() else []
    csp = [v for v in violations if "DUP-ID" not in v]
    dup = [v for v in violations if "DUP-ID" in v]
    print(f"\nFases: {sum(ok for _, ok, _ in results)} de {len(results)} correctas. "
          f"Violaciones de CSP: {len(csp)}. IDs duplicados: {len(dup)}.")  # fmt: skip
    for line in violations[:15]:
        print("  ", line[:300])
    return 0 if all(ok for _, ok, _ in results) and not violations else 1


if __name__ == "__main__":
    sys.exit(main())
