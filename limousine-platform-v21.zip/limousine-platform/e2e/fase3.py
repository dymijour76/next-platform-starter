"""Recorrido de la fase 3 (servicios y precios) en un navegador real."""
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase3")
ok = []
SCL = ZoneInfo("America/Santiago")

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name)

def next_weekday(wd, weeks=1):
    d = datetime.now(SCL).date() + timedelta(days=7 * weeks)
    return d + timedelta(days=(wd - d.weekday()) % 7)

def login(page, email, pw):
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(pw)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account")

def logout(page):
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")

def steps(browser, ctx, page):
    # 1. Catálogo público
    page.goto(BASE)
    page.get_by_role("link", name="Ver detalles y precios").click()
    expect(page).to_have_url(f"{BASE}/services")
    expect(page.get_by_role("heading", name="Premium")).to_be_visible()
    check("catálogo muestra el precio desde", page.get_by_text("$85.000").count() == 1)
    page.screenshot(path=f"{SHOTS}/01-servicios.png", full_page=True)

    # 2. Cotización con recargos: sábado 23:00, 4 horas en Premium
    page.get_by_role("link", name="Premium").click()
    expect(page.get_by_role("heading", name="Calcule su precio")).to_be_visible()
    saturday = next_weekday(5)
    page.get_by_label("Fecha").fill(saturday.isoformat())
    page.get_by_label("Hora de recogida").fill("23:00")
    page.get_by_label("Duración").select_option(str(4 * 60))
    page.get_by_role("button", name="Calcular precio").click()
    expect(page.get_by_text("Recargo nocturno (20 %)")).to_be_visible()
    expect(page.get_by_text("Recargo fin de semana (10 %)")).to_be_visible()
    # 40.000 + 4 × 85.000 = 380.000; +20 % (76.000) +10 % (38.000) = 494.000
    expect(page.get_by_role("cell", name="$494.000")).to_be_visible()
    expect(page.get_by_text("sábado", exact=False).first).to_be_visible()
    check("cotización con recargos nocturno y de fin de semana")
    check("la duración elegida se conserva", page.get_by_label("Duración").input_value() == "240")
    check("hora en formato de 24 horas", page.get_by_text("23:00").count() >= 1)
    page.screenshot(path=f"{SHOTS}/02-cotizacion.png", full_page=True)

    # 3. Día hábil a mediodía: sin recargos
    wednesday = next_weekday(2)
    page.get_by_label("Fecha").fill(wednesday.isoformat())
    page.get_by_label("Hora de recogida").fill("12:00")
    page.get_by_label("Duración").select_option(str(3 * 60))
    page.get_by_role("button", name="Calcular precio").click()
    expect(page.get_by_role("cell", name="$295.000")).to_be_visible()
    check("día hábil sin recargos", page.get_by_text("Recargo nocturno").count() == 0)

    # 4. Anticipación insuficiente
    soon = datetime.now(SCL) + timedelta(minutes=40)
    page.get_by_label("Fecha").fill(soon.date().isoformat())
    page.get_by_label("Hora de recogida").fill(soon.strftime("%H:%M"))
    page.get_by_role("button", name="Calcular precio").click()
    expect(page.get_by_text("anticipación").first).to_be_visible()
    check("rechaza recogidas con poca anticipación")
    page.screenshot(path=f"{SHOTS}/03-anticipacion.png")

    # 5. Administrador: cambia la tarifa de Standard
    login(page, ADMIN_EMAIL, ADMIN_PASSWORD)
    page.goto(f"{BASE}/admin/services")
    page.screenshot(path=f"{SHOTS}/04-admin-servicios.png", full_page=True)
    page.get_by_role("link", name="Standard").click()
    expect(page.get_by_role("heading", name="Standard")).to_be_visible()
    page.get_by_label("Valor hora").fill("38000")
    page.get_by_role("button", name="Guardar cambios").click()
    expect(page.get_by_text("Servicio guardado.")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/05-editar-servicio.png", full_page=True)
    page.goto(f"{BASE}/services")
    # 15.000 + 2 × 38.000 = 91.000
    check("el catálogo refleja la nueva tarifa", page.get_by_text("$91.000").count() == 1)

    # 6. Nueva regla: descuento por viaje largo, y simulador
    page.goto(f"{BASE}/admin/pricing")
    page.get_by_role("link", name="Nueva regla").click()
    expect(page.get_by_role("heading", name="Nueva regla de precio")).to_be_visible()
    page.get_by_label("Nombre", exact=True).fill("Descuento viaje largo")
    page.get_by_label("Tipo").select_option("DISCOUNT")
    page.get_by_label("Valor", exact=True).fill("10")
    page.get_by_label("Desde cuántas horas").fill("6")
    page.screenshot(path=f"{SHOTS}/06-nueva-regla.png", full_page=True)
    page.get_by_role("button", name="Crear regla").click()
    expect(page.get_by_text("Regla creada.")).to_be_visible()
    check("regla creada")

    page.goto(f"{BASE}/admin/pricing")
    expect(page.get_by_text("Descuento viaje largo")).to_be_visible()
    expect(page.get_by_text("−10 %")).to_be_visible()
    page.get_by_label("Servicio").select_option(label="Standard")
    page.get_by_label("Fecha").fill(wednesday.isoformat())
    page.get_by_label("Hora de recogida").fill("12:00")
    page.get_by_label("Duración").select_option(str(6 * 60))
    page.get_by_role("button", name="Simular").click()
    expect(page.get_by_text("Descuento viaje largo (10 %)")).to_be_visible()
    # 15.000 + 6 × 38.000 = 243.000; −10 % = −24.300 → 218.700
    expect(page.get_by_role("cell", name="$218.700")).to_be_visible()
    check("simulador aplica el descuento por duración")
    check("descuento con signo antes del peso", page.get_by_role("cell", name="−$24.300").count() == 1)
    page.screenshot(path=f"{SHOTS}/07-precios-simulador.png", full_page=True)

    # 7. Configuración: validación y guardado
    page.get_by_label("Zona horaria").fill("Marte/Olympus")
    page.get_by_role("button", name="Guardar configuración").click()
    expect(page.get_by_text("Zona horaria desconocida.")).to_be_visible()
    page.get_by_label("Zona horaria").fill("America/Santiago")
    page.get_by_role("button", name="Guardar configuración").click()
    expect(page.get_by_text("Configuración guardada.")).to_be_visible()
    check("configuración valida la zona horaria")
    logout(page)

    # 8. Administrador de reservas: ve la tarifa, no la modifica, no ve Precios
    login(page, "reservas@empresa.cl", "Faro-Costero-Nocturno")
    page.goto(f"{BASE}/admin")
    nav = page.get_by_role("navigation", name="Administración")
    check("reservas ve Servicios pero no Precios",
          nav.get_by_role("link", name="Servicios").count() == 1 and nav.get_by_role("link", name="Precios").count() == 0)
    page.goto(f"{BASE}/admin/services")
    check("reservas no puede crear servicios", page.get_by_role("link", name="Nuevo servicio").count() == 0)
    page.get_by_role("link", name="Premium").click()
    expect(page.get_by_role("heading", name="Premium")).to_be_visible()
    check("tarifa de sólo lectura", page.get_by_label("Valor hora").is_disabled())
    check("sin botón guardar", page.get_by_role("button", name="Guardar cambios").count() == 0)
    page.goto(f"{BASE}/admin/pricing")
    check("acceso directo a Precios bloqueado", "denied=1" in page.url)
    logout(page)

    # 9. Móvil
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL")
    mp = m.new_page(); mp.set_default_timeout(8000)
    mp.goto(f"{BASE}/services/professional")
    mp.get_by_label("Fecha").fill(saturday.isoformat())
    mp.get_by_label("Hora de recogida").fill("20:00")
    mp.get_by_role("button", name="Calcular precio").click()
    expect(mp.get_by_text("Recargo fin de semana (10 %)")).to_be_visible()
    mp.screenshot(path=f"{SHOTS}/08-movil-servicio.png", full_page=True)
    check("sin desbordamiento en móvil", not mp.evaluate("document.documentElement.scrollWidth > innerWidth"))

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL")
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        steps(browser, ctx, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url); raise
    finally:
        browser.close()
print(f"\n{len(ok)} comprobaciones superadas")
