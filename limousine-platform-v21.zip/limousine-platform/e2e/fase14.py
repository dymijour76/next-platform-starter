"""Recorrido de la fase 14: billetera (crédito, pago con saldo, reembolso al saldo, privacidad).

Uso: python fase14.py
"""
import re
from datetime import date, timedelta

from playwright.sync_api import expect, sync_playwright

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, shots

SHOTS = shots("fase14")
PW = "Faro-Costero-Nocturno"
ok: list[str] = []


def check(name: str, cond: bool = True) -> None:
    assert cond, name
    ok.append(name)
    print("✓", name, flush=True)


def login(browser, email: str, password: str, locale: str = "es-CL"):  # type: ignore[no-untyped-def]
    page = browser.new_context(locale=locale, permissions=["clipboard-read", "clipboard-write"]).new_page()
    page.set_default_timeout(10000)
    page.goto(BASE + "/login")
    page.locator("input[name=email]").fill(email)
    page.locator("input[name=password]").fill(password)
    page.locator("main form button[type=submit]").first.click()
    page.wait_for_url(re.compile(r"/account$"))
    return page


def main() -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        # 1. Crédito desde la ficha del cliente
        admin = login(b, ADMIN_EMAIL, ADMIN_PASSWORD)
        admin.goto(BASE + "/admin/users?q=valentina")
        admin.get_by_role("link", name=re.compile("Valentina")).first.click()
        wallet = admin.locator("section[aria-labelledby=wallet-title]")
        expect(wallet).to_be_visible()
        wallet.get_by_label("Monto").fill("300000")
        wallet.get_by_label(re.compile("^Motivo")).fill("Compensación por demora del 12 de septiembre")
        wallet.get_by_role("button", name="Otorgar crédito").click()
        expect(admin.get_by_text("Crédito otorgado.")).to_be_visible()
        expect(wallet).to_contain_text("$300.000")
        check("crédito otorgado desde el panel")

        # 2. El cliente ve su saldo y el motivo
        client = login(b, "valentina@example.com", PW)
        client.goto(BASE + "/account/wallet")
        expect(client.get_by_text("$300.000").first).to_be_visible()
        check("saldo y motivo visibles para el cliente", client.get_by_text("Compensación por demora del 12 de septiembre").count() == 1)
        check("sin recarga mientras esté desactivada", client.get_by_role("heading", name="Recargar saldo").count() == 0)

        # 3. Reserva pagada con saldo
        client.goto(BASE + "/book")
        day = date.today() + timedelta(days=(2 - date.today().weekday()) % 7 + 7)
        client.get_by_label("Fecha").fill(day.isoformat())
        client.get_by_label("Hora de recogida").fill("10:00")
        client.get_by_role("button", name="Ver precio y disponibilidad").click()
        client.get_by_label("Dirección de recogida").fill("Av. Apoquindo 3000, Las Condes")
        client.get_by_label("Acepto la política de cancelación.").check()
        client.get_by_role("button", name="Reservar y pagar").click()
        # En la pasarela se puede volver: la reserva queda pendiente y ahí aparece el saldo.
        client.wait_for_url(re.compile(r"/payments/simulator/"))
        client.goto(BASE + "/account/reservations")
        client.locator("a[href^='/account/reservations/RES-']").first.click()
        client.wait_for_url(re.compile(r"/account/reservations/RES-\d{4}-\d{6}"))
        code = re.search(r"RES-\d{4}-\d{6}", client.url).group(0)  # type: ignore[union-attr]
        expect(client.get_by_role("button", name="Pagar con mi saldo")).to_be_visible()
        client.get_by_role("button", name="Pagar con mi saldo").click()
        expect(client.get_by_text("Reserva pagada con su saldo.", exact=False)).to_be_visible()
        check("reserva pagada con saldo y confirmada", client.get_by_text("Confirmada").count() >= 1)
        client.screenshot(path=f"{SHOTS}/01-pagada-con-saldo.png", full_page=True)
        client.goto(BASE + "/account/wallet")
        check("el pago aparece en los movimientos", client.get_by_text(f"Pago de la reserva {code}").count() == 1)

        # 4. Cancelación: el reembolso vuelve al saldo
        client.goto(BASE + f"/account/reservations/{code}")
        client.get_by_role("button", name="Cancelar reserva").click()
        client.get_by_role("button", name=re.compile("Sí, cancelar")).click()
        expect(client.get_by_text("La reserva fue cancelada.", exact=False).first).to_be_visible()
        client.goto(BASE + "/account/wallet")
        check("el reembolso vuelve al saldo", client.get_by_text(f"Reembolso de la reserva {code}").count() == 1)
        card = client.get_by_role("region", name="Tarjeta de su billetera")
        expect(card).to_contain_text("$300.000")
        check("saldo restituido completo")
        check("la tarjeta muestra un número válido", re.search(r"LP-\d{4}-\d{4}", card.inner_text()) is not None)
        check("la tarjeta muestra al titular", "VALENTINA" in card.inner_text().upper())
        number = re.search(r"LP-\d{4}-\d{4}", card.inner_text()).group(0)  # type: ignore[union-attr]
        client.get_by_role("button", name="Copiar número").click()
        expect(client.get_by_text("Número copiado")).to_be_visible()
        check("copiar el número lo deja en el portapapeles",
              client.evaluate("navigator.clipboard.readText()") == number)
        client.screenshot(path=f"{SHOTS}/02-billetera.png", full_page=True)

        # 5. En creole
        # Su cuenta quedó en español: cambia al creole con el selector.
        client.goto(BASE + "/account/wallet")
        client.get_by_label("Idioma: Español").click()
        client.get_by_role("button", name="Kreyòl ayisyen").click()
        expect(client.get_by_role("heading", name="Bous mwen")).to_be_visible()
        check("movimientos traducidos al creole", client.get_by_text("Kredi yo bay").count() == 1)
        client.get_by_label("Lang: Kreyòl ayisyen").click()
        client.get_by_role("button", name="Español").click()
        expect(client.get_by_role("heading", name="Mi billetera")).to_be_visible()

        # 6. Con saldo no se elimina la cuenta
        client.goto(BASE + "/account/privacy")
        client.get_by_role("button", name="Eliminar mi cuenta").click()  # abre el formulario
        client.locator("input[name=current_password]").fill(PW)
        client.locator("input[name=confirmation]").fill("ELIMINAR")
        client.get_by_role("button", name="Eliminar definitivamente").click()
        expect(client.get_by_text("Tiene saldo en su billetera", exact=False)).to_be_visible()
        check("con saldo no se elimina la cuenta", client.get_by_text("Tiene saldo en su billetera", exact=False).count() == 1)
        b.close()
    print(f"\n{len(ok)} comprobaciones superadas")


if __name__ == "__main__":
    main()
