"""Actividad simulada de 30 días para probar el panel y los reportes."""
import asyncio, random, secrets
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from zoneinfo import ZoneInfo

from fixtures import _backend  # noqa: F401  (debe ir antes de importar la app)
from sqlalchemy import select
from app.db.session import SessionLocal, engine
from app.db import models  # noqa: F401
from app.auth.security import hash_password
from app.drivers.models import Driver
from app.payments.models import Payment, Refund
from app.reservations.models import Reservation, ReservationCounter
from app.services.models import Service
from app.users.models import CustomerProfile, Role, User, UserRole
from app.vehicles.models import Vehicle
from common import PASSWORD

SCL = ZoneInfo("America/Santiago")
random.seed(7)
counter = 0

def new_res(svc, pickup, status, total, created=None, **kw):
    global counter
    counter += 1
    r = Reservation(code=f"RES-2026-{counter:06d}", service_id=svc.id, status=status, pickup_at=pickup,
        duration_minutes=180, end_at=pickup + timedelta(hours=3), blocks_until=pickup + timedelta(hours=4),
        pickup_address=random.choice(["Av. Apoquindo 3000, Las Condes", "Aeropuerto de Santiago", "Hotel W, Isidora Goyenechea 3000", "Av. Kennedy 5413, Las Condes"]),
        passenger_count=random.randint(1, 4), contact_name=random.choice(["Ana Pérez", "Luis Soto", "Carla Rojas", "Diego Fuentes", "Paula Díaz"]),
        contact_email="cliente@example.com", contact_phone="+56912345678", currency="CLP", total_amount=Decimal(total),
        pricing_snapshot={"pickup_local": pickup.astimezone(SCL).isoformat(), "lines": [], "net": "0", "tax": "0", "tax_name": "IVA", "prices_include_tax": True, "billed_hours": "3"},
        cancellation_policy_snapshot={"text": "Cancelación sin costo hasta 24 horas antes.", "free_cancellation_hours": 24, "late_cancellation_refund_percent": 0},
        qr_token=secrets.token_urlsafe(16), **kw)
    if created: r.created_at = created
    return r

async def main():
    async with SessionLocal() as db:
        services = {s.slug: s for s in await db.scalars(select(Service))}
        price = {"standard": 125000, "professional": 190000, "premium": 295000}
        now = datetime.now(UTC)
        today = now.astimezone(SCL).date()
        rows = []
        for back in range(30, 0, -1):
            day = today - timedelta(days=back)
            for _ in range(random.randint(1, 4)):
                slug = random.choice(list(services))
                pickup = datetime(day.year, day.month, day.day, random.choice([9, 12, 15, 19, 22]), 0, tzinfo=SCL)
                status = random.choices(["COMPLETED", "CANCELLED", "NO_SHOW", "EXPIRED"], [80, 10, 4, 6])[0]
                r = new_res(services[slug], pickup, status, price[slug], created=pickup - timedelta(days=random.randint(1, 10)))
                db.add(r); await db.flush()
                if status in ("COMPLETED", "NO_SHOW", "CANCELLED"):
                    paid = pickup - timedelta(days=random.randint(1, 5))
                    refund = status == "CANCELLED"
                    p = Payment(reservation_id=r.id, provider="simulated", status="REFUNDED" if refund else "AUTHORIZED",
                                amount=r.total_amount, currency="CLP", refunded_amount=r.total_amount if refund else 0,
                                buy_order=f"{r.code}-1", session_id="s", authorized_at=paid, expires_at=paid,
                                card_last4="6623", authorization_code=f"{random.randint(1000,9999)}")
                    db.add(p); await db.flush()
                    if refund:
                        f = Refund(payment_id=p.id, amount=r.total_amount, status="SUCCEEDED", reason="Cancelación de la reserva")
                        db.add(f); await db.flush(); f.created_at = pickup - timedelta(hours=30)
        # Un reembolso fallido reciente
        r = new_res(services["standard"], now + timedelta(days=5), "CANCELLED", 125000)
        db.add(r); await db.flush()
        p = Payment(reservation_id=r.id, provider="simulated", status="AUTHORIZED", amount=Decimal(125000), currency="CLP",
                    buy_order=f"{r.code}-1", session_id="s", authorized_at=now - timedelta(days=1), expires_at=now, card_last4="1234")
        db.add(p); await db.flush()
        db.add(Refund(payment_id=p.id, amount=Decimal(125000), status="FAILED", reason="Cancelación de la reserva", error_message="Webpay no respondió"))
        # Conductor con licencia por vencer, y viajes de hoy asignados
        u = User(email="jorge.vidal@example.com", password_hash=hash_password(PASSWORD), first_name="Jorge", last_name="Vidal", phone="+56955551234")
        db.add(u); await db.flush(); db.add(CustomerProfile(user_id=u.id))
        role = await db.scalar(select(Role).where(Role.code == "driver")); db.add(UserRole(user_id=u.id, role_id=role.id))
        d = Driver(user_id=u.id, license_number="15234567", license_class="A2", license_expires_on=today + timedelta(days=12))
        db.add(d); await db.flush()
        vehicles = {v.service_id: v for v in await db.scalars(select(Vehicle))}
        end_of_day = datetime.combine(today, datetime.min.time(), tzinfo=SCL) + timedelta(hours=23, minutes=30)
        for i, slug in enumerate(["premium", "professional"]):
            pickup = min(now + timedelta(hours=1 + i * 5), end_of_day - timedelta(hours=1 - i * 0.5)).replace(second=0, microsecond=0)
            tr = new_res(services[slug], pickup, "CONFIRMED", price[slug], vehicle_id=vehicles[services[slug].id].id,
                         driver_id=d.id if i == 0 else None, confirmed_at=now)
            db.add(tr); await db.flush()
            pp = Payment(reservation_id=tr.id, provider="simulated", status="AUTHORIZED", amount=tr.total_amount, currency="CLP",
                         buy_order=f"{tr.code}-1", session_id="s", authorized_at=now - timedelta(hours=3), expires_at=now, card_last4="6623")
            db.add(pp)
        # Mañana, confirmado y sin asignar
        db.add(new_res(services["standard"], now + timedelta(hours=26), "CONFIRMED", 125000, confirmed_at=now))
        db.add(new_res(services["premium"], now + timedelta(days=3), "PENDING_PAYMENT", 295000, hold_expires_at=now + timedelta(minutes=25)))
        await db.merge(ReservationCounter(year=2026, last_value=counter))
        await db.commit()
        print("reservas creadas:", counter)
    await engine.dispose()
if __name__ == "__main__":
    asyncio.run(main())
