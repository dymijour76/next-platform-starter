"""Acceso a los modelos del backend desde los fixtures."""
import os
import sys

from common import BACKEND, DATABASE_URL

sys.path.insert(0, str(BACKEND))
os.environ["DATABASE_URL"] = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://", 1)
