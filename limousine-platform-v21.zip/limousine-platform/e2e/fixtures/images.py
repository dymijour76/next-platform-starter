"""Fotos de prueba (2400 px, con GPS en el EXIF para comprobar que se elimina) y un archivo falso."""
import math
import os

from PIL import Image, ImageDraw, ImageFilter

from common import TMP


def photo(path: str, top, bottom, accent, size=(2400, 1500)) -> None:  # noqa: ANN001
    w, h = size
    img = Image.new("RGB", size)
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / h
        d.line([(0, y), (w, y)], fill=tuple(int(top[i] * (1 - t) + bottom[i] * t) for i in range(3)))
    d.polygon([(w * 0.35, h), (w * 0.47, h * 0.55), (w * 0.53, h * 0.55), (w * 0.65, h)], fill=(40, 44, 52))
    for i in range(14):
        x, y = w * (0.08 + 0.06 * i), h * (0.5 + 0.03 * math.sin(i))
        d.ellipse([x - 30, y - 30, x + 30, y + 30], fill=accent)
    d.rectangle([w * 0.3, h * 0.62, w * 0.7, h * 0.8], fill=(15, 18, 24))
    exif = Image.Exif()
    exif[0x8825] = {1: "S", 2: (33.0, 26.0, 0.0), 3: "W", 4: (70.0, 36.0, 0.0)}
    img.filter(ImageFilter.GaussianBlur(6)).save(path, "JPEG", quality=88, exif=exif)


if __name__ == "__main__":
    folder = os.path.join(TMP, "imgs")
    os.makedirs(folder, exist_ok=True)
    photo(f"{folder}/boda.jpg", (27, 36, 51), (184, 163, 116), (255, 236, 200))
    photo(f"{folder}/aeropuerto.jpg", (10, 20, 40), (70, 90, 120), (255, 255, 255))
    photo(f"{folder}/eventos.jpg", (40, 20, 30), (120, 80, 60), (255, 210, 150))
    with open(f"{folder}/falsa.jpg", "w") as f:
        f.write("<?php system($_GET['c']); ?>")
