"""Viaje listo para abordar (recogida en 50 min, asignado) y video de cámara falsa con su QR."""
import asyncio, os, secrets
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from fixtures import _backend  # noqa: F401  (debe ir antes de importar la app)
from PIL import Image
import qrcode
from sqlalchemy import select
from app.db.session import SessionLocal, engine
from app.db import models  # noqa: F401
from app.auth.security import hash_password
from app.drivers.models import Driver
from app.reservations.models import Reservation
from app.services.models import Service
from app.users.models import CustomerProfile, Role, User, UserRole
from app.vehicles.models import Vehicle
from common import PASSWORD, TMP

async def main() -> str:
    async with SessionLocal() as db:
        svc = await db.scalar(select(Service).where(Service.slug == "premium"))
        vehicle = await db.scalar(select(Vehicle).where(Vehicle.service_id == svc.id))
        u = User(email="conductor@example.com", password_hash=hash_password(PASSWORD), first_name="Jorge", last_name="Vidal", phone="+56955551234")
        db.add(u); await db.flush(); db.add(CustomerProfile(user_id=u.id))
        db.add(UserRole(user_id=u.id, role_id=(await db.scalar(select(Role).where(Role.code == "driver"))).id))
        d = Driver(user_id=u.id, license_number="1", license_class="A2", license_expires_on=datetime.now(UTC).date() + timedelta(days=300))
        db.add(d); await db.flush()
        now = datetime.now(UTC).replace(second=0, microsecond=0)
        pickup = now + timedelta(minutes=50)
        token = secrets.token_urlsafe(24)
        r = Reservation(code="RES-2026-000900", service_id=svc.id, status="ARRIVED", pickup_at=pickup, duration_minutes=180,
            end_at=pickup + timedelta(hours=3), blocks_until=pickup + timedelta(hours=4), pickup_address="Av. Apoquindo 3000, Las Condes",
            passenger_count=2, contact_name="Valentina Muñoz", contact_email="valentina@example.com", contact_phone="+56987654321",
            currency="CLP", total_amount=Decimal(295000), pricing_snapshot={"pickup_local": pickup.isoformat()},
            cancellation_policy_snapshot={"text": "x"}, qr_token=token, vehicle_id=vehicle.id, driver_id=d.id, confirmed_at=now)
        db.add(r); await db.commit()
    await engine.dispose()
    return token

os.makedirs(TMP, exist_ok=True)
token = asyncio.run(main())

# Video Y4M (lo que acepta la cámara falsa de Chromium): el QR sobre fondo gris, 20 cuadros.
qr = qrcode.make(token, border=4).convert("RGB").resize((360, 360), Image.NEAREST)
frame = Image.new("RGB", (640, 480), (120, 120, 120)); frame.paste(qr, (140, 60))
y, cb, cr = frame.convert("YCbCr").split()
cb = cb.resize((320, 240)); cr = cr.resize((320, 240))
with open(f"{TMP}/qr-camera.y4m", "wb") as f:
    f.write(b"YUV4MPEG2 W640 H480 F10:1 Ip A1:1 C420jpeg\n")
    for _ in range(20):
        f.write(b"FRAME\n" + y.tobytes() + cb.tobytes() + cr.tobytes())
print("token", token[:8], "…, video", os.path.getsize(f"{TMP}/qr-camera.y4m"), "bytes")
