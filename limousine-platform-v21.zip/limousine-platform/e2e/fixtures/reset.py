"""Estado de partida de un recorrido.

  python -m fixtures.reset [--users demo|admin] [--no-vehicles] [--keep-content]

Siempre: sin reservas, pagos ni conductores; tarifas y reglas de ejemplo; Redis y
el registro de emails vacíos. Por defecto, un vehículo por servicio.
"""

import argparse
import os
import shutil
import subprocess
import sys

from common import SMTP_LOG, flush_redis, sql

VEHICLES = """insert into vehicles (plate, service_id, brand, model, year, color, passenger_capacity)
select v.plate, s.id, v.brand, v.model, 2024, 'Negro', v.cap from services s join (values
 ('standard','RTKL21','Mercedes-Benz','Clase E',4),('professional','SGHP35','Lincoln','Navigator L',8),
 ('premium','TBWX48','Cadillac','Escalade ESV',10)) v(slug,plate,brand,model,cap) on v.slug = s.slug"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--users", choices=["demo", "admin"], default="demo")
    parser.add_argument("--no-vehicles", action="store_true")
    parser.add_argument("--keep-content", action="store_true")
    args = parser.parse_args()

    # Billetera: TRUNCATE (no dispara el trigger que protege los movimientos; con CASCADE
    # también vacía los pagos y reembolsos que apuntan a ella).
    sql("truncate wallet_entries, wallets cascade")
    for table in ("messages", "reviews", "refunds", "payments", "reservations", "reservation_counters", "vehicle_blocks", "vehicles", "drivers"):
        sql(f"delete from {table}")
    sql("update services set hourly_rate = 35000 where slug = 'standard'")
    # Contenido sin traducir: cada recorrido parte del mismo estado.
    sql("update services set translations = '{}'::jsonb")
    sql("update pricing_rules set translations = '{}'::jsonb")
    sql("update users set locale = null")  # nadie eligió idioma todavía
    sql("delete from app_settings where key = 'company'")  # datos de la empresa de fábrica
    sql("delete from pricing_rules where name not in ('Recargo nocturno', 'Recargo fin de semana')")
    if not args.no_vehicles:
        sql(VEHICLES)
    if not args.keep_content:
        for table in ("carousel_slides", "service_images", "media_assets"):
            sql(f"delete from {table}")
        media = os.environ.get("MEDIA_ROOT")
        if media:
            shutil.rmtree(os.path.join(media, "media"), ignore_errors=True)
    flush_redis()
    if os.path.exists(SMTP_LOG):
        os.remove(SMTP_LOG)
    if args.users == "admin":
        sql("delete from users where email <> (select email from users u join user_roles ur on ur.user_id = u.id "
            "join roles r on r.id = ur.role_id where r.code = 'super_admin' order by u.created_at limit 1)")
    else:
        subprocess.run([sys.executable, "-m", "fixtures.users"], check=True)


if __name__ == "__main__":
    main()
