"""Usuarios de prueba (se conserva el administrador general): clienta, operaciones y finanzas."""
import asyncio

from fixtures import _backend  # noqa: F401  (debe ir antes de importar la app)

from sqlalchemy import select, text

from app.auth.security import hash_password
from app.db import models  # noqa: F401
from app.db.session import SessionLocal, engine
from app.users.models import CustomerProfile, Role, User, UserRole
from common import ADMIN_EMAIL, PASSWORD

PEOPLE = [
    ("valentina@example.com", "Valentina", "Muñoz", "customer", "+56987654321"),
    ("reservas@empresa.cl", "Tomás", "Reyes", "reservations_admin", None),
    ("finanzas@empresa.cl", "Paula", "Soto", "finance_admin", None),
]


async def main() -> None:
    async with SessionLocal() as db:
        await db.execute(text("delete from drivers"))
        await db.execute(text("delete from users where email <> :admin"), {"admin": ADMIN_EMAIL})
        for email, first, last, role, phone in PEOPLE:
            user = User(email=email, password_hash=hash_password(PASSWORD), first_name=first, last_name=last, phone=phone)
            db.add(user)
            await db.flush()
            db.add(CustomerProfile(user_id=user.id, address="Av. Apoquindo 3000", city="Las Condes"))
            role_id = await db.scalar(select(Role.id).where(Role.code == role))
            db.add(UserRole(user_id=user.id, role_id=role_id))
        await db.commit()
    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
