"""Recorrido de la fase 4 (reservas) en un navegador real."""
import re, subprocess, time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase4")
PW = "Faro-Costero-Nocturno"
SCL = ZoneInfo("America/Santiago")
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name, flush=True)


def next_weekday(wd, weeks=1):
    d = datetime.now(SCL).date() + timedelta(days=7 * weeks)
    return d + timedelta(days=(wd - d.weekday()) % 7)

def login_form(page, email):
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(PW)
    page.get_by_role("button", name="Ingresar").click()

def logout(page):
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")

def step1(page, service, day, hour, minutes):
    page.get_by_label("Servicio", exact=True).select_option(label=service)
    page.get_by_label("Fecha").fill(day.isoformat())
    page.get_by_label("Hora de recogida").fill(hour)
    page.get_by_label("Duración").select_option(str(minutes))
    page.get_by_role("button", name="Ver precio y disponibilidad").click()

def steps(browser, page):
    wed = next_weekday(2)

    # 1. Desde la ficha del servicio, sin sesión: pide login y vuelve a la reserva
    page.goto(f"{BASE}/services/premium")
    page.get_by_label("Fecha").fill(wed.isoformat())
    page.get_by_label("Hora de recogida").fill("12:00")
    page.get_by_role("button", name="Calcular precio").click()
    page.get_by_role("link", name="Reservar este servicio").click()
    expect(page).to_have_url(re.compile(r"/login\?next="))
    login_form(page, "valentina@example.com")
    expect(page).to_have_url(f"{BASE}/book?service=premium")
    check("login devuelve a la reserva con el servicio elegido",
          "Premium" in page.get_by_label("Servicio", exact=True).locator("option:checked").inner_text())

    # 2. Paso 1: precio y disponibilidad
    step1(page, "Premium, hasta 10 pasajeros", wed, "12:00", 180)
    expect(page.get_by_role("cell", name="$295.000")).to_be_visible()
    expect(page.get_by_label("Dirección de recogida")).to_be_visible()
    check("paso 1 muestra precio y abre el paso 2")
    check("dirección y contacto prellenados desde el perfil",
          "Apoquindo" in page.get_by_label("Dirección de recogida").input_value()
          and page.get_by_label("Teléfono").input_value() == "+56987654321")
    page.screenshot(path=f"{SHOTS}/01-reservar-paso2.png", full_page=True)

    # 3. Paso 2: sin aceptar la política, luego reservar
    page.get_by_label("Destino").fill("Hotel W, Isidora Goyenechea 3000")
    page.get_by_label("Pasajeros").select_option("4")
    page.get_by_label("Indicaciones").fill("Aniversario: por favor, champaña fría.")
    page.get_by_role("button", name="Reservar y pagar").click()
    expect(page.get_by_text("Debe aceptar la política de cancelación.")).to_be_visible()
    check("exige aceptar la política", page.get_by_label("Destino").input_value().startswith("Hotel W"))
    page.get_by_label("Acepto la política de cancelación.").check()
    page.get_by_role("button", name="Reservar y pagar").click()
    # La clienta abandona la pasarela: la reserva queda pendiente de pago.
    expect(page).to_have_url(re.compile(r"/payments/simulator/checkout"))
    page.get_by_role("button", name="Anular compra").click()
    expect(page).to_have_url(re.compile(r"/account/reservations/RES-\d{4}-\d{6}\?payment=aborted"))
    code = re.search(r"RES-\d{4}-\d{6}", page.url).group(0)
    expect(page.get_by_text("El pago no se completó.")).to_be_visible()
    expect(page.get_by_text("Pendiente de pago").first).to_be_visible()
    expect(page.get_by_text("Mantenemos su cupo hasta las")).to_be_visible()
    check(f"reserva creada {code}")
    page.screenshot(path=f"{SHOTS}/02-reserva-creada.png", full_page=True)

    # 4. El mismo horario ya no tiene unidades (Premium tiene 1)
    page.goto(f"{BASE}/book?service=premium")
    step1(page, "Premium, hasta 10 pasajeros", wed, "13:00", 180)
    expect(page.get_by_text("No quedan unidades disponibles para ese horario.")).to_be_visible()
    check("sin doble reserva", page.get_by_label("Dirección de recogida").count() == 0)
    page.screenshot(path=f"{SHOTS}/03-sin-disponibilidad.png", full_page=True)
    # 4 horas después (2 h + 1 h de preparación) sí hay
    step1(page, "Premium, hasta 10 pasajeros", wed, "17:00", 180)
    expect(page.get_by_label("Dirección de recogida")).to_be_visible()
    check("disponible después del tiempo de preparación")

    # 5. Mis reservas y resumen de cuenta
    page.goto(f"{BASE}/account")
    expect(page.get_by_role("heading", name="Próxima reserva")).to_be_visible()
    expect(page.get_by_text("Premium").first).to_be_visible()
    page.goto(f"{BASE}/account/reservations")
    expect(page.get_by_text(code)).to_be_visible()
    check("aparece en Mis reservas y en el resumen")
    page.screenshot(path=f"{SHOTS}/04-mis-reservas.png", full_page=True)
    logout(page)

    # 6. Operador de reservas: busca, confirma e historial
    page.goto(f"{BASE}/login"); login_form(page, "reservas@empresa.cl")
    expect(page).to_have_url(f"{BASE}/account")
    page.goto(f"{BASE}/admin/reservations")
    page.get_by_label("Buscar").fill("valentina")
    page.get_by_role("button", name="Filtrar").click()
    expect(page.get_by_role("link", name=code)).to_be_visible()
    page.screenshot(path=f"{SHOTS}/05-admin-reservas.png", full_page=True)
    page.get_by_role("link", name=code).click()
    expect(page.get_by_role("heading", name=code)).to_be_visible()
    page.get_by_label("Nota").fill("Transferencia recibida")
    page.get_by_role("button", name="Confirmar sin pago en línea").click()
    expect(page.get_by_text("Reserva confirmada. Se avisó al cliente por email.")).to_be_visible()
    expect(page.get_by_text("Confirmada").first).to_be_visible()
    expect(page.get_by_text("por Tomás Reyes: Transferencia recibida")).to_be_visible()
    check("operador confirma y queda en el historial")
    page.screenshot(path=f"{SHOTS}/06-admin-detalle.png", full_page=True)
    page.goto(f"{BASE}/admin/reservations/settings")
    check("operador ve la política sin poder editarla", page.get_by_label("Cupo retenido (minutos)").is_disabled())
    logout(page)

    # 7. La clienta cancela dentro del plazo: reembolso total
    page.goto(f"{BASE}/login"); login_form(page, "valentina@example.com")
    expect(page).to_have_url(f"{BASE}/account")
    page.goto(f"{BASE}/account/reservations/{code}")
    expect(page.get_by_text("Confirmada").first).to_be_visible()
    page.get_by_role("button", name="Cancelar reserva").click()
    expect(page.get_by_text("se le devolverán $295.000")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/07-cancelar.png", full_page=True)
    page.get_by_role("button", name="Sí, cancelar la reserva").click()
    expect(page.get_by_text("La reserva fue cancelada.")).to_be_visible()
    page.reload()
    expect(page.get_by_text("Reembolso: $295.000")).to_be_visible()
    check("cancelación con reembolso según política")

    # 8. Vencimiento automático por el worker
    page.goto(f"{BASE}/book?service=standard")
    step1(page, "Standard, hasta 4 pasajeros", next_weekday(3), "10:00", 120)
    page.get_by_label("Acepto la política de cancelación.").check()
    page.get_by_role("button", name="Reservar y pagar").click()
    expect(page).to_have_url(re.compile(r"/payments/simulator/checkout"))
    page.get_by_role("button", name="Anular compra").click()
    expect(page).to_have_url(re.compile(r"payment=aborted"))
    code2 = re.search(r"RES-\d{4}-\d{6}", page.url).group(0)
    sql(f"update reservations set hold_expires_at = now() - interval '1 second' where code = '{code2}'")
    for _ in range(40):
        if sql(f"select status from reservations where code = '{code2}'") == "EXPIRED":
            break
        time.sleep(2)
    page.reload()
    expect(page.get_by_text("Vencida").first).to_be_visible()
    check("el worker vence la reserva impaga")

    # 9. Emails reales entregados por el worker
    time.sleep(3)
    log = open(SMTP_LOG, encoding="utf-8", errors="ignore").read()
    for subject in [f"Recibimos su reserva {code}", f"Reserva {code} confirmada", f"Reserva {code} cancelada", f"Reserva {code2} vencida"]:
        check(f"email: {subject}", subject in log)

    # 10. Móvil
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL",
                            storage_state=page.context.storage_state())
    mp = m.new_page(); mp.set_default_timeout(8000)
    mp.goto(f"{BASE}/book?service=professional")
    step1(mp, "Professional, hasta 8 pasajeros", next_weekday(4), "20:00", 180)
    expect(mp.get_by_label("Dirección de recogida")).to_be_visible()
    total_y = mp.get_by_text("Total", exact=True).locator("visible=true").first.bounding_box()["y"]
    check("en móvil el precio aparece antes de los datos del viaje",
          total_y < mp.get_by_label("Dirección de recogida").bounding_box()["y"])
    mp.screenshot(path=f"{SHOTS}/08-movil-reservar.png", full_page=True)
    check("sin desbordamiento en móvil", not mp.evaluate("document.documentElement.scrollWidth > innerWidth"))

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL")
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        steps(browser, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url); raise
    finally:
        browser.close()
print(f"\n{len(ok)} comprobaciones superadas")
