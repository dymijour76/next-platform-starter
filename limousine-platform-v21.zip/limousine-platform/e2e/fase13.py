"""Recorrido de la fase 13: calificaciones y reseñas.

Uso: python fase13.py   (datos: fixtures.trip, que crea al conductor)
"""
import re
from datetime import date, timedelta

from playwright.sync_api import expect, sync_playwright

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, email_subjects, shots, sql

SHOTS = shots("fase13")
PW = "Faro-Costero-Nocturno"
COMMENT = "Chófer muy puntual y amable. El auto, impecable."
ok: list[str] = []


def check(name: str, cond: bool = True) -> None:
    assert cond, name
    ok.append(name)
    print("✓", name, flush=True)


def login(browser, email: str, password: str, locale: str = "es-CL"):  # type: ignore[no-untyped-def]
    page = browser.new_context(locale=locale).new_page()
    page.set_default_timeout(10000)
    page.goto(BASE + "/login")
    page.locator("input[name=email]").fill(email)
    page.locator("input[name=password]").fill(password)
    page.locator("main form button[type=submit]").first.click()
    page.wait_for_url(re.compile(r"/(account|driver)$"))
    return page


def main() -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        # 1. Reserva pagada
        client = login(b, "valentina@example.com", PW)
        client.goto(BASE + "/book")
        day = date.today() + timedelta(days=(2 - date.today().weekday()) % 7 + 7)
        client.get_by_label("Fecha").fill(day.isoformat())
        client.get_by_label("Hora de recogida").fill("10:00")
        client.get_by_role("button", name="Ver precio y disponibilidad").click()
        client.get_by_label("Dirección de recogida").fill("Av. Apoquindo 3000, Las Condes")
        client.get_by_label("Acepto la política de cancelación.").check()
        client.get_by_role("button", name="Reservar y pagar").click()
        client.get_by_role("button", name="Aprobar pago").click()
        expect(client.get_by_text("Pago recibido", exact=False)).to_be_visible()
        code = re.search(r"RES-\d{4}-\d{6}", client.url).group(0)  # type: ignore[union-attr]
        check("no se puede calificar antes del viaje", client.locator("#calificar").count() == 0)

        # 2. Asignación, viaje en el pasado y cierre desde el panel
        admin = login(b, ADMIN_EMAIL, ADMIN_PASSWORD)
        admin.goto(BASE + f"/admin/reservations?q={code}")
        admin.locator("tbody tr a").first.click()
        admin.locator("select[name=vehicle_id]").select_option(index=1)
        admin.locator("select[name=driver_id]").select_option(label="Jorge Vidal (licencia A2)")
        admin.get_by_role("button", name="Guardar asignación").click()
        expect(admin.get_by_text("Asignación guardada", exact=False)).to_be_visible()
        sql(f"update reservations set pickup_at = now() - interval '5 hours', end_at = now() - interval '3 hours', "
            f"blocks_until = now() - interval '2 hours' where code = '{code}'")
        admin.reload()
        admin.get_by_role("button", name="Marcar completada").click()
        expect(admin.get_by_text("Reserva marcada como completada.")).to_be_visible()
        admin.wait_for_timeout(1500)  # el worker envía los emails
        check("invitación a calificar por email", f"¿Cómo estuvo su viaje? ({code})" in email_subjects())

        # 3. La clienta califica (servicio con el ratón, chófer con el teclado)
        client.goto(BASE + f"/account/reservations/{code}#calificar")
        form = client.locator("#calificar")
        expect(form.get_by_role("heading", name="¿Cómo estuvo su viaje?")).to_be_visible()
        # Como un usuario: clic en la cuarta estrella (la etiqueta de la opción).
        service_stars = form.locator("fieldset", has_text="Servicio")
        service_stars.locator("label").nth(3).click()
        check("cuatro estrellas con el ratón", service_stars.get_by_label("4 estrellas").is_checked())
        driver_stars = form.locator("fieldset", has_text="Chófer")
        driver_stars.locator("input[value='1']").focus()
        for _ in range(4):
            client.keyboard.press("ArrowRight")
        check("las estrellas se eligen con el teclado", driver_stars.locator("input[value='5']").is_checked())
        form.get_by_label("Comentario (opcional)", exact=True).fill(COMMENT)
        consent = form.get_by_label(re.compile("Acepto que mi comentario se publique"))
        check("la autorización muestra el nombre abreviado", "Valentina M." in (consent.locator("xpath=..").inner_text()))
        consent.check()
        form.get_by_role("button", name="Enviar calificación").click()
        expect(client.get_by_text("Su comentario se publicará después de una revisión.")).to_be_visible()
        check("calificación enviada y en revisión")
        client.screenshot(path=f"{SHOTS}/01-calificacion.png", full_page=True)

        visitor = b.new_context(locale="es-CL").new_page()
        visitor.goto(BASE)
        check("sin moderar, el comentario no se publica", visitor.get_by_text(COMMENT).count() == 0)

        # 4. Moderación
        admin.goto(BASE + "/admin/reviews")
        expect(admin.get_by_text(COMMENT)).to_be_visible()
        admin.get_by_role("button", name="Publicar").click()
        expect(admin.get_by_text("Reseña publicada.")).to_be_visible()
        check("el equipo publica el comentario")

        visitor.goto(BASE)
        quote = visitor.locator("blockquote", has_text=COMMENT)
        expect(quote).to_be_visible()
        check("testimonio en la portada con su autor", visitor.get_by_text("Valentina M.").count() >= 1)
        ht = b.new_context(locale="ht").new_page()
        ht.goto(BASE)
        check("el comentario conserva su idioma (lang)", ht.locator("blockquote", has_text=COMMENT).get_attribute("lang") == "es")
        visitor.goto(BASE + "/services")
        check("promedio y cantidad en el catálogo", visitor.get_by_text(re.compile(r"\d,\d · 1 opinión")).count() >= 1)
        visitor.screenshot(path=f"{SHOTS}/02-catalogo-con-promedio.png", full_page=True)

        # 5. Calificación del conductor, sólo en el panel
        admin.goto(BASE + "/admin/drivers")
        admin.get_by_role("link", name=re.compile("Jorge")).first.click()
        rating = admin.locator("section[aria-labelledby=driver-rating]")
        expect(rating).to_contain_text("5,0 · 1 opinión")
        check("calificación del conductor en su ficha")
        b.close()
    print(f"\n{len(ok)} comprobaciones superadas")


if __name__ == "__main__":
    main()
