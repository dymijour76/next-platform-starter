"""Recorrido de la fase 7 (contenido: biblioteca, carrusel y fotos de servicios)."""
import io, re, urllib.request
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from PIL import Image
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase7")
SCL = ZoneInfo("America/Santiago")
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name, flush=True)

def login(page, email, password):
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(password)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account")

def logout(page):
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")

def upload(page, path, alt):
    page.get_by_label("Imagen", exact=True).set_input_files(path)
    page.get_by_label("Descripción de la imagen").fill(alt)
    page.get_by_role("button", name="Subir").click()

def new_slide(page, image_alt, title, subtitle, cta=None, start=None):
    page.goto(f"{BASE}/admin/content/slides/new")
    page.locator("label", has_text=image_alt).first.click()
    page.get_by_label("Título", exact=True).fill(title)
    page.get_by_label("Texto (opcional)", exact=True).fill(subtitle)
    if cta:
        page.get_by_label("Texto del botón (opcional)", exact=True).fill(cta[0])
        page.get_by_label("Enlace del botón").fill(cta[1])
    if start:
        page.get_by_label("Desde").fill(start)
    page.get_by_role("button", name="Crear diapositiva").click()
    expect(page).to_have_url(f"{BASE}/admin/content?saved=1")

def steps(browser, page):
    # 1. Sin diapositivas, portada de texto
    page.goto(BASE)
    expect(page.get_by_role("heading", name="Su chófer le espera.")).to_be_visible()
    check("sin diapositivas, portada de texto")

    login(page, ADMIN_EMAIL, ADMIN_PASSWORD)
    page.goto(f"{BASE}/admin/content/media")

    # 2. Validaciones de subida
    upload(page, f"{TMP}/imgs/falsa.jpg", "Intento con un archivo falso")
    expect(page.get_by_text("El archivo no es una imagen válida.").first).to_be_visible()
    check("archivo disfrazado de foto rechazado")
    page.get_by_label("Imagen", exact=True).set_input_files(f"{TMP}/imgs/boda.jpg")
    page.get_by_label("Descripción de la imagen").fill("")
    page.get_by_role("button", name="Subir").click()
    expect(page.get_by_text("Describa la imagen (texto alternativo).")).to_be_visible()
    check("descripción obligatoria")

    # 3. Subir tres fotos
    for n, (path, alt) in enumerate([(f"{TMP}/imgs/boda.jpg", "Limusina blanca decorada para una boda"),
                                     (f"{TMP}/imgs/aeropuerto.jpg", "Sedán negro esperando en el aeropuerto"),
                                     (f"{TMP}/imgs/eventos.jpg", "Interior iluminado de la limusina")], start=1):
        upload(page, path, alt)
        # Espera a que la imagen nueva aparezca: el aviso de éxito puede ser el de la anterior.
        expect(page.locator("main li img")).to_have_count(n, timeout=15000)
    check("tres imágenes en la biblioteca", page.locator("main li img").count() == 3)
    page.screenshot(path=f"{SHOTS}/01-biblioteca.png", full_page=True)
    src = page.locator("main li img").first.get_attribute("src")
    served = Image.open(io.BytesIO(urllib.request.urlopen(src).read()))
    check("se sirve en WebP sin datos de ubicación", served.format == "WEBP" and not served.getexif())

    # 4. Carrusel: dos activas y una programada para mañana; reordenar
    new_slide(page, "Limusina blanca", "Su boda, sin preocupaciones", "Limusinas decoradas y chófer de etiqueta.",
              ("Ver Premium", "/services/premium"))
    tomorrow = (datetime.now(SCL) + timedelta(days=1)).date().isoformat()
    new_slide(page, "Sedán negro", "Traslados al aeropuerto", "Seguimos su vuelo y esperamos por usted.",
              ("Reservar", "/book"), start=tomorrow)
    new_slide(page, "Interior iluminado", "Eventos corporativos", "Reciba a sus invitados como se merecen.")
    expect(page.get_by_text(re.compile("Programada desde"))).to_be_visible()
    check("diapositiva programada no se publica aún", page.get_by_text("En la portada").count() == 2)
    # Dos clics seguidos, sin esperar: cada uno debe subirla un lugar.
    page.get_by_role("button", name="Subir «Eventos corporativos»").click()
    page.get_by_role("button", name="Subir «Eventos corporativos»").click()
    page.wait_for_timeout(1500)
    page.reload()
    expect(page.locator("ol li").first).to_contain_text("Eventos corporativos")
    check("reordenar diapositivas")
    page.screenshot(path=f"{SHOTS}/02-carrusel-admin.png", full_page=True)

    # Enlace peligroso rechazado
    page.goto(f"{BASE}/admin/content/slides/new")
    page.locator("label", has_text="Limusina blanca").first.click()
    page.get_by_label("Título", exact=True).fill("Prueba")
    page.get_by_label("Texto del botón (opcional)", exact=True).fill("Clic")
    page.get_by_label("Enlace del botón").fill("javascript:alert(1)")
    page.get_by_role("button", name="Crear diapositiva").click()
    expect(page.get_by_text("Use una ruta del sitio (/services) o una dirección https://.")).to_be_visible()
    check("enlace javascript: rechazado")

    # 5. Fotos del servicio Premium: portada = interior
    page.goto(f"{BASE}/admin/services")
    page.get_by_role("link", name="Premium").click()
    expect(page.get_by_role("heading", name="Fotografías")).to_be_visible()
    for alt, pos in [("Interior iluminado", "1"), ("Limusina blanca", "2")]:
        item = page.locator("li", has_text=alt)
        item.get_by_label("Mostrar").check()
        item.get_by_role("spinbutton").fill(pos)
    page.get_by_role("button", name="Guardar fotografías").click()
    expect(page.get_by_text("Fotografías guardadas. La primera es la portada.")).to_be_visible()
    check("fotos del servicio guardadas")

    # 6. Imagen en uso no se puede eliminar
    page.goto(f"{BASE}/admin/content/media")
    in_use = page.locator("main li", has_text="En uso").first.get_by_role("button", name="Eliminar imagen")
    check("imagen en uso protegida", in_use.is_disabled())
    logout(page)

    # 7. Portada pública con carrusel
    page.goto(BASE)
    carousel = page.get_by_role("region", name="Destacados")
    expect(carousel).to_be_visible()
    expect(page.get_by_role("heading", name="Eventos corporativos")).to_be_visible()
    check("carrusel en la portada en el orden elegido")
    check("la programada no aparece", page.get_by_role("button", name=re.compile("Ir a la diapositiva")).count() == 2)
    check("imagen principal cargada", page.evaluate("[...document.querySelectorAll('section img')].some(i => i.complete && i.naturalWidth > 0)"))
    page.get_by_role("button", name="Pausar").click()
    check("botón de pausa", page.get_by_role("button", name="Reanudar").count() == 1)
    page.get_by_role("button", name="Diapositiva siguiente").click()
    expect(page.get_by_role("heading", name="Su boda, sin preocupaciones")).to_be_visible()
    check("la diapositiva oculta no recibe foco", page.locator("[aria-roledescription='diapositiva'][inert]").count() == 1)
    page.get_by_role("link", name="Ver Premium").click()
    expect(page).to_have_url(f"{BASE}/services/premium")
    check("botón de la diapositiva lleva al servicio")
    first = page.locator("main img").first
    check("portada del servicio es la foto elegida", first.get_attribute("alt") == "Interior iluminado de la limusina")
    page.screenshot(path=f"{SHOTS}/04-servicio-fotos.png", full_page=True)
    page.goto(BASE)
    page.get_by_role("button", name="Pausar").click()
    page.screenshot(path=f"{SHOTS}/03-portada.png", full_page=True)

    # 8. Sin permiso de contenido
    login(page, "reservas@empresa.cl", "Faro-Costero-Nocturno")
    page.goto(f"{BASE}/admin/content")
    check("operador sin acceso a contenido", "denied=1" in page.url)
    logout(page)

    # 9. Móvil y movimiento reducido
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL", reduced_motion="reduce")
    mp = m.new_page(); mp.set_default_timeout(8000)
    mp.goto(BASE)
    expect(mp.get_by_role("heading", name="Eventos corporativos")).to_be_visible()
    mp.wait_for_timeout(8000)  # más que el intervalo: con movimiento reducido no debe avanzar
    check("con movimiento reducido no avanza solo", mp.get_by_role("heading", name="Eventos corporativos").is_visible())
    mp.screenshot(path=f"{SHOTS}/05-movil-portada.png", full_page=True)
    check("sin desbordamiento en móvil", not mp.evaluate("document.documentElement.scrollWidth > innerWidth"))

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL")
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        steps(browser, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url); raise
    finally:
        browser.close()
print(f"\n{len(ok)} comprobaciones superadas")
