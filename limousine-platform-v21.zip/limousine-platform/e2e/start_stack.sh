#!/usr/bin/env bash
# Arranca API, worker, receptor de emails y sitio para los recorridos.
# Requisitos: PostgreSQL y Redis corriendo, migraciones aplicadas y el sitio
# compilado (cd frontend && npm run build). Variables opcionales:
#   PYTHON (python del backend), E2E_LOGS (carpeta de registros), REQUIRE_STAFF_MFA.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="${PYTHON:-python}"
LOGS="${E2E_LOGS:-/tmp/e2e-logs}"
mkdir -p "$LOGS"

# Un servidor viejo en el mismo puerto serviría otra compilación: mejor detenerse.
for port in 3000 8000 1025; do
  if (exec 3<>/dev/tcp/127.0.0.1/$port) 2>/dev/null; then
    echo "El puerto $port está ocupado. Ejecute stop_stack.sh primero." >&2
    exit 1
  fi
done

export DATABASE_URL="${DATABASE_URL:-postgresql+asyncpg://limo:limo@127.0.0.1:5432/limo}"
export REDIS_URL="${REDIS_URL:-redis://127.0.0.1:6379/0}"
export EMAIL_BACKEND=smtp EMAIL_HOST=127.0.0.1 EMAIL_PORT=1025
export FRONTEND_URL="${FRONTEND_URL:-http://127.0.0.1:3000}"
export MEDIA_BASE_URL="${MEDIA_BASE_URL:-http://127.0.0.1:8000}"
export MEDIA_ROOT="${MEDIA_ROOT:-/tmp/e2e-media}"
export E2E_SMTP_LOG="${E2E_SMTP_LOG:-/tmp/e2e-smtp.log}"

# setsid: los procesos siguen aunque se cierre la terminal que los lanzó.
cd "$ROOT/e2e" && setsid nohup "$PYTHON" smtp_sink.py >"$LOGS/smtp.log" 2>&1 < /dev/null &
cd "$ROOT/backend"
setsid nohup "$PYTHON" -m arq app.worker.WorkerSettings >"$LOGS/worker.log" 2>&1 < /dev/null &
setsid nohup "$PYTHON" -m uvicorn app.main:app --host 127.0.0.1 --port 8000 >"$LOGS/api.log" 2>&1 < /dev/null &

# Servidor autocontenido de Next.js: necesita los archivos estáticos a su lado.
cd "$ROOT/frontend"
rm -rf .next/standalone/.next/static && cp -r .next/static .next/standalone/.next/static
cd .next/standalone
PORT=3000 HOSTNAME=127.0.0.1 API_INTERNAL_URL=http://127.0.0.1:8000 setsid nohup node server.js >"$LOGS/web.log" 2>&1 < /dev/null &

# ready: la API responde y además llega a PostgreSQL y Redis.
for url in http://127.0.0.1:8000/api/v1/health/ready http://127.0.0.1:3000/api/health; do
  for _ in $(seq 1 60); do curl -fs --max-time 5 "$url" >/dev/null && break; sleep 1; done
  curl -fs --max-time 5 "$url" >/dev/null || { echo "No respondió: $url (ver $LOGS)"; exit 1; }
done
echo "Sistema listo (registros en $LOGS)"
