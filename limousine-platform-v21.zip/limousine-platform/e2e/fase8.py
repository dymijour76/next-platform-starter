"""Recorrido de la fase 8 (panel de indicadores y reportes)."""
import re
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase8")
PW = "Faro-Costero-Nocturno"
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name, flush=True)

def login(page, email, password=PW):
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(password)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account")

def logout(page):
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")

def steps(browser, page):
    # 1. Administrador general: todo el panel con alertas
    login(page, ADMIN_EMAIL, ADMIN_PASSWORD)
    page.goto(f"{BASE}/admin")
    alerts = page.get_by_role("region", name="Requiere atención")
    expect(alerts).to_be_visible()
    for text in ["sin vehículo o conductor", "reembolsos? fallidos?", "La licencia de Jorge Vidal vence"]:
        expect(alerts.get_by_text(re.compile(text))).to_be_visible()
    check("alertas: sin asignar, reembolso fallido y licencia")
    for heading in ["Operación", "Este mes", "Flota"]:
        expect(page.get_by_role("heading", name=heading)).to_be_visible()
    expect(page.get_by_role("table", name="Viajes de hoy")).to_be_visible()
    check("viajes de hoy con conductor o aviso", page.get_by_text("Jorge Vidal").count() >= 1 and page.get_by_text("Sin conductor").count() >= 1)
    page.screenshot(path=f"{SHOTS}/01-panel-admin.png", full_page=True)
    alerts.get_by_role("link", name=re.compile("sin vehículo o conductor")).click()
    expect(page).to_have_url(f"{BASE}/admin/reservations?unassigned=true")
    check("la alerta lleva al despacho")

    # 2. Reportes de reservas
    page.goto(f"{BASE}/admin/reports")
    expect(page.get_by_role("img", name="Reservas por periodo y estado")).to_be_visible()
    check("gráfico de reservas", page.locator("svg rect").count() > 20)
    check("30 días en la tabla", page.get_by_role("table", name="Reservas por periodo").locator("tbody tr").count() == 30)
    page.screenshot(path=f"{SHOTS}/02-reporte-reservas.png", full_page=True)
    page.get_by_label("Agrupar por").select_option("week")
    page.get_by_role("button", name="Ver").click()
    expect(page).to_have_url(re.compile("group=week"))
    # La dirección cambia antes que la tabla: se espera a que muestre semanas.
    expect(page.get_by_role("table", name="Reservas por periodo").locator("tbody tr").first).to_contain_text("sem.")
    check("agrupado por semana", page.get_by_role("table", name="Reservas por periodo").locator("tbody tr").count() in (5, 6))

    # 3. Ingresos y descarga CSV
    page.get_by_role("link", name="Ingresos").click()
    expect(page.get_by_role("img", name="Ingresos por periodo")).to_be_visible()
    expect(page.get_by_role("table", name="Ingresos por periodo").locator("tbody tr").first).to_contain_text("sem.")
    check("la pestaña conserva la agrupación", "group=week" in page.url
          and page.get_by_label("Agrupar por").input_value() == "week"
          and page.get_by_role("table", name="Ingresos por periodo").locator("tbody tr").count() in (5, 6))
    expect(page.get_by_role("table", name="Por servicio")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/03-reporte-ingresos.png", full_page=True)
    with page.expect_download() as info:
        page.get_by_role("link", name="Descargar CSV").click()
    download = info.value
    content = open(download.path(), "rb").read().decode("utf-8")
    check("CSV para Excel", content.startswith("\ufeff") and content.lstrip("\ufeff").startswith("Periodo;Cobrado;Reembolsado;Neto;Pagos"))
    check("nombre del archivo", re.fullmatch(r"ingresos_\d{8}-\d{8}\.csv", download.suggested_filename) is not None)

    # 4. Rango inválido
    page.get_by_label("Desde").fill("2025-01-01")
    page.get_by_label("Agrupar por").select_option("day")
    page.get_by_role("button", name="Ver").click()
    expect(page.get_by_text(re.compile("máximo 92 días"))).to_be_visible()
    check("rango demasiado amplio explicado")
    logout(page)

    # 5. Finanzas: sólo su área
    login(page, "finanzas@empresa.cl")
    page.goto(f"{BASE}/admin")
    expect(page.get_by_role("heading", name="Este mes")).to_be_visible()
    check("finanzas no ve operación", page.get_by_role("heading", name="Operación").count() == 0)
    check("finanzas ve su alerta", page.get_by_text(re.compile("reembolsos? fallidos?")).count() == 1)
    page.screenshot(path=f"{SHOTS}/04-panel-finanzas.png", full_page=True)
    logout(page)

    # 6. Operaciones: sin reportes financieros ni ingresos del mes
    login(page, "reservas@empresa.cl")
    page.goto(f"{BASE}/admin")
    expect(page.get_by_role("heading", name="Operación")).to_be_visible()
    check("operaciones no ve ingresos", page.get_by_role("heading", name="Este mes").count() == 0)
    nav = page.get_by_role("navigation", name="Administración")
    check("operaciones sin menú de reportes", nav.get_by_role("link", name="Reportes").count() == 0)
    page.goto(f"{BASE}/admin/reports?tab=revenue")
    check("acceso directo a reportes bloqueado", "denied=1" in page.url)
    logout(page)

    # 7. Móvil
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL")
    mp = m.new_page(); mp.set_default_timeout(8000)
    login(mp, ADMIN_EMAIL, ADMIN_PASSWORD)
    mp.goto(f"{BASE}/admin")
    expect(mp.get_by_role("heading", name="Operación")).to_be_visible()
    mp.screenshot(path=f"{SHOTS}/05-movil-panel.png", full_page=True)
    check("sin desbordamiento en móvil", not mp.evaluate("document.documentElement.scrollWidth > innerWidth"))

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL", accept_downloads=True)
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        steps(browser, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url); raise
    finally:
        browser.close()
print(f"\n{len(ok)} comprobaciones superadas")
