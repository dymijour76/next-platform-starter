"""Recorrido de la fase 16: monedas de referencia (USD, EUR, BRL) y tasas manuales.

Uso: python fase16.py
El entorno de pruebas no tiene internet: la actualización automática falla (y se comprueba
que la plataforma lo informa y sigue funcionando); las tasas se fijan a mano.
"""
import re
from datetime import date, timedelta

from playwright.sync_api import expect, sync_playwright

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, shots, sql

SHOTS = shots("fase16")
ok: list[str] = []


def check(name: str, cond: bool = True) -> None:
    assert cond, name
    ok.append(name)
    print("✓", name, flush=True)


def main() -> None:
    sql("delete from exchange_rates")
    with sync_playwright() as p:
        b = p.chromium.launch()
        visitor = b.new_context(locale="es-CL").new_page()
        visitor.set_default_timeout(10000)
        visitor.goto(BASE + "/services")
        check("sin tasas no se ofrece cambiar de moneda", visitor.get_by_label(re.compile("^Moneda:")).count() == 0)

        admin = b.new_context(locale="es-CL").new_page()
        admin.set_default_timeout(15000)
        admin.goto(BASE + "/login")
        admin.locator("input[name=email]").fill(ADMIN_EMAIL)
        admin.locator("input[name=password]").fill(ADMIN_PASSWORD)
        admin.locator("main form button[type=submit]").first.click()
        admin.wait_for_url(BASE + "/account")
        admin.goto(BASE + "/admin/currencies")
        admin.get_by_role("button", name="Actualizar ahora").click()
        expect(admin.get_by_text("No se pudieron obtener las tasas", exact=False)).to_be_visible()
        check("si la fuente no responde, se informa con claridad")

        def set_rate(code: str, value: str) -> None:
            row = admin.locator("tr", has=admin.get_by_role("rowheader", name=re.compile(f"^{code}")))
            row.locator("input[name=manual_rate]").fill(value)
            row.get_by_role("button", name="Fijar").click()

        set_rate("BRL", "1.234")
        expect(admin.get_by_text("fuera del rango razonable", exact=False)).to_be_visible()
        check("un error de tipeo en la tasa se rechaza")
        # Espera el valor en la fila de esa moneda (el aviso de un guardado anterior sigue en pantalla).
        for code, value, shown in (("USD", "950", "950"), ("EUR", "1.030,50", "1030,5"), ("BRL", "175", "175")):
            set_rate(code, value)
            row = admin.locator("tr", has=admin.get_by_role("rowheader", name=re.compile(f"^{code}")))
            expect(row).to_contain_text("Manual")
            expect(row).to_contain_text(re.compile(shown.replace(",", r"[.,]?").replace("1030", r"1\.?030")))
        check("tasas manuales vigentes y marcadas")
        check("el formato chileno «1.030,50» se interpreta bien")
        admin.screenshot(path=f"{SHOTS}/01-monedas.png", full_page=True)

        # El visitante elige dólares: referencia junto a los pesos
        visitor.goto(BASE + "/services")
        visitor.get_by_label(re.compile("^Moneda:")).click()
        visitor.get_by_role("button", name=re.compile("Dólar estadounidense")).click()
        expect(visitor.get_by_text(re.compile(r"aprox\. USD")).first).to_be_visible()
        check("el catálogo muestra la referencia en dólares", visitor.get_by_text("$").count() >= 1)
        visitor.get_by_role("link", name=re.compile("Premium")).first.click()
        expect(visitor.get_by_text(re.compile(r"\$[\d.]+ · aprox\. USD"))).to_be_visible()
        check("la ficha muestra pesos y dólares")
        day = date.today() + timedelta(days=(2 - date.today().weekday()) % 7 + 7)
        visitor.get_by_label("Fecha").fill(day.isoformat())
        visitor.get_by_label("Hora de recogida").fill("10:00")
        visitor.get_by_role("button", name=re.compile("Calcular")).click()
        expect(visitor.locator("table").get_by_text(re.compile(r"aprox\. USD"))).to_be_visible()
        check("el total del cotizador trae su referencia")
        visitor.screenshot(path=f"{SHOTS}/02-servicio-en-usd.png", full_page=True)

        visitor.get_by_label(re.compile("^Moneda:")).click()
        visitor.get_by_role("button", name=re.compile("Peso chileno")).click()
        expect(visitor.get_by_label("Moneda: Peso chileno")).to_be_visible()
        check("en pesos no se muestra referencia", visitor.get_by_text(re.compile("aprox\\.")).count() == 0)

        en = b.new_context(locale="en-US").new_page()
        en.goto(BASE + "/services")
        en.get_by_label(re.compile("^Currency:")).click()
        en.get_by_role("button", name=re.compile("Euro")).click()
        expect(en.get_by_text(re.compile(r"approx\. EUR")).first).to_be_visible()
        check("en inglés, «approx. EUR»")
        b.close()
    print(f"\n{len(ok)} comprobaciones superadas")


if __name__ == "__main__":
    main()
