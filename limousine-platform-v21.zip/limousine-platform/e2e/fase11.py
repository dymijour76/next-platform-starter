"""Recorrido de la fase 11: la plataforma en cinco idiomas (es, en, fr, ht, zh).

Uso: python fase11.py publico   (sitio, cliente y conductor; datos: fixtures.trip)
     python fase11.py panel     (panel y contenido traducible; datos: fixtures.activity)
"""
import re
import sys
from datetime import date, timedelta

from playwright.sync_api import expect, sync_playwright

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, shots  # noqa: F401

SHOTS = shots("fase11")
PW = "Faro-Costero-Nocturno"
ok: list[str] = []


def check(name: str, cond: bool = True) -> None:
    assert cond, name
    ok.append(name)
    print("✓", name, flush=True)


def new_page(browser, locale: str, mobile: bool = False):  # type: ignore[no-untyped-def]
    opts = {"locale": locale, "viewport": {"width": 390, "height": 844} if mobile else {"width": 1280, "height": 900}}
    if mobile:
        opts.update(device_scale_factor=2, is_mobile=True, has_touch=True)
    page = browser.new_context(**opts).new_page()
    page.set_default_timeout(10000)
    return page


def next_weekday(weekday: int) -> date:
    today = date.today()
    return today + timedelta(days=(weekday - today.weekday()) % 7 + 7)


# ------------------------------------------------------------------ sitio, cliente, conductor

def language_rules(b) -> None:  # type: ignore[no-untyped-def]
    page = new_page(b, "fr-FR")
    page.goto(BASE)
    expect(page.get_by_role("link", name="Créer un compte")).to_be_visible()
    check("navegador en francés: sitio en francés", page.evaluate("document.documentElement.lang") == "fr")
    page.get_by_label("Langue: Français").click()
    page.get_by_role("button", name="Kreyòl ayisyen").click()
    expect(page.get_by_role("link", name="Kreye yon kont")).to_be_visible()
    check("selector: creole", page.evaluate("document.documentElement.lang") == "ht")
    page.get_by_label("Lang: Kreyòl ayisyen").click()
    page.get_by_role("button", name="中文（简体）").click()
    expect(page.get_by_role("link", name="注册")).to_be_visible()
    check("mandarín con lang=zh-Hans", page.evaluate("document.documentElement.lang") == "zh-Hans")
    page.goto(BASE + "/login")
    page.locator("input[name=email]").fill("nadie@example.com")
    page.locator("input[name=password]").fill("incorrecta-123")
    page.get_by_role("button", name="登录", exact=True).click()
    expect(page.get_by_text("邮箱或密码不正确。")).to_be_visible()
    check("error de la API en chino")
    page.goto(BASE + "/no-existe-esta-pagina")
    check("404 en chino", page.get_by_role("heading", name="找不到该页面").count() == 1)


def customer_in_creole(b) -> None:  # type: ignore[no-untyped-def]
    page = new_page(b, "ht")
    page.goto(BASE + "/login")
    page.get_by_label("Imèl").fill("valentina@example.com")
    page.get_by_label("Modpas").fill(PW)
    page.get_by_role("button", name="Konekte").click()
    page.wait_for_url(BASE + "/account")
    expect(page.get_by_role("heading", name="Bonjou, Valentina")).to_be_visible()
    check("navegador en creole sin idioma en la cuenta: sigue en creole")
    page.goto(BASE + "/book")
    page.get_by_label("Dat").fill(next_weekday(2).isoformat())
    page.get_by_label("Lè pou vin chèche w").fill("10:00")
    page.get_by_role("button", name="Wè pri ak disponiblite").click()
    expect(page.get_by_label("Adrès pou vin chèche w")).to_be_visible()
    check("fecha en creole al reservar", page.get_by_text("mèkredi", exact=False).count() >= 1)
    page.get_by_label("Adrès pou vin chèche w").fill("Av. Apoquindo 3000, Las Condes")
    page.get_by_label("Mwen aksepte politik anilasyon an.").check()
    page.get_by_role("button", name="Rezève epi peye").click()
    page.get_by_role("button", name="Apwouve peman an").click()
    expect(page.get_by_text("Nou resevwa peman an", exact=False)).to_be_visible()
    check("pago confirmado en creole")
    check("desglose con horas en creole", page.get_by_text(re.compile(r"\d+ èdtan ×")).count() == 1)
    check("fecha corta sin abreviatura francesa", page.get_by_text("sept.", exact=False).count() == 0)
    page.screenshot(path=f"{SHOTS}/01-reserva-creole.png", full_page=True)
    page.get_by_role("button", name="Anile rezèvasyon an").click()
    page.get_by_role("button", name="Wi, anile rezèvasyon an").click()
    expect(page.get_by_text("Rezèvasyon an anile.", exact=False)).to_be_visible()
    check("cancelación en creole")


def driver_in_creole(b) -> None:  # type: ignore[no-untyped-def]
    page = new_page(b, "ht", mobile=True)
    page.goto(BASE + "/login")
    page.get_by_label("Imèl").fill("conductor@example.com")
    page.get_by_label("Modpas").fill(PW)
    page.get_by_role("button", name="Konekte").click()
    page.wait_for_url(BASE + "/driver")
    expect(page.get_by_role("heading", name="Vwayaj mwen")).to_be_visible()
    check("panel del conductor en creole, con selector", page.get_by_label("Lang: Kreyòl ayisyen").count() == 1)
    page.locator("a[href^='/driver/trips/']").first.click()
    expect(page.get_by_role("link", name=re.compile("^Rele "))).to_be_visible()
    check("vehículo con 'plak'", page.get_by_text("plak", exact=False).count() == 1)
    page.screenshot(path=f"{SHOTS}/02-conductor-creole.png", full_page=True)
    page.get_by_role("button", name="Konfime anbakman san QR").click()
    expect(page.get_by_text("Pasaje a monte. Bon vwayaj!")).to_be_visible()
    check("abordaje en creole")


# ------------------------------------------------------------------ panel y contenido

def admin_login(b, locale: str):  # type: ignore[no-untyped-def]
    page = new_page(b, locale)
    page.goto(BASE + "/login")
    page.locator("input[name=email]").fill(ADMIN_EMAIL)
    page.locator("input[name=password]").fill(ADMIN_PASSWORD)
    page.locator("main form button[type=submit]").first.click()
    page.wait_for_url(BASE + "/account")
    return page


def admin_in_english(b) -> None:  # type: ignore[no-untyped-def]
    page = admin_login(b, "en-US")
    page.goto(BASE + "/admin")
    expect(page.get_by_role("heading", name="Needs attention")).to_be_visible()
    check("inicio del panel en inglés", page.get_by_text("Net revenue").count() == 1)
    check("alertas del servidor en inglés", page.get_by_text("failed refund", exact=False).count() >= 1)
    page.goto(BASE + "/admin/reservations")
    expect(page.get_by_role("columnheader", name="Assignment")).to_be_visible()
    plates = [x for x in page.locator("tbody tr td:nth-child(5)").all_inner_texts() if x.strip() not in ("", "—") and "No vehicle" not in x and "Unassigned" not in x]
    check("la columna de asignación muestra patentes", len(plates) > 0 and all(len(x.split()[-1]) == 6 for x in plates))
    page.goto(BASE + "/admin/reservations?status=PENDING_PAYMENT")
    page.locator("tbody tr a").first.click()
    page.get_by_role("button", name="Confirm without online payment").click()
    expect(page.get_by_text("Booking confirmed. The customer was notified by email.")).to_be_visible()
    check("historial con nota del sistema traducida", page.get_by_text("Confirmed manually", exact=False).count() >= 1)
    page.goto(BASE + "/admin/pricing")
    expect(page.get_by_role("heading", name="Rules")).to_be_visible()
    check("condiciones de reglas en inglés", page.get_by_text(re.compile(r"Sat and Sun|from \d\d:\d\d to")).count() >= 1)
    page.screenshot(path=f"{SHOTS}/03-panel-ingles.png", full_page=True)


def content_translation(b) -> None:  # type: ignore[no-untyped-def]
    # La cuenta del administrador quedó en inglés en el paso anterior: el paso no depende
    # del idioma de la interfaz (busca por los campos, no por los textos).
    page = admin_login(b, "es-CL")
    page.goto(BASE + "/admin/services")
    page.get_by_role("link", name="Premium").click()
    english = page.locator("details:has(#tr-en-tagline) > summary")
    save = page.get_by_role("button", name=re.compile("^(Guardar cambios|Save changes)$"))
    english.click()
    page.locator("#tr-en-tagline").fill("For moments that happen once")
    save.click()
    expect(page.get_by_text(re.compile("^(Servicio guardado.|Service saved.)$"))).to_be_visible()
    save.click()
    page.reload()
    english.click()
    check("un segundo guardado conserva la traducción", page.locator("#tr-en-tagline").input_value() == "For moments that happen once")
    en = new_page(b, "en-US")
    en.goto(BASE + "/services/premium")
    check("visitante en inglés ve la traducción", en.get_by_text("For moments that happen once").count() == 1)


def main(part: str) -> None:
    with sync_playwright() as p:
        b = p.chromium.launch()
        try:
            if part == "publico":
                language_rules(b)
                customer_in_creole(b)
                driver_in_creole(b)
            else:
                admin_in_english(b)
                content_translation(b)
        finally:
            b.close()
    print(f"\n{len(ok)} comprobaciones superadas")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "publico")
