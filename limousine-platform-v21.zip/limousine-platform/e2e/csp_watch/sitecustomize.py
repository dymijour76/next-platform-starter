"""Vigía de los recorridos: violaciones de CSP e IDs duplicados, registrados en E2E_CSP_LOG.

Se carga solo al arrancar Python (PYTHONPATH) y envuelve Browser.new_context de
Playwright, así que cubre todos los recorridos sin modificarlos.
"""
import json

try:
    from playwright.sync_api._generated import Browser
except Exception:  # sin Playwright: nada que hacer
    Browser = None

import os

LOG = os.environ.get("E2E_CSP_LOG", "/tmp/e2e-csp-violations.log")
SCRIPT = """
// IDs duplicados: rompen la relación entre etiqueta y campo (accesibilidad y clics).
(() => {
  const seen = new Set();
  setInterval(() => {
    const counts = {};
    document.querySelectorAll('[id]').forEach((el) => { counts[el.id] = (counts[el.id] || 0) + 1; });
    for (const [id, n] of Object.entries(counts)) {
      const key = location.pathname + '#' + id;
      if (n > 1 && !seen.has(key)) { seen.add(key); console.error('DUP-ID ' + JSON.stringify({id, n, page: location.pathname})); }
    }
  }, 1000);
})();
document.addEventListener('securitypolicyviolation', (e) => {
  console.error('CSP-VIOLATION ' + JSON.stringify({directive: e.violatedDirective, blocked: e.blockedURI,
    source: e.sourceFile, line: e.lineNumber, sample: e.sample, page: location.pathname}));
});
"""

if Browser is not None:
    _original = Browser.new_context

    def new_context(self, *args, **kwargs):
        ctx = _original(self, *args, **kwargs)
        ctx.add_init_script(SCRIPT)

        def watch(page):
            def on_console(msg):
                text = msg.text
                if "CSP-VIOLATION" in text or "Content Security Policy" in text or "DUP-ID" in text:
                    with open(LOG, "a") as f:
                        f.write(json.dumps({"page": page.url, "text": text[:500]}) + "\n")
            page.on("console", on_console)

        ctx.on("page", watch)
        return ctx

    Browser.new_context = new_context
