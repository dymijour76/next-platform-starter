"""Receptor SMTP de prueba: escribe cada email recibido en E2E_SMTP_LOG. Corre hasta que se lo detiene."""
import os
import time

from aiosmtpd.controller import Controller

LOG = os.environ.get("E2E_SMTP_LOG", "/tmp/e2e-smtp.log")


class Handler:
    async def handle_DATA(self, server, session, envelope):  # noqa: ANN001, ANN201
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"TO={envelope.rcpt_tos}\n{envelope.content.decode(errors='ignore')[:20000]}\n=====\n")
        return "250 OK"


if __name__ == "__main__":
    controller = Controller(Handler(), hostname="127.0.0.1", port=int(os.environ.get("E2E_SMTP_PORT", "1025")))
    controller.start()
    while True:
        time.sleep(3600)
