"""Configuración y utilidades compartidas por los recorridos en navegador.

Todo se configura por variables de entorno (valores por defecto para uso local):

  E2E_BASE_URL        sitio (http://127.0.0.1:3000)
  E2E_DATABASE_URL    PostgreSQL para preparar datos (postgresql://limo:limo@127.0.0.1:5432/limo)
  E2E_REDIS_URL       Redis (redis://127.0.0.1:6379/0)
  E2E_SMTP_LOG        archivo donde el receptor de prueba escribe los emails
  E2E_SHOTS           carpeta de capturas
  E2E_TMP             archivos temporales (imágenes de prueba, video de la cámara)
  E2E_ADMIN_EMAIL / E2E_ADMIN_PASSWORD   administrador general existente
"""

import os
import subprocess
from pathlib import Path

BASE = os.environ.get("E2E_BASE_URL", "http://127.0.0.1:3000")
DATABASE_URL = os.environ.get("E2E_DATABASE_URL", "postgresql://limo:limo@127.0.0.1:5432/limo")
REDIS_URL = os.environ.get("E2E_REDIS_URL", "redis://127.0.0.1:6379/0")
SMTP_LOG = os.environ.get("E2E_SMTP_LOG", "/tmp/e2e-smtp.log")
SHOTS_ROOT = Path(os.environ.get("E2E_SHOTS", "e2e-shots"))
TMP = os.environ.get("E2E_TMP", "/tmp/e2e")
ADMIN_EMAIL = os.environ.get("E2E_ADMIN_EMAIL", "admin@empresa.cl")
ADMIN_PASSWORD = os.environ.get("E2E_ADMIN_PASSWORD", "Carrusel-Sedan-2026")
PASSWORD = "Faro-Costero-Nocturno"  # la de los usuarios de prueba (fixtures/users.py)
BACKEND = Path(__file__).resolve().parents[1] / "backend"


def shots(phase: str) -> str:
    path = SHOTS_ROOT / phase
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def sql(query: str) -> str:
    """Ejecuta SQL con psql (por la entrada estándar: admite cualquier comilla)."""
    result = subprocess.run(
        ["psql", DATABASE_URL, "-tA", "-v", "ON_ERROR_STOP=1"],
        input=query + ";", capture_output=True, text=True, check=False,
    )  # fmt: skip
    assert result.returncode == 0, result.stderr
    return result.stdout.strip()


def flush_redis() -> None:
    import redis

    redis.Redis.from_url(REDIS_URL).flushdb()


def smtp_log_text() -> str:
    try:
        return open(SMTP_LOG, encoding="utf-8", errors="ignore").read()
    except FileNotFoundError:
        return ""


def email_subjects() -> list[str]:
    """Asuntos de los emails recibidos, decodificados ("=?utf-8?q?…?=" → texto)."""
    import re
    from email.header import decode_header, make_header

    raw = smtp_log_text()
    return [
        str(make_header(decode_header(m.group(1).replace("\n", ""))))
        for m in re.finditer(r"^Subject: (.+(?:\n[ \t].+)*)", raw, re.M)
    ]
