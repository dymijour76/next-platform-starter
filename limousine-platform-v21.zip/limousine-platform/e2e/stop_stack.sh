#!/usr/bin/env bash
# Detiene lo que arrancó start_stack.sh. Ojo: Next.js se renombra "next-server" al arrancar.
for pattern in "uvicorn app.main:app" "arq app.worker.WorkerSettings" "smtp_sink.py" "node server.js" "next-server"; do
  pkill -f "$pattern" 2>/dev/null || true
done
# Espera a que los puertos queden libres (hasta 10 s).
for _ in $(seq 1 20); do
  (exec 3<>/dev/tcp/127.0.0.1/3000) 2>/dev/null || (exec 3<>/dev/tcp/127.0.0.1/8000) 2>/dev/null || exit 0
  sleep 0.5
done
echo "Aviso: algún puerto (3000 u 8000) sigue ocupado" >&2
