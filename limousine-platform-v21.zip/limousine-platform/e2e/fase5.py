"""Recorrido de la fase 5 (pagos) en un navegador real, con la pasarela simulada."""
import re, subprocess, time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase5")
PW = "Faro-Costero-Nocturno"
SCL = ZoneInfo("America/Santiago")
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name, flush=True)


def next_weekday(wd, weeks=1):
    d = datetime.now(SCL).date() + timedelta(days=7 * weeks)
    return d + timedelta(days=(wd - d.weekday()) % 7)

def login(page, email, password=PW):
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(password)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account")

def logout(page):
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")

def book_and_go_to_gateway(page, service, label, day, hour, minutes):
    page.goto(f"{BASE}/book?service={service}")
    page.get_by_label("Servicio", exact=True).select_option(label=label)
    page.get_by_label("Fecha").fill(day.isoformat())
    page.get_by_label("Hora de recogida").fill(hour)
    page.get_by_label("Duración").select_option(str(minutes))
    page.get_by_role("button", name="Ver precio y disponibilidad").click()
    page.get_by_label("Acepto la política de cancelación.").check()
    page.get_by_role("button", name="Reservar y pagar").click()
    expect(page).to_have_url(re.compile(r"/payments/simulator/checkout\?token=sim_"))
    expect(page.get_by_role("heading", name="Pasarela simulada")).to_be_visible()

def decide(page, button):
    page.get_by_role("button", name=button).click()
    expect(page).to_have_url(re.compile(r"/account/reservations/RES-\d{4}-\d{6}\?payment="))
    return re.search(r"RES-\d{4}-\d{6}", page.url).group(0)

def steps(browser, page):
    login(page, "valentina@example.com")

    # 1. Reservar y pagar: aprobado
    book_and_go_to_gateway(page, "premium", "Premium, hasta 10 pasajeros", next_weekday(2), "12:00", 180)
    expect(page.get_by_text("$295.000")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/01-pasarela.png")
    premium = decide(page, "Aprobar pago")
    check("reservar lleva a la pasarela y vuelve pagado", page.url.endswith("payment=paid"))
    expect(page.get_by_text("Pago recibido. Su reserva está confirmada")).to_be_visible()
    expect(page.get_by_text("Confirmada").first).to_be_visible()
    expect(page.get_by_text("tarjeta terminada en 6623")).to_be_visible()
    check("reserva confirmada con comprobante de pago", page.get_by_role("button", name="Pagar ahora").count() == 0)
    page.screenshot(path=f"{SHOTS}/02-pagada.png", full_page=True)

    # 2. Volver a abrir el retorno (recarga o botón atrás): no se paga dos veces
    token = sql(f"select provider_token from payments p join reservations r on r.id = p.reservation_id where r.code = '{premium}'")
    page.goto(f"{BASE}/payments/return?token_ws={token}")
    expect(page).to_have_url(f"{BASE}/account/reservations/{premium}?payment=paid")
    check("retorno repetido es idempotente",
          sql(f"select count(*) from reservation_events e join reservations r on r.id = e.reservation_id where r.code = '{premium}' and to_status = 'CONFIRMED'") == "1")

    # 3. Rechazo y reintento
    book_and_go_to_gateway(page, "standard", "Standard, hasta 4 pasajeros", next_weekday(3), "10:00", 120)
    standard = decide(page, "Rechazar")
    expect(page.get_by_text("El pago fue rechazado. No se hizo ningún cargo")).to_be_visible()
    expect(page.get_by_text("Pendiente de pago").first).to_be_visible()
    page.screenshot(path=f"{SHOTS}/03-rechazado.png", full_page=True)
    page.get_by_role("button", name="Reintentar el pago").click()
    expect(page).to_have_url(re.compile(r"/payments/simulator/checkout"))
    decide(page, "Aprobar pago")
    check("rechazo y reintento exitoso", page.url.endswith(f"{standard}?payment=paid"))

    # 4. Abandono en la pasarela
    book_and_go_to_gateway(page, "professional", "Professional, hasta 8 pasajeros", next_weekday(4), "20:00", 180)
    professional = decide(page, "Anular compra")
    expect(page.get_by_text("El pago no se completó.")).to_be_visible()
    check("abandono deja la reserva pendiente y pagable",
          page.get_by_role("button", name="Pagar ahora").count() == 1)

    # 5. Cancelar la reserva pagada: reembolso automático por la pasarela
    page.goto(f"{BASE}/account/reservations/{premium}")
    page.get_by_role("button", name="Cancelar reserva").click()
    expect(page.get_by_text("por el mismo medio de pago")).to_be_visible()
    page.get_by_role("button", name="Sí, cancelar la reserva").click()
    expect(page.get_by_text("La reserva fue cancelada.")).to_be_visible()
    expect(page.get_by_text("Reembolsado").first).to_be_visible()
    expect(page.get_by_text("Reembolso de $295.000: Procesado")).to_be_visible()
    check("cancelación con reembolso automático")
    page.screenshot(path=f"{SHOTS}/04-reembolsado.png", full_page=True)

    # Móvil: reserva pendiente con botón de pago
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL",
                            storage_state=page.context.storage_state())
    mp = m.new_page(); mp.set_default_timeout(8000)
    mp.goto(f"{BASE}/account/reservations/{professional}")
    expect(mp.get_by_role("button", name="Pagar ahora")).to_be_visible()
    mp.screenshot(path=f"{SHOTS}/05-movil-pendiente.png", full_page=True)
    check("sin desbordamiento en móvil", not mp.evaluate("document.documentElement.scrollWidth > innerWidth"))
    logout(page)

    # 6. Finanzas: totales, sin reembolsar ni abrir reservas
    login(page, "finanzas@empresa.cl")
    page.goto(f"{BASE}/admin/payments")
    totals = page.locator("dl").first
    expect(totals.get_by_text("$380.000")).to_be_visible()   # 295.000 + 85.000
    expect(totals.get_by_text("$85.000")).to_be_visible()    # neto tras reembolsar 295.000
    check("finanzas ve cobrado, reembolsado y neto")
    check("finanzas no abre reservas", page.get_by_role("link", name=premium).count() == 0)
    page.screenshot(path=f"{SHOTS}/06-finanzas-pagos.png", full_page=True)
    page.goto(f"{BASE}/admin/reservations")
    check("finanzas sin acceso a reservas", "denied=1" in page.url)
    logout(page)

    # 7. Administrador: reembolso manual parcial
    login(page, ADMIN_EMAIL, ADMIN_PASSWORD)
    rid = sql(f"select id from reservations where code = '{standard}'")
    page.goto(f"{BASE}/admin/reservations/{rid}")
    page.get_by_role("button", name="Reembolso manual").click()
    page.get_by_label("Monto a reembolsar").fill("10000")
    page.get_by_label("Motivo del reembolso").fill("Compensación por demora del chófer")
    page.get_by_role("button", name="Reembolsar").click()
    expect(page.get_by_text("Reembolso procesado.")).to_be_visible()
    page.reload()
    expect(page.get_by_text("Reembolso parcial").first).to_be_visible()
    check("reembolso manual parcial")
    page.screenshot(path=f"{SHOTS}/07-admin-pagos.png", full_page=True)

    # 8. Emails
    time.sleep(3)
    log = open(SMTP_LOG, encoding="utf-8", errors="ignore").read()
    check("email de confirmación con datos del pago", "terminada en 6623" in log)
    check("email de cancelación menciona la devolución", "por el mismo medio de" in log)

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL")
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        steps(browser, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url); raise
    finally:
        browser.close()
print(f"\n{len(ok)} comprobaciones superadas")
