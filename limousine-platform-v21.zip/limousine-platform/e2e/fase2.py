"""Recorrido de extremo a extremo de la fase 2 en un navegador real."""
import re, time
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase2")
PW = ADMIN_PASSWORD
NEW_PW = "Faro-Costero-Nocturno"
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name)

def last_token(to):
    import email as email_lib
    raw = open(SMTP_LOG).read()
    blocks = [b for b in re.split(r"^TO=", raw, flags=re.M) if b.startswith(f"['{to}']")]
    msg = email_lib.message_from_string(blocks[-1].split("\n", 1)[1].rsplit("\n=====", 1)[0])
    text = next(part.get_payload(decode=True).decode()
                for part in msg.walk() if part.get_content_type() == "text/plain")
    return re.findall(r"\?token=([A-Za-z0-9_\-]+)", text)[-1]

def run(p):
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL")
    page = ctx.new_page()
    page.set_default_timeout(8000)
    try:
        steps(browser, ctx, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True)
        print("URL al fallar:", page.url)
        raise
    finally:
        browser.close()

def steps(browser, ctx, page):

    # 1. Portada y registro
    page.goto(BASE); page.screenshot(path=f"{SHOTS}/01-portada.png")
    page.get_by_role("link", name="Crear cuenta").click()
    expect(page).to_have_url(f"{BASE}/register")
    page.get_by_role("button", name="Crear cuenta").click()   # vacío: errores por campo
    expect(page.get_by_text("Este campo es obligatorio.").first).to_be_visible()
    expect(page.get_by_text("Debe aceptar los términos")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/02-registro-errores.png", full_page=True)
    check("registro vacío muestra errores por campo")

    page.get_by_label("Nombre").fill("Valentina")
    page.get_by_label("Apellido").fill("Muñoz")
    page.get_by_label("Email", exact=True).fill("valentina@example.com")
    page.get_by_label("Teléfono").fill("+56 9 8765 4321")
    page.get_by_label("Contraseña", exact=True).fill(PW)
    page.get_by_label("Repita la contraseña").fill(PW)
    page.get_by_label("Acepto los").check()
    page.get_by_role("button", name="Crear cuenta").click()
    expect(page).to_have_url(f"{BASE}/account?welcome=1")
    expect(page.get_by_text("Su cuenta está lista")).to_be_visible()
    expect(page.get_by_text("Confirme su email")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/03-cuenta-bienvenida.png", full_page=True)
    check("registro inicia sesión y muestra aviso de verificación")

    cookies = {c["name"]: c for c in ctx.cookies()}
    check("tokens en cookies httpOnly", cookies["lp_at"]["httpOnly"] and cookies["lp_rt"]["httpOnly"])
    check("tokens no accesibles desde JavaScript", page.evaluate("document.cookie").find("lp_") == -1)

    # 2. Verificación de email con el enlace real del correo
    time.sleep(2)
    page.goto(f"{BASE}/verify-email?token={last_token('valentina@example.com')}")
    page.screenshot(path=f"{SHOTS}/04-confirmar-email.png")
    page.get_by_role("button", name="Confirmar mi email").click()
    expect(page).to_have_url(f"{BASE}/account?verified=1")
    expect(page.get_by_text("Confirme su email")).to_have_count(0)
    check("verificación de email con enlace del correo")

    # 3. Perfil: RUT inválido y luego válido
    page.get_by_role("navigation", name="Mi cuenta").get_by_role("link", name="Mi perfil").click()
    page.get_by_label("RUT").fill("76.543.210-9")
    page.get_by_label("Empresa").fill("Eventos del Sur SpA")
    page.get_by_role("button", name="Guardar cambios").click()
    expect(page.get_by_text("revise el dígito verificador")).to_be_visible()
    check("RUT inválido rechazado sin perder lo escrito", page.get_by_label("Empresa").input_value() == "Eventos del Sur SpA")
    page.get_by_label("RUT").fill("76.543.210-3")
    page.get_by_role("button", name="Guardar cambios").click()
    expect(page.get_by_text("Sus datos se guardaron.")).to_be_visible()
    check("RUT normalizado", page.get_by_label("RUT").input_value() == "76543210-3")
    page.screenshot(path=f"{SHOTS}/05-perfil.png", full_page=True)

    # 4. Renovación silenciosa: se borra el token de acceso; el proxy usa el refresh token
    ctx.clear_cookies(name="lp_at")
    page.goto(f"{BASE}/account")
    expect(page.get_by_role("heading", name="Hola, Valentina")).to_be_visible()
    check("proxy renueva la sesión sin pedir login", "lp_at" in {c["name"] for c in ctx.cookies()})

    # 5. Cambio de contraseña
    page.get_by_role("navigation", name="Mi cuenta").get_by_role("link", name="Seguridad").click()
    pw_form = page.locator("form", has=page.get_by_role("button", name="Cambiar contraseña"))
    pw_form.get_by_label("Contraseña actual").fill("equivocada-123")
    page.get_by_label("Contraseña nueva", exact=True).fill(NEW_PW)
    page.get_by_label("Repita la contraseña nueva").fill(NEW_PW)
    page.get_by_role("button", name="Cambiar contraseña").click()
    expect(page.get_by_text("La contraseña actual no es correcta.").first).to_be_visible()
    pw_form.get_by_label("Contraseña actual").fill(PW)
    page.get_by_label("Contraseña nueva", exact=True).fill(NEW_PW)
    page.get_by_label("Repita la contraseña nueva").fill(NEW_PW)
    page.get_by_role("button", name="Cambiar contraseña").click()
    expect(page.get_by_text("Contraseña actualizada.")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/06-seguridad.png", full_page=True)
    page.goto(f"{BASE}/account")
    expect(page.get_by_role("heading", name="Hola, Valentina")).to_be_visible()
    check("cambio de contraseña mantiene la sesión actual")

    # 6. Un cliente no puede entrar al panel
    page.goto(f"{BASE}/admin")
    check("cliente redirigido fuera de /admin", page.url.startswith(f"{BASE}/account"))

    # 7. Cerrar sesión y login con redirección
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")
    page.goto(f"{BASE}/account/profile")
    check("ruta protegida pide login", "/login?next=%2Faccount%2Fprofile" in page.url)
    page.get_by_label("Email", exact=True).fill("valentina@example.com")
    page.get_by_label("Contraseña").fill(PW)  # contraseña vieja
    page.get_by_role("button", name="Ingresar").click()
    expect(page.get_by_text("El email o la contraseña no son correctos.")).to_be_visible()
    check("email conservado tras error", page.get_by_label("Email", exact=True).input_value() == "valentina@example.com")
    page.screenshot(path=f"{SHOTS}/07-login-error.png")
    page.get_by_label("Contraseña").fill(NEW_PW)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account/profile")
    check("login vuelve a la página solicitada")
    page.get_by_role("button", name="Cerrar sesión").click()

    # 8. Recuperación de contraseña
    page.goto(f"{BASE}/forgot-password")
    page.get_by_label("Email", exact=True).fill("valentina@example.com")
    page.get_by_role("button", name="Enviar enlace").click()
    expect(page.get_by_text("Si el email está registrado")).to_be_visible()
    time.sleep(2)
    page.goto(f"{BASE}/reset-password?token={last_token('valentina@example.com')}")
    page.get_by_label("Contraseña nueva").fill(PW)
    page.get_by_label("Repita la contraseña").fill(PW)
    page.get_by_role("button", name="Guardar contraseña").click()
    expect(page).to_have_url(f"{BASE}/login?reset=1")
    expect(page.get_by_text("Su contraseña se actualizó")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/08-login-tras-reset.png")
    check("recuperación de contraseña completa")

    # 9. Administrador: usuarios
    page.get_by_label("Email", exact=True).fill(ADMIN_EMAIL)
    page.get_by_label("Contraseña").fill(PW)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account")
    page.get_by_role("link", name="Administración").click()
    page.screenshot(path=f"{SHOTS}/09-admin-inicio.png")
    page.get_by_role("navigation", name="Administración").get_by_role("link", name="Usuarios").click()
    expect(page.get_by_text("valentina@example.com")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/10-admin-usuarios.png", full_page=True)
    page.get_by_label("Buscar").fill("valentina")
    page.get_by_role("button", name="Filtrar").click()
    expect(page.get_by_text("1 usuario ·")).to_be_visible()
    check("búsqueda de usuarios")

    page.get_by_role("link", name="Invitar usuario").click()
    page.get_by_label("Nombre").fill("Tomás")
    page.get_by_label("Apellido").fill("Reyes")
    page.get_by_label("Email", exact=True).fill("tomas.reyes@example.com")
    page.get_by_label("Administrador de reservas").check()
    page.screenshot(path=f"{SHOTS}/11-invitar.png", full_page=True)
    page.get_by_role("button", name="Enviar invitación").click()
    expect(page.get_by_text("Invitación enviada a tomas.reyes@example.com")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/12-usuario-detalle.png", full_page=True)
    check("invitación de personal")

    # Suspender a la clienta desde su ficha
    page.goto(f"{BASE}/admin/users?q=valentina")
    page.get_by_role("link", name="Valentina Muñoz").click()
    page.get_by_label("Estado de la cuenta").select_option("SUSPENDED")
    page.get_by_role("button", name="Guardar cambios").click()
    expect(page.get_by_text("Cambios guardados.")).to_be_visible()
    check("suspensión de cuenta")

    # Roles
    page.get_by_role("navigation", name="Administración").get_by_role("link", name="Roles y permisos").click()
    page.screenshot(path=f"{SHOTS}/13-roles.png", full_page=True)
    page.get_by_role("link", name="Nuevo rol").click()
    page.get_by_label("Código").fill("despacho")
    page.get_by_label("Nombre").fill("Despacho")
    page.get_by_label("Ver reservas").check()
    page.get_by_label("Asignar vehículos y conductores").check()
    page.get_by_role("button", name="Crear rol").click()
    expect(page.get_by_text("Rol creado.")).to_be_visible()
    page.screenshot(path=f"{SHOTS}/14-rol-detalle.png", full_page=True)
    page.get_by_role("button", name="Eliminar rol").click()
    expect(page.get_by_text("Rol eliminado.")).to_be_visible()
    check("crear y eliminar rol")

    # 10. El invitado activa su cuenta y ve sólo lo suyo
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")
    time.sleep(1)
    page.goto(f"{BASE}/reset-password?token={last_token('tomas.reyes@example.com')}")
    page.get_by_label("Contraseña nueva").fill(NEW_PW)
    page.get_by_label("Repita la contraseña").fill(NEW_PW)
    page.get_by_role("button", name="Guardar contraseña").click()
    expect(page).to_have_url(f"{BASE}/login?reset=1")
    page.get_by_label("Email", exact=True).fill("tomas.reyes@example.com")
    page.get_by_label("Contraseña").fill(NEW_PW)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}/account")
    page.goto(f"{BASE}/admin")
    expect(page.get_by_role("heading", name="Hola, Tomás")).to_be_visible()
    expect(page.get_by_text("Administrador de reservas")).to_be_visible()
    nav = page.get_by_role("navigation", name="Administración")
    check("personal sin users:read no ve Usuarios", nav.get_by_role("link", name="Usuarios").count() == 0)
    page.goto(f"{BASE}/admin/users")
    check("acceso directo por URL bloqueado", "denied=1" in page.url)
    page.screenshot(path=f"{SHOTS}/15-admin-reservas-sin-acceso.png")

    # 11. La clienta suspendida no puede entrar
    page.get_by_role("button", name="Cerrar sesión").click()
    expect(page).to_have_url(f"{BASE}/")
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill("valentina@example.com")
    page.get_by_label("Contraseña").fill(PW)
    page.get_by_role("button", name="Ingresar").click()
    expect(page.get_by_text("Esta cuenta está desactivada")).to_be_visible()
    check("cuenta suspendida no puede ingresar")

    # 12. Móvil
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL")
    mp = m.new_page()
    mp.goto(f"{BASE}/login"); mp.screenshot(path=f"{SHOTS}/16-movil-login.png", full_page=True)
    mp.goto(f"{BASE}/register"); mp.screenshot(path=f"{SHOTS}/17-movil-registro.png", full_page=True)
    overflow = mp.evaluate("document.documentElement.scrollWidth > window.innerWidth")
    check("sin desbordamiento horizontal en móvil", not overflow)

with sync_playwright() as p:
    run(p)

print(f"\n{len(ok)} comprobaciones superadas")
