"""Recorrido de la fase 6 (vehículos, conductores, asignación y panel del conductor)."""
import email as email_lib, re, subprocess, time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from playwright.sync_api import sync_playwright, expect

from common import ADMIN_EMAIL, ADMIN_PASSWORD, BASE, SMTP_LOG, TMP, flush_redis, shots, smtp_log_text, sql  # noqa: F401
SHOTS = shots("fase6")
PW = "Faro-Costero-Nocturno"
ADMIN_PW = ADMIN_PASSWORD
SCL = ZoneInfo("America/Santiago")
ok = []

def check(name, cond=True):
    assert cond, name
    ok.append(name); print("✓", name, flush=True)


def next_weekday(wd, weeks=1):
    d = datetime.now(SCL).date() + timedelta(days=7 * weeks)
    return d + timedelta(days=(wd - d.weekday()) % 7)

def last_token(to):
    raw = open(SMTP_LOG).read()
    blocks = [b for b in re.split(r"^TO=", raw, flags=re.M) if b.startswith(f"['{to}']")]
    # El email más reciente que traiga un enlace con token (hay otros avisos sin enlace).
    for block in reversed(blocks):
        msg = email_lib.message_from_string(block.split("\n", 1)[1].rsplit("\n=====", 1)[0])
        body = next(p.get_payload(decode=True).decode() for p in msg.walk() if p.get_content_type() == "text/plain")
        tokens = re.findall(r"\?token=([A-Za-z0-9_\-]+)", body)
        if tokens:
            return tokens[-1]
    raise AssertionError(f"Sin enlaces para {to}")

def login(page, email, password=PW, landing="/account"):
    page.goto(f"{BASE}/login")
    page.get_by_label("Email", exact=True).fill(email)
    page.get_by_label("Contraseña").fill(password)
    page.get_by_role("button", name="Ingresar").click()
    expect(page).to_have_url(f"{BASE}{landing}")

def logout(page):
    page.get_by_role("button", name=re.compile("Cerrar sesión|Salir")).click()
    expect(page).to_have_url(f"{BASE}/")

def steps(browser, page):
    # 1. Sin vehículos, el servicio avisa que no se puede reservar
    login(page, ADMIN_EMAIL, ADMIN_PW)
    page.goto(f"{BASE}/admin/services")
    check("servicio sin vehículos advierte que no se puede reservar", page.get_by_text("(no se puede reservar)").count() == 3)

    # 2. Registrar vehículos
    for service, plate, brand, model, cap in [("Premium", "tbwx 48", "Cadillac", "Escalade ESV", "10"),
                                              ("Standard", "rtkl-21", "Mercedes-Benz", "Clase E", "4")]:
        page.goto(f"{BASE}/admin/vehicles/new")
        page.get_by_label("Patente").fill(plate)
        page.get_by_label("Servicio").select_option(label=service)
        page.get_by_label("Marca").fill(brand)
        page.get_by_label("Modelo").fill(model)
        page.get_by_label("Color").fill("Negro")
        page.get_by_label("Pasajeros").fill(cap)
        if service == "Premium":
            page.screenshot(path=f"{SHOTS}/01-nuevo-vehiculo.png", full_page=True)
        page.get_by_role("button", name="Crear vehículo").click()
        expect(page.get_by_text("Vehículo creado.")).to_be_visible()
    check("patente normalizada", page.get_by_text("Patente RTKL21").count() == 1)

    # 3. Mantención del Standard mañana
    tomorrow = (datetime.now(SCL) + timedelta(days=1)).date().isoformat()
    page.get_by_label("Desde").fill(tomorrow)
    page.get_by_label("Hasta").fill(tomorrow)
    page.get_by_label("Motivo").fill("Mantención de frenos")
    page.get_by_role("button", name="Registrar mantención").click()
    expect(page.get_by_text("Mantención registrada.")).to_be_visible()
    expect(page.get_by_text("Mantención de frenos")).to_be_visible()
    check("mantención registrada")
    page.screenshot(path=f"{SHOTS}/02-vehiculo-mantencion.png", full_page=True)
    page.goto(f"{BASE}/admin/vehicles")
    page.screenshot(path=f"{SHOTS}/03-vehiculos.png", full_page=True)

    # 4. Registrar conductor (persona nueva: recibe invitación)
    page.goto(f"{BASE}/admin/drivers/new")
    page.get_by_label("Email", exact=True).fill("jorge.vidal@example.com")
    page.get_by_label("Nombre", exact=True).fill("Jorge")
    page.get_by_label("Apellido").fill("Vidal")
    page.get_by_label("Teléfono").fill("+56 9 5555 1234")
    page.get_by_label("Número de licencia").fill("15.234.567")
    page.get_by_label("Vencimiento de la licencia").fill((datetime.now(SCL).date() + timedelta(days=400)).isoformat())
    page.get_by_role("button", name="Registrar conductor").click()
    expect(page.get_by_text("Conductor registrado.")).to_be_visible()
    check("conductor registrado")
    page.goto(f"{BASE}/admin/drivers")
    page.screenshot(path=f"{SHOTS}/04-conductores.png", full_page=True)
    logout(page)

    # 5. La clienta reserva y paga Premium
    login(page, "valentina@example.com")
    page.goto(f"{BASE}/book?service=premium")
    page.get_by_label("Fecha").fill(next_weekday(2).isoformat())
    page.get_by_label("Hora de recogida").fill("12:00")
    page.get_by_role("button", name="Ver precio y disponibilidad").click()
    page.get_by_label("Acepto la política de cancelación.").check()
    page.get_by_role("button", name="Reservar y pagar").click()
    page.get_by_role("button", name="Aprobar pago").click()
    expect(page).to_have_url(re.compile(r"payment=paid"))
    code = re.search(r"RES-\d{4}-\d{6}", page.url).group(0)
    check(f"reserva pagada {code}")
    logout(page)

    # 6. El operador despacha: filtra las sin asignar y asigna
    login(page, "reservas@empresa.cl")
    page.goto(f"{BASE}/admin/reservations")
    page.get_by_label("Sólo confirmadas sin vehículo o conductor").check()
    page.get_by_role("button", name="Filtrar").click()
    expect(page.get_by_role("link", name=code)).to_be_visible()
    expect(page.get_by_text("Sin asignar")).to_be_visible()
    check("filtro de despacho")
    page.get_by_role("link", name=code).click()
    expect(page.get_by_role("heading", name=code)).to_be_visible()
    for label, text in [("Vehículo", "TBWX48"), ("Conductor", "Jorge Vidal")]:
        select = page.get_by_label(label, exact=True)
        select.select_option(select.locator("option", has_text=text).get_attribute("value"))
    page.screenshot(path=f"{SHOTS}/05-asignar.png", full_page=True)
    page.get_by_role("button", name="Guardar asignación").click()
    expect(page.get_by_text("Asignación guardada.")).to_be_visible()
    expect(page.get_by_text(re.compile("Asignación: vehículo Cadillac"))).to_be_visible()
    check("asignación guardada y en el historial")
    page.goto(f"{BASE}/admin/vehicles")
    page.get_by_role("link", name="Cadillac Escalade ESV").click()
    check("operador ve vehículos sin poder editarlos", page.get_by_label("Patente").is_disabled())
    logout(page)

    # 7. La clienta ve su chófer, vehículo y QR
    login(page, "valentina@example.com")
    page.goto(f"{BASE}/account/reservations/{code}")
    expect(page.get_by_role("heading", name="Su viaje")).to_be_visible()
    expect(page.get_by_text("Jorge", exact=True)).to_be_visible()
    expect(page.get_by_text(re.compile("Cadillac Escalade ESV negro, patente TBWX48", re.I))).to_be_visible()
    check("QR de abordaje visible", page.locator("[aria-label^='Código QR de abordaje'] svg").count() == 1)
    page.screenshot(path=f"{SHOTS}/06-cliente-qr.png", full_page=True)
    logout(page)

    # La recogida pasa a dentro de una hora para poder operar el viaje
    pickup = (datetime.now(SCL) + timedelta(minutes=50)).replace(second=0, microsecond=0)
    sql(f"update reservations set pickup_at = '{pickup.isoformat()}', end_at = '{(pickup + timedelta(hours=3)).isoformat()}', "
        f"blocks_until = '{(pickup + timedelta(hours=4)).isoformat()}', "
        f"pricing_snapshot = jsonb_set(pricing_snapshot, '{{pickup_local}}', to_jsonb('{pickup.isoformat()}'::text)) "
        f"where code = '{code}'")
    token = sql(f"select qr_token from reservations where code = '{code}'")

    # 8. El conductor acepta la invitación y opera el viaje desde el teléfono
    time.sleep(2)
    m = browser.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, locale="es-CL",
                            permissions=["camera"])
    # Lector de QR de prueba: devuelve el token de la reserva, como si la cámara lo leyera.
    m.add_init_script(f"window.BarcodeDetector = class {{ constructor() {{}} async detect() {{ return [{{ rawValue: '{token}' }}]; }} }};")
    d = m.new_page(); d.set_default_timeout(8000)
    d.goto(f"{BASE}/reset-password?token={last_token('jorge.vidal@example.com')}")
    d.get_by_label("Contraseña nueva").fill(PW)
    d.get_by_label("Repita la contraseña").fill(PW)
    d.get_by_role("button", name="Guardar contraseña").click()
    expect(d).to_have_url(f"{BASE}/login?reset=1")
    login(d, "jorge.vidal@example.com", landing="/driver")
    check("el conductor entra directo a sus viajes")
    expect(d.get_by_text("Av. Apoquindo 3000", exact=False)).to_be_visible()
    d.screenshot(path=f"{SHOTS}/07-conductor-viajes.png", full_page=True)
    d.get_by_role("link", name=re.compile("Av. Apoquindo")).click()
    expect(d.get_by_role("link", name=re.compile("Llamar"))).to_be_visible()
    d.get_by_role("button", name="Salir hacia la recogida").click()
    expect(d.get_by_text("Listo: el pasajero sabe que va en camino.")).to_be_visible()
    d.get_by_role("button", name="Llegué al punto de recogida").click()
    expect(d.get_by_text("Registrado: está en el punto de recogida.")).to_be_visible()
    d.screenshot(path=f"{SHOTS}/08-conductor-en-el-lugar.png", full_page=True)
    d.get_by_role("button", name="Escanear QR del pasajero").click()
    expect(d.get_by_text("Pasajero a bordo. ¡Buen viaje!")).to_be_visible()
    check("abordaje validado con el QR escaneado")
    d.get_by_role("button", name="Terminar viaje").click()
    expect(d.get_by_text("Viaje terminado. ¡Gracias!")).to_be_visible()
    d.screenshot(path=f"{SHOTS}/09-conductor-terminado.png", full_page=True)
    check("viaje terminado por el conductor")
    check("sin desbordamiento en el panel del conductor", not d.evaluate("document.documentElement.scrollWidth > innerWidth"))
    check("historial registra el QR", sql(f"select count(*) from reservation_events e join reservations r on r.id = e.reservation_id where r.code = '{code}' and e.note = 'Abordaje validado con QR'") == "1")

    # 9. Emails
    time.sleep(3)
    from email.header import decode_header, make_header
    raw = open(SMTP_LOG, encoding="utf-8", errors="ignore").read()
    # Los asuntos con tildes viajan codificados (RFC 2047): se decodifican antes de comparar.
    log = "\n".join(str(make_header(decode_header(line[9:].strip()))) for line in raw.splitlines()
                     if line.startswith("Subject: "))
    for subject in [f"Su chófer para la reserva {code}", f"Nuevo viaje asignado: {code}", f"Su chófer va en camino ({code})"]:
        check(f"email: {subject}", subject in log)

with sync_playwright() as p:
    browser = p.chromium.launch(args=["--use-fake-device-for-media-stream", "--use-fake-ui-for-media-stream"])
    ctx = browser.new_context(viewport={"width": 1280, "height": 860}, locale="es-CL")
    page = ctx.new_page(); page.set_default_timeout(8000)
    try:
        steps(browser, page)
    except Exception:
        page.screenshot(path=f"{SHOTS}/FALLO.png", full_page=True); print("URL al fallar:", page.url)
        for c in browser.contexts[1:]:
            for pg in c.pages: pg.screenshot(path=f"{SHOTS}/FALLO-movil.png", full_page=True); print("URL móvil:", pg.url)
        raise
    finally:
        browser.close()
print(f"\n{len(ok)} comprobaciones superadas")
