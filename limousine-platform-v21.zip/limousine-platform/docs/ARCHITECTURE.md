# Arquitectura

```text
Navegador ──► Next.js (frontend) ──► FastAPI (backend) ──► PostgreSQL
                                          │
                                          ├──► Redis ◄── Worker (arq)
                                          └──► Almacenamiento S3 (Fase 7)
```

## Decisiones tomadas en la Fase 1

**API versionada bajo `/api/v1`.** Permite introducir cambios incompatibles en
`/api/v2` sin romper la futura aplicación móvil.

**SQLAlchemy asíncrono + asyncpg.** Coherente con FastAPI; evita bloquear el
servidor durante consultas.

**arq como cola de tareas.** Asíncrono como el resto del backend y reutiliza
Redis, sin añadir otro broker. Se usará para emails, recordatorios y para
liberar reservas cuyo pago no se completó a tiempo.

**Dos endpoints de salud.** `/health/live` sólo indica que el proceso responde
(para reinicios); `/health/ready` comprueba base de datos y Redis (para decidir
si recibe tráfico). Si se mezclaran, una caída de Redis haría reiniciar la API
en bucle sin arreglar nada.

**Migraciones como paso separado.** El servicio `migrate` se ejecuta una vez
antes de la API. En producción, con varias réplicas, evita que cada una intente
migrar al mismo tiempo. La imagen de producción permite migrar al arrancar
(`RUN_MIGRATIONS=true`) sólo para despliegues de una réplica.

**Configuración sólo desde el entorno.** La API se niega a arrancar en
producción con el secreto JWT por defecto o con `DEBUG` activo.

**Next.js en modo `standalone`.** La imagen de producción incluye sólo lo
necesario para ejecutar el servidor.

**Fuentes autoalojadas.** Se instalan desde npm (`@fontsource`) en vez de
cargarse desde Google Fonts: no hay dependencia de terceros en el build ni se
envían datos de visitantes a otro dominio.

**API sólo con tokens Bearer; el sitio web como intermediario (BFF).** La API
no maneja cookies: cualquier cliente (el sitio, una futura app móvil) usa
tokens. El servidor de Next.js guarda los tokens en cookies `httpOnly` de su
propio dominio y llama a la API desde el servidor (Server Components y Server
Actions). El archivo `frontend/proxy.ts` renueva el token de acceso cuando le
queda menos de un minuto, antes de cada página. Ventajas: los tokens no son
accesibles desde JavaScript, no hace falta CORS con credenciales, y las páginas
se renderizan en el servidor ya sabiendo quién es el usuario.

**Permisos consultados en cada petición.** El JWT sólo identifica al usuario;
roles y permisos se leen de la base de datos en cada petición, así los cambios
rigen de inmediato. Si en el futuro pesara en rendimiento, se puede cachear en
Redis con invalidación al modificar roles.

**Emails por cola.** La API encola los emails en Redis (arq) y el worker los
envía, con hasta 5 reintentos. Un servidor SMTP lento no retrasa las respuestas.

## Módulos del backend

`backend/app/` contiene un paquete por dominio (`auth`, `users`, `services`,
`reservations`, `pricing`, `payments`, `vehicles`, `drivers`, `carousel`,
`promotions`, `coupons`, `notifications`, `reports`, `audit`). Cada uno tendrá
sus modelos, esquemas, lógica de negocio y rutas, y se registra en
`app/api/v1/router.py`.

## Motor de precios (Fase 3)

`app/pricing/engine.py` es una función pura: recibe tarifa, reglas,
configuración, hora de recogida y duración, y devuelve el desglose. No toca la
base de datos ni el reloj, así que el mismo cálculo se reproduce exactamente en
tests, en el simulador del panel y, en la Fase 4, al confirmar la reserva.

Orden del cálculo:

1. Tarifa de salida + horas facturables × valor hora. Las horas se redondean
   hacia arriba al tramo configurado (30 min por defecto) y nunca bajan del
   mínimo del servicio.
2. Reglas que aplican, en orden de prioridad. **Los porcentajes se calculan
   todos sobre el subtotal del paso 1 y se suman, sin encadenarse**: 20 % + 10 %
   son 30 %, no 32 %. Así el cliente puede verificar la cuenta.
3. Si el total queda bajo el precio mínimo del servicio, se agrega una línea de
   ajuste. El total nunca es negativo.
4. Impuesto. Con precios con IVA incluido (obligatorio al consumidor en Chile),
   se informa el neto y el IVA contenidos en el total.

Cada línea se redondea a la unidad de la moneda (pesos enteros en CLP) y el
total es la suma exacta de las líneas.

Las condiciones de las reglas se evalúan con la **hora local de recogida** en la
zona configurada, incluido el cambio de horario de verano de Chile. Una franja
como 22:00–06:00 cruza la medianoche.

**Sin precio por kilómetro.** Cobrar por distancia exige que el servidor la
calcule con un proveedor de mapas; si la enviara el navegador, el cliente podría
bajarse el precio. Queda para cuando se integre un proveedor de mapas.

## Reservas (Fase 4)

**Cuenta obligatoria para reservar.** Permite "Mis reservas", la cancelación
por el propio cliente y un aislamiento simple entre clientes. El registro
inicia sesión de inmediato. Como la reserva guarda el contacto del pasajero
aparte del usuario, habilitar reservas como invitado más adelante no requiere
cambiar el esquema.

**Disponibilidad por unidades de flota.** Hasta la Fase 6 no hay vehículos
concretos, así que cada servicio indica cuántas unidades tiene. Una reserva
ocupa una unidad desde la recogida hasta el fin del servicio más el tiempo de
preparación (60 min por defecto). Cuentan las reservas confirmadas y las
pendientes cuyo cupo retenido no venció.

**Sin doble reserva, también con concurrencia.** Validar la disponibilidad no
basta si dos personas reservan a la vez. Al crear (o confirmar una reserva cuyo
cupo venció), la fila del servicio se bloquea con `SELECT … FOR UPDATE` antes de
contar: las peticiones simultáneas del mismo servicio se atienden de a una. Un
test lanza ocho reservas simultáneas contra un servicio de dos unidades y
comprueba que se crean exactamente dos. En la Fase 6, al asignar vehículos y
conductores concretos, se agregará además una restricción de exclusión de
PostgreSQL (`tstzrange` + `btree_gist`) que lo garantiza a nivel de base de datos.

**Pago pendiente con cupo retenido.** Mientras no exista el pago en línea (Fase
5), la reserva queda en `PENDING_PAYMENT` y retiene su cupo 30 minutos. El
personal puede confirmarla a mano (por ejemplo, tras una transferencia). El
worker revisa cada minuto y vence las que no se confirmaron; aunque el worker
estuviera detenido, una reserva con el cupo vencido deja de bloquear el horario.

**Precio recalculado al reservar.** El navegador envía el total que mostró; el
servidor recalcula y, si difiere, pide al cliente confirmar el precio nuevo en
vez de cobrar uno distinto al que vio.

## Pagos (Fase 5)

**Proveedor intercambiable.** `app/payments/providers/` define la interfaz
(`start`, `commit`, `refund`) y dos implementaciones: **Webpay Plus** (Transbank)
y una **pasarela simulada** para desarrollo. Agregar Mercado Pago o Flow es
escribir un adaptador más; reservas, reembolsos y pantallas no cambian. Se elige
con `PAYMENT_PROVIDER`.

**Flujo (el de Webpay Plus):**

1. El cliente reserva y el sitio pide `POST /reservations/{code}/pay`. La API
   crea el intento, extiende el cupo retenido durante la ventana de pago y
   devuelve la URL de la pasarela con el token.
2. El navegador se envía a la pasarela con un formulario POST.
3. La pasarela devuelve al cliente a `/payments/return` del sitio, que llama a
   la API. **La API confirma el pago directamente con el proveedor** (`commit`):
   lo que diga el navegador no basta. Webpay Plus no tiene webhooks; si no se
   confirma, Transbank no captura el cargo.
4. Si se aprobó, la reserva pasa a confirmada en la misma transacción y se
   envía el email con los datos del pago.

**Casos límite cubiertos:**

- **Retorno repetido** (recarga, botón atrás): la fila del pago se bloquea y un
  pago ya procesado devuelve el resultado registrado sin confirmar otra vez.
- **Pago aprobado sin cupo**: si el cupo retenido venció y otro cliente tomó el
  horario, el pago se revierte en el acto y se avisa al cliente.
- **Monto u orden distintos** a los esperados: no se confirma y se devuelve el cargo.
- **Abandono** en la pasarela (`TBK_TOKEN`) o **tiempo agotado**: el intento
  queda abandonado; la reserva sigue pendiente y se puede reintentar.
- **Nunca volvió** (cerró el navegador): el worker marca el intento como
  vencido. Webpay no cobra sin confirmación.
- **Reembolso fallido** (pasarela caída): queda registrado como fallido y el
  personal con permiso lo reintenta desde la reserva.

**Redirecciones relativas.** Las rutas `/payments/*` del sitio responden con
`Location` relativo: detrás de un proxy, el origen que ve Next.js no es el
dominio del cliente, y una URL absoluta mal armada haría perder la sesión.

**Pendiente: comprobante tributario.** El sitio muestra el comprobante de pago
(tarjeta, autorización, fecha), pero la boleta o factura electrónica ante el SII
requiere un proveedor de facturación electrónica; no está incluida.

## Flota, asignación y panel del conductor (Fase 6)

**Capacidad desde los vehículos.** Un servicio acepta tantas reservas
simultáneas como vehículos activos tenga, descontando los que estén en
mantención en ese horario. Es un solo dato, así que no puede contradecirse con
otro. El cálculo es conservador: cuenta cualquier reserva que se solape con el
periodo pedido.

**Asignación en dos capas.** La aplicación valida y explica (servicio correcto,
capacidad, mantención, licencia vigente el día del viaje, disponibilidad); las
restricciones de exclusión de PostgreSQL son la garantía final. Si dos personas
asignan el mismo vehículo a la vez, una recibe `ASSIGNMENT_CONFLICT`.

**Estados del viaje** los marca el conductor desde su panel, con ventanas de
tiempo (no puede salir con más de 12 horas de anticipación ni marcar "no se
presentó" antes de la hora). Cada paso queda en el historial con su autor.

**Abordaje con QR.** La página de la reserva genera en el servidor un QR con el
`qr_token` aleatorio (no el código visible, que es adivinable). El conductor lo
escanea con `BarcodeDetector` y la cámara trasera; la API lo compara en tiempo
constante. Si la cámara no está disponible, el abordaje puede confirmarse sin QR
y queda registrado así.

**Carga de modelos por proceso.** Las relaciones entre modelos se declaran por
nombre. El worker y el comando de consola importan `app.db.models` al arrancar;
un test verifica en procesos limpios que cada proceso puede configurar todos los
modelos (este defecto ocurrió y detenía el vencimiento de reservas impagas).

## Imágenes y contenido (Fase 7)

**Procesamiento en la API.** Cada subida se abre con Pillow para verificar que
es realmente JPG, PNG o WebP (no se confía en la extensión ni en el
`Content-Type`). Se rechazan imágenes de más de 40 megapíxeles mirando sólo la
cabecera, antes de decodificar (protección contra bombas de descompresión). Se
aplica la rotación EXIF y se generan variantes WebP de 480, 960, 1600 y 2400 px
sin ningún metadato: las fotos de teléfono suelen traer la ubicación GPS en el
EXIF. El trabajo pesado corre en un hilo aparte para no bloquear la API.

**Almacenamiento intercambiable** (`app/media/storage.py`): disco local en
desarrollo (la API los sirve en `/media`) y S3 o compatible en producción, con
`Cache-Control: immutable`. La API no arranca en producción con disco local,
porque las réplicas no lo comparten.

**Imágenes adaptables.** El sitio usa `<img srcset sizes>` con las variantes ya
generadas, en vez del optimizador de Next.js: las imágenes no se procesan en
cada visita y se pueden servir desde un CDN.

**Carrusel accesible.** Botón de pausa (el contenido que avanza solo debe poder
detenerse, WCAG 2.2.2), se detiene al pasar el mouse o al navegar con el teclado
por dentro, no avanza si la persona pidió reducir el movimiento, y las
diapositivas ocultas son `inert` (sin foco ni lectores de pantalla). Sin
diapositivas publicadas, la portada muestra un texto de bienvenida.

**Reordenar desde el estado actual.** Las flechas del carrusel leen el orden
vigente en cada clic, no el que tenía la página al cargarse: dos clics seguidos
mueven la diapositiva dos lugares.

## Panel e informes (Fase 8)

**Cada área ve lo suyo.** El panel arma sólo las secciones para las que la
persona tiene permiso: operaciones no ve ingresos; finanzas no ve la operación.

**Hora local.** Los periodos se calculan en PostgreSQL con
`date_trunc(periodo, timezone(zona, marca))`: un pago del 31 de mayo a las 23:30
en Santiago es de mayo aunque en UTC ya sea junio (hay un test para ese caso).

**Periodos completos.** La serie se completa en Python con todos los periodos del
rango, para que los gráficos no salten días sin actividad.

**CSV para Excel en Chile.** Separador `;`, marca UTF-8 (BOM) para que Excel lea
bien las tildes, y decimales con coma.

**Gráficos sin librerías.** SVG generado en el servidor, sin JavaScript, siempre
acompañado de la tabla con los mismos datos (lo que leen los lectores de
pantalla y donde se ven las cifras exactas).

## Seguridad (Fase 9)

**CSP con nonce.** `proxy.ts` genera un nonce por petición y arma la política
(`lib/csp.ts`). Scripts: sólo los de Next.js con el nonce (`'strict-dynamic'`).
Estilos: hojas del sitio y bloques con nonce; los atributos `style=""` se
permiten con `style-src-attr`. Formularios: el sitio y Transbank. Todo el sitio
se renderiza por petición (`connection()` en el layout raíz), condición para
usar nonces. La API responde con `default-src 'none'`.

**Verificación en dos pasos.** TOTP (RFC 6238) con desfase de ±1 intervalo. Se
guarda el último intervalo usado y se rechaza cualquier código igual o anterior
(un código interceptado no se puede reutilizar). El secreto se cifra con Fernet
(`FIELD_ENCRYPTION_KEY`); los códigos de respaldo se guardan como SHA-256. El
paso intermedio usa un JWT de tipo `mfa`, que la API nunca acepta como sesión.

**Ley 21.719.** La supresión anonimiza en vez de borrar: las reservas pagadas,
los pagos y los reembolsos se conservan sin datos personales, porque la ley
tributaria obliga a guardar los registros contables. Las entradas de auditoría
sobre la persona conservan que hubo cambios, pero no su contenido.

**Recorridos en el repositorio.** `e2e/` contiene los recorridos de todas las
fases y corre en CI contra una base nueva. Ver `e2e/README.md`.
