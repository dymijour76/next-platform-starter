# Operación

Comandos desde `infrastructure/`. Para abreviar:

```bash
alias dc='docker compose --env-file .env.production -f docker-compose.prod.yml'
```

## Estado y registros

```bash
dc ps                       # estado y salud de cada servicio
dc logs -f --tail=100 backend worker
dc logs caddy | grep -i error
```

Los registros son JSON (una línea por evento) y rotan solos (5 × 10 MB por
servicio). Cada petición lleva un `request_id`, que también aparece en los
errores de Sentry: sirve para cruzar ambos.

## Vigilancia externa

Configure un servicio de monitoreo (UptimeRobot, Better Stack, Healthchecks.io)
para consultar cada 1 a 5 minutos:

| URL | Qué indica si falla |
|---|---|
| `https://DOMINIO/` | El sitio no responde |
| `https://DOMINIO/healthz/api` | La API no llega a PostgreSQL o Redis |
| `https://DOMINIO/healthz/worker` | El worker no late hace más de 3 minutos: **no se envían emails ni vencen las reservas impagas** |
| `BACKUP_PING_URL` (tipo "latido") | El respaldo diario no llegó |

## Respaldos

Todos los días a las 03:00 (hora de Chile): 7 diarios, 4 semanales y 6
mensuales en `infrastructure/backups/`, verificados al crearlos y, si se
configura `BACKUP_S3_BUCKET`, copiados fuera del servidor. **Un respaldo que sólo
vive en el mismo servidor no protege si se pierde el servidor.**

```bash
dc exec backup backup.sh                     # respaldo inmediato
ls -lh backups/daily/                        # disponibles
cat backups/last-success                     # último respaldo correcto
```

### Probar un respaldo (recomendado una vez al mes)

Restaura en una base aparte, sin tocar la de producción:

```bash
dc exec backup restore.sh /backups/daily/<archivo>.dump prueba_restauracion
dc exec postgres psql -U limo -d prueba_restauracion -c "select count(*) from reservations"
dc exec postgres dropdb -U limo prueba_restauracion
```

### Restaurar producción

1. Detenga lo que escribe en la base: `dc stop frontend backend worker`.
2. Restaure (pide escribir el nombre de la base para confirmar):
   `dc exec backup restore.sh /backups/daily/<archivo>.dump`
3. Levante de nuevo: `dc up -d`.

Se pierde lo ocurrido después de ese respaldo. Los pagos hechos en ese intervalo
siguen en Transbank: concílielos con el portal de Transbank.

## Actualizar y revertir

```bash
git pull && ./scripts/deploy.sh             # actualizar
git checkout <versión-anterior> && ./scripts/deploy.sh   # revertir el código
```

Revertir el código no revierte las migraciones. Por eso las migraciones deben
ser compatibles con la versión anterior (agregar columnas o tablas; borrar o
renombrar sólo en una versión posterior, cuando nada las use). Si una
actualización dañó datos, restaure el respaldo que `deploy.sh` tomó justo antes.

## Tareas frecuentes

| Tarea | Comando |
|---|---|
| Crear un administrador | `dc run --rm backend python -m app.cli create-admin --email x@empresa.cl` |
| Consola de la base | `dc exec postgres psql -U limo` |
| Reiniciar un servicio | `dc restart worker` |
| Ver la versión desplegada | `dc exec backend printenv APP_VERSION` |

## Rotación de secretos

- `JWT_SECRET`: cambiarlo cierra todas las sesiones (todos deben volver a entrar).
- `INTERNAL_PROXY_SECRET`, `POSTGRES_PASSWORD`, `REDIS_PASSWORD`: cambie el valor
  y ejecute `deploy.sh`. La contraseña de PostgreSQL también debe cambiarse dentro
  de la base: `ALTER USER limo PASSWORD '...'`.
- `FIELD_ENCRYPTION_KEY`: **no se puede rotar sin más**; con una clave nueva, las
  verificaciones en dos pasos existentes dejan de funcionar y deben restablecerse.
