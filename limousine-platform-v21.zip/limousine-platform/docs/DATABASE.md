# Base de datos

Motor: PostgreSQL 16. Migraciones: Alembic (`backend/migrations/`).

## Convenciones

Todas las tablas siguen estas reglas, implementadas en `backend/app/db/base.py`:

- **Clave primaria UUID** generada por PostgreSQL con `gen_random_uuid()`.
  Los códigos visibles (p. ej. `RES-2026-000125`) son columnas aparte.
- **`created_at` / `updated_at`** de tipo `timestamptz`. Todas las fechas se
  guardan en UTC y se muestran en la zona horaria configurada.
- **Montos** en `NUMERIC`, nunca `FLOAT`, siempre acompañados de su columna
  `currency` (código ISO 4217).
- **Nombres de índices y restricciones deterministas** (`ix_`, `uq_`, `fk_`,
  `ck_`, `pk_`), para que las migraciones autogeneradas sean estables.
- **Emails** con tipo `citext`, para que `Ana@x.com` y `ana@x.com` sean el mismo.

## Extensiones

| Extensión | Para qué |
|---|---|
| `pgcrypto` | `gen_random_uuid()` |
| `citext` | Texto sin distinción de mayúsculas |
| `btree_gist` | Restricciones de exclusión por rango horario: impiden, a nivel de base de datos, asignar el mismo vehículo o conductor a dos reservas solapadas |

## Flujo de trabajo

```bash
make migration m="crear tabla users"   # genera la migración a partir de los modelos
make migrate                            # la aplica
```

Revise siempre la migración generada antes de aplicarla: Alembic no detecta
todo (por ejemplo, cambios de tipo en columnas con datos o restricciones de
exclusión, que se escriben a mano).

Los modelos nuevos deben importarse en `backend/app/db/models.py` para que
Alembic los detecte.

## Pendiente

Esquema completo (Fases 2 a 8) y procedimiento de backup y restauración (Fase 9).

## Tablas de la Fase 2 (migración `0002`)

| Tabla | Contenido |
|---|---|
| `users` | Email (`citext`, único sin distinguir mayúsculas), hash Argon2id, nombre, teléfono, `status` (`ACTIVE`/`INACTIVE`/`SUSPENDED`), `email_verified_at`, `last_login_at`, `token_version` |
| `customer_profiles` | 1:1 con `users`: dirección, empresa, datos de facturación (RUT validado), `preferences` (JSONB), `marketing_consent`, `terms_accepted_at` |
| `roles` | Código, nombre, descripción, `is_system` |
| `permissions` | Código (`modulo:accion`), módulo, descripción |
| `role_permissions` | Roles ↔ permisos |
| `user_roles` | Usuarios ↔ roles, con `assigned_at` y `assigned_by` |
| `refresh_tokens` | Hash SHA-256, `family_id`, vencimiento, revocación y motivo, IP y navegador |
| `one_time_tokens` | Hash, propósito (`EMAIL_VERIFICATION`, `PASSWORD_RESET`), vencimiento, `used_at` |
| `audit_logs` | Actor, acción, entidad, valores antes/después (JSONB), IP, navegador, `request_id` |

La migración crea los 28 permisos y los 5 roles del sistema (`super_admin`,
`reservations_admin`, `finance_admin`, `driver`, `customer`). Los datos están
copiados dentro de la migración para que no cambie si después cambia el código.
Al agregar permisos en fases futuras, la migración correspondiente debe
insertarlos y asignarlos al menos a `super_admin`.

Una persona puede tener varios roles; sus permisos son la unión. Los
conductores serán usuarios con rol `driver` más una ficha en `drivers` (Fase 6).

## Tablas de la Fase 3 (migración `0003`)

| Tabla | Contenido |
|---|---|
| `services` | `slug` único, nombre, textos, capacidad, `features` (JSONB), tarifa (`base_fare`, `hourly_rate`, `min_hours`, `max_hours`, `minimum_fare`), `is_active`, `sort_order` |
| `pricing_rules` | Nombre, `kind`, `adjustment_type`, `value` y condiciones: `service_ids` (arreglo de UUID), `days_of_week` (arreglo), franja `time_from`/`time_until`, fechas `valid_from`/`valid_until`, `min_hours`, `priority`, `is_active` |
| `app_settings` | Configuración clave → JSON. La migración crea `pricing` con los valores iniciales (CLP, America/Santiago, IVA 19 % incluido, tramos de 30 min, 2 h de anticipación, 365 días) |

Las restricciones `CHECK` impiden montos negativos, porcentajes sobre 100,
franjas incompletas y rangos de fechas invertidos, aunque se escriba
directamente en la base.

Los servicios no se eliminan, se desactivan: las reservas (Fase 4) los
referenciarán. Las reglas sí se pueden eliminar, porque cada reserva guardará
una copia completa del cálculo (`Quote.snapshot()` en `app/pricing/engine.py`):
tarifa usada, líneas, reglas aplicadas, neto, impuesto y total.

## Tablas de la Fase 4 (migración `0004`)

| Tabla | Contenido |
|---|---|
| `reservations` | `code` (`RES-2026-000125`) y UUID; `user_id`; `service_id`; `status`; `pickup_at`, `duration_minutes`, `end_at`, `blocks_until`; direcciones; pasajeros; contacto del pasajero; `currency`, `total_amount`, `pricing_snapshot` y `cancellation_policy_snapshot` (JSONB); `hold_expires_at`; fechas de confirmación y cancelación; `refund_amount`; `qr_token`; `idempotency_key` |
| `reservation_events` | Historial: estado anterior y nuevo, autor, nota y fecha |
| `reservation_counters` | Último correlativo por año, para el código visible |

`services.fleet_size` indica cuántas unidades tiene cada servicio. La migración
también crea la configuración `booking` (30 min de cupo retenido, 60 min de
preparación, cancelación sin costo hasta 24 h antes, sin reembolso después).

**Todas las fechas son `timestamptz`.** `blocks_until` es el fin del servicio
más el tiempo de preparación: la unidad está ocupada desde `pickup_at` hasta
ahí.

**Copias inmutables.** `pricing_snapshot` guarda la tarifa, cada línea del
desglose, las reglas aplicadas, neto, impuesto y total; la política aceptada
queda en `cancellation_policy_snapshot`. Cambiar precios o la política después
no altera reservas existentes.

**Datos de contacto separados de la cuenta.** El pasajero puede ser otra
persona, y si en el futuro se permiten reservas sin cuenta, `user_id` queda
vacío sin cambiar el esquema.

**Código correlativo sin huecos por concurrencia**: se obtiene con
`INSERT … ON CONFLICT DO UPDATE … RETURNING` sobre `reservation_counters`, en la
misma transacción que la reserva.

**Token del QR** (`qr_token`): aleatorio de 192 bits, independiente del código
visible, que es adivinable. Se usará en la Fase 6 para validar el abordaje.

## Tablas de la Fase 5 (migración `0005`)

| Tabla | Contenido |
|---|---|
| `payments` | Un intento de pago por fila: reserva, proveedor, estado, monto, `refunded_amount`, `buy_order` único (`RES-2026-000001-1`), `provider_token` único, código de autorización, últimos 4 dígitos, tipo de pago, cuotas, código de respuesta, respuesta del proveedor (JSONB, sin datos de tarjeta), `authorized_at`, `expires_at` |
| `refunds` | Reembolsos de un pago: monto, estado (`PENDING`, `SUCCEEDED`, `FAILED`), motivo, referencia y respuesta del proveedor, error, quién lo pidió |

Restricciones `CHECK`: montos positivos y lo reembolsado nunca supera lo
cobrado. **No se guardan números de tarjeta**: sólo los últimos 4 dígitos que
informa el proveedor.

## Tablas de la Fase 6 (migración `0006`)

| Tabla | Contenido |
|---|---|
| `vehicles` | Patente única, servicio, marca, modelo, año, color, pasajeros, estado, notas |
| `vehicle_blocks` | Mantenciones: vehículo, inicio, término, motivo, quién la registró |
| `drivers` | Cuenta de usuario (única), número y clase de licencia, vencimiento, estado, notas |

`reservations` suma `vehicle_id`, `driver_id` y `boarded_at`, y los estados
`EN_ROUTE`, `ARRIVED` e `IN_PROGRESS`. **Se elimina `services.fleet_size`**: la
capacidad sale de los vehículos.

**Sin doble asignación, garantizado por PostgreSQL.** Dos restricciones de
exclusión (extensión `btree_gist`):

```sql
EXCLUDE USING gist (vehicle_id WITH =, tstzrange(pickup_at, blocks_until) WITH &&)
  WHERE (vehicle_id IS NOT NULL AND status IN ('CONFIRMED','EN_ROUTE','ARRIVED','IN_PROGRESS'))
```

y la misma para `driver_id`. Un vehículo o conductor no puede estar en dos
viajes activos cuyos periodos (incluida la preparación) se solapen, aunque la
aplicación fallara o dos personas asignaran a la vez. Las reservas canceladas o
terminadas dejan de contar.

## Tablas de la Fase 7 (migración `0007`)

| Tabla | Contenido |
|---|---|
| `media_assets` | Imagen: nombre original, `alt_text`, dimensiones, bytes y `variants` (JSONB: ancho, alto y clave de cada WebP) |
| `carousel_slides` | Imagen, título, texto, botón (texto y enlace), orden, activa, `starts_at` y `ends_at` |
| `service_images` | Galería de cada servicio con su orden (la primera es la portada) |

Las claves de almacenamiento son `media/<id>/<ancho>.webp`: incluyen el id de la
imagen y no cambian, así que se pueden cachear sin límite. El archivo original
subido no se guarda: sólo las variantes procesadas, sin metadatos.
