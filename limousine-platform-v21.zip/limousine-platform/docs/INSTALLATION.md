# Instalación

## Opción A: Docker (recomendada)

Requisitos: Docker Desktop o Docker Engine con Compose v2.24 o superior.

```bash
cp .env.example .env
docker compose up --build
```

Al arrancar, Compose ejecuta en orden:

1. `postgres` y `redis`, esperando a que respondan a su healthcheck.
2. `migrate`, que aplica las migraciones pendientes y termina.
3. `backend` (puerto 8000) y `worker`, sólo si las migraciones terminaron bien.
4. `frontend` (puerto 3000).

El código de `backend/` y `frontend/` se monta como volumen: los cambios se
recargan sin reconstruir la imagen.

Comprobación: abra http://localhost:3000/estado. Los tres componentes deben
aparecer como "Disponible".

## Opción B: sin Docker

Requisitos: Python 3.12, Node.js 22, PostgreSQL 16 y Redis 7 instalados localmente.

### Base de datos

```sql
CREATE USER limo WITH PASSWORD 'limo';
CREATE DATABASE limo OWNER limo;
```

El usuario no necesita ser superusuario: las extensiones que usa el proyecto
(`pgcrypto`, `citext`, `btree_gist`) son *trusted* en PostgreSQL 13+ y las puede
crear el dueño de la base.

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
export DATABASE_URL=postgresql+asyncpg://limo:limo@localhost:5432/limo
export REDIS_URL=redis://localhost:6379/0
alembic upgrade head
uvicorn app.main:app --reload       # API en http://localhost:8000
arq app.worker.WorkerSettings       # worker, en otra terminal
```

### Frontend

```bash
cd frontend
npm ci
API_INTERNAL_URL=http://localhost:8000 npm run dev    # http://localhost:3000
```

## Verificación de calidad

```bash
# Backend
ruff check . && ruff format --check . && mypy app && pytest -q
# Frontend
npm run lint && npm run typecheck && npm run build
```

Los tests marcados `integration` necesitan PostgreSQL y Redis reales. Para
omitirlos: `pytest -m "not integration"`.

## Primer administrador

Las cuentas del personal se crean por invitación desde el panel, pero el
primer administrador general se crea por consola:

```bash
make admin email=ana@empresa.cl
# sin Docker:
cd backend && python -m app.cli create-admin --email ana@empresa.cl --first-name Ana --last-name Pérez
```

La contraseña se pide por teclado (o en la variable `ADMIN_PASSWORD` para
automatizar). Si el email ya existe, se le asigna el rol y se actualiza la
contraseña. Luego ingrese en http://localhost:3000/login y vaya a *Administración*.

## Datos de ejemplo

```bash
make demo
# sin Docker:
cd backend && python -m app.cli seed-demo
```

Carga los servicios Standard, Professional y Premium, cuatro vehículos (sin
vehículos no se puede reservar) y dos reglas (recargo nocturno y de fin de semana). Los precios son sólo ilustrativos: revíselos en
*Administración → Servicios* y *Precios*. Si ya hay servicios, no hace nada.

## Imágenes en desarrollo

Con `docker compose`, las imágenes subidas se guardan en el volumen `media_data`
y la API las sirve en http://localhost:8000/media. Sin Docker, quedan en
`backend/media/`.

## Emails en desarrollo

Con `docker compose`, todos los emails (verificación, recuperación,
invitaciones) se capturan en **Mailpit**: http://localhost:8025. No se envía
nada a direcciones reales. Sin Docker, `EMAIL_BACKEND=console` los escribe en
el log del worker.

## Tests

```bash
make test
# sin Docker (requiere PostgreSQL y Redis locales):
cd backend && pytest
```

Los tests usan una base de datos propia con sufijo `_test` (se crea y migra
sola; el usuario de PostgreSQL necesita permiso `CREATEDB`) y la base 15 de
Redis. Nunca tocan los datos de desarrollo.

## Variables de entorno

Todas están documentadas en [`.env.example`](../.env.example). Las más importantes:

| Variable | Uso |
|---|---|
| `ENVIRONMENT` | `development`, `test`, `staging` o `production` |
| `DATABASE_URL` | Conexión a PostgreSQL (driver `asyncpg`) |
| `REDIS_URL` | Conexión a Redis |
| `JWT_SECRET` | Firma de tokens. En producción: 32 caracteres mínimo, o la API no arranca |
| `CORS_ORIGINS` | Lista JSON de orígenes permitidos |
| `API_INTERNAL_URL` | URL de la API vista desde el servidor Next.js |
| `NEXT_PUBLIC_API_URL` | URL de la API vista desde el navegador (se fija al compilar) |
| `FRONTEND_URL` | URL pública del sitio, para los enlaces de los emails |
| `EMAIL_BACKEND` | `console` (desarrollo) o `smtp` (obligatorio en producción) |
| `EMAIL_HOST`, `EMAIL_PORT`, `EMAIL_USER`, `EMAIL_PASSWORD`, `EMAIL_USE_TLS`, `EMAIL_FROM` | Servidor de correo |
| `REQUIRE_EMAIL_VERIFICATION` | `true` impide iniciar sesión sin confirmar el email |
| `ACCESS_TOKEN_MINUTES`, `REFRESH_TOKEN_DAYS` | Duración de la sesión (15 min y 30 días por defecto) |
| `STORAGE_BACKEND`, `MEDIA_ROOT`, `MEDIA_BASE_URL`, `S3_*`, `UPLOAD_MAX_MB` | Imágenes: disco local o S3 (ver Despliegue) |
| `PAYMENT_PROVIDER` | `simulated` (desarrollo: pasarela de prueba en el sitio) o `webpay` |
| `WEBPAY_ENVIRONMENT`, `WEBPAY_COMMERCE_CODE`, `WEBPAY_API_KEY` | Webpay Plus. Por defecto, las credenciales públicas de integración |

## Problemas frecuentes

**El servicio `migrate` falla.** Revise `docker compose logs migrate`. Casi
siempre se debe a credenciales distintas entre `.env` y un volumen de PostgreSQL
creado antes; `make reset` elimina el volumen (y los datos locales).

**`/estado` muestra "No se pudo conectar con la API".** Compruebe
`docker compose ps` y los logs de `backend`.

**No llegan los emails.** Revise `docker compose logs worker`. En desarrollo
están en Mailpit (http://localhost:8025), no en su bandeja real.

**"Demasiados intentos" al probar el login.** Los límites viven en Redis:
`docker compose exec redis redis-cli flushdb` los reinicia en desarrollo.

**Los cambios del frontend no se recargan en Windows/macOS.** Ya está activado
`WATCHPACK_POLLING`; si persiste, reinicie el servicio `frontend`.
