# Seguridad

## Plataforma (Fase 1)

- Secretos sólo por variables de entorno; `.env` excluido de Git.
- La API no arranca en producción con `JWT_SECRET` por defecto o corto, con
  `DEBUG` activo ni con `EMAIL_BACKEND=console`.
- Documentación interactiva de la API (`/docs`) deshabilitada en producción.
- CORS restringido a orígenes configurados.
- Cabeceras de seguridad en API y frontend; sin `X-Powered-By`.
- `X-Request-ID` en cada respuesta, log y registro de auditoría.
- Contenedores sin privilegios; usuario de base de datos sin superusuario.
- Consultas parametrizadas (SQLAlchemy). Análisis estático (Ruff `S`) en CI.

## Autenticación y sesiones (Fase 2)

**Contraseñas.** Argon2id con los parámetros recomendados por OWASP (19 MiB,
2 iteraciones); los hashes antiguos se actualizan al iniciar sesión. Política
NIST SP 800-63B: mínimo 10 caracteres, sin exigir símbolos, rechazo de
contraseñas comunes y de las que contienen el email.

**Sin enumeración de cuentas.** El login responde igual con email inexistente
o contraseña errónea, y tarda lo mismo (se verifica contra un hash ficticio).
La recuperación de contraseña responde igual exista o no la cuenta. El estado
de una cuenta suspendida sólo se revela a quien conoce la contraseña.

**Tokens.**

| Token | Duración | Formato | Almacenamiento en servidor |
|---|---|---|---|
| Acceso | 15 min | JWT HS256 (`sub`, `ver`, `type`, `iss`, `iat`, `exp`, `jti`) | — |
| Refresh | 30 días | Aleatorio de 256 bits | Sólo su hash SHA-256 |
| Verificación de email | 48 h | Aleatorio de 256 bits, un solo uso | Sólo su hash |
| Restablecer contraseña | 60 min (invitación: 72 h) | Aleatorio de 256 bits, un solo uso | Sólo su hash |

- El algoritmo del JWT está fijado: se rechazan `alg: none` y firmas ajenas.
- **Rotación de refresh tokens.** Cada uso entrega uno nuevo. Si un token ya
  usado vuelve a aparecer (señal de robo), se revoca toda la familia de ese
  inicio de sesión. Hay una ventana de 30 s para peticiones paralelas legítimas.
- **Invalidación inmediata.** Cada usuario tiene `token_version`, incluido en el
  JWT. Cambiar la contraseña, cerrar todas las sesiones o suspender la cuenta lo
  incrementa, y todos los tokens de acceso anteriores dejan de valer al instante.
- Sólo el último enlace de recuperación o verificación emitido es válido.
- La verificación de email exige pulsar un botón: los filtros de correo que
  abren enlaces automáticamente no la completan.

**Sitio web (patrón BFF).** El navegador nunca ve los tokens: el servidor de
Next.js los guarda en cookies `httpOnly`, `SameSite=Lax` y `Secure` en
producción, y llama a la API. Un ataque XSS no puede leerlos. Las Server
Actions de Next.js verifican el origen de cada envío (protección CSRF). Las
redirecciones tras el login sólo aceptan rutas internas.

**Límites de intentos** en Redis, compartidos entre réplicas (ver
[API](API.md)). Si Redis cae, las peticiones se permiten y se registra la
incidencia, para no bloquear el acceso de todos los clientes.

## Autorización (Fase 2)

- RBAC: 28 permisos y 5 roles de sistema; roles personalizados desde el panel.
- Los permisos se consultan en la base de datos en cada petición: un cambio de
  roles rige sin volver a iniciar sesión.
- Protección contra escalada de privilegios, aplicada en la API:
  - nadie puede otorgar (en un usuario o en un rol) permisos que no tiene;
  - nadie puede administrar a alguien con más permisos que él;
  - nadie puede cambiar su propio estado ni sus roles;
  - siempre debe quedar un administrador general activo.
- El frontend oculta lo que el perfil no puede usar, pero la API es la que
  decide: acceder por URL directa a una sección sin permiso redirige.

## Precios (Fase 3)

- El precio se calcula siempre en el servidor. La cotización sólo recibe
  servicio, fecha y duración; cualquier monto enviado por el cliente se ignora
  (hay un test que lo comprueba).
- Cambiar una tarifa exige el permiso de precios además del de servicios: quien
  sólo edita el catálogo no puede tocar montos.
- Los cambios de servicios, reglas y configuración quedan en la auditoría, con
  los valores anteriores y nuevos.
- La cotización pública tiene límite de 60 peticiones por minuto por IP.
- Restricciones `CHECK` en la base impiden montos negativos o porcentajes
  inválidos aunque falle una validación de la aplicación.

## Reservas (Fase 4)

- Aislamiento entre clientes: cada consulta filtra por el usuario de la sesión;
  la reserva de otro cliente responde `404`, sin revelar que existe (probado).
- El precio y la disponibilidad se calculan en el servidor; el total enviado
  por el navegador sólo se usa para detectar un cambio de precio.
- Clave de idempotencia por intento: un doble clic no duplica la reserva, y la
  clave de otro usuario no permite leer su reserva.
- El token del QR es aleatorio e independiente del código visible.
- Transiciones de estado restringidas y registradas con autor y nota.
- Límites: 10 reservas por hora y 60 consultas de disponibilidad por minuto por usuario.

## Pagos (Fase 5)

- El pago se confirma siempre servidor a servidor con el proveedor; los
  parámetros de retorno del navegador sólo identifican el intento.
- Se verifica que monto y orden de compra coincidan con lo esperado; si no, no
  se confirma y se devuelve el cargo.
- Retorno idempotente con bloqueo de fila: un pago no confirma dos veces.
- No se almacenan números de tarjeta (sólo los últimos 4 dígitos informados).
- La pasarela simulada responde `404` fuera de `PAYMENT_PROVIDER=simulated`, y
  la API no arranca en producción con ella ni con las credenciales públicas de
  integración de Webpay.
- Reembolsos manuales y reintentos exigen `payments:refund` y quedan en la
  auditoría. Finanzas (`payments:read`) ve cobros y totales, pero no reembolsa.

## Flota y conductores (Fase 6)

- Doble asignación imposible también a nivel de base de datos (restricciones de exclusión).
- El conductor sólo accede a sus viajes y sólo a lo necesario del pasajero
  (nombre, teléfono, direcciones, indicaciones): nunca precios, pagos ni email.
- El QR contiene un token aleatorio de 192 bits, se entrega sólo al dueño de la
  reserva mientras el viaje está activo y se compara en tiempo constante.
- **Cámara:** `Permissions-Policy: camera=(self)` en todo el sitio. Tiene que ser
  todo el sitio porque la política la fija el primer documento cargado y la
  navegación interna no la cambia (restringirla a `/driver` bloqueaba el
  escáner). Sólo el escáner del conductor la solicita, el navegador pide permiso
  a la persona y ningún sitio externo puede usarla. Micrófono bloqueado.
- Excepción documentada a "no otorgar permisos propios": quien administra
  conductores puede dar el rol de conductor, que sólo permite ver sus viajes.
- Altas, cambios, mantenciones y asignaciones quedan en la auditoría.

## Imágenes (Fase 7)

- El tipo se verifica abriendo la imagen, no por extensión ni `Content-Type`: un
  archivo de texto con nombre `.jpg` se rechaza (probado).
- Límite de tamaño leído sin cargar el archivo completo en memoria, y de 40
  megapíxeles comprobado en la cabecera (bombas de descompresión).
- Se descartan todos los metadatos, incluida la ubicación GPS (probado también
  descargando la imagen servida).
- Sólo se guardan y sirven variantes re-codificadas en WebP: el archivo
  original, que podría llevar contenido oculto, nunca se publica.
- Las rutas de almacenamiento local no pueden salir de la carpeta de medios.
- Los enlaces del carrusel sólo admiten rutas del sitio o `https://`.
- 60 subidas por hora por usuario; subir, editar y borrar queda en la auditoría.

## Panel e informes (Fase 8)

- Cada sección del panel se entrega sólo con el permiso de su área; los informes
  financieros exigen `reports:financial`, también en la descarga CSV (la ruta de
  descarga del sitio reenvía la sesión y la API verifica el permiso).
- Rangos acotados para que un informe no pueda recorrer años día por día.

## Fase 9: endurecimiento

**Cabeceras.** Sitio: CSP con nonce por petición, `X-Frame-Options: DENY`,
`Cross-Origin-Opener-Policy`, `Referrer-Policy`, `Permissions-Policy` y, en
producción, `Strict-Transport-Security`. API: `default-src 'none'`,
`Cross-Origin-Resource-Policy` y HSTS en producción.

La CSP se verificó de dos formas: un XSS realista (HTML inyectado con
`onerror`) queda bloqueado, y los recorridos de todas las fases corren con cero
violaciones (pago, imágenes, cámara, gráficos).

**Registros.** El `X-Request-ID` que envía un cliente se acepta sólo si es
corto y sin caracteres especiales; si no, se genera uno nuevo. Antes se podía
inyectar texto arbitrario en los registros.

**Cuentas.** Bloqueo progresivo por cuenta además del límite por IP;
verificación en dos pasos opcional para todos y exigible al personal
(`REQUIRE_STAFF_MFA`); restablecimiento por un administrador con auditoría y
cierre de sesiones.

**Dependencias.** `pip-audit` y `npm audit` en cada ejecución de CI. Al cerrar
esta fase no había vulnerabilidades conocidas.

**Límites.** La implementación de la Ley 21.719 es técnica: los plazos de
retención y los textos deben revisarse con asesoría legal. No se hizo una
prueba de penetración externa; se recomienda antes de producción.

## Producción (Fase 10)

- **Superficie mínima:** sólo Caddy publica puertos. La API, PostgreSQL y Redis
  no son alcanzables desde Internet; Redis y PostgreSQL con contraseña.
- **IP real del visitante:** la API la acepta del sitio sólo con
  `INTERNAL_PROXY_SECRET` y si es una IP válida (probado: sin el secreto, con un
  secreto distinto o con un valor que no es IP, se ignora). Antes, en producción,
  todos los visitantes habrían compartido una sola IP para los límites de intentos.
- **Contenedores:** sin capacidades del kernel (`cap_drop: ALL`),
  `no-new-privileges` y usuarios sin privilegios; API y worker de sólo lectura.
- **Sentry:** no se envían IP, cookies, cuerpo de las peticiones ni cabeceras de
  autorización (probado).
- **Respaldos:** verificados al crearse; restauración probada tabla por tabla.

## Auditoría (Fase 2)

Se registran en `audit_logs` la creación y modificación de usuarios y la
creación, modificación y eliminación de roles: quién, cuándo, valores antes y
después, IP, navegador y `X-Request-ID`. El registro se guarda en la misma
transacción que la operación.

## Pruebas

209 tests automáticos del backend y recorridos en navegador de las fases 2 a 9 (ver `e2e/README.md`), ambos en CI, entre ellos: tokens
falsificados, expirados y `alg: none`; reutilización de refresh tokens;
enlaces reutilizados o vencidos; escalada de privilegios; autoascenso por el
perfil; eliminación del último administrador; inyección de precios desde el
cliente; acceso a reservas de otro cliente; reservas simultáneas; efectos inmediatos de la
suspensión; límites de intentos; tokens y contraseñas nunca almacenados en claro.

## Pendiente

| Fase | Control |
|---|---|
| 4 | Aislamiento de reservas entre clientes; pruebas de manipulación de precios |
| 5 | Verificación de firma e idempotencia en webhooks de pago |
| 7 | Validación de tipo y tamaño de archivos subidos |
| 9 | CSP estricta, bloqueo progresivo por intentos, 2FA para el personal, eliminación de cuentas (Ley 21.719) |
| 10 | HTTPS, WAF, rotación de secretos, monitoreo y alertas |

## Reporte de vulnerabilidades

Definir el contacto responsable antes de la puesta en producción.
