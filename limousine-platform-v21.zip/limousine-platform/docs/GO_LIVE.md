# Antes de salir en vivo

Marque cada punto. Los marcados ⚠ bloquean la salida.

## Infraestructura
- [ ] ⚠ Dominio apuntando al servidor; HTTPS funcionando (candado en el navegador).
- [ ] ⚠ `.env.production` completo, con secretos generados por `generate-secrets.sh`.
- [ ] ⚠ `FIELD_ENCRYPTION_KEY` y `JWT_SECRET` guardados también en un gestor de contraseñas.
- [ ] Firewall: sólo 22, 80 y 443 abiertos; SSH con llave, sin contraseña.
- [ ] Actualizaciones automáticas de seguridad del sistema operativo activadas.

## Datos y respaldos
- [ ] ⚠ Respaldo diario funcionando (`backups/last-success` reciente).
- [ ] ⚠ Copia fuera del servidor configurada (`BACKUP_S3_BUCKET`).
- [ ] ⚠ **Una restauración de prueba hecha** (ver `OPERATIONS.md`). Un respaldo que nunca se restauró no está probado.
- [ ] Sin datos de ejemplo (`seed-demo` no se ejecutó en producción).

## Vigilancia
- [ ] ⚠ Monitoreo externo de `/`, `/healthz/api` y `/healthz/worker`, con avisos por email o teléfono.
- [ ] Aviso de respaldo no recibido (`BACKUP_PING_URL`).
- [ ] Sentry configurado (`SENTRY_DSN`) o decidido prescindir de él.

## Pagos
- [ ] ⚠ Webpay probado en el ambiente de integración (lista en `DEPLOYMENT.md`).
- [ ] ⚠ Proceso de validación de Transbank completado y credenciales de producción cargadas.
- [ ] Una compra real de monto bajo, seguida de su anulación, en producción.
- [ ] Definido cómo se emitirá la boleta o factura electrónica (SII): el sistema no la emite.

## Emails
- [ ] ⚠ SMTP de producción configurado; los emails llegan (revise también la carpeta de spam).
- [ ] Registros SPF, DKIM y DMARC del dominio remitente configurados.

## Contenido y operación
- [ ] ⚠ Servicios, precios, recargos y política de cancelación revisados por el negocio.
- [ ] ⚠ Vehículos y conductores reales cargados (sin vehículos no se puede reservar).
- [ ] Carrusel y fotografías de los servicios.
- [ ] Personal creado con sus roles; verificación en dos pasos activada (`REQUIRE_STAFF_MFA=true`).

## Legal
- [ ] ⚠ Términos y condiciones y política de privacidad redactados por un abogado (hoy son textos de ejemplo).
- [ ] Revisión legal del tratamiento de datos según la Ley 21.719 (plazos de retención, textos).
- [ ] Recomendado: prueba de penetración externa.

## El día de la salida
- [ ] `deploy.sh` ejecutado con la versión final; `dc ps` con todo "healthy".
- [ ] Recorrido manual: registrarse, reservar, pagar, recibir emails, cancelar y ver el reembolso.
- [ ] El conductor entra a su panel desde su teléfono y escanea un QR de prueba.
