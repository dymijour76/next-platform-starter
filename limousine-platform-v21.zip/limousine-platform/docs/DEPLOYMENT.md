# Despliegue

Producción en un servidor Linux con Docker Compose (Hetzner, DigitalOcean, AWS
Lightsail, un proveedor local…). Todo corre en contenedores estándar, así que se
puede trasladar a otro proveedor cambiando poco.

## Arquitectura

```
Internet ──443──▶ Caddy (HTTPS automático) ──▶ Sitio (Next.js) ──▶ API (FastAPI) ──▶ PostgreSQL
                     │                                              │               Redis
                     └─ /healthz/api, /healthz/worker ──────────────┘   Worker ─────┘
                                                                        Respaldos ──▶ PostgreSQL, S3
```

- **Sólo Caddy publica puertos** (80 y 443). La API, PostgreSQL y Redis quedan en
  la red interna: el navegador habla únicamente con el sitio, que llama a la API
  desde el servidor. Las imágenes se sirven desde S3 o su CDN.
- **IP real del visitante:** Caddy la escribe en `X-Forwarded-For` (reemplazando
  lo que mande el cliente); el sitio la reenvía a la API en `X-Client-IP` con
  `INTERNAL_PROXY_SECRET`, y la API sólo la acepta con ese secreto. Sin esto, los
  límites por IP se aplicarían a todos los usuarios juntos. **El sitio nunca debe
  quedar accesible sin pasar por Caddy.**
- Contenedores de la aplicación sin privilegios (`cap_drop: ALL`,
  `no-new-privileges`); la API y el worker con sistema de archivos de sólo lectura.

## Servidor recomendado

Para empezar: 2 vCPU, 4 GB de RAM y 40 GB de disco, con Ubuntu 24.04 LTS. Abra
sólo los puertos 22 (SSH, idealmente sólo desde su IP), 80 y 443.

## Primera instalación

```bash
# En el servidor, con Docker y el plugin de Compose instalados:
git clone <repositorio> limousine && cd limousine/infrastructure
./scripts/generate-secrets.sh        # crea .env.production con secretos nuevos (permisos 600)
nano .env.production                 # dominio, email, Webpay, S3, respaldos
./scripts/deploy.sh                  # construye, migra y levanta

# Primer administrador (pide la contraseña):
docker compose --env-file .env.production -f docker-compose.prod.yml \
  run --rm backend python -m app.cli create-admin --email usted@empresa.cl
```

Antes de ejecutar `deploy.sh`, el dominio debe apuntar (registro A) a la IP del
servidor: Caddy pide el certificado en el primer arranque. **No cargue los datos
de ejemplo (`seed-demo`) en producción.**

## Actualizar

```bash
git pull && ./scripts/deploy.sh
```

`deploy.sh` respalda la base, construye, aplica migraciones y reinicia. Ver
`docs/OPERATIONS.md` para revertir una versión y restaurar respaldos.

## Antes de activar Webpay (obligatorio)

El adaptador de Webpay Plus sigue la documentación pública de Transbank y está
probado contra un servidor que imita sus respuestas, **pero no se ha ejecutado
contra el ambiente de integración real de Transbank** (el entorno de desarrollo
no tenía acceso). Antes de producción:

1. Configure `PAYMENT_PROVIDER=webpay` y `WEBPAY_ENVIRONMENT=integration` (con
   las credenciales públicas de integración que ya trae `.env.example`).
2. `FRONTEND_URL` debe ser una dirección pública con HTTPS: Transbank devuelve
   al cliente a `FRONTEND_URL/payments/return`.
3. Haga compras de prueba con las tarjetas de prueba de Transbank: una
   aprobada, una rechazada, una anulada en el formulario de Webpay y una en la
   que deje pasar el tiempo sin pagar. Verifique en cada caso el estado de la
   reserva y del pago en *Administración*.
4. Cancele una reserva pagada y confirme que el reembolso aparece como
   procesado. Pruebe también un reembolso parcial.
5. Revise si Transbank devuelve al cliente por GET o por POST en su versión
   actual (la ruta acepta ambos) y que el certificado exigido por Transbank
   para pasar a producción se complete.
6. Con el código de comercio y la llave de producción que entregue Transbank:
   `WEBPAY_ENVIRONMENT=production`, `WEBPAY_COMMERCE_CODE`, `WEBPAY_API_KEY`.
   La API no arranca en producción con las credenciales de integración.

## Imágenes en producción

`STORAGE_BACKEND=s3` es obligatorio en producción (la API no arranca con disco
local). Configure `S3_BUCKET`, `S3_REGION`, las credenciales y `MEDIA_BASE_URL`
con la URL pública del bucket o, mejor, de un CDN delante de él (CloudFront,
Cloudflare). Para MinIO o Cloudflare R2, indique también `S3_ENDPOINT_URL`.

El bucket debe permitir lectura pública de `media/*` (o servirse sólo por el CDN)
y escritura únicamente con las credenciales de la API. El adaptador está probado
contra un S3 simulado, no contra AWS real: tras configurarlo, suba una imagen de
prueba y verifique que se vea en la portada.

## Seguridad en producción (Fase 9)

- `FIELD_ENCRYPTION_KEY` es obligatoria (la API no arranca sin ella). Guárdela
  como secreto y respáldela: **si se pierde, las verificaciones en dos pasos
  existentes dejan de funcionar** y habrá que restablecerlas una por una.
- Se recomienda `REQUIRE_STAFF_MFA=true`.
- El sitio necesita `MEDIA_BASE_URL` con el mismo valor que la API, para
  permitir esas imágenes en la política de seguridad de contenido.
- Antes de salir a producción, conviene una prueba de penetración externa y
  una revisión legal de los textos y plazos de la Ley 21.719.

## Actualizar a la versión con idiomas (fase 11)

`deploy.sh` aplica solo las migraciones nuevas (idioma de cada usuario y traducciones del
contenido). Después, si usa los datos de ejemplo, complete sus traducciones:

```bash
dc run --rm backend python -m app.cli seed-demo
```

No pisa nada que su equipo haya cambiado. El contenido propio se traduce desde el panel
(sección **Traducciones** de cada servicio, recargo y diapositiva). Ver `docs/I18N.md`.

## Actualizar a la fase 12 (comprobante en PDF, pie de página y redes)

La imagen del backend ahora instala las tipografías del comprobante: hay que reconstruirla
(`deploy.sh` lo hace). Después, complete **Administración → Sitio y contacto** con los datos
de su empresa: aparecen en el pie de página y en los comprobantes.
