# Sitio de demostración

Para mostrar la plataforma a un cliente antes de salir en vivo. En un servidor nuevo, un
solo comando deja el sitio publicado con HTTPS, datos de ejemplo y un administrador.

| | Demo | Producción (`DEPLOYMENT.md`) |
|---|---|---|
| Dirección | `<ip-con-guiones>.sslip.io` (sin comprar dominio) | Dominio propio |
| Pagos | Simulados: nadie paga de verdad | Webpay |
| Emails | No se envían: quedan en el registro | SMTP |
| Imágenes | Disco del servidor | S3 |
| Buscadores | No indexan el sitio | Normal |

## Pasos

1. Cree un servidor Ubuntu 24.04 (2 vCPU, 4 GB de RAM), por ejemplo en Vultr, ubicación
   Santiago. Anote la IP y la contraseña de `root`.
2. Desde su computador, suba el zip y conéctese:

   ```bash
   scp limousine-platform-v20.zip root@IP:/root/
   ssh root@IP
   ```

3. En el servidor:

   ```bash
   apt-get update && apt-get install -y unzip
   unzip limousine-platform-v20.zip && cd limousine-platform/infrastructure
   sudo bash scripts/demo-setup.sh
   ```

   Pregunta la dirección (Enter acepta la propuesta), su email, el nombre de la empresa y
   el email del administrador, y luego la contraseña del administrador.

## Operación

```bash
cd ~/limousine-platform/infrastructure
dc() { docker compose --env-file .env.production -f docker-compose.prod.yml -f docker-compose.demo.yml "$@"; }
dc ps                         # estado
dc logs --tail=100 backend    # registro (aquí aparecen los emails, p. ej. recuperar contraseña)
./scripts/deploy.sh           # actualizar tras subir una versión nueva
```

## Al terminar la demo

- Para pasar a producción: dominio propio, `DEMO_MODE` eliminado, `ENVIRONMENT=production`,
  Webpay, S3 y SMTP según `DEPLOYMENT.md` y `GO_LIVE.md`.
- Si no se usará más, elimine el servidor en el panel del proveedor (se deja de pagar).
