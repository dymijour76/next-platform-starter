# Publicar en Netlify + Render + Cloudflare R2

Netlify sólo ejecuta el sitio (Next.js). El resto va en otros servicios, todos con plan
gratuito:

| Parte | Servicio | Archivo |
|---|---|---|
| Código | GitHub (repositorio privado) | — |
| Sitio | Netlify | `netlify.toml` |
| API + worker, PostgreSQL, Redis | Render | `render.yaml`, `backend/start-render.sh` |
| Imágenes | Cloudflare R2 | — |

Modo demostración: pagos simulados, emails en el registro de Render (no se envían).

## 1. GitHub

1. Cree una cuenta en github.com e instale **GitHub Desktop**.
2. Descomprima el zip en una carpeta nueva (no use la carpeta donde trabaja con Docker:
   tiene su `.env`).
3. GitHub Desktop → *File → Add local repository* → elija la carpeta
   `limousine-platform` → *create a repository* → *Create repository*.
4. *Publish repository*, con **Keep this code private** marcado.

## 2. Cloudflare R2 (imágenes)

1. Cree una cuenta en cloudflare.com → **R2 Object Storage** (puede pedir una tarjeta
   aunque el plan gratuito no cobre).
2. *Create bucket*: `lubin-media`.
3. En el bucket → *Settings → Public access → R2.dev subdomain → Allow*. Copie la URL
   `https://pub-….r2.dev`: es **MEDIA_BASE_URL**.
4. R2 → *Manage API tokens* → *Create API token*, permiso **Object Read & Write**, sólo
   para `lubin-media`. Copie **Access Key ID**, **Secret Access Key** y el endpoint
   `https://<id-de-cuenta>.r2.cloudflarestorage.com`.

## 3. Render (API, base de datos y Redis)

1. Cree una cuenta en render.com **con su cuenta de GitHub**.
2. *New → Blueprint* → elija el repositorio. Render lee `render.yaml` y pide:

   | Variable | Valor |
   |---|---|
   | `S3_BUCKET` | `lubin-media` |
   | `S3_ENDPOINT_URL` | el endpoint de R2 |
   | `S3_ACCESS_KEY` / `S3_SECRET_KEY` | las claves de R2 |
   | `MEDIA_BASE_URL` | `https://pub-….r2.dev` |
   | `FRONTEND_URL` | `https://lubin-vip-limo.netlify.app` (el nombre que usará en Netlify) |
   | `ADMIN_EMAIL` / `ADMIN_PASSWORD` | su administrador (contraseña de 12+ caracteres) |

3. *Apply*. La primera vez tarda unos 10 minutos.
4. Anote la dirección del servicio `lubin-api` (p. ej. `https://lubin-api.onrender.com`)
   y, en *Environment*, el valor de **INTERNAL_PROXY_SECRET**.

## 4. Netlify (sitio)

1. Cree una cuenta en netlify.com **con su cuenta de GitHub**.
2. *Add new project → Import an existing project → GitHub* → el repositorio.
   Netlify lee `netlify.toml` (carpeta `frontend`). Nombre del proyecto: `lubin-vip-limo`.
3. Antes de publicar, en *Environment variables* agregue:

   | Variable | Valor |
   |---|---|
   | `API_INTERNAL_URL` | la dirección de Render |
   | `INTERNAL_PROXY_SECRET` | el mismo valor que en Render |
   | `MEDIA_BASE_URL` | el mismo valor que en Render |
   | `NEXT_PUBLIC_COMPANY_NAME` | `Lubin VIP Limo` |
   | `CLIENT_IP_HEADER` | `x-nf-client-connection-ip` |
   | `API_TIMEOUT_MS` | `9000` |

4. *Deploy*. Si el nombre final no es el que puso en `FRONTEND_URL`, corríjalo en Render.

## 5. Primer ingreso

Entre a `https://lubin-vip-limo.netlify.app/admin` con su administrador. Después, en Render,
borre `ADMIN_PASSWORD` (si no, la contraseña se repone en cada reinicio).

Cada cambio publicado en GitHub (*Push origin* en GitHub Desktop) actualiza Render y
Netlify solos.

## Limitaciones del plan gratuito

- **La base de datos gratuita de Render vence a los 30 días.** Antes, pásela a un plan
  pagado de Render o a Neon (cambie `DATABASE_URL`; la API acepta la URL tal como la
  entrega el proveedor).
- Render duerme la API tras 15 minutos sin visitas; la función `keep-awake` de Netlify la
  visita cada 10 minutos. Si aun así está dormida, la primera página puede fallar: recargue.
- Emails: Render bloquea el envío por SMTP en el plan gratuito. Se ven en *Logs* del
  servicio (p. ej. el enlace para recuperar la contraseña).
- Imágenes de hasta unos 5 MB (límite de envío de Netlify).
- Para salir en vivo: plan pagado, Webpay, SMTP y dominio propio (`GO_LIVE.md`).
