# Guía de administración

Se amplía en cada fase. Esta versión cubre usuarios y permisos (Fase 2).

## Acceso

Ingrese con su cuenta en `/login` y pulse **Administración** en la cabecera.
El menú lateral muestra sólo las secciones que su perfil permite.

## Invitar a una persona del personal

1. *Usuarios* → **Invitar usuario**.
2. Complete nombre, email y, opcionalmente, teléfono.
3. Marque uno o más roles. Los roles con permisos que usted no tiene aparecen
   deshabilitados.
4. **Enviar invitación.** La persona recibe un email con un enlace para crear
   su contraseña, válido por 72 horas. Si vence, puede usar *Olvidé mi
   contraseña* en la pantalla de acceso con el mismo email.

Los clientes no se invitan: crean su propia cuenta en `/register`.

## Modificar o suspender una cuenta

En *Usuarios*, busque por nombre, email o teléfono, o filtre por rol y estado.
En la ficha de la persona puede cambiar sus datos, su estado y sus roles.

| Estado | Efecto |
|---|---|
| Activa | Puede ingresar normalmente |
| Inactiva | No puede ingresar (p. ej., dejó la empresa) |
| Suspendida | No puede ingresar ni recuperar la contraseña (bloqueo) |

Al pasar una cuenta a inactiva o suspendida, todas sus sesiones abiertas se
cierran de inmediato. Los cambios de roles también rigen al instante.

**Limitaciones intencionales:** no puede cambiar su propio estado ni sus roles
(pídaselo a otro administrador); no puede modificar a alguien con más permisos
que usted; y el sistema impide dejar la plataforma sin ningún administrador
general activo.

## Roles

| Rol | Puede |
|---|---|
| Administrador general | Todo. Sus permisos no se pueden reducir |
| Administrador de reservas | Gestionar reservas y asignaciones; ver clientes, servicios, vehículos y conductores |
| Administrador financiero | Ver pagos, reembolsos y reportes financieros |
| Conductor | Usar el panel del conductor (Fase 6) |
| Cliente | Reservar y gestionar sus propias reservas |

En *Roles y permisos* puede crear roles propios (por ejemplo, "Despacho
nocturno") combinando permisos, y editar los permisos de los roles del sistema
salvo el administrador general. Un rol del sistema, o uno con personas
asignadas, no se puede eliminar.

Todas estas acciones quedan en el registro de auditoría.

## Servicios

*Administración → Servicios* muestra el catálogo con su valor hora, mínimo de
horas y el precio "desde" que ve el cliente. En cada servicio se editan:

- **Presentación:** nombre, dirección web (`/services/premium`), frase breve,
  descripción y lo que incluye (uno por línea).
- **Capacidad** y **orden** en el catálogo.
- **Tarifa:** valor hora, tarifa de salida (monto fijo por reserva), mínimo y
  máximo de horas, y precio mínimo. Todos los montos con IVA incluido. Cambiar
  la tarifa requiere el permiso de precios.
- **Activo:** un servicio inactivo desaparece del sitio y no se puede reservar.
  Los servicios no se eliminan, para conservar el historial de reservas.

## Precios

*Administración → Precios* reúne tres herramientas.

**Reglas.** Recargos o descuentos, en porcentaje o monto fijo, que se aplican
cuando se cumplen todas sus condiciones: días de la semana, franja horaria
(puede cruzar la medianoche, como 22:00 a 06:00), rango de fechas (feriados,
temporada alta), servicios y duración mínima. Lo que se deja en blanco no
restringe. Todo se evalúa con la fecha y hora de **recogida**.

Cómo se combinan: los porcentajes se calculan todos sobre la tarifa y se suman.
Un recargo nocturno de 20 % y uno de fin de semana de 10 % suman 30 % de la
tarifa. Después se aplica el precio mínimo del servicio.

Para pausar una regla, desmárquela como activa. Eliminarla no afecta a reservas
ya hechas: cada reserva guarda su propio cálculo.

**Simulador.** Calcula el precio de cualquier servicio, fecha, hora y duración,
incluso de servicios inactivos o fechas pasadas. Úselo para comprobar una regla
antes de activarla.

**Configuración.** Moneda, zona horaria, impuesto y si los precios lo incluyen,
tramo de cobro (15, 30 o 60 minutos), anticipación mínima para reservar y hasta
cuántos días adelante se puede reservar.

## Reservas

*Administración → Reservas* lista las reservas por fecha de recogida. Puede
buscar por código, nombre, email o teléfono, y filtrar por estado, servicio y
fechas.

| Estado | Significa |
|---|---|
| Pendiente de pago | Recién hecha; el cupo queda retenido 30 minutos |
| Confirmada | Pagada o confirmada por el personal |
| Completada | El servicio se realizó |
| No se presentó | El cliente no llegó a la recogida |
| Cancelada | Por el cliente o por la empresa |
| Vencida | No se confirmó a tiempo; el cupo se liberó solo |

En la ficha de cada reserva:

- **Confirmar reserva** (pendientes): úselo cuando el pago llegó por otro medio,
  por ejemplo transferencia. Anote el detalle en la nota. Si el cupo retenido
  ya había vencido y otra reserva tomó el horario, el sistema no la confirma.
- **Marcar completada / No se presentó**: disponibles después de la hora de
  recogida.
- **Cancelar reserva**: requiere un motivo, que se incluye en el email al
  cliente. Si la empresa cancela, se devuelve el total, salvo que marque
  "Aplicar la política de cancelación". El monto a devolver queda registrado en
  la reserva; el reembolso en sí se gestiona con el pago en línea (Fase 5).
- **Historial**: cada cambio de estado con fecha, autor y nota.

El cliente recibe un email al reservar, al confirmarse, al cancelarse y al
vencerse la reserva.

**Capacidad.** Cada vehículo activo de un servicio permite una reserva
simultánea de ese servicio. Un servicio sin vehículos no se puede reservar (la
lista de servicios lo advierte en rojo).

**Política y plazos** (enlace en la lista de reservas; modificar requiere el
permiso de configuración): minutos de cupo retenido, preparación entre viajes,
horas de cancelación sin costo y porcentaje que se devuelve fuera de plazo.
Rigen para reservas nuevas; cada reserva conserva la política que aceptó el
cliente.

## Pagos

Los clientes pagan en línea al reservar. En la ficha de cada reserva, la sección
**Pagos** muestra cada cobro (tarjeta, autorización, fecha) y sus reembolsos.

- **Cancelaciones:** al cancelar una reserva pagada, el reembolso que
  corresponde se hace solo, por la misma pasarela.
- **Reembolso manual** (permiso de reembolsos): total o parcial, con motivo;
  por ejemplo, una compensación. Queda en la auditoría.
- **Reembolso fallido:** si la pasarela no respondió, aparece en rojo con el
  botón **Reintentar reembolso**.
- **Confirmar sin pago en línea:** sólo si el cliente pagó por otro medio
  (transferencia). En ese caso los reembolsos se gestionan fuera del sistema.

*Administración → Pagos* (finanzas y administración general) lista los cobros
con filtros por estado, fechas y búsqueda por reserva, orden de compra o
autorización, y muestra cobrado, reembolsado y neto del período filtrado.

## Vehículos

*Administración → Vehículos*: patente, servicio al que pertenece, marca, modelo,
año, color, pasajeros y estado (activo, fuera de servicio, dado de baja). La
patente se escribe como quiera (`bcdf-12`) y se guarda normalizada (`BCDF12`).

**Mantenciones:** en la ficha del vehículo, registre el periodo y el motivo.
Durante ese tiempo el vehículo no cuenta para reservar ni se puede asignar. El
sistema no permite programar una mantención encima de viajes ya asignados, ni
desactivar un vehículo con viajes pendientes: reasígnelos primero.

## Conductores

*Administración → Conductores*: al registrar un conductor con un email nuevo, se
le crea una cuenta y recibe un email para crear su contraseña; si el email ya
tiene cuenta, se le agrega el rol de conductor. Registre la clase y el
vencimiento de la licencia: con la licencia vencida no se le pueden asignar
viajes, y la lista la marca en rojo.

## Asignar vehículo y conductor

En la ficha de una reserva **confirmada**, sección *Vehículo y conductor*, elija
ambos. Las opciones no disponibles aparecen deshabilitadas con el motivo (en
mantención, capacidad insuficiente, licencia vencida, ocupado en otra reserva).
Al completar la asignación, el cliente recibe el nombre del chófer y el vehículo,
y el conductor, los datos del viaje.

Para despachar, en *Reservas* marque **Sólo confirmadas sin vehículo o
conductor**; la columna *Asignación* muestra lo que falta.

## Panel del conductor

El conductor entra con su email en `/login` y llega a **Mis viajes**. En cada
viaje ve la dirección (con enlace al mapa), el pasajero con botón para llamar,
las indicaciones y el vehículo, y avanza con botones grandes:

1. **Salir hacia la recogida** (desde 12 horas antes): avisa al cliente por email.
2. **Llegué al punto de recogida.**
3. **Escanear QR del pasajero** con la cámara del teléfono. Si no funciona,
   **Confirmar abordaje sin QR** tras verificar el nombre; queda registrado.
4. **Terminar viaje.**

Si el pasajero no llega, después de la hora de recogida aparece **El pasajero no
se presentó**. Todo queda en el historial de la reserva.

## Contenido: carrusel y fotografías

*Administración → Contenido* (permiso de contenido).

**Biblioteca de imágenes.** Suba fotos JPG, PNG o WebP de hasta 10 MB con una
descripción de lo que se ve (la leen los lectores de pantalla y los buscadores;
es obligatoria). El sistema quita los datos de ubicación de las fotos, las
endereza y genera versiones livianas para cada pantalla. Una imagen en uso no
se puede eliminar: quítela antes del carrusel o del servicio.

**Carrusel de la portada.** Cada diapositiva tiene una imagen (idealmente
horizontal, de 1600 px de ancho o más), un título, un texto opcional y un botón
opcional con su enlace (una página del sitio como `/services/premium` o una
dirección `https://`). Puede programarla con fechas de inicio y término, por
ejemplo para una campaña; la lista indica si está *En la portada*,
*Programada*, *Terminada* o *Inactiva*. Ordénelas con las flechas. Se muestran
hasta 8; sin diapositivas, la portada muestra un texto de bienvenida.

**Fotografías de un servicio.** En la ficha del servicio (*Servicios*), sección
*Fotografías*: marque las imágenes que se muestran y su orden; la número 1 es la
portada del servicio en la página de inicio y en el catálogo. Sin fotografías,
el servicio se muestra con una portada tipográfica.

## Inicio del panel

Al entrar a *Administración* verá los indicadores de su área:

- **Requiere atención:** viajes de las próximas 48 horas sin vehículo o
  conductor, reembolsos fallidos, servicios sin vehículos y licencias vencidas
  o por vencer. Cada aviso lleva a donde se resuelve.
- **Operación:** viajes de hoy (con conductor y estado), próximos 7 días, sin
  asignar y pendientes de pago.
- **Este mes:** ingresos netos (con la variación respecto del mismo tramo del
  mes anterior), cobrado, reembolsado y ticket promedio.
- **Flota:** vehículos activos, en mantención ahora y conductores activos.

## Reportes

*Administración → Reportes* (permisos de reportes operativos o financieros).

- **Reservas:** por estado y por servicio, con la tasa de cancelación. Elija si
  cuentan por *fecha del viaje* (lo realizado) o por *fecha de la reserva* (lo
  vendido en el periodo).
- **Ingresos:** cobrado, reembolsado y neto por periodo y por servicio, con IVA
  incluido. Los cobros cuentan en la fecha del pago y los reembolsos en la fecha
  en que se hicieron.

Elija el rango y si agrupar por día, semana o mes. **Descargar CSV** baja la
tabla del periodo lista para abrir en Excel.

## Verificación en dos pasos

Cada persona la activa en *Mi cuenta → Seguridad*: escanea un código con una
aplicación de autenticación (Google Authenticator, Microsoft Authenticator,
1Password…) y recibe 10 códigos de respaldo para cuando no tenga el teléfono.

Si la empresa la exige al personal (`REQUIRE_STAFF_MFA=true`), quien no la
tenga activa será enviado a activarla al entrar al panel.

**Si alguien pierde el teléfono y sus códigos:** en *Usuarios*, abra su ficha y
pulse **Restablecer verificación en dos pasos**. Se cierran sus sesiones y
deberá configurarla de nuevo. Nadie puede restablecer la propia.

## Cuentas bloqueadas

Tras varios intentos fallidos de contraseña, la cuenta espera unos minutos
antes de aceptar otro intento (1, 15 o 60 minutos), y su titular recibe un
aviso por email. Recuperar la contraseña la desbloquea de inmediato.

## Idiomas

El panel, como todo el sitio, está en español, inglés, francés, creole haitiano y chino. Cada
persona elige su idioma con el selector 🌐 de la cabecera.

**Traducir el contenido:** al editar un servicio, una regla de precio o una diapositiva del
carrusel, abra la sección **Traducciones**. Cada idioma indica si está *Completo*, *Parcial* o
*Sin traducir*. Lo que quede vacío se muestra en español a quien navegue en ese idioma.

Los datos que escriben las personas (nombres, direcciones, notas, el color de un vehículo) se
muestran tal como se escribieron.

## Sitio y contacto

En **Administración → Sitio y contacto** (permiso de configuración general) se editan los
datos que aparecen en el **pie de todas las páginas** y en el **encabezado de los
comprobantes en PDF**:

- Nombre comercial, razón social y RUT de la empresa.
- Descripción breve y horario de atención (se pueden traducir en la sección **Traducciones**).
- Dirección, teléfono, email y WhatsApp. Con un número de WhatsApp, el pie muestra un enlace
  para escribir directamente.
- Redes sociales: la dirección completa de cada perfil, empezando por `https://`. Las que se
  dejen vacías no se muestran.

## Comprobantes

Cada reserva tiene los botones **Descargar comprobante (PDF)** e **Imprimir comprobante**, en
la cuenta del cliente y en el panel. El comprobante sale en el idioma de quien lo descarga e
incluye los datos de la empresa, del viaje, el desglose, los pagos y la política de
cancelación. **No es una boleta ni factura electrónica** y lo dice expresamente: la boleta del
SII se emite por separado.

## Reseñas

Al completarse un viaje, el cliente recibe un email para calificar el **servicio** y al
**chófer** (de 1 a 5 estrellas) y dejar un comentario, durante 30 días. Sólo puede calificar
quien hizo el viaje, una vez por reserva.

En **Administración → Reseñas** (permiso de contenido) aparecen primero las que esperan revisión:

- **Publicar** muestra el comentario en la portada y en la página del servicio, con el nombre
  abreviado del cliente ("Valentina M."). Sólo se puede publicar si el cliente lo autorizó.
- **Ocultar** se usa **sólo** para comentarios ofensivos o con datos personales, **no para
  los negativos**. Aunque se oculte el comentario, sus estrellas siguen contando en el
  promedio: si el promedio sólo incluyera las opiniones favorables, engañaría a los clientes.

La calificación de cada **chófer** aparece en su ficha (Conductores) y sólo la ve el personal.

## Billetera

Cada cliente tiene una **billetera** con saldo a favor, que usa para pagar reservas («Pagar con
mi saldo», cuando le alcanza para el total).

**De dónde viene el saldo:**

- **Créditos que otorga su equipo** (por ejemplo, una compensación), desde la ficha del cliente
  en **Usuarios**. El motivo es obligatorio: lo ve el cliente en sus movimientos y queda en la
  auditoría con el nombre de quien lo otorgó. Sólo pueden otorgarlo los perfiles con permiso
  para emitir reembolsos (de fábrica, el administrador general); el administrador financiero
  puede **ver** la billetera, no otorgar crédito.
- **Reembolsos** de reservas pagadas con saldo: vuelven al saldo automáticamente.
- **Recargas con tarjeta**: construidas pero **desactivadas** (ver abajo).

**Garantías:** cada movimiento queda registrado y **no se puede modificar ni borrar** (lo impide
la base de datos); el saldo nunca queda negativo y dos pagos simultáneos no pueden gastar el
mismo saldo. Un cliente con saldo no puede eliminar su cuenta hasta usarlo o pedir que se le
devuelva.

**Cómo se cuenta en pagos y reportes:**

- En **Pagos**, «Cobrado» es el dinero que pasó por la pasarela (tarjetas y recargas). Los pagos
  con saldo aparecen en la lista pero no suman al cobrado: ese dinero ya entró al recargarse (o
  nunca entró, si fue un crédito de la empresa).
- En **Reportes**, las ventas son las reservas pagadas (con tarjeta o con saldo). Las recargas no
  son ventas: son saldo que la empresa le debe al cliente hasta que lo use.

### Activar la recarga con dinero

Guardar dinero de clientes para pagos futuros puede quedar regulado como medio de pago con
provisión de fondos (Ley 20.950, supervisado por la CMF). **Antes de activarla, confírmelo con un
abogado.** Luego, en el `.env`: `WALLET_TOPUP_ENABLED=true` (y, si quiere, `WALLET_TOPUP_MIN` y
`WALLET_TOPUP_MAX`). La recarga usa la misma pasarela que las reservas; una recarga se puede
devolver desde **Pagos** sólo si el cliente aún tiene ese saldo.

## Mensajes entre cliente y chófer

Cuando una reserva tiene chófer asignado, el cliente y el chófer pueden escribirse desde la
reserva y desde el panel del conductor. La conversación queda abierta durante el viaje y hasta
**2 horas después** del término; luego se puede leer, pero no escribir. Si la reserva se cancela,
se cierra.

Cada uno recibe un aviso por email (en su idioma) cuando le llega un mensaje que no ha leído; un
solo aviso por racha de mensajes, sin el texto del mensaje.

En el detalle de la reserva del panel, su equipo puede **leer** la conversación (para resolver un
reclamo o coordinar), pero no escribir ni marcarla como leída.

### Número de billetera

Cada billetera tiene un número único con aspecto de tarjeta, por ejemplo `LP-4821-7730`. El último
dígito es de verificación: si alguien dicta o copia mal un número, el sistema lo detecta en vez de
encontrar la billetera de otra persona. En **Usuarios** puede buscar a un cliente por ese número,
con o sin guiones. No es una tarjeta bancaria ni sirve para pagar fuera de su sitio.

## Monedas

Los precios se cobran **siempre en pesos chilenos** (Webpay cobra en pesos y la ley exige informar
los precios en moneda nacional). Los visitantes pueden elegir dólar, euro o real brasileño con el
selector de la cabecera, y verán al lado de los precios en pesos un **valor aproximado** ("aprox.
USD 311").

En **Administración → Monedas** (permiso de configuración general):

- Las **tasas automáticas** se actualizan una vez al día desde ExchangeRate-API (acceso abierto, con
  atribución). Una tasa absurda de la fuente se descarta y queda la anterior. **Actualizar ahora**
  las pide sin esperar.
- Puede **fijar una tasa a mano** (pesos por 1 unidad): tiene prioridad sobre la automática hasta
  que pulse **Usar la automática**. Se acepta "1.030,50" o "1030.50". Una tasa fuera del rango
  razonable de esa moneda se rechaza, para que un error de tipeo no muestre precios absurdos.
- Cada cambio queda en la auditoría. Si no hay ninguna tasa, el selector de moneda no aparece.

## Precios de los servicios

Cada servicio (Standard, Professional, Premium…) tiene su tarifa en **Administración → Servicios**:
abra el servicio y edite la sección **Tarifa**:

- **Valor hora** y **tarifa de salida** (monto fijo por reserva; 0 si no aplica).
- **Mínimo y máximo de horas**, y **precio mínimo** (si el cálculo queda por debajo, se cobra ese monto).

El precio final es tarifa de salida + horas × valor hora, más los recargos o descuentos de
**Administración → Precios** (por ejemplo, nocturno o fin de semana). Los montos incluyen IVA.
Los cambios rigen para las cotizaciones y reservas nuevas; las reservas hechas conservan su
precio. Use el **Simulador** de Precios para probar un precio antes de publicarlo.

## Código de verificación del chófer

Cuando una reserva tiene chófer asignado, el pasajero ve en su reserva un **código de 4 dígitos**
y el chófer ve el mismo código en su viaje. Al llegar, el pasajero le pide el código: si no
coincide, no sube. Si se cambia el chófer, el código cambia. Funciona sin cámara ni conexión. El
chófer, a su vez, verifica al pasajero escaneando el QR de su reserva (o "Confirmar abordaje sin QR").

Redes sociales disponibles en **Sitio y contacto**: Instagram, Facebook, TikTok, YouTube, X, Threads,
LinkedIn, Pinterest, Snapchat, Telegram, Tripadvisor y Google (perfil de empresa).
