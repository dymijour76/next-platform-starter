# Guía de usuario

Se amplía en cada fase. Esta versión cubre la cuenta de cliente (Fase 2).

## Crear una cuenta

En **Crear cuenta** ingrese su nombre, email y una contraseña de al menos 10
caracteres. Una frase de varias palabras es más segura y fácil de recordar que
una palabra con símbolos. Recibirá un email para confirmar su dirección: abra
el enlace y pulse **Confirmar mi email**.

## Mi cuenta

- **Resumen:** sus datos principales y avisos pendientes.
- **Mi perfil:** nombre, teléfono, dirección y datos de facturación. Si
  necesita factura a nombre de una empresa, ingrese su RUT, razón social y
  giro; el RUT se valida automáticamente.
- **Seguridad:** cambiar la contraseña, cambiar el email de acceso y cerrar la
  sesión en todos sus dispositivos.

## Olvidé mi contraseña

En la pantalla de acceso pulse **Olvidé mi contraseña** e ingrese su email.
Recibirá un enlace válido por 60 minutos. Al crear la nueva contraseña, se
cierra la sesión en todos sus dispositivos.

## Su sesión

Su sesión se mantiene abierta hasta 30 días en el mismo navegador. Si usó un
computador compartido, pulse **Cerrar sesión**, o use *Seguridad → Cerrar
sesión en todos los dispositivos*.

## Servicios y precios

En **Servicios** verá cada opción con su capacidad y el precio desde el que
parte. En la página de cada servicio, elija fecha, hora de recogida y duración,
y pulse **Calcular precio**. Verá el desglose completo: tarifa, horas y los
recargos o descuentos que correspondan (por ejemplo, horario nocturno o fin de
semana). El precio final incluye IVA.

El precio es referencial hasta confirmar la reserva, que se habilitará en la
próxima etapa.

## Reservar

1. Pulse **Reservar** (o **Reservar este servicio** en la página de un servicio).
   Si no ha iniciado sesión, se le pedirá y volverá a la reserva.
2. Elija servicio, fecha, hora de recogida y duración, y pulse **Ver precio y
   disponibilidad**. Verá el precio final con IVA.
3. Complete la dirección de recogida, el destino (opcional si contrata por
   horas), la cantidad de pasajeros y los datos del pasajero de contacto, que
   puede ser otra persona. Acepte la política de cancelación y pulse **Reservar**.

Al pulsar **Reservar y pagar** irá a la pasarela de pago segura. Al volver,
verá el resultado: si el pago se aprobó, la reserva queda confirmada y recibirá
un email con el comprobante (tarjeta y código de autorización).

Si el pago fue rechazado o salió de la pasarela sin pagar, la reserva queda
**pendiente de pago** con el cupo retenido por un tiempo: puede pagar desde
*Mis reservas* con **Pagar ahora**. Si no se paga a tiempo, vence sola y no se
cobra nada.

## Mis reservas

En *Mi cuenta → Mis reservas* verá sus reservas próximas y su historial. En
cada una puede ver el detalle y el precio.

**Cancelar.** Mientras falte para la hora de recogida, puede cancelar desde la
reserva. Antes de confirmar la cancelación verá cuánto se le devolverá según la
política que aceptó (por defecto, sin costo hasta 24 horas antes). Recibirá la
confirmación por email. El reembolso se hace al mismo medio de pago; el plazo
en que aparece en su cuenta depende de su banco.

## El día del viaje

Cuando la reserva tenga chófer asignado, recibirá un email con su nombre y el
vehículo, y en *Mis reservas* verá la sección **Su viaje** con un **código QR**.
Muéstrelo al chófer al subir: así queda registrado su abordaje. Le avisaremos
por email cuando el chófer vaya en camino, y el estado de la reserva mostrará
cuando esté en el punto de recogida.

## Verificación en dos pasos

En *Mi cuenta → Seguridad* puede activar una protección adicional: además de
la contraseña, le pediremos un código de una aplicación de su teléfono. Guarde
los códigos de respaldo que le mostramos: le permiten entrar si pierde el
teléfono.

## Sus datos

En *Mi cuenta → Mis datos* puede descargar toda la información de su cuenta y,
si lo desea, eliminarla. Al eliminarla borramos su nombre, email, teléfono,
direcciones y datos de facturación. Conservamos sin sus datos personales el
registro de las reservas pagadas, que la ley tributaria nos obliga a guardar.

## Idioma

El sitio está en español, English, Français, Kreyòl ayisyen y 中文. Elija su idioma con el
símbolo 🌐 de la parte superior. Si tiene cuenta, lo recordamos, y sus emails le llegan en ese
idioma.

## Comprobante de su reserva

En **Mi cuenta → Mis reservas**, abra la reserva y use **Descargar comprobante (PDF)** para
guardarlo o **Imprimir comprobante** para abrirlo e imprimirlo. Sale en el idioma que tenga
elegido en el sitio.

## Calificar su viaje

Después del viaje le enviaremos un email para que nos cuente cómo le fue. También puede
hacerlo en **Mi cuenta → Mis reservas**, en la reserva completada, durante 30 días. Si autoriza
publicar su comentario, aparecerá en el sitio con su nombre abreviado después de una revisión.

## Mi billetera

En **Mi cuenta → Mi billetera** ve su saldo a favor y cada movimiento: créditos, pagos y
reembolsos. Al pagar una reserva, si su saldo alcanza para el total, aparece **Pagar con mi
saldo**. Si cancela una reserva pagada con saldo, el reembolso vuelve a su billetera.

## Mensajes con su chófer

Cuando asignemos su chófer, en el detalle de su reserva aparece **Mensajes con su chófer** para
coordinar el encuentro (por ejemplo, la puerta o el equipaje). Le avisamos por email si le
responde. Puede escribir hasta 2 horas después del viaje.

Su billetera aparece como una tarjeta con su nombre, su número único (por ejemplo,
`LP-4821-7730`) y su saldo. Ese número identifica su billetera en nuestro sitio; no es una tarjeta
bancaria. Si nos escribe por un saldo, puede indicarnos ese número.

## Moneda

Con el selector de moneda de la parte superior (CLP, USD, EUR o BRL) verá, junto a cada precio en
pesos, un valor aproximado en la moneda elegida. Se cobra siempre en pesos chilenos.

## Comprobar a su chófer

Cuando le asignemos un chófer, verá en su reserva un **código de 4 dígitos**. Al llegar, pídale al
chófer que le diga su código: si no es el mismo, no suba y llámenos.
