# API

Base: `/api/v1`. En desarrollo, la especificación OpenAPI completa está en
http://localhost:8000/docs.

## Convenciones

**Autenticación.** `Authorization: Bearer <access_token>`. El token de acceso
dura 15 minutos; se renueva con el refresh token en `POST /auth/refresh`.

**Errores.** Siempre con la misma forma. `code` es estable (los clientes deciden
con él); `message` está en español y se puede mostrar al usuario; `fields`
aparece en errores de validación:

```json
{"error": {"code": "VALIDATION_ERROR", "message": "Revise los datos ingresados.",
           "fields": {"password": "La contraseña debe tener al menos 10 caracteres."}}}
```

Códigos frecuentes: `NOT_AUTHENTICATED`, `TOKEN_INVALID`, `TOKEN_REVOKED` (401);
`PERMISSION_DENIED`, `PRIVILEGE_ESCALATION`, `SELF_MODIFICATION`,
`ACCOUNT_DISABLED`, `EMAIL_NOT_VERIFIED` (403); `NOT_FOUND` (404); `EMAIL_TAKEN`,
`LAST_SUPER_ADMIN`, `ROLE_PROTECTED`, `ROLE_IN_USE` (409); `VALIDATION_ERROR`
(422); `RATE_LIMITED` (429, con cabecera `Retry-After`).

**Paginación.** `?page=1&page_size=20` (máximo 100). Respuesta:
`{"items": [...], "total": 0, "page": 1, "page_size": 20}`.

Todas las respuestas incluyen `X-Request-ID`.

## Salud

| Método | Ruta | Respuesta |
|---|---|---|
| GET | `/health/live` | `200` si el proceso responde |
| GET | `/health/ready` | `200` si base de datos y Redis responden; `503` si alguno falla |

## Autenticación

| Método | Ruta | Auth | Descripción | Límite |
|---|---|---|---|---|
| POST | `/auth/register` | — | Crea una cuenta de cliente y envía el email de verificación. `201` con el usuario | 5/h por IP |
| POST | `/auth/login` | — | `{email, password}` → par de tokens | 10/15 min por IP+email; 50/15 min por IP |
| POST | `/auth/refresh` | — | `{refresh_token}` → par nuevo (el anterior queda invalidado) | 120/5 min por IP |
| POST | `/auth/logout` | — | `{refresh_token}` → cierra esa sesión. `204` | |
| POST | `/auth/logout-all` | ✓ | Cierra todas las sesiones del usuario. `204` | |
| POST | `/auth/forgot-password` | — | `{email}` → `202` siempre (no revela si existe) | 10/h por IP; 3/h por email |
| POST | `/auth/reset-password` | — | `{token, password, password_confirmation}` → `204` | 20/h por IP |
| POST | `/auth/verify-email` | — | `{token}` → `204` | 20/h por IP |
| POST | `/auth/resend-verification` | ✓ | Reenvía el enlace si falta verificar. `204` | 3/h por usuario |
| GET | `/auth/me` | ✓ | Usuario actual con roles, permisos y perfil | |

Par de tokens:

```json
{"access_token": "...", "token_type": "bearer", "expires_in": 900,
 "refresh_token": "...", "refresh_expires_in": 2592000}
```

## Perfil propio

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/users/me` | Igual que `/auth/me` |
| PATCH | `/users/me` | Nombre, teléfono, dirección, facturación (RUT validado), preferencias, consentimiento de marketing. Sólo se modifican los campos enviados; `null` borra un dato opcional |
| POST | `/users/me/password` | `{current_password, password, password_confirmation}` → par de tokens nuevo; las demás sesiones se cierran (5/15 min) |
| POST | `/users/me/email` | `{email, current_password}` → el email queda sin verificar; se avisa a la dirección anterior (5/h) |

## Administración

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/users` | `users:read` | Lista paginada. Filtros: `q` (nombre, email, teléfono), `role`, `status` |
| POST | `/users` | `users:write` | Invita a una persona del personal: `{email, first_name, last_name, phone?, roles[]}`. Recibe un enlace de 72 h para crear su contraseña |
| GET | `/users/{id}` | `users:read` | Detalle |
| PATCH | `/users/{id}` | `users:write` | Nombre, teléfono, `status` (`ACTIVE`, `INACTIVE`, `SUSPENDED`), `roles[]` |
| GET | `/permissions` | `roles:read` | Catálogo de permisos |
| GET | `/roles` | `roles:read` | Roles con permisos y cantidad de usuarios |
| POST | `/roles` | `roles:write` | `{code, name, description?, permissions[]}` |
| PUT | `/roles/{id}` | `roles:write` | `{name?, description?, permissions?}` |
| DELETE | `/roles/{id}` | `roles:write` | Sólo roles no del sistema y sin usuarios |

Reglas que aplica la API en administración (ver [Seguridad](SECURITY.md)):
nadie puede otorgar permisos que no tiene ni administrar a alguien con más
permisos que él; nadie cambia su propio estado o roles; siempre debe quedar al
menos un administrador general activo; los permisos de `super_admin` no se editan.

## Servicios (público)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/services` | Servicios activos, ordenados. Incluye `price_from`: lo mínimo que cuesta una reserva antes de recargos |
| GET | `/services/{slug}` | Un servicio activo; `404` si no existe o está inactivo |

Los montos viajan como texto decimal exacto (`"60000"`), nunca como número de coma flotante.

## Precios (público)

| Método | Ruta | Descripción | Límite |
|---|---|---|---|
| GET | `/pricing/config` | Moneda, zona horaria, impuesto, tramo de cobro, anticipación mínima y máxima | |
| POST | `/pricing/quote` | `{service_id, pickup_at, duration_minutes}` → desglose y total | 60/min por IP |

`pickup_at` debe incluir zona horaria (`2026-10-10T23:00:00-03:00`); sin ella la
API responde `422`. El precio se calcula siempre en el servidor: cualquier monto
enviado por el cliente se ignora.

```json
{"service": {"id": "…", "name": "Premium"}, "currency": "CLP",
 "pickup_local": "2026-10-10T23:00:00-03:00", "duration_minutes": 240, "billed_hours": "4",
 "lines": [{"code": "BASE_FARE", "label": "Tarifa de salida", "amount": "40000"},
           {"code": "HOURS", "label": "4 horas × $85.000", "amount": "340000"},
           {"code": "RULE", "label": "Recargo nocturno (20 %)", "amount": "76000"},
           {"code": "RULE", "label": "Recargo fin de semana (10 %)", "amount": "38000"}],
 "total": "494000", "net": "415126", "tax": "78874", "tax_rate": "0.19", "tax_name": "IVA",
 "prices_include_tax": true}
```

Rechazos (`422`, con `fields.pickup_at` o `fields.duration_minutes`):
`PICKUP_TOO_SOON`, `PICKUP_TOO_FAR`, `DURATION_TOO_LONG`.

## Administración de servicios y precios

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/admin/services` | `services:read` | Todos, incluidos los inactivos |
| POST | `/admin/services` | `services:write` + `pricing:write` | Crea un servicio con su tarifa |
| GET | `/admin/services/{id}` | `services:read` | |
| PATCH | `/admin/services/{id}` | `services:write` (+ `pricing:write` si cambia la tarifa) | Sólo modifica lo enviado. Los servicios no se eliminan: se desactivan |
| GET | `/admin/pricing/rules` | `pricing:read` | Recargos y descuentos |
| POST | `/admin/pricing/rules` | `pricing:write` | Crea una regla |
| GET / PUT / DELETE | `/admin/pricing/rules/{id}` | `pricing:read` / `pricing:write` | PUT reemplaza la regla completa |
| POST | `/admin/pricing/simulate` | `pricing:read` | Como `/pricing/quote`, admitiendo servicios inactivos y cualquier fecha |
| GET / PUT | `/admin/pricing/settings` | `pricing:read` / `pricing:write` | Moneda, zona horaria, impuesto, tramos, anticipación |

Regla de precio:

```json
{"name": "Recargo nocturno", "kind": "SURCHARGE", "adjustment_type": "PERCENT", "value": "20",
 "time_from": "22:00", "time_until": "06:00", "days_of_week": null, "valid_from": null,
 "valid_until": null, "service_ids": null, "min_hours": null, "priority": 10, "is_active": true}
```

`kind`: `SURCHARGE` o `DISCOUNT`. `adjustment_type`: `PERCENT` (máximo 100) o
`FIXED`. `days_of_week`: 0 = lunes … 6 = domingo. Las condiciones en `null` no
restringen. `valid_until` está incluido.

## Reservas (cliente)

Requieren sesión. Un cliente sólo accede a sus propias reservas: la de otro
responde `404`, igual que una inexistente.

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/booking/policy` | Política de cancelación vigente y minutos de cupo retenido (público) |
| POST | `/reservations/preview` | `{service_id, pickup_at, duration_minutes}` → `{quote, available, passenger_capacity}` |
| POST | `/reservations` | Crea la reserva (ver abajo). `201`; `200` si se repite la misma `idempotency_key` |
| GET | `/reservations?scope=upcoming\|past` | Próximas (pendientes o confirmadas) o historial |
| GET | `/reservations/{code}` | Detalle, con `can_cancel` y `refund_if_cancelled_now` |
| POST | `/reservations/{code}/cancel` | `{reason?}` |

Crear una reserva:

```json
{"service_id": "…", "pickup_at": "2026-10-07T12:00:00-03:00", "duration_minutes": 180,
 "pickup_address": "Av. Apoquindo 3000, Las Condes", "dropoff_address": null,
 "passenger_count": 4, "contact_name": "Ana Pérez", "contact_email": "ana@example.com",
 "contact_phone": "+56 9 1234 5678", "notes": null,
 "expected_total": "295000", "accept_policy": true,
 "idempotency_key": "2f0c…"}
```

- El precio se recalcula en el servidor. `expected_total` es el total que vio
  el cliente: si no coincide (cambió una regla o una tarifa), la API responde
  `409 PRICE_CHANGED` con el precio nuevo en el mensaje.
- `idempotency_key` (UUID generado por intento) evita reservas duplicadas por
  doble clic o reintentos de red.
- Errores propios: `SLOT_UNAVAILABLE` (409), `TOO_MANY_PASSENGERS` (422),
  `IDEMPOTENCY_CONFLICT` (409), más los de la cotización.

La reserva nace en `PENDING_PAYMENT` con `hold_expires_at` (30 minutos por
defecto). Límite: 10 reservas por hora por usuario.

## Reservas (administración)

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/admin/reservations` | `reservations:read` | Paginado. Filtros: `status`, `service_id`, `date_from`, `date_to` (fechas locales de recogida), `q` (código, nombre, email, teléfono) |
| GET | `/admin/reservations/{id}` | `reservations:read` | Detalle con cliente e historial de estados |
| POST | `/admin/reservations/{id}/confirm` | `reservations:write` | `{note?}`. Si el cupo retenido ya venció, vuelve a comprobar disponibilidad |
| POST | `/admin/reservations/{id}/complete` | `reservations:write` | Sólo después de la hora de recogida |
| POST | `/admin/reservations/{id}/no-show` | `reservations:write` | Sólo después de la hora de recogida |
| POST | `/admin/reservations/{id}/cancel` | `reservations:cancel` | `{reason, apply_policy}`. Por defecto devuelve el total |
| GET / PUT | `/admin/booking/settings` | `reservations:read` / `settings:write` | Cupo retenido, preparación entre viajes, política de cancelación |

Estados y transiciones permitidas (cualquier otra responde `409 INVALID_TRANSITION`):

| Desde | Hacia |
|---|---|
| `PENDING_PAYMENT` | `CONFIRMED`, `CANCELLED`, `EXPIRED` (automático) |
| `CONFIRMED` | `COMPLETED`, `NO_SHOW`, `CANCELLED` |

## Pagos

| Método | Ruta | Auth | Descripción |
|---|---|---|---|
| POST | `/reservations/{code}/pay` | Cliente dueño | Inicia (o reintenta) el pago de una reserva pendiente → `{url, fields}`. El cliente se envía a `url` con un formulario POST con `fields`. Extiende el cupo retenido mientras paga. 10 cada 10 min |
| POST | `/payments/return` | — | Parámetros con que vuelve la pasarela (`token_ws`, `TBK_TOKEN`, `TBK_ORDEN_COMPRA`, `TBK_ID_SESION`) → `{reservation_code, outcome}`. Idempotente |
| GET / POST | `/payments/simulator/{token}` | — | Sólo con `PAYMENT_PROVIDER=simulated`: datos del pago y decisión (`approve`, `reject`, `abort`) |
| GET | `/admin/payments` | `payments:read` | Paginado, con `totals` (`collected`, `refunded`, `net`, `count`). Filtros: `status`, `date_from`, `date_to`, `q`. Sin `status`, oculta los intentos sin movimiento de dinero |
| POST | `/admin/payments/{id}/refund` | `payments:refund` | `{amount, reason}`: reembolso manual total o parcial |
| POST | `/admin/refunds/{id}/retry` | `payments:refund` | Reintenta un reembolso fallido |

`outcome`: `paid`, `rejected`, `aborted`, `error` o `refunded_unavailable` (el
pago se aprobó pero el horario ya no estaba libre: se devolvió el cargo).

Estados de un pago: `CREATED` (en la pasarela), `AUTHORIZED`, `REJECTED`,
`ABORTED`, `EXPIRED` (nunca volvió), `ERROR`, `REFUNDED`, `PARTIALLY_REFUNDED`.

Cancelar una reserva pagada (`/reservations/{code}/cancel` o
`/admin/reservations/{id}/cancel`) devuelve automáticamente por la pasarela el
monto que corresponde según la política. Las respuestas de reserva incluyen
`can_pay` y `payments` (con sus reembolsos).

## Vehículos

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/admin/vehicles?service_id=` | `vehicles:read` | Con sus mantenciones vigentes o futuras |
| POST | `/admin/vehicles` | `vehicles:write` | `{plate, service_id, brand, model, year, color, passenger_capacity, status, notes}`. Patente chilena (`BCDF12` o `AB1234`), se normaliza |
| GET / PUT | `/admin/vehicles/{id}` | `vehicles:read` / `vehicles:write` | No se puede desactivar ni cambiar de servicio un vehículo con viajes asignados (`VEHICLE_IN_USE`) |
| POST | `/admin/vehicles/{id}/blocks` | `vehicles:write` | Mantención `{starts_at, ends_at, reason}`. Rechazada si choca con viajes asignados |
| DELETE | `/admin/vehicles/{id}/blocks/{block_id}` | `vehicles:write` | |

`status`: `ACTIVE`, `INACTIVE` (fuera de servicio), `RETIRED` (dado de baja).
**La capacidad de un servicio es su número de vehículos activos sin mantención en
el horario pedido**; un servicio sin vehículos no se puede reservar. Las
respuestas de `/admin/services` incluyen `vehicle_count`.

## Conductores

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/admin/drivers` | `drivers:read` | Con `license_expired` y `upcoming_trips` |
| POST | `/admin/drivers` | `drivers:write` | `{email, first_name, last_name, phone, license_number, license_class, license_expires_on, status, notes}`. Crea la cuenta e invita si el email no existe; si existe, le agrega el rol de conductor |
| GET / PUT | `/admin/drivers/{id}` | `drivers:read` / `drivers:write` | No se desactiva con viajes asignados (`DRIVER_IN_USE`) |

Clases de licencia: `A1`–`A5`, `B`.

## Asignación

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/admin/reservations/{id}/assignment` | `reservations:assign` | `{vehicles, drivers}`: cada opción con `available` y `reason` (fuera de servicio, en mantención, capacidad, licencia vencida, ocupado en otra reserva) |
| PUT | `/admin/reservations/{id}/assignment` | `reservations:assign` | `{vehicle_id, driver_id}` (cualquiera puede ser `null`). Sólo reservas `CONFIRMED`. Avisa al cliente cuando la asignación queda completa y al conductor asignado |

Errores: `NOT_ASSIGNABLE`, `INVALID_VEHICLE`, `VEHICLE_UNAVAILABLE`,
`DRIVER_UNAVAILABLE`, `ASSIGNMENT_CONFLICT` (otra persona asignó lo mismo a la vez).
`/admin/reservations` acepta `unassigned=true` (confirmadas sin vehículo o conductor).

## Panel del conductor

Permiso `driver_portal:access` y ficha de conductor activa (si no, `DRIVER_INACTIVE`).
El conductor sólo ve sus viajes; de otro responde `404`. No incluye precios ni pagos.

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/driver/trips?scope=upcoming\|past` | Viajes asignados, con `actions` disponibles ahora |
| GET | `/driver/trips/{id}` | Detalle: direcciones, pasajero y teléfono, indicaciones, vehículo |
| POST | `/driver/trips/{id}/status` | `{status: EN_ROUTE \| ARRIVED \| NO_SHOW \| COMPLETED, note?}` |
| POST | `/driver/trips/{id}/board` | `{qr_token}` o `{without_qr: true}` → `IN_PROGRESS` |

Estados del viaje: `CONFIRMED` → `EN_ROUTE` (desde 12 h antes) → `ARRIVED` →
`IN_PROGRESS` (abordaje) → `COMPLETED`. `NO_SHOW` desde `ARRIVED` después de la
hora de recogida. Un QR que no corresponde responde `422 QR_MISMATCH`.

`GET /reservations/{code}` incluye `driver_name`, `vehicle_label`, `boarded_at` y,
sólo para el dueño y mientras el viaje está activo, `qr_token`.

## Contenido

Imágenes, carrusel y galerías requieren `content:write`.

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/content/carousel` | Público: diapositivas activas y dentro de su programación, en orden (máx. 8) |
| GET | `/admin/media` | Biblioteca, con `usage` (en cuántos lugares se usa cada imagen) |
| POST | `/admin/media` | `multipart/form-data`: `file` (JPG, PNG o WebP, hasta `UPLOAD_MAX_MB`) y `alt_text` (obligatorio). 60 por hora |
| PATCH | `/admin/media/{id}` | `{alt_text}` |
| DELETE | `/admin/media/{id}` | `409 MEDIA_IN_USE` si está en el carrusel o en un servicio |
| GET / POST | `/admin/carousel` | Diapositivas `{image_id, title, subtitle, cta_label, cta_url, is_active, starts_at, ends_at}`, con `live` |
| GET / PUT / DELETE | `/admin/carousel/{id}` | |
| PUT | `/admin/carousel-order` | `{ids}` en el orden deseado; deben ser todas las diapositivas |
| PUT | `/admin/services/{id}/images` | `{image_ids}` en orden; la primera es la portada |

Cada imagen se entrega lista para `<img>`: `{id, alt, width, height, src, srcset}`.
`src` es la variante de hasta 1600 px; `srcset` incluye 480, 960, 1600 y 2400 px
(las que no superan el original). Los servicios traen `gallery`.

`cta_url` acepta rutas del sitio (`/services/premium`) o direcciones `https://`;
se rechazan `javascript:`, `data:`, `//otro-sitio` y `http://`. El botón necesita
texto y enlace, o ninguno.

Errores de subida: `INVALID_IMAGE` (422, con el motivo en `fields.file`),
`FILE_TOO_LARGE` (413).

## Panel e informes (Fase 8)

| Método | Ruta | Permiso | Descripción |
|---|---|---|---|
| GET | `/admin/dashboard` | `dashboard:view` | Indicadores por área según los permisos: `operations` (`reservations:read`), `finance` (`payments:read`), `fleet` (`vehicles:read`), `drivers` (`drivers:read`); las demás vienen en `null`. `alerts`: acciones pendientes con enlace |
| GET | `/admin/reports/reservations` | `reports:read` | `date_from`, `date_to`, `group` (`day` \| `week` \| `month`), `basis` (`pickup`: fecha del viaje; `created`: fecha de la reserva) |
| GET | `/admin/reports/revenue` | `reports:financial` | `date_from`, `date_to`, `group`. Criterio de caja: cobros por fecha de autorización, reembolsos por fecha de reembolso |
| GET | `/admin/reports/reservations.csv`, `/admin/reports/revenue.csv` | Igual que arriba | CSV para Excel en español |

Rango máximo: 92 días por día, 366 por semana, 1100 por mes. La serie trae todos
los periodos del rango, también los que no tienen actividad (en cero). Las
semanas empiezan el lunes. Todo se agrupa en la zona horaria del negocio.

Alertas (`kind`): `unassigned` (confirmadas de las próximas 48 horas sin
vehículo o conductor), `failed_refunds`, `no_vehicles` (servicio activo sin
vehículos), `license` (licencias vencidas o que vencen en 30 días).

`finance.change` compara el neto del mes con el mismo tramo del mes anterior
(del 1 al mismo día), para que la comparación sea pareja.

## Seguridad de la cuenta (Fase 9)

### Inicio de sesión con verificación en dos pasos

Si la cuenta la tiene activa, `POST /auth/login` responde (con contraseña
correcta) `{mfa_required: true, mfa_token, expires_in}` en vez de los tokens. El
`mfa_token` dura 5 minutos y sólo sirve para el paso siguiente:

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/auth/mfa` | `{mfa_token, code}`: código de 6 dígitos o código de respaldo (`xxxx-xxxx`) → tokens. 5 intentos por permiso temporal |

Errores: `INVALID_MFA_CODE` (código incorrecto o ya usado), `MFA_TOKEN_INVALID`
(vencido o de otro tipo).

**Bloqueo progresivo:** 5, 10 y 15 intentos fallidos de contraseña sobre una
misma cuenta (desde cualquier IP) la bloquean 1, 15 y 60 minutos
(`429 ACCOUNT_LOCKED` con `Retry-After`). Igual para cuentas inexistentes.

### Gestión de la verificación en dos pasos

| Método | Ruta | Descripción |
|---|---|---|
| POST | `/users/me/mfa/setup` | `{current_password}` → `{secret, otpauth_uri}` (aún no activa) |
| POST | `/users/me/mfa/enable` | `{code}` → `{backup_codes}` (10, se muestran una vez) |
| POST | `/users/me/mfa/backup-codes` | `{code}` → códigos nuevos; los anteriores dejan de servir |
| POST | `/users/me/mfa/disable` | `{current_password, code}`. `409 MFA_REQUIRED_FOR_STAFF` si se exige al personal |
| POST | `/users/{id}/mfa/reset` | `users:write`. Para quien perdió el teléfono y los códigos; cierra sus sesiones |

Con `REQUIRE_STAFF_MFA=true`, los endpoints protegidos por permiso responden
`403 MFA_REQUIRED` al personal sin verificación activa. `GET /auth/me` incluye
`mfa_enabled`, `mfa_setup_required` y `mfa_backup_codes_left`.

### Derechos del titular (Ley 21.719)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/users/me/export` | Todos los datos de la cuenta en JSON (acceso y portabilidad) |
| POST | `/users/me/delete` | `{current_password, confirmation: "ELIMINAR"}`. Sólo clientes. `409 ACTIVE_RESERVATIONS` si hay reservas pendientes o en curso |

## Idiomas (fase 11)

La API responde en el idioma de la cabecera `Accept-Language` (es, en, fr, ht, zh; otro o
ninguno: español): mensajes de error y validación, desglose de precio, política de
cancelación, alertas del panel, historial de reservas y etiquetas de los reportes. El sitio la
envía en cada llamada.

- `GET /auth/me` incluye `locale` (o `null` si la persona nunca eligió); `PATCH /users/me`
  acepta `{"locale": "ht"}`.
- Servicios, reglas de precio y diapositivas aceptan `translations`:
  `{"en": {"name": "…", "tagline": "…"}, "fr": {…}}`. Las respuestas públicas vienen ya en el
  idioma pedido; las del panel traen el texto base y `translations`.
- `GET /roles` trae `name` y `description` originales (para editarlos) y `display_name` y
  `display_description` traducidos (para mostrarlos).
- El CSV de los reportes usa el separador y los decimales que espera Excel en ese idioma.

## Sitio y comprobantes (fase 12)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/site` | Datos públicos de la empresa: nombre, contacto, `whatsapp_url`, redes; descripción y horario en el idioma pedido |
| GET / PUT | `/admin/site` | Datos de la empresa con traducciones (`settings:write`). Redes sólo `https://`; RUT validado |
| GET | `/reservations/{code}/receipt` | Comprobante en PDF de una reserva propia (`inline`) |
| GET | `/admin/reservations/{id}/receipt` | Comprobante en PDF desde el panel (`reservations:read`) |

El PDF sale en el idioma de `Accept-Language`. Necesita las tipografías WenQuanYi Micro Hei y
DejaVu Sans (`fonts-wqy-microhei`, `fonts-dejavu-core`; ya incluidas en la imagen Docker).

## Reseñas (fase 13)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/reservations/{code}/review` | Si se puede calificar (`eligible`, `deadline`, `has_driver`) y la reseña propia |
| POST | `/reservations/{code}/review` | `{service_rating, driver_rating?, comment?, consent_publish}` (1 a 5). `409 NOT_REVIEWABLE` o `ALREADY_REVIEWED` |
| GET | `/reviews?service=premium&limit=6` | Comentarios publicados (autorizados y revisados) |
| GET | `/admin/reviews?status=PENDING` | Para moderar (`content:write`); `pending` = cantidad por revisar |
| POST | `/admin/reviews/{id}/moderate` | `{action: "publish" \| "hide"}`, con auditoría |

Los servicios públicos traen `rating: {average, count}`, calculado con **todas** las
calificaciones (también las de comentarios ocultos). Los conductores del panel traen
`rating_average` y `rating_count`.

## Billetera (fase 14)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/wallet` | Saldo, movimientos (detalle en el idioma pedido) y configuración de recarga |
| POST | `/reservations/{code}/pay-with-wallet` | Paga el total con saldo. `409 INSUFFICIENT_BALANCE` si no alcanza |
| POST | `/wallet/topups` | `{amount}` → redirección a la pasarela. `409 TOPUP_DISABLED` mientras esté desactivada |
| GET | `/admin/users/{id}/wallet` | Billetera de un cliente (`payments:read`) |
| POST | `/admin/users/{id}/wallet/credits` | `{amount, reason}` (`payments:refund`), con auditoría |

`POST /payments/return` incluye `topup: true` cuando el pago era una recarga. En
`/admin/payments`, las recargas traen `is_topup: true` y `reservation_code: null`.

Un pago pertenece a una reserva **o** a una billetera (restricción `ck_payments_one_target`). Los
movimientos (`wallet_entries`) son inmutables (trigger) y el saldo se actualiza con una sola
instrucción atómica (`UPDATE … WHERE balance + monto >= 0 RETURNING balance`).

## Chat entre cliente y chófer (fase 15)

| Método | Ruta | Descripción |
|---|---|---|
| GET / POST | `/reservations/{code}/messages` | Cliente: leer (marca como leídos los recibidos) y enviar `{body}` |
| GET / POST | `/driver/trips/{id}/messages` | Chófer: lo mismo, sólo en sus viajes |
| GET | `/admin/reservations/{id}/messages` | Personal (`reservations:read`): sólo lectura, sin marcar como leído |

La respuesta trae `open`, `closes_at`, `counterpart` (nombre de pila del otro) y `messages`
(`mine`, `sender_role`, `body`, `created_at`, `read`). Abierto con chófer asignado desde que se
confirma hasta 2 horas después del término (`409 CHAT_CLOSED` fuera de ese plazo). Hasta 1.000
caracteres por mensaje y 20 mensajes por minuto. `GET /driver/trips` incluye `unread_messages`.

En el sitio, el navegador usa `/account/reservations/{code}/messages` y
`/driver/trips/{id}/messages`, que agregan la sesión y rechazan envíos de otro origen (CSRF).

`GET /wallet` y `GET /admin/users/{id}/wallet` incluyen `number` (`LP-4821-7730`: 7 dígitos y uno de
verificación con el algoritmo de Luhn) y `holder` (nombre del titular). `GET /users?q=` encuentra al
cliente por ese número, con o sin guiones; un número con el dígito de verificación equivocado no
encuentra a nadie.

## Monedas (fase 16)

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/currencies` | Tasas vigentes (pesos por 1 unidad) de USD, EUR y BRL, su origen (`auto`, `manual`) y la atribución |
| GET | `/admin/currencies` | Tasas automáticas y manuales (`settings:write`) |
| PUT | `/admin/currencies/{code}` | `{manual_rate}` o `null` para volver a la automática. `RATE_OUT_OF_RANGE` si no es razonable |
| POST | `/admin/currencies/refresh` | Pide las tasas a la fuente. `502 RATES_UNAVAILABLE` si no responde (quedan las anteriores) |

El worker las actualiza cada día (`refresh_exchange_rates`). Fuente: `EXCHANGE_RATE_URL`
(por defecto, el acceso abierto de ExchangeRate-API, que exige atribución).
