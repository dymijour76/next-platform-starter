#!/bin/sh
# Respaldo de PostgreSQL con rotación, verificación y copia opcional fuera del servidor.
#
# Guarda en $BACKUP_DIR (por defecto /backups):
#   daily/   los últimos 7 días
#   weekly/  los últimos 4 domingos
#   monthly/ los últimos 6 días 1 de mes
# Variables: PGHOST, PGUSER, PGPASSWORD, PGDATABASE (las de libpq).
# Opcionales: BACKUP_S3_BUCKET (+ S3_ENDPOINT_URL, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY),
#             BACKUP_PING_URL (se visita sólo si todo salió bien: aviso si un día no llega).
set -eu

DIR="${BACKUP_DIR:-/backups}"
STAMP="$(date +%Y%m%d-%H%M)"
NAME="${PGDATABASE}-${STAMP}.dump"
mkdir -p "$DIR/daily" "$DIR/weekly" "$DIR/monthly"

echo "[respaldo] Iniciando $NAME"
# Formato "custom": comprimido y restaurable tabla por tabla. Se escribe a un
# temporal y se renombra al final: nunca queda un respaldo a medias con nombre válido.
pg_dump --format=custom --compress=6 --no-owner --file="$DIR/daily/$NAME.part"
# Verificación: el índice del archivo se puede leer entero.
pg_restore --list "$DIR/daily/$NAME.part" > /dev/null
mv "$DIR/daily/$NAME.part" "$DIR/daily/$NAME"
SIZE="$(du -h "$DIR/daily/$NAME" | cut -f1)"

[ "$(date +%u)" = "7" ] && cp "$DIR/daily/$NAME" "$DIR/weekly/"
[ "$(date +%d)" = "01" ] && cp "$DIR/daily/$NAME" "$DIR/monthly/"

# Rotación: se conservan los más recientes de cada carpeta.
# Los nombres los genera este script (sin espacios): ls -t es seguro aquí.
# shellcheck disable=SC2012
prune() { ls -1t "$1"/*.dump 2>/dev/null | tail -n +"$(( $2 + 1 ))" | xargs -r rm -f; }
prune "$DIR/daily" 7
prune "$DIR/weekly" 4
prune "$DIR/monthly" 6

if [ -n "${BACKUP_S3_BUCKET:-}" ]; then
  ENDPOINT=""
  [ -n "${S3_ENDPOINT_URL:-}" ] && ENDPOINT="--endpoint-url $S3_ENDPOINT_URL"
  # shellcheck disable=SC2086
  aws s3 cp $ENDPOINT "$DIR/daily/$NAME" "s3://$BACKUP_S3_BUCKET/backups/$NAME" --only-show-errors
  echo "[respaldo] Copiado a s3://$BACKUP_S3_BUCKET/backups/"
fi

date -Iseconds > "$DIR/last-success"
[ -n "${BACKUP_PING_URL:-}" ] && curl -fsS -m 10 --retry 3 "$BACKUP_PING_URL" > /dev/null
echo "[respaldo] Listo: $NAME ($SIZE)"
