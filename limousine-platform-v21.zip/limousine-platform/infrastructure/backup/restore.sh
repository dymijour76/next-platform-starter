#!/bin/sh
# Restaura un respaldo sobre la base indicada. DESTRUCTIVO para esa base.
#
#   restore.sh /backups/daily/limo-20261001-0300.dump            # sobre $PGDATABASE (pide confirmación)
#   restore.sh ARCHIVO otra_base                                  # prueba de restauración en otra base
#   RESTORE_CONFIRM=si restore.sh ARCHIVO                         # sin preguntar (automatización)
set -eu

FILE="${1:?Indique el archivo de respaldo}"
TARGET="${2:-$PGDATABASE}"
[ -f "$FILE" ] || { echo "No existe: $FILE" >&2; exit 1; }
pg_restore --list "$FILE" > /dev/null || { echo "El archivo no es un respaldo válido" >&2; exit 1; }

if [ "${RESTORE_CONFIRM:-}" != "si" ]; then
  printf "Se reemplazará TODO el contenido de la base '%s'. Escriba el nombre de la base para confirmar: " "$TARGET"
  read -r answer
  [ "$answer" = "$TARGET" ] || { echo "Cancelado."; exit 1; }
fi

# La base debe existir (vacía o no): --clean reemplaza los objetos que estén en el respaldo.
psql -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname = '$TARGET'" | grep -q 1 \
  || createdb "$TARGET"
pg_restore --clean --if-exists --no-owner --exit-on-error -d "$TARGET" "$FILE"
echo "Restaurado $FILE en '$TARGET'."
