#!/usr/bin/env bash
# Despliegue o actualización: construye, respalda, migra, levanta y verifica.
#   ./scripts/deploy.sh            versión = commit actual
set -euo pipefail
cd "$(dirname "$0")/.."

[ -f .env.production ] || { echo "Falta .env.production (ver scripts/generate-secrets.sh)" >&2; exit 1; }
export APP_VERSION="${APP_VERSION:-$(git rev-parse --short HEAD 2>/dev/null || date +%Y%m%d%H%M)}"
FILES=(-f docker-compose.prod.yml)
# Sitio de demostración (scripts/demo-setup.sh): imágenes en disco y Caddyfile.demo.
if grep -q '^DEMO_MODE=true' .env.production; then FILES+=(-f docker-compose.demo.yml); fi
compose() { docker compose --env-file .env.production "${FILES[@]}" "$@"; }

echo "==> Versión $APP_VERSION: construyendo imágenes"
compose build

if compose ps --status running postgres | grep -q postgres; then
  echo "==> Respaldo previo a la actualización"
  compose exec -T backup backup.sh
fi

echo "==> Base de datos y Redis"
compose up -d postgres redis

echo "==> Migraciones"
compose run --rm migrate

echo "==> Servicios"
compose up -d --remove-orphans

echo "==> Verificando"
for _ in $(seq 1 30); do
  if compose exec -T backend python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/api/v1/health/ready').status==200 else 1)" 2>/dev/null; then
    echo "API lista."
    break
  fi
  sleep 2
done
compose ps
docker image prune -f > /dev/null
DOMAIN_SET="$(grep '^DOMAIN=' .env.production | cut -d= -f2-)"
echo "==> Listo: https://$DOMAIN_SET  (vigilancia: /healthz/api y /healthz/worker)"
