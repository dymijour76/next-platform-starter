#!/usr/bin/env bash
# Crea .env.production a partir de la plantilla, con secretos aleatorios nuevos.
# No sobrescribe un .env.production existente (perder FIELD_ENCRYPTION_KEY o
# JWT_SECRET cierra sesiones e invalida la verificación en dos pasos).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ -e .env.production ]; then
  echo ".env.production ya existe: no se modifica." >&2
  exit 1
fi

rand() { openssl rand -base64 "$1" | tr -d '\n=' | tr '+/' '-_'; }
# Fernet: 32 bytes en base64 urlsafe, con relleno.
fernet() { openssl rand 32 | base64 | tr -d '\n' | tr '+/' '-_'; }

umask 077  # sólo el dueño puede leer el archivo
sed \
  -e "s|^JWT_SECRET=.*|JWT_SECRET=$(rand 48)|" \
  -e "s|^FIELD_ENCRYPTION_KEY=.*|FIELD_ENCRYPTION_KEY=$(fernet)|" \
  -e "s|^INTERNAL_PROXY_SECRET=.*|INTERNAL_PROXY_SECRET=$(rand 36)|" \
  -e "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(rand 24)|" \
  -e "s|^REDIS_PASSWORD=.*|REDIS_PASSWORD=$(rand 24)|" \
  .env.production.example > .env.production

echo "Creado .env.production (permisos 600). Complete dominio, email, Webpay, S3 y respaldos."
echo "Respalde FIELD_ENCRYPTION_KEY y JWT_SECRET en un gestor de contraseñas."
