#!/usr/bin/env bash
# Publica un sitio de DEMOSTRACIÓN en un servidor Ubuntu nuevo, para mostrarlo a un cliente.
#
#   sudo bash scripts/demo-setup.sh
#
# - Dirección con HTTPS sin comprar dominio: <ip-con-guiones>.sslip.io
# - Pagos simulados (nadie paga de verdad), emails en el registro, imágenes en el disco.
# - Datos de ejemplo (servicios, vehículos, precios) y un administrador.
# Se puede volver a ejecutar: no cambia los secretos ni borra datos.
set -euo pipefail
cd "$(dirname "$0")/.."

[ "$(id -u)" = "0" ] || { echo "Ejecute con sudo: sudo bash scripts/demo-setup.sh" >&2; exit 1; }

echo "==> 1/6 Docker"
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
fi
docker compose version >/dev/null

echo "==> 2/6 Memoria de intercambio (evita que la construcción se quede sin memoria)"
if [ "$(swapon --show | wc -l)" = "0" ]; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

echo "==> 3/6 Cortafuegos: sólo SSH, HTTP y HTTPS"
if command -v ufw >/dev/null 2>&1; then
  ufw allow 22/tcp >/dev/null; ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; ufw allow 443/udp >/dev/null
  ufw --force enable >/dev/null
fi

echo "==> 4/6 Configuración"
if [ ! -e .env.production ]; then
  IP="$(curl -fsS4 https://api.ipify.org || curl -fsS4 https://ifconfig.me)"
  DEFAULT_DOMAIN="$(echo "$IP" | tr . -).sslip.io"
  read -rp "Dirección del sitio [$DEFAULT_DOMAIN]: " DOMAIN
  DOMAIN="${DOMAIN:-$DEFAULT_DOMAIN}"
  read -rp "Su email (aviso del certificado HTTPS): " ACME_EMAIL
  read -rp "Nombre de la empresa [Lubin VIP Limo]: " COMPANY
  COMPANY="${COMPANY:-Lubin VIP Limo}"

  bash scripts/generate-secrets.sh >/dev/null
  set_var() {  # reemplaza o agrega VAR=valor
    local key="$1" value="$2"
    if grep -q "^$key=" .env.production; then
      sed -i "s|^$key=.*|$key=$value|" .env.production
    else
      echo "$key=$value" >> .env.production
    fi
  }
  set_var ENVIRONMENT staging
  set_var DEMO_MODE true
  set_var DOMAIN "$DOMAIN"
  set_var ACME_EMAIL "$ACME_EMAIL"
  set_var COMPANY_NAME "\"$COMPANY\""
  set_var FRONTEND_URL "https://$DOMAIN"
  set_var MEDIA_BASE_URL "https://$DOMAIN"
  set_var PAYMENT_PROVIDER simulated
  set_var STORAGE_BACKEND local
  set_var EMAIL_BACKEND console
  set_var REQUIRE_STAFF_MFA false
  echo "Creado .env.production (sitio: https://$DOMAIN)."
else
  echo ".env.production ya existe: se conserva."
fi

echo "==> 5/6 Construir y levantar (la primera vez tarda 10 a 20 minutos)"
chmod +x scripts/*.sh
bash scripts/deploy.sh

compose() {
  docker compose --env-file .env.production -f docker-compose.prod.yml -f docker-compose.demo.yml "$@"
}
echo "==> 6/6 Datos de ejemplo y administrador"
compose run --rm backend python -m app.cli seed-demo
if [ ! -e .admin-created ]; then
  read -rp "Email del administrador: " ADMIN_EMAIL
  compose run --rm backend python -m app.cli create-admin --email "$ADMIN_EMAIL"
  touch .admin-created
fi

DOMAIN="$(grep '^DOMAIN=' .env.production | cut -d= -f2-)"
echo
echo "Listo. Sitio de demostración: https://$DOMAIN"
echo "Panel de administración:      https://$DOMAIN/admin"
echo "Si el navegador avisa de un certificado, espere 1 o 2 minutos y recargue."
