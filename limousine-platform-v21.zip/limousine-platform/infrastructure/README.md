# infrastructure/

Producción con Docker Compose. Guía completa: `docs/DEPLOYMENT.md`; operación
diaria: `docs/OPERATIONS.md`; antes de salir en vivo: `docs/GO_LIVE.md`.

| Archivo | Qué es |
|---|---|
| `docker-compose.prod.yml` | Caddy, sitio, API, worker, PostgreSQL, Redis, respaldos y migraciones |
| `Caddyfile` | HTTPS automático, IP real del visitante y rutas de vigilancia |
| `.env.production.example` | Todas las variables de producción |
| `scripts/generate-secrets.sh` | Crea `.env.production` con secretos aleatorios |
| `scripts/deploy.sh` | Despliega o actualiza: respalda, construye, migra, levanta y verifica |
| `scripts/demo-setup.sh` | Publica un sitio de demostración en un servidor nuevo (ver `docs/DEMO.md`) |
| `docker-compose.demo.yml`, `Caddyfile.demo` | Complementos de la demo: imágenes en disco, sin indexar |
| `backup/` | Imagen de respaldos: diarios a las 03:00, rotación, verificación, S3 y aviso |
